import React from 'react';
import { Star, Trophy } from 'lucide-react';
import { Player, PlayerColor, Token, BoardThemeId, TokenStyleId } from '../types';
import { AvatarDisplay } from './AvatarDisplay';
import { VipBadge } from './VipBadge';
import { TokenPiece } from './TokenPiece';
import {
  COLOR_CONFIG,
  PERIMETER_PATH,
  START_INDICES,
  SAFE_PERIMETER_INDICES,
  HOME_PATHS,
  YARD_COORDS,
  BoardCoord,
} from '../utils/ludoConstants';
import { BOARD_THEMES } from '../utils/customizationConstants';
import { getTokenCoord } from '../utils/ludoLogic';

interface LudoBoardProps {
  players: Player[];
  currentTurnColor: PlayerColor;
  eligibleTokenIds: number[];
  onTokenClick: (tokenId: number) => void;
  hasRolled: boolean;
  diceValue: number | null;
  boardTheme?: BoardThemeId;
  tokenStyle?: TokenStyleId;
}

export const LudoBoard: React.FC<LudoBoardProps> = ({
  players,
  currentTurnColor,
  eligibleTokenIds,
  onTokenClick,
  hasRolled,
  boardTheme = 'classic',
  tokenStyle = 'classic',
}) => {
  const themeDef = BOARD_THEMES.find((t) => t.id === boardTheme) || BOARD_THEMES[0];
  // Collect all tokens with their board coordinates
  const tokensOnBoard: { token: Token; player: Player; coord: BoardCoord; isEligible: boolean }[] = [];

  players.forEach((player) => {
    if (!player || !player.tokens) return;
    const playerColor = player.color || 'red';
    player.tokens.forEach((rawToken) => {
      const token: Token = {
        ...rawToken,
        color: rawToken.color || playerColor,
      };
      const coord = getTokenCoord(token);
      const isEligible =
        player.color === currentTurnColor &&
        hasRolled &&
        eligibleTokenIds.includes(token.id);

      tokensOnBoard.push({
        token,
        player,
        coord,
        isEligible,
      });
    });
  });

  // Group tokens by (r, c) to display clusters/stacks nicely
  const tokenGroups = new Map<string, typeof tokensOnBoard>();
  tokensOnBoard.forEach((item) => {
    const key = `${item.coord.r}_${item.coord.c}`;
    if (!tokenGroups.has(key)) {
      tokenGroups.set(key, []);
    }
    tokenGroups.get(key)!.push(item);
  });

  // Check if a cell is a safe star cell
  const isStarCell = (r: number, c: number) => {
    return SAFE_PERIMETER_INDICES.some((idx) => {
      const p = PERIMETER_PATH[idx];
      return p.r === r && p.c === c;
    });
  };

  // Check if a cell is a colored home lane cell
  const getHomeLaneColor = (r: number, c: number): PlayerColor | null => {
    // Red home lane: col 7, rows 9..13
    if (c === 7 && r >= 9 && r <= 13) return 'red';
    // Green home lane: row 7, cols 1..5
    if (r === 7 && c >= 1 && c <= 5) return 'green';
    // Yellow home lane: col 7, rows 1..5
    if (c === 7 && r >= 1 && r <= 5) return 'yellow';
    // Blue home lane: row 7, cols 9..13
    if (r === 7 && c >= 9 && c <= 13) return 'blue';
    return null;
  };

  // Check if a cell is a colored start cell
  const getStartCellColor = (r: number, c: number): PlayerColor | null => {
    const colors: PlayerColor[] = ['red', 'green', 'yellow', 'blue'];
    for (const clr of colors) {
      const startCoord = PERIMETER_PATH[START_INDICES[clr]];
      if (startCoord.r === r && startCoord.c === c) return clr;
    }
    return null;
  };

  // Render individual 15x15 track cells (outside yards and center home)
  const renderCell = (r: number, c: number) => {
    // Is this inside Green Yard (0..5, 0..5)? Handled by Yard block
    if (r <= 5 && c <= 5) return null;
    // Inside Yellow Yard (0..5, 9..14)?
    if (r <= 5 && c >= 9) return null;
    // Inside Red Yard (9..14, 0..5)?
    if (r >= 9 && c <= 5) return null;
    // Inside Blue Yard (9..14, 9..14)?
    if (r >= 9 && c >= 9) return null;
    // Inside Center Home (6..8, 6..8)? Handled by Center Home block
    if (r >= 6 && r <= 8 && c >= 6 && c <= 8) return null;

    const homeColor = getHomeLaneColor(r, c);
    const startColor = getStartCellColor(r, c);
    const isStar = isStarCell(r, c);

    let cellBg = themeDef.trackCellBg;
    let cellBorder = themeDef.trackCellBorder;
    let textColor = themeDef.trackCellText;
    let arrowIndicator = null;

    if (homeColor) {
      const hl = themeDef.homeLanes[homeColor];
      cellBg = `${hl.bg} ${hl.text}`;
      cellBorder = hl.border;
    } else if (startColor) {
      const sc = themeDef.startCells[startColor];
      cellBg = sc.bg;
      cellBorder = sc.border;
      textColor = sc.text;
      if (startColor === 'red') arrowIndicator = '▲';
      else if (startColor === 'green') arrowIndicator = '▶';
      else if (startColor === 'yellow') arrowIndicator = '▼';
      else if (startColor === 'blue') arrowIndicator = '◀';
    }

    const key = `${r}_${c}`;
    const tokensHere = tokenGroups.get(key) || [];

    return (
      <div
        key={key}
        style={{ gridRow: r + 1, gridColumn: c + 1 }}
        className={`relative w-full h-full border ${cellBorder} ${cellBg} flex items-center justify-center select-none`}
      >
        {/* Star Icon for Safe spots */}
        {isStar && (
          <div className="absolute inset-0 flex items-center justify-center opacity-85">
            <Star
              className="w-3.5 h-3.5 sm:w-4 sm:h-4 drop-shadow-sm"
              style={{
                color: themeDef.safeStarColor,
                fill: themeDef.safeStarFill,
              }}
              strokeWidth={1.5}
            />
          </div>
        )}

        {/* Direction arrow on start cells */}
        {arrowIndicator && !isStar && (
          <span className={`text-[10px] sm:text-xs font-black opacity-40 select-none ${textColor}`}>
            {arrowIndicator}
          </span>
        )}

        {/* Tokens rendered on this track cell */}
        {renderTokensAtCell(tokensHere)}
      </div>
    );
  };

  // Render tokens stacked or clustered on a cell
  const renderTokensAtCell = (tokens: (typeof tokensOnBoard)[number][]) => {
    if (tokens.length === 0) return null;

    if (tokens.length === 1) {
      const item = tokens[0];
      return renderSingleToken(item);
    }

    // Multiple tokens stacked on same cell
    return (
      <div className="relative w-full h-full flex items-center justify-center">
        {tokens.map((item, idx) => {
          const offset = (idx - (tokens.length - 1) / 2) * 4;
          return (
            <div
              key={`${item.player.color}_${item.token.id}`}
              style={{
                transform: `translate(${offset}px, ${offset}px)`,
                zIndex: item.isEligible ? 40 : 10 + idx,
              }}
              className="absolute"
            >
              {renderSingleToken(item, true)}
            </div>
          );
        })}
        <span className="absolute -top-1 -right-1 z-30 bg-slate-950 text-white text-[9px] font-black px-1 rounded-full border border-amber-400 shadow-md">
          {tokens.length}
        </span>
      </div>
    );
  };

  const renderSingleToken = (
    item: (typeof tokensOnBoard)[number],
    isStacked: boolean = false
  ) => {
    const tokenColor = item.player?.color || 'red';
    const colorCfg = (tokenColor && COLOR_CONFIG[tokenColor]) || COLOR_CONFIG.red;
    return (
      <TokenPiece
        key={`${tokenColor}_${item.token.id}`}
        color={tokenColor}
        styleId={tokenStyle}
        size={isStacked ? 'sm' : 'md'}
        isEligible={item.isEligible}
        onClick={() => item.isEligible && onTokenClick(item.token.id)}
        title={`${colorCfg.name} Token ${item.token.id + 1} ${
          item.isEligible ? '(Click to move)' : ''
        }`}
      />
    );
  };

  // Render a player's Home Yard (Base)
  const renderYard = (color: PlayerColor) => {
    const config = (color && COLOR_CONFIG[color]) || COLOR_CONFIG.red;
    const yardTheme = (themeDef.yardBgs && themeDef.yardBgs[color]) || {
      bg: '#fff',
      border: '#e2e8f0',
      text: '#1e293b',
      dockBg: 'bg-slate-50',
      dockBorder: 'border-slate-300',
    };
    const player = players.find((p) => p.color === color);
    const yardSlots = YARD_COORDS[color] || [];

    let gridArea = '';
    if (color === 'green') gridArea = '1 / 1 / 7 / 7';
    if (color === 'yellow') gridArea = '1 / 10 / 7 / 16';
    if (color === 'red') gridArea = '10 / 1 / 16 / 7';
    if (color === 'blue') gridArea = '10 / 10 / 16 / 16';

    return (
      <div
        key={`yard_${color}`}
        className="relative p-2 sm:p-3 flex flex-col justify-between rounded-2xl shadow-inner border-2 select-none"
        style={{
          gridArea,
          backgroundColor: yardTheme.bg,
          borderColor: yardTheme.border,
        }}
      >
        {/* Yard Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5 min-w-0">
            {player?.avatar ? (
              <AvatarDisplay avatar={player.avatar} size={28} vipFrameId={player.vipFrameId} />
            ) : (
              <span className="text-base sm:text-lg">{config.avatar}</span>
            )}
            <span
              className="text-xs sm:text-sm font-black tracking-wide truncate max-w-[75px]"
              style={{ color: yardTheme.text }}
            >
              {player?.name || config.name}
            </span>
            {player?.isVip && (
              <VipBadge badgeId={player.vipBadge || 'vip_crown'} size="sm" showText={false} />
            )}
          </div>
          <span
            className="text-[10px] font-bold px-1.5 py-0.5 rounded-full text-white shadow-xs shrink-0"
            style={{ backgroundColor: yardTheme.border }}
          >
            {color === currentTurnColor ? 'Active Turn' : config.name}
          </span>
        </div>

        {/* 4 Yard Docks for Tokens */}
        <div
          className={`grid grid-cols-2 gap-2 sm:gap-3 p-2 rounded-xl shadow-sm border ${yardTheme.dockBorder} my-auto`}
          style={{ backgroundColor: boardTheme === 'neon' ? '#0d1527' : 'rgba(255,255,255,0.85)' }}
        >
          {yardSlots.map((coord, idx) => {
            const token = player?.tokens[idx];
            const isYard = token?.step === -1;
            const isEligible =
              color === currentTurnColor &&
              hasRolled &&
              token &&
              eligibleTokenIds.includes(token.id);

            return (
              <div
                key={`yard_slot_${color}_${idx}`}
                className={`w-8 h-8 sm:w-10 sm:h-10 mx-auto rounded-full ${yardTheme.dockBg} border-2 border-dashed ${yardTheme.dockBorder} flex items-center justify-center shadow-inner`}
              >
                {isYard && token && (
                  <TokenPiece
                    color={color}
                    styleId={tokenStyle}
                    size="lg"
                    isEligible={isEligible}
                    onClick={() => isEligible && onTokenClick(token.id)}
                    title={`${config.name} Token ${token.id + 1} (Roll 6 to exit)`}
                  />
                )}
              </div>
            );
          })}
        </div>

        {/* Finished count info */}
        <div
          className="text-center text-[10px] font-extrabold"
          style={{ color: yardTheme.text }}
        >
          Finished:{' '}
          {player?.tokens.filter((t) => t.isHome).length || 0} / 4
        </div>
      </div>
    );
  };

  // Render Central Home (Triangles)
  const renderCenterHome = () => {
    return (
      <div
        key="center-home"
        style={{ gridArea: '7 / 7 / 10 / 10' }}
        className={`relative w-full h-full ${themeDef.centerHome.bgClass} ${themeDef.centerHome.borderClass} overflow-hidden shadow-2xl flex items-center justify-center select-none`}
      >
        {/* SVG Triangles meeting in center */}
        <svg
          viewBox="0 0 100 100"
          className="absolute inset-0 w-full h-full pointer-events-none"
        >
          {/* Top Triangle: Yellow */}
          <polygon points="0,0 100,0 50,50" fill={COLOR_CONFIG.yellow.hex} opacity={themeDef.centerHome.triangleOpacity} />
          {/* Left Triangle: Green */}
          <polygon points="0,0 0,100 50,50" fill={COLOR_CONFIG.green.hex} opacity={themeDef.centerHome.triangleOpacity} />
          {/* Right Triangle: Blue */}
          <polygon points="100,0 100,100 50,50" fill={COLOR_CONFIG.blue.hex} opacity={themeDef.centerHome.triangleOpacity} />
          {/* Bottom Triangle: Red */}
          <polygon points="0,100 100,100 50,50" fill={COLOR_CONFIG.red.hex} opacity={themeDef.centerHome.triangleOpacity} />
        </svg>

        {/* Center Victory Badge */}
        <div
          className={`relative z-10 w-9 h-9 sm:w-11 sm:h-11 rounded-full ${themeDef.centerHome.centerBadgeClass} shadow-xl border-2 flex flex-col items-center justify-center animate-pulse`}
        >
          <Trophy className="w-4 h-4 sm:w-5 sm:h-5" />
          <span className="text-[8px] sm:text-[9px] font-black tracking-tight leading-none">
            HOME
          </span>
        </div>

        {/* Floating counters of reached tokens */}
        <div className="absolute top-1 left-1/2 -translate-x-1/2 text-[9px] font-bold text-amber-950 bg-amber-300/90 px-1 rounded-sm shadow-sm">
          {players.find((p) => p.color === 'yellow')?.tokens.filter((t) => t.isHome).length || 0}
        </div>
        <div className="absolute bottom-1 left-1/2 -translate-x-1/2 text-[9px] font-bold text-white bg-rose-700/90 px-1 rounded-sm shadow-sm">
          {players.find((p) => p.color === 'red')?.tokens.filter((t) => t.isHome).length || 0}
        </div>
        <div className="absolute left-1 top-1/2 -translate-y-1/2 text-[9px] font-bold text-white bg-emerald-700/90 px-1 rounded-sm shadow-sm">
          {players.find((p) => p.color === 'green')?.tokens.filter((t) => t.isHome).length || 0}
        </div>
        <div className="absolute right-1 top-1/2 -translate-y-1/2 text-[9px] font-bold text-white bg-blue-700/90 px-1 rounded-sm shadow-sm">
          {players.find((p) => p.color === 'blue')?.tokens.filter((t) => t.isHome).length || 0}
        </div>
      </div>
    );
  };

  // Generate 15x15 grid cells
  const gridCells = [];
  for (let r = 0; r < 15; r++) {
    for (let c = 0; c < 15; c++) {
      const cell = renderCell(r, c);
      if (cell) gridCells.push(cell);
    }
  }

  return (
    <div
      id="ludo-board-outer-frame"
      className={`relative w-full max-w-[560px] aspect-square mx-auto p-2 sm:p-3.5 rounded-3xl transition-all duration-300 flex items-center justify-center ${themeDef.outerFrameClass}`}
    >
      {/* 15x15 Grid Board */}
      <div
        className={`w-full h-full grid grid-cols-15 grid-rows-15 rounded-2xl overflow-hidden ${themeDef.gridBorderClass}`}
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(15, minmax(0, 1fr))',
          gridTemplateRows: 'repeat(15, minmax(0, 1fr))',
        }}
      >
        {/* 4 Corner Yards */}
        {renderYard('green')}
        {renderYard('yellow')}
        {renderYard('red')}
        {renderYard('blue')}

        {/* Central Home */}
        {renderCenterHome()}

        {/* Track Cells */}
        {gridCells}
      </div>
    </div>
  );
};
