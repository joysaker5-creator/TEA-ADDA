import React, { useState, useRef, useEffect } from 'react';
import { ChevronDown, Search, Globe, Check } from 'lucide-react';
import { CountryInfo, COUNTRIES_195 } from '../utils/countryData';

interface CountryPickerProps {
  selectedCountry: CountryInfo;
  onSelectCountry: (country: CountryInfo) => void;
  disabled?: boolean;
}

export const CountryPicker: React.FC<CountryPickerProps> = ({
  selectedCountry,
  onSelectCountry,
  disabled = false,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const dropdownRef = useRef<HTMLDivElement>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      // Auto focus search input when opened
      setTimeout(() => searchInputRef.current?.focus(), 50);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen]);

  // Filter countries by search query
  const query = searchQuery.trim().toLowerCase();
  const filteredCountries = COUNTRIES_195.filter((c) => {
    if (!query) return true;
    return (
      c.name.toLowerCase().includes(query) ||
      c.nameBn.toLowerCase().includes(query) ||
      c.dialCode.includes(query) ||
      c.code.toLowerCase().includes(query)
    );
  });

  const popularCountries = COUNTRIES_195.filter((c) => c.popular);

  return (
    <div className="relative inline-block" ref={dropdownRef}>
      {/* Country Selector Trigger Button */}
      <button
        type="button"
        id="country-picker-trigger"
        onClick={() => !disabled && setIsOpen(!isOpen)}
        disabled={disabled}
        className="flex items-center gap-1.5 px-2.5 py-2 sm:py-2.5 bg-amber-100/90 hover:bg-amber-200/90 border-2 border-amber-300 rounded-2xl text-xs font-bold text-amber-950 transition-all active:scale-95 disabled:opacity-60 cursor-pointer shrink-0 shadow-sm"
        title="দেশ ও ডায়াল কোড পরিবর্তন করুন (১৯৫ টি দেশ সমর্থিত)"
      >
        <span className="text-base leading-none">{selectedCountry.flag}</span>
        <span className="font-mono font-extrabold text-[12px]">{selectedCountry.dialCode}</span>
        <ChevronDown className={`w-3 h-3 text-amber-800 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      {/* Country Dropdown Menu */}
      {isOpen && (
        <div className="absolute left-0 top-full mt-1.5 z-50 w-72 sm:w-80 bg-white border-2 border-amber-400 rounded-2xl shadow-2xl overflow-hidden flex flex-col text-slate-900 animate-fade-in max-h-80">
          {/* Header & Search */}
          <div className="p-2.5 bg-gradient-to-r from-amber-500 to-orange-500 text-white shrink-0 space-y-1.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5 text-xs font-bold">
                <Globe className="w-3.5 h-3.5" />
                <span>দেশ নির্বাচন করুন (১৯৫টি দেশ)</span>
              </div>
              <span className="text-[10px] bg-white/20 px-1.5 py-0.5 rounded-full font-bold">
                VPN ছাড়া সক্রিয় 🌐
              </span>
            </div>

            {/* Search Input */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-amber-700 absolute left-2.5 top-1/2 -translate-y-1/2" />
              <input
                ref={searchInputRef}
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="দেশের নাম বা ডায়াল কোড খুঁজুন (উদা: +966, দুবাই)..."
                className="w-full pl-8 pr-3 py-1.5 bg-white text-slate-900 placeholder:text-slate-400 rounded-xl text-xs font-semibold focus:outline-none border border-amber-300"
              />
            </div>
          </div>

          {/* Country List */}
          <div className="overflow-y-auto p-1.5 space-y-1 max-h-60 scrollbar-thin">
            {!searchQuery && (
              <div className="px-2 py-1 text-[10px] font-bold text-amber-800 uppercase tracking-wider bg-amber-50 rounded-lg">
                জনপ্রিয় দেশসমূহ (প্রবাসী ও প্রবাসী বাংলাদেশী)
              </div>
            )}

            {/* If no search, show popular first */}
            {!searchQuery && (
              <div className="space-y-0.5 mb-1.5">
                {popularCountries.map((country) => {
                  const isSelected = country.code === selectedCountry.code;
                  return (
                    <button
                      key={`pop-${country.code}`}
                      type="button"
                      onClick={() => {
                        onSelectCountry(country);
                        setIsOpen(false);
                        setSearchQuery('');
                      }}
                      className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                        isSelected
                          ? 'bg-amber-500 text-white font-bold shadow-sm'
                          : 'hover:bg-amber-100/70 text-slate-800'
                      }`}
                    >
                      <div className="flex items-center gap-2 truncate">
                        <span className="text-base">{country.flag}</span>
                        <span className="truncate">{country.nameBn}</span>
                        <span className="text-[10px] opacity-75 font-normal">({country.name})</span>
                      </div>
                      <div className="flex items-center gap-1 shrink-0">
                        <span className="font-mono text-[11px] font-bold opacity-90">{country.dialCode}</span>
                        {isSelected && <Check className="w-3.5 h-3.5 ml-1" />}
                      </div>
                    </button>
                  );
                })}
              </div>
            )}

            {/* All / Filtered Countries */}
            {!searchQuery && (
              <div className="px-2 py-1 text-[10px] font-bold text-slate-500 uppercase tracking-wider bg-slate-100 rounded-lg">
                সকল দেশ (১৯৫ দেশ তালিকা)
              </div>
            )}

            {filteredCountries.length === 0 ? (
              <div className="p-4 text-center text-xs text-slate-500 font-semibold">
                কোনো দেশ পাওয়া যায়নি "{searchQuery}"
              </div>
            ) : (
              filteredCountries.map((country) => {
                const isSelected = country.code === selectedCountry.code;
                return (
                  <button
                    key={country.code}
                    type="button"
                    onClick={() => {
                      onSelectCountry(country);
                      setIsOpen(false);
                      setSearchQuery('');
                    }}
                    className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-xl text-xs font-medium transition-all ${
                      isSelected
                        ? 'bg-amber-500 text-white font-bold shadow-sm'
                        : 'hover:bg-amber-100/60 text-slate-800'
                    }`}
                  >
                    <div className="flex items-center gap-2 truncate">
                      <span className="text-base">{country.flag}</span>
                      <span className="truncate font-semibold">{country.nameBn}</span>
                      <span className="text-[10px] opacity-75 font-normal truncate">({country.name})</span>
                    </div>
                    <div className="flex items-center gap-1 shrink-0">
                      <span className="font-mono text-[11px] font-bold opacity-80">{country.dialCode}</span>
                      {isSelected && <Check className="w-3.5 h-3.5 ml-1 text-white" />}
                    </div>
                  </button>
                );
              })
            )}
          </div>

          {/* Footer note */}
          <div className="p-2 bg-amber-50 border-t border-amber-200 text-center text-[10px] text-amber-900 font-medium shrink-0">
            ✓ ১৯৫টি দেশের যেকোনো নাম্বার দিয়ে VPN ছাড়া সরাসরি ওটিপি ও লগইন
          </div>
        </div>
      )}
    </div>
  );
};
