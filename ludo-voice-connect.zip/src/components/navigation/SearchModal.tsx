import React, { useState } from 'react';
import { Search, Users, Key, Film, Play, Sparkles, X, ChevronRight, Hash } from 'lucide-react';
import { Sound } from '../../utils/soundEffects';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onJoinRoom?: (roomCode: string) => void;
  onOpenShorts?: () => void;
  onOpenAdda?: () => void;
  isEn?: boolean;
}

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  onJoinRoom,
  onOpenShorts,
  onOpenAdda,
  isEn = true,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'all' | 'rooms' | 'players' | 'reels'>('all');
  const [roomCodeInput, setRoomCodeInput] = useState('');

  if (!isOpen) return null;

  // Mock search results database
  const sampleRooms = [
    { code: 'LUDO-7842', name: isEn ? 'Dhaka Premier League 🏆' : 'ঢাকা প্রিমিয়ার লিগ 🏆', players: '3/4', entry: '500 🪙', host: 'Shakib_Pro' },
    { code: 'ADDA-9912', name: isEn ? '10-Player Voice Adda 🎙️' : '১০-প্লেয়ার লাইভ ভয়েস আড্ডা 🎙️', players: '7/10', entry: 'Free', host: 'Nusrat_Voice' },
    { code: 'QUICK-3301', name: isEn ? '2-Player Fast Battle ⚡' : '২-প্লেয়ার ফাস্ট ব্যাটল ⚡', players: '1/2', entry: '1000 🪙', host: 'Rakib_BD' },
  ];

  const samplePlayers = [
    { id: 'usr-901', name: isEn ? 'Tanvir Ahmed' : 'তানভীর আহমেদ', level: 24, badge: '👑 VIP Pro', winRate: '72%' },
    { id: 'usr-902', name: isEn ? 'Fariha Islam' : 'ফারিহা ইসলাম', level: 18, badge: isEn ? '⭐ Star Player' : '⭐ স্টার প্লেয়ার', winRate: '68%' },
    { id: 'usr-903', name: isEn ? 'Shakib 72' : 'সাকিব ৭২', level: 35, badge: isEn ? '🏆 Master League' : '🏆 মাস্টার লিগ', winRate: '81%' },
  ];

  const sampleReels = [
    { id: 'reel-1', title: isEn ? 'Rolled a 6 at the last moment for an epic win! 🎲' : 'লাস্ট মোমেন্টে ৬ ফেলে অবিশ্বাস্য ম্যাচ উইন! 🎲', views: '24.5K', creator: 'Joy_Ludo' },
    { id: 'reel-2', title: isEn ? 'Incredible capture trick on green token 🤣' : 'সবুজ গুটি কাটার এমন টেকনিক কখনো দেখেননি 🤣', views: '18.2K', creator: 'LudoMaster_BD' },
  ];

  const handleJoinByCode = (e: React.FormEvent) => {
    e.preventDefault();
    if (!roomCodeInput.trim()) return;
    Sound.playClick();
    if (onJoinRoom) {
      onJoinRoom(roomCodeInput.trim().toUpperCase());
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 animate-fade-in">
      <div className="w-full max-w-xl bg-slate-950 border-2 border-slate-700 rounded-3xl p-5 sm:p-6 text-white shadow-2xl space-y-4 max-h-[85vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-black border border-white/20 flex items-center justify-center text-white">
              <Search className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-black text-white">
                {isEn ? 'Search Hub' : 'সার্চ (Search Hub)'}
              </h3>
              <p className="text-[11px] text-slate-400">
                {isEn ? 'Search rooms, players, or reels videos' : 'রুম কোড, প্লেয়ার্স বা রিলস ভিডিও সার্চ করুন'}
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              Sound.playClick();
              onClose();
            }}
            className="w-8 h-8 rounded-full bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center cursor-pointer border border-slate-700"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Search Input */}
        <div className="relative">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={isEn ? 'Search player name, ID or videos...' : 'প্লেয়ারের নাম, আইডি বা ভিডিও খুঁজুন...'}
            className="w-full pl-10 pr-4 py-2.5 bg-slate-900 border border-slate-700 rounded-2xl text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-400 transition-all"
            autoFocus
          />
        </div>

        {/* Quick Room Code Join Form */}
        <form onSubmit={handleJoinByCode} className="flex gap-2 p-2.5 bg-slate-900/90 rounded-2xl border border-slate-800 items-center">
          <div className="flex items-center gap-1.5 text-xs text-amber-300 font-bold px-2 shrink-0">
            <Key className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{isEn ? 'Room Code:' : 'রুম কোড:'}</span>
          </div>
          <input
            type="text"
            value={roomCodeInput}
            onChange={(e) => setRoomCodeInput(e.target.value.toUpperCase())}
            placeholder={isEn ? 'e.g. LUDO-7842' : 'যেমন: LUDO-7842'}
            className="flex-1 px-3 py-1.5 bg-black border border-slate-700 rounded-xl text-xs font-mono uppercase text-white focus:outline-none focus:border-amber-400"
          />
          <button
            type="submit"
            className="px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs cursor-pointer shadow-md"
          >
            {isEn ? 'Join' : 'যোগ দিন'}
          </button>
        </form>

        {/* Tabs */}
        <div className="flex gap-1.5 border-b border-slate-800 pb-2 overflow-x-auto">
          {[
            { id: 'all', label: isEn ? '🔍 All Results' : '🔍 সব ফলাফল' },
            { id: 'rooms', label: isEn ? '🎲 Custom Rooms' : '🎲 কাস্টম রুম' },
            { id: 'players', label: isEn ? '👥 Players' : '👥 প্লেয়ার্স' },
            { id: 'reels', label: isEn ? '🎬 Reels Shorts' : '🎬 রিলস শর্টস' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => {
                Sound.playButtonTick();
                setActiveTab(tab.id as any);
              }}
              className={`px-3 py-1 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                activeTab === tab.id
                  ? 'bg-white text-slate-950 font-black shadow-md'
                  : 'bg-slate-900 text-slate-400 hover:text-white'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Results Body */}
        <div className="flex-1 overflow-y-auto space-y-3 pr-1 max-h-[300px]">
          {/* Rooms */}
          {(activeTab === 'all' || activeTab === 'rooms') && (
            <div className="space-y-1.5">
              <span className="text-[11px] font-black text-amber-300 uppercase tracking-wider block">
                {isEn ? 'Active Custom Rooms' : 'চলমান কাস্টম রুমসমূহ'}
              </span>
              {sampleRooms.map((room) => (
                <div
                  key={room.code}
                  className="p-2.5 rounded-2xl bg-slate-900 hover:bg-slate-850 border border-slate-800 flex items-center justify-between transition-all"
                >
                  <div>
                    <p className="text-xs font-bold text-white flex items-center gap-1.5">
                      <span>{room.name}</span>
                      <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-800 text-amber-300 font-mono">
                        {room.code}
                      </span>
                    </p>
                    <p className="text-[10px] text-slate-400">
                      {isEn ? 'Host' : 'হোস্ট'}: {room.host} • {isEn ? 'Entry' : 'এন্ট্রি'}: {room.entry}
                    </p>
                  </div>
                  <button
                    onClick={() => {
                      Sound.playClick();
                      if (onJoinRoom) onJoinRoom(room.code);
                      onClose();
                    }}
                    className="px-3 py-1 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold cursor-pointer"
                  >
                    {isEn ? 'Join' : 'জয়েন'} ({room.players})
                  </button>
                </div>
              ))}
            </div>
          )}

          {/* Players */}
          {(activeTab === 'all' || activeTab === 'players') && (
            <div className="space-y-1.5">
              <span className="text-[11px] font-black text-cyan-300 uppercase tracking-wider block">
                {isEn ? 'Online Players' : 'অনলাইন প্লেয়ার্স'}
              </span>
              {samplePlayers.map((ply) => (
                <div
                  key={ply.id}
                  className="p-2.5 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between"
                >
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-full bg-cyan-500/20 border border-cyan-400 flex items-center justify-center text-xs font-bold text-cyan-300">
                      {ply.name ? ply.name.charAt(0) : 'P'}
                    </div>
                    <div>
                      <p className="text-xs font-bold text-white">{ply.name}</p>
                      <p className="text-[10px] text-slate-400">
                        {isEn ? 'Level' : 'লেভেল'} {ply.level} • {ply.badge}
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={() => {
                      Sound.playClick();
                      alert(isEn ? `Game invite sent to ${ply.name}!` : `${ply.name}-কে খেলার আমন্ত্রণ পাঠানো হয়েছে!`);
                    }}
                    className="px-2.5 py-1 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 text-xs font-bold cursor-pointer border border-slate-700"
                  >
                    {isEn ? 'Invite' : 'আমন্ত্রণ পাঠান'}
                  </button>
                </div>
              ))}
            </div>
          )}

          {/* Reels */}
          {(activeTab === 'all' || activeTab === 'reels') && (
            <div className="space-y-1.5">
              <span className="text-[11px] font-black text-rose-300 uppercase tracking-wider block">
                {isEn ? 'Trending Short Clips' : 'জনপ্রিয় শর্টস ভিডিও'}
              </span>
              {sampleReels.map((reel) => (
                <div
                  key={reel.id}
                  className="p-2.5 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between"
                >
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-xl bg-rose-500/20 border border-rose-400 flex items-center justify-center text-xs text-rose-300">
                      🎬
                    </div>
                    <div>
                      <p className="text-xs font-bold text-white line-clamp-1">{reel.title}</p>
                      <p className="text-[10px] text-slate-400">
                        {reel.creator} • {reel.views} {isEn ? 'views' : 'ভিউ'}
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={() => {
                      Sound.playClick();
                      if (onOpenShorts) onOpenShorts();
                      onClose();
                    }}
                    className="px-3 py-1 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold cursor-pointer flex items-center gap-1"
                  >
                    <Play className="w-3 h-3 fill-white" /> {isEn ? 'Play' : 'প্লে'}
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
