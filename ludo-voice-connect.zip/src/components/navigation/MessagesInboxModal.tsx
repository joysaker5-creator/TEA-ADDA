import React, { useState } from 'react';
import { MessageSquare, Send, Bell, Gift, Sparkles, X, User, CheckCheck, Smile } from 'lucide-react';
import { Sound } from '../../utils/soundEffects';

interface MessagesInboxModalProps {
  isOpen: boolean;
  onClose: () => void;
  onClaimGift?: (coins: number) => void;
  isEn?: boolean;
}

interface MessageItem {
  id: string;
  sender: string;
  type: 'system' | 'friend' | 'gift';
  text: string;
  time: string;
  giftCoins?: number;
  isClaimed?: boolean;
}

export const MessagesInboxModal: React.FC<MessagesInboxModalProps> = ({
  isOpen,
  onClose,
  onClaimGift,
  isEn = true,
}) => {
  const [activeTab, setActiveTab] = useState<'all' | 'friends' | 'system'>('all');
  const [chatInput, setChatInput] = useState('');
  const [messages, setMessages] = useState<MessageItem[]>([
    {
      id: 'm1',
      sender: isEn ? 'Joy Ludo Official 👑' : 'জয় লুডু অফিশিয়াল 👑',
      type: 'gift',
      text: isEn
        ? 'Welcome! Claim your daily bonus gift of 1,000 free coins.'
        : 'স্বাগতম! আপনার দৈনিক উপহার হিসেবে ১,০০০ ফ্রি কয়েন গ্রহণ করুন।',
      time: isEn ? '10m ago' : '১০ মিনিট আগে',
      giftCoins: 1000,
      isClaimed: false,
    },
    {
      id: 'm2',
      sender: isEn ? 'Shakib (Pro_Ludo)' : 'সাকিব (Pro_Ludo)',
      type: 'friend',
      text: isEn
        ? 'Hey bro, up for a 4-player classic match? Opening a room now!'
        : 'দোস্ত, ৪-প্লেয়ার ম্যাচে আসবি? এখনই রুম খুলছি!',
      time: isEn ? '25m ago' : '২৫ মিনিট আগে',
    },
    {
      id: 'm3',
      sender: isEn ? 'System Alert ⚡' : 'সিস্টেম এলার্ট ⚡',
      type: 'system',
      text: isEn
        ? 'Grand Ludo Championship Tournament starts at 9 PM tonight! Prize pool: 100,000 coins.'
        : 'আজ রাত ৯টায় অনুষ্ঠিত হবে গ্র্যান্ড লুডু চ্যাম্পিয়নশিপ টুর্নামেন্ট! প্রাইজপুল ১,০০,০০০ কয়েন।',
      time: isEn ? '2h ago' : '২ ঘন্টা আগে',
    },
    {
      id: 'm4',
      sender: isEn ? 'Tanvir Ahmed' : 'তানভীর আহমেদ',
      type: 'friend',
      text: isEn
        ? 'That lucky 6 roll in the last match was legendary bro! 🤣'
        : 'গত ম্যাচে তোর ৬ পড়ার চালটা চরম ছিল ভাই! 🤣',
      time: isEn ? 'Yesterday' : 'গতকাল',
    },
  ]);

  if (!isOpen) return null;

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;
    Sound.playClick();

    const newMsg: MessageItem = {
      id: `msg-${Date.now()}`,
      sender: isEn ? 'You' : 'আমি (You)',
      type: 'friend',
      text: chatInput.trim(),
      time: isEn ? 'Just now' : 'এখনই',
    };

    setMessages([newMsg, ...messages]);
    setChatInput('');
  };

  const handleClaim = (msgId: string, coins: number) => {
    Sound.playRewardClaim();
    setMessages((prev) =>
      prev.map((m) => (m.id === msgId ? { ...m, isClaimed: true } : m))
    );
    if (onClaimGift) {
      onClaimGift(coins);
    }
  };

  const filtered = messages.filter((m) => {
    if (activeTab === 'all') return true;
    if (activeTab === 'friends') return m.type === 'friend';
    if (activeTab === 'system') return m.type === 'system' || m.type === 'gift';
    return true;
  });

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 animate-fade-in">
      <div className="w-full max-w-lg bg-slate-950 border-2 border-slate-700 rounded-3xl p-5 sm:p-6 text-white shadow-2xl space-y-4 max-h-[85vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-black border border-white/20 flex items-center justify-center text-white">
              <MessageSquare className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-black text-white">
                {isEn ? 'Messages & Inbox' : 'মেসেজ ও ইনবক্স (Messages)'}
              </h3>
              <p className="text-[11px] text-slate-400">
                {isEn ? 'Friends chat & system notifications' : 'ফ্রেন্ডস চ্যাট এবং সিস্টেম ইনবক্স নোটিস'}
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              Sound.playClick();
              onClose();
            }}
            className="w-8 h-8 rounded-full bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center cursor-pointer border border-slate-700"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Category Tabs */}
        <div className="flex gap-1.5 border-b border-slate-800 pb-2">
          {[
            { id: 'all', label: isEn ? '💬 All' : '💬 সব বার্তা' },
            { id: 'friends', label: isEn ? '👥 Friends' : '👥 বন্ধুদের মেসেজ' },
            { id: 'system', label: isEn ? '🎁 Gifts & System' : '🎁 সিস্টেম ও গিফট' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => {
                Sound.playButtonTick();
                setActiveTab(tab.id as any);
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                activeTab === tab.id
                  ? 'bg-white text-slate-950 font-black shadow-md'
                  : 'bg-slate-900 text-slate-400 hover:text-white'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Message List */}
        <div className="flex-1 overflow-y-auto space-y-2.5 pr-1 max-h-[320px]">
          {filtered.length === 0 ? (
            <div className="text-center py-8 text-slate-500 text-xs">
              {isEn ? 'No messages yet' : 'কোনো মেসেজ নেই'}
            </div>
          ) : (
            filtered.map((msg) => (
              <div
                key={msg.id}
                className={`p-3 rounded-2xl border transition-all ${
                  msg.type === 'gift'
                    ? 'bg-amber-950/40 border-amber-500/40'
                    : msg.sender.includes('You') || msg.sender.includes('আমি')
                    ? 'bg-blue-950/40 border-blue-500/40'
                    : 'bg-slate-900 border-slate-800'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center gap-1.5">
                    {msg.type === 'gift' ? (
                      <Gift className="w-3.5 h-3.5 text-yellow-400 animate-bounce" />
                    ) : (
                      <User className="w-3.5 h-3.5 text-cyan-400" />
                    )}
                    <span className="text-xs font-black text-white">{msg.sender}</span>
                  </div>
                  <span className="text-[10px] text-slate-500">{msg.time}</span>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed pl-5">{msg.text}</p>

                {/* Gift Claim Button */}
                {msg.type === 'gift' && msg.giftCoins && (
                  <div className="mt-2.5 pl-5 flex items-center justify-between">
                    <span className="text-xs font-bold text-yellow-400">
                      🪙 +{msg.giftCoins.toLocaleString()} {isEn ? 'Coins' : 'কয়েন'}
                    </span>
                    {msg.isClaimed ? (
                      <span className="px-3 py-1 rounded-xl bg-slate-800 text-emerald-400 text-xs font-bold flex items-center gap-1">
                        <CheckCheck className="w-3.5 h-3.5" /> {isEn ? 'Claimed' : 'ক্লেইম করা হয়েছে'}
                      </span>
                    ) : (
                      <button
                        onClick={() => handleClaim(msg.id, msg.giftCoins!)}
                        className="px-3 py-1 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-xs cursor-pointer shadow-md"
                      >
                        {isEn ? 'Claim Gift' : 'উপহার গ্রহণ করুন'}
                      </button>
                    )}
                  </div>
                )}
              </div>
            ))
          )}
        </div>

        {/* Send Chat Bar */}
        <form onSubmit={handleSendMessage} className="flex gap-2 pt-2 border-t border-slate-800">
          <input
            type="text"
            value={chatInput}
            onChange={(e) => setChatInput(e.target.value)}
            placeholder={isEn ? 'Type a message...' : 'একটি মেসেজ লিখুন...'}
            className="flex-1 px-3.5 py-2 bg-slate-900 border border-slate-700 rounded-2xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
          />
          <button
            type="submit"
            className="px-4 py-2 rounded-2xl bg-white hover:bg-slate-200 text-slate-950 font-black text-xs flex items-center gap-1.5 cursor-pointer shadow-md"
          >
            <Send className="w-3.5 h-3.5" /> {isEn ? 'Send' : 'পাঠান'}
          </button>
        </form>
      </div>
    </div>
  );
};
