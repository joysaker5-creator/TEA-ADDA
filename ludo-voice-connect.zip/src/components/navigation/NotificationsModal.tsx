import React from 'react';
import { Bell, Trophy, Gift, ShieldAlert, Sparkles, X, Check, ArrowRight } from 'lucide-react';
import { Sound } from '../../utils/soundEffects';

interface NotificationsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenStore?: () => void;
  onOpenInvite?: () => void;
  onOpenShorts?: () => void;
  isEn?: boolean;
}

export const NotificationsModal: React.FC<NotificationsModalProps> = ({
  isOpen,
  onClose,
  onOpenStore,
  onOpenInvite,
  onOpenShorts,
  isEn = true,
}) => {
  if (!isOpen) return null;

  const notifications = [
    {
      id: 'notif-1',
      title: isEn ? '🏆 Tournament Notice: Grand Weekly Cup' : '🏆 টুর্নামেন্ট নোটিশ: গ্র্যান্ড উইকলি কাপ',
      description: isEn
        ? 'Tournament registration closes tomorrow at 3 PM. Confirm your spot now!'
        : 'আগামীকাল দুপুর ৩টায় টুর্নামেন্টের রেজিস্ট্রেশন বন্ধ হবে। এখনই অংশগ্রহণ নিশ্চিত করুন!',
      time: isEn ? '15m ago' : '১৫ মিনিট আগে',
      type: 'tournament',
      actionLabel: isEn ? 'View Tournaments' : 'টুর্নামেন্ট দেখুন',
    },
    {
      id: 'notif-2',
      title: isEn ? '🎁 Referral Bonus Active' : '🎁 ইনভাইট বোনাস সক্রিয়',
      description: isEn
        ? 'Invite each friend and get 5,000 coins + 20 diamonds! Limited time reward.'
        : 'প্রতি বন্ধুকে ইনভাইট করলে পাবেন ৫,০০০ কয়েন ও ২০ ডায়মন্ড! অফার সীমিত সময়ের জন্য।',
      time: isEn ? '1h ago' : '১ ঘণ্টা আগে',
      type: 'reward',
      actionLabel: isEn ? 'Invite Friends' : 'ইনভাইট করুন',
      onClick: onOpenInvite,
    },
    {
      id: 'notif-3',
      title: isEn ? '🎬 New Viral Ludo Clips Added' : '🎬 নতুন ভাইরাল লুডু ভিডিও যুক্ত হয়েছে',
      description: isEn
        ? 'Check out amazing gameplay tips, funny moments, and tip diamonds to creators in Reels.'
        : 'ভিডিও স্ক্রল ফিডে সেরা লুডু ট্রিকস ও ফানি মোমেন্টস ভিডিও দেখুন এবং ডায়মন্ড টিপস দিন।',
      time: isEn ? '3h ago' : '৩ ঘণ্টা আগে',
      type: 'shorts',
      actionLabel: isEn ? 'Watch Videos' : 'ভিডিও দেখুন',
      onClick: onOpenShorts,
    },
    {
      id: 'notif-4',
      title: isEn ? '🛡️ Healthy Play Time Reminder' : '🛡️ স্ক্রিন টাইম রিমাইন্ডার',
      description: isEn
        ? 'Take periodic breaks to protect your eyes and maintain healthy daily gaming habits.'
        : 'আপনার স্বাস্থ্য ও চোখের সুরক্ষায় নিয়মিত বিরতি নিন এবং অভিভাবকীয় সুরক্ষা সেটিংস সক্রিয় রাখুন।',
      time: isEn ? '5h ago' : '৫ ঘণ্টা আগে',
      type: 'safety',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 animate-fade-in">
      <div className="w-full max-w-lg bg-slate-950 border-2 border-slate-700 rounded-3xl p-5 sm:p-6 text-white shadow-2xl space-y-4 max-h-[85vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-black border border-white/20 flex items-center justify-center text-white">
              <Bell className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-black text-white">
                {isEn ? 'Notifications' : 'নোটিফিকেশন (Notifications)'}
              </h3>
              <p className="text-[11px] text-slate-400">
                {isEn ? 'Game updates, tournaments & reward alerts' : 'খেলার আপডেট, টুর্নামেন্ট ও পুরষ্কারের নোটিস'}
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              Sound.playClick();
              onClose();
            }}
            className="w-8 h-8 rounded-full bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center cursor-pointer border border-slate-700"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Notification List */}
        <div className="flex-1 overflow-y-auto space-y-2.5 pr-1 max-h-[360px]">
          {notifications.map((n) => (
            <div
              key={n.id}
              className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition-all space-y-1.5"
            >
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-black text-white flex items-center gap-1.5">
                  {n.title}
                </h4>
                <span className="text-[10px] text-slate-500">{n.time}</span>
              </div>
              <p className="text-[11px] text-slate-300 leading-relaxed">{n.description}</p>
              {n.actionLabel && (
                <div className="pt-1 flex justify-end">
                  <button
                    onClick={() => {
                      Sound.playClick();
                      if (n.onClick) n.onClick();
                      onClose();
                    }}
                    className="px-3 py-1 rounded-xl bg-white hover:bg-slate-200 text-slate-950 font-black text-[11px] flex items-center gap-1 cursor-pointer transition-all shadow-xs"
                  >
                    <span>{n.actionLabel}</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="pt-2 border-t border-slate-800 flex justify-between items-center text-xs text-slate-400">
          <span>{isEn ? 'All caught up ✓' : 'সব নোটিফিকেশন পড়া হয়েছে ✓'}</span>
          <button
            onClick={() => {
              Sound.playClick();
              onClose();
            }}
            className="text-amber-300 font-bold hover:underline"
          >
            {isEn ? 'Close' : 'বন্ধ করুন'}
          </button>
        </div>
      </div>
    </div>
  );
};
