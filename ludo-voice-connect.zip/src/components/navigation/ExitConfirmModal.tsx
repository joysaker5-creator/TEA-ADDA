import React from 'react';
import { LogOut, RotateCcw, Home, X, AlertTriangle } from 'lucide-react';
import { Sound } from '../../utils/soundEffects';

interface ExitConfirmModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirmExit: () => void;
  onRestartMatch?: () => void;
  isEn?: boolean;
}

export const ExitConfirmModal: React.FC<ExitConfirmModalProps> = ({
  isOpen,
  onClose,
  onConfirmExit,
  onRestartMatch,
  isEn = true,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 animate-fade-in">
      <div className="w-full max-w-sm bg-slate-950 border-2 border-slate-700 rounded-3xl p-5 sm:p-6 text-white text-center space-y-4 shadow-2xl">
        <div className="w-14 h-14 rounded-2xl bg-black border border-white/20 text-white flex items-center justify-center mx-auto text-2xl font-black">
          <LogOut className="w-6 h-6 text-amber-400" />
        </div>

        <div>
          <h3 className="text-base font-black text-white">
            {isEn ? 'Leave Current Match?' : 'খেলা বন্ধ করতে চান?'}
          </h3>
          <p className="text-xs text-slate-300 mt-1 leading-relaxed">
            {isEn
              ? 'Are you sure you want to exit and return to the main home lobby?'
              : 'আপনি কি বর্তমান গেম বা স্ক্রিন বন্ধ করে মূল হোম লবিতে ফিরে যেতে চান?'}
          </p>
        </div>

        <div className="space-y-2 pt-2">
          {/* Back to Home Lobby */}
          <button
            onClick={() => {
              Sound.playClick();
              onConfirmExit();
              onClose();
            }}
            className="w-full py-3 rounded-2xl bg-white hover:bg-slate-200 text-slate-950 font-black text-xs flex items-center justify-center gap-2 cursor-pointer shadow-lg transition-all"
          >
            <Home className="w-4 h-4" />
            <span>{isEn ? 'Return to Home Lobby' : 'হোম লবিতে ফিরে যান'}</span>
          </button>

          {/* Restart Match if available */}
          {onRestartMatch && (
            <button
              onClick={() => {
                Sound.playClick();
                onRestartMatch();
                onClose();
              }}
              className="w-full py-2.5 rounded-2xl bg-slate-900 hover:bg-slate-800 text-amber-300 font-bold text-xs flex items-center justify-center gap-2 cursor-pointer border border-slate-700"
            >
              <RotateCcw className="w-4 h-4" />
              <span>{isEn ? 'Restart Match' : 'নতুন করে ম্যাচ শুরু করুন'}</span>
            </button>
          )}

          {/* Cancel */}
          <button
            onClick={() => {
              Sound.playClick();
              onClose();
            }}
            className="w-full py-2.5 rounded-2xl bg-slate-900 text-slate-400 hover:text-white font-bold text-xs cursor-pointer border border-slate-800"
          >
            {isEn ? 'Cancel (Keep Playing)' : 'বাতিল (খেলা চালিয়ে যান)'}
          </button>
        </div>
      </div>
    </div>
  );
};
