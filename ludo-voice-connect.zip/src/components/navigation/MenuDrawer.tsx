import React from 'react';
import {
  Menu,
  X,
  BookOpen,
  Palette,
  Volume2,
  VolumeX,
  ShieldCheck,
  ShoppingBag,
  Crown,
  Gift,
  Film,
  Megaphone,
  Mic,
  BarChart3,
  HelpCircle,
  LogOut,
  Sparkles,
  Settings,
  Download,
} from 'lucide-react';
import { Sound } from '../../utils/soundEffects';

interface MenuDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenSettings: () => void;
  onOpenRules: () => void;
  onOpenCustomization: () => void;
  onOpenStore: () => void;
  onOpenVip: () => void;
  onOpenAgeSafety: () => void;
  onOpenInvite: () => void;
  onOpenShorts: () => void;
  onOpenStudio: () => void;
  onOpenAdvertiser: () => void;
  onOpenAdda: () => void;
  onOpenStats: () => void;
  onOpenLevelRoadmap?: () => void;
  onOpenWatchAd?: () => void;
  onOpenApkModal?: () => void;
  soundMuted: boolean;
  onToggleSound: () => void;
}

export const MenuDrawer: React.FC<MenuDrawerProps> = ({
  isOpen,
  onClose,
  onOpenSettings,
  onOpenRules,
  onOpenCustomization,
  onOpenStore,
  onOpenVip,
  onOpenAgeSafety,
  onOpenInvite,
  onOpenShorts,
  onOpenStudio,
  onOpenAdvertiser,
  onOpenAdda,
  onOpenStats,
  onOpenLevelRoadmap,
  onOpenWatchAd,
  onOpenApkModal,
  soundMuted,
  onToggleSound,
}) => {
  if (!isOpen) return null;

  const menuItems = [
    {
      label: 'Game Settings (Sound, Controls & Language)',
      icon: <Settings className="w-4 h-4 text-amber-400" />,
      badge: 'Settings',
      onClick: onOpenSettings,
    },
    {
      label: 'Video Reels & Shorts',
      icon: <Film className="w-4 h-4 text-rose-400" />,
      badge: 'NEW',
      onClick: onOpenShorts,
    },
    {
      label: '10-Player Voice Adda (Audio Club)',
      icon: <Mic className="w-4 h-4 text-purple-400" />,
      badge: 'LIVE',
      onClick: onOpenAdda,
    },
    {
      label: 'Creator Studio & Monetization',
      icon: <Film className="w-4 h-4 text-yellow-400" />,
      badge: 'Earn',
      onClick: onOpenStudio,
    },
    {
      label: 'Level Roadmap & XP Rewards',
      icon: <Sparkles className="w-4 h-4 text-amber-300" />,
      badge: 'XP',
      onClick: onOpenLevelRoadmap || onOpenStats,
    },
    {
      label: 'Free Ad Rewards (+350 🪙)',
      icon: <Gift className="w-4 h-4 text-yellow-300 animate-bounce" />,
      badge: 'Free Coins',
      onClick: onOpenWatchAd || onOpenStore,
    },
    {
      label: 'VIP Club Membership',
      icon: <Crown className="w-4 h-4 text-amber-400" />,
      badge: '👑 VIP',
      onClick: onOpenVip,
    },
    {
      label: 'Coins & Diamonds Store',
      icon: <ShoppingBag className="w-4 h-4 text-emerald-400" />,
      badge: 'Offers',
      onClick: onOpenStore,
    },
    {
      label: 'Board Themes, Dice & Tokens',
      icon: <Palette className="w-4 h-4 text-cyan-400" />,
      onClick: onOpenCustomization,
    },
    {
      label: 'Game Rules & Strategy Guide',
      icon: <BookOpen className="w-4 h-4 text-blue-400" />,
      onClick: onOpenRules,
    },
    {
      label: 'Age Safety & Screen Time Controls',
      icon: <ShieldCheck className="w-4 h-4 text-emerald-400" />,
      onClick: onOpenAgeSafety,
    },
    {
      label: 'Player Stats & Match History',
      icon: <BarChart3 className="w-4 h-4 text-indigo-400" />,
      onClick: onOpenStats,
    },
    {
      label: 'Invite Friends (+5,000 🪙)',
      icon: <Gift className="w-4 h-4 text-pink-400" />,
      badge: 'Bonus',
      onClick: onOpenInvite,
    },
    {
      label: 'Ad Sponsor & Partnerships',
      icon: <Megaphone className="w-4 h-4 text-amber-500" />,
      onClick: onOpenAdvertiser,
    },
  ];

  return (
    <div
      className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex animate-fade-in"
      onClick={onClose}
    >
      <div
        className="w-80 max-w-[85vw] h-full bg-slate-950 border-r-2 border-slate-700 p-5 text-white flex flex-col justify-between shadow-2xl animate-slide-in"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Header */}
        <div className="space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-black border border-white/20 flex items-center justify-center text-white font-black text-xl">
                ☕
              </div>
              <div>
                <h3 className="text-sm font-black text-white">TEA ADDA Menu</h3>
                <p className="text-[10px] text-slate-400">All Options & Settings</p>
              </div>
            </div>
            <button
              onClick={() => {
                Sound.playClick();
                onClose();
              }}
              className="w-8 h-8 rounded-full bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center cursor-pointer border border-slate-700"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Menu Items List */}
          <div className="space-y-1 overflow-y-auto max-h-[60vh] pr-1">
            {menuItems.map((item, idx) => (
              <button
                key={idx}
                onClick={() => {
                  Sound.playClick();
                  item.onClick();
                  onClose();
                }}
                className="w-full p-2.5 rounded-2xl bg-slate-900/60 hover:bg-slate-800 text-left flex items-center justify-between text-xs text-slate-200 hover:text-white transition-all cursor-pointer border border-transparent hover:border-slate-700"
              >
                <div className="flex items-center gap-2.5 truncate">
                  {item.icon}
                  <span className="truncate">{item.label}</span>
                </div>
                {item.badge && (
                  <span className="text-[9px] font-black px-1.5 py-0.2 rounded bg-amber-400 text-slate-950 shrink-0">
                    {item.badge}
                  </span>
                )}
              </button>
            ))}
          </div>
        </div>

        {/* Bottom Actions: Sound Toggle & Version */}
        <div className="pt-3 border-t border-slate-800 space-y-2">
          <div className="p-2 rounded-xl bg-slate-900/90 border border-slate-800 text-[10px] text-slate-300 flex items-start gap-2 leading-relaxed">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
            <span>TEA ADDA is a free-to-play social game. Win virtual coins & rewards through skill and gameplay.</span>
          </div>

          <button
            onClick={() => {
              Sound.playClick();
              onToggleSound();
            }}
            className="w-full py-2 rounded-2xl bg-slate-900 hover:bg-slate-800 text-xs font-bold flex items-center justify-center gap-2 text-slate-300 border border-slate-700 cursor-pointer"
          >
            {soundMuted ? (
              <>
                <VolumeX className="w-4 h-4 text-rose-400" />
                <span>Sound is Muted (Click to Unmute)</span>
              </>
            ) : (
              <>
                <Volume2 className="w-4 h-4 text-emerald-400" />
                <span>Sound is ON (Click to Mute)</span>
              </>
            )}
          </button>
          <p className="text-[10px] text-center text-slate-500">TEA ADDA PRO v3.4 • 100% Safe Social Entertainment</p>
        </div>
      </div>
    </div>
  );
};
