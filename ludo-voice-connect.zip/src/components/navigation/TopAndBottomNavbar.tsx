import React from 'react';
import {
  Menu,
  Search,
  MessageSquare,
  Home,
  Film,
  Mic,
  Radio,
  Bell,
  Gamepad2,
  User,
  Sparkles,
  Settings,
  Coins,
  Gem,
  Volume2,
  VolumeX,
  Plus,
  Flame,
  Globe,
  Crown,
  Download,
} from 'lucide-react';
import { Sound } from '../../utils/soundEffects';
import { VipSubscriptionState } from '../../types';

interface TopAndBottomNavbarProps {
  // Top bar callbacks
  onOpenMenu: () => void;
  onOpenSearch: () => void;
  onOpenMessages: () => void;
  onOpenSettings?: () => void;
  onOpenStore?: () => void;
  onOpenDailyBonus?: () => void;
  onOpenVip?: () => void;
  onOpenApkModal?: () => void;
  soundMuted?: boolean;
  onToggleSound?: () => void;
  currentLanguage?: 'en' | 'bn';
  onToggleLanguage?: () => void;

  // VIP & Level state
  vipState?: VipSubscriptionState;
  userLevel?: number;

  // Currency values
  userCoins?: number;
  userDiamonds?: number;

  // Bottom bar callbacks
  onHomeClick: () => void;
  onReelsClick: () => void;
  onAudioLiveClick?: () => void;
  onCloseClick?: () => void;
  onNotificationClick: () => void;
  onGameClick: () => void;
  onProfileClick: () => void;

  // Badge counts
  unreadMessagesCount?: number;
  unreadNotificationsCount?: number;
  hasActiveReels?: boolean;
  isAudioLiveActive?: boolean;
  isMyTurn?: boolean;
  activeTab?: 'home' | 'game';
}

export const TopAndBottomNavbar: React.FC<TopAndBottomNavbarProps> = ({
  onOpenMenu,
  onOpenSearch,
  onOpenMessages,
  onOpenSettings,
  onOpenStore,
  onOpenDailyBonus,
  onOpenVip,
  onOpenApkModal,
  soundMuted = false,
  onToggleSound,
  currentLanguage = 'en',
  onToggleLanguage,
  vipState,
  userLevel,
  userCoins = 5000,
  userDiamonds = 20,
  onHomeClick,
  onReelsClick,
  onAudioLiveClick,
  onCloseClick,
  onNotificationClick,
  onGameClick,
  onProfileClick,
  unreadMessagesCount = 2,
  unreadNotificationsCount = 3,
  hasActiveReels = true,
  isAudioLiveActive = true,
  isMyTurn = false,
  activeTab = 'game',
}) => {
  const isEn = currentLanguage === 'en';

  // VIP Tier Visual Configuration
  const getVipConfig = (tier?: string) => {
    switch (tier) {
      case 'vip_royal':
        return {
          labelEn: 'VIP Royal',
          labelBn: 'রয়্যাল VIP',
          levelNum: 4,
          containerStyle:
            'bg-gradient-to-r from-amber-950/90 via-rose-950/80 to-yellow-950/90 border-amber-400 shadow-[0_0_15px_rgba(251,191,36,0.55)] hover:border-yellow-300',
          crownStyle: 'text-amber-300 fill-amber-400 drop-shadow-[0_0_6px_rgba(251,191,36,0.8)] animate-pulse',
          textStyle: 'bg-gradient-to-r from-yellow-200 via-amber-300 to-rose-300 bg-clip-text text-transparent',
          badgeLevelStyle: 'bg-gradient-to-r from-amber-400 to-yellow-300 text-slate-950',
        };
      case 'vip_diamond':
        return {
          labelEn: 'VIP Diamond',
          labelBn: 'ডায়মন্ড VIP',
          levelNum: 3,
          containerStyle:
            'bg-gradient-to-r from-cyan-950/90 via-sky-950/80 to-slate-950/90 border-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.5)] hover:border-cyan-300',
          crownStyle: 'text-cyan-300 fill-cyan-400 drop-shadow-[0_0_6px_rgba(6,182,212,0.8)] animate-pulse',
          textStyle: 'bg-gradient-to-r from-cyan-200 via-sky-300 to-cyan-400 bg-clip-text text-transparent',
          badgeLevelStyle: 'bg-gradient-to-r from-cyan-400 to-sky-300 text-slate-950',
        };
      case 'vip_silver':
        return {
          labelEn: 'VIP Silver',
          labelBn: 'সিলভার VIP',
          levelNum: 1,
          containerStyle:
            'bg-gradient-to-r from-slate-900/90 via-slate-800/80 to-slate-900/90 border-slate-300/80 shadow-[0_0_12px_rgba(203,213,225,0.4)] hover:border-slate-200',
          crownStyle: 'text-slate-200 fill-slate-300 drop-shadow-[0_0_6px_rgba(203,213,225,0.8)]',
          textStyle: 'text-slate-200',
          badgeLevelStyle: 'bg-slate-300 text-slate-950',
        };
      case 'vip_gold':
      default:
        return {
          labelEn: 'VIP Gold',
          labelBn: 'গোল্ড VIP',
          levelNum: 2,
          containerStyle:
            'bg-gradient-to-r from-amber-950/90 via-yellow-950/80 to-amber-900/90 border-amber-400 shadow-[0_0_15px_rgba(245,158,11,0.5)] hover:border-amber-300',
          crownStyle: 'text-amber-300 fill-amber-400 drop-shadow-[0_0_6px_rgba(245,158,11,0.8)] animate-pulse',
          textStyle: 'bg-gradient-to-r from-amber-200 via-yellow-300 to-amber-400 bg-clip-text text-transparent',
          badgeLevelStyle: 'bg-gradient-to-r from-amber-400 to-yellow-400 text-slate-950',
        };
    }
  };

  const vipConfig = getVipConfig(vipState?.tier);

  return (
    <>
      {/* ========================================================
          TOP NAVIGATION BAR (Clean Borderless Icon Layout + Wallet Stats)
          Left: [ ☰ ] [ TEA ADDA ] | Center: [ 👑 VIP ] [ 🪙 Coins ] [ 💎 Gems ] | Right: [ 🔊 ] [ 🔍 ] [ 💬 ] [ ⚙️ ]
          ======================================================== */}
      <header className="w-full bg-black/95 backdrop-blur-md border-b border-slate-800 text-white px-2.5 sm:px-6 py-2 flex items-center justify-between sticky top-0 z-40 shadow-xl select-none">
        {/* Left: ☰ Menu Button & Logo */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          <button
            id="nav-menu-hamburger-btn"
            onClick={() => {
              Sound.playClick();
              onOpenMenu();
            }}
            className="w-9 h-9 sm:w-10 sm:h-10 hover:bg-white/10 active:scale-95 transition-all flex flex-col items-center justify-center gap-1.5 cursor-pointer rounded-xl group"
            title="Open Menu"
            aria-label="Menu"
          >
            <div className="w-5 h-0.5 bg-white group-hover:bg-amber-300 transition-colors" />
            <div className="w-5 h-0.5 bg-white group-hover:bg-amber-300 transition-colors" />
            <div className="w-5 h-0.5 bg-white group-hover:bg-amber-300 transition-colors" />
          </button>

          <div className="flex items-center gap-1 sm:gap-2 cursor-pointer" onClick={onGameClick}>
            <span className="text-xs sm:text-sm font-black tracking-wider text-amber-400 flex items-center gap-1">
              ☕ TEA ADDA
            </span>
            <span className="text-[9px] sm:text-[10px] px-1.5 py-0.2 rounded-full bg-emerald-500 text-slate-950 font-black">
              LIVE
            </span>
          </div>
        </div>

        {/* Center: Live VIP Status + Coins & Diamonds Balance Badges */}
        <div className="flex items-center gap-1.5 sm:gap-2.5">
          {/* Prominent VIP Status / Level Indicator with Crown icon */}
          {vipState?.isActive && (
            <button
              id="nav-vip-indicator-btn"
              onClick={() => {
                Sound.playClick();
                if (onOpenVip) onOpenVip();
              }}
              className={`flex items-center gap-1 sm:gap-1.5 px-2 sm:px-2.5 py-1 rounded-full border active:scale-95 transition-all cursor-pointer group shrink-0 ${vipConfig.containerStyle}`}
              title={
                isEn
                  ? `VIP Status: ${vipConfig.labelEn} (Level ${userLevel || vipConfig.levelNum}) - Click to manage VIP`
                  : `ভিআইপি স্ট্যাটাস: ${vipConfig.labelBn} (লেভেল ${userLevel || vipConfig.levelNum}) - বিস্তারিত দেখতে ক্লিক করুন`
              }
            >
              <Crown
                className={`w-3.5 h-3.5 sm:w-4 sm:h-4 ${vipConfig.crownStyle} group-hover:rotate-12 transition-transform shrink-0`}
              />
              <span className={`text-[10px] sm:text-xs font-black tracking-wider uppercase ${vipConfig.textStyle}`}>
                <span className="inline sm:hidden">VIP</span>
                <span className="hidden sm:inline">{isEn ? vipConfig.labelEn : vipConfig.labelBn}</span>
              </span>
              <span className={`px-1 py-0.2 rounded-full text-[9px] font-black leading-none shrink-0 ${vipConfig.badgeLevelStyle}`}>
                Lv.{userLevel || vipConfig.levelNum}
              </span>
            </button>
          )}

          {/* Coins Pill */}
          <button
            onClick={() => {
              Sound.playClick();
              if (onOpenStore) onOpenStore();
            }}
            className="flex items-center gap-1 px-2 sm:px-2.5 py-1 rounded-full bg-amber-950/80 border border-amber-500/60 hover:border-amber-400 active:scale-95 transition-all cursor-pointer shadow-sm group"
            title="Recharge Coins"
          >
            <Coins className="w-3.5 h-3.5 text-amber-400 fill-amber-400 group-hover:rotate-12 transition-transform shrink-0" />
            <span className="text-[11px] sm:text-xs font-black text-amber-300 font-mono">
              {userCoins.toLocaleString('en-US')}
            </span>
            <div className="w-4 h-4 rounded-full bg-amber-500 text-slate-950 flex items-center justify-center text-[10px] font-black shrink-0">
              <Plus className="w-3 h-3" />
            </div>
          </button>

          {/* Diamonds Pill */}
          <button
            onClick={() => {
              Sound.playClick();
              if (onOpenStore) onOpenStore();
            }}
            className="flex items-center gap-1 px-2 sm:px-2.5 py-1 rounded-full bg-cyan-950/80 border border-cyan-500/50 hover:border-cyan-400 active:scale-95 transition-all cursor-pointer shadow-sm group"
            title="Diamonds Vault"
          >
            <Gem className="w-3.5 h-3.5 text-cyan-400 fill-cyan-400 group-hover:scale-110 transition-transform shrink-0" />
            <span className="text-[11px] sm:text-xs font-black text-cyan-200 font-mono">
              {userDiamonds.toLocaleString('en-US')}
            </span>
          </button>

          {/* Daily Streak Bonus Icon */}
          {onOpenDailyBonus && (
            <button
              onClick={() => {
                Sound.playClick();
                onOpenDailyBonus();
              }}
              className="hidden sm:flex items-center gap-1 px-2 py-1 rounded-full bg-rose-950/80 border border-rose-500/60 hover:border-rose-400 text-rose-300 text-[11px] font-black active:scale-95 transition-all cursor-pointer"
              title="Claim Daily Bonus"
            >
              <Flame className="w-3.5 h-3.5 text-rose-400 fill-rose-500 animate-pulse" />
              <span>Bonus</span>
            </button>
          )}
        </div>

        {/* Right Buttons: [ 🔊 Sound ] [ 🔍 Search ]  [ 💬 Messages ]  [ ⚙️ Settings ] */}
        <div className="flex items-center gap-0.5 sm:gap-1.5 shrink-0">
          {/* Sound Toggle */}
          {onToggleSound && (
            <button
              onClick={() => {
                onToggleSound();
              }}
              className="w-8 h-8 sm:w-9 sm:h-9 hover:bg-white/10 active:scale-95 transition-all flex items-center justify-center cursor-pointer rounded-xl text-slate-300 hover:text-white"
              title={soundMuted ? 'Unmute Sound' : 'Mute Sound'}
              aria-label="Sound"
            >
              {soundMuted ? (
                <VolumeX className="w-4 h-4 sm:w-5 sm:h-5 text-rose-400" />
              ) : (
                <Volume2 className="w-4 h-4 sm:w-5 sm:h-5 text-emerald-400" />
              )}
            </button>
          )}

          {/* Search Button */}
          <button
            id="nav-search-btn"
            onClick={() => {
              Sound.playClick();
              onOpenSearch();
            }}
            className="w-8 h-8 sm:w-9 sm:h-9 hover:bg-white/10 active:scale-95 transition-all flex items-center justify-center cursor-pointer rounded-xl text-amber-300 hover:text-amber-200"
            title="Search"
            aria-label="Search"
          >
            <Search className="w-4 h-4 sm:w-5 sm:h-5" />
          </button>

          {/* Messages Button */}
          <button
            id="nav-messages-btn"
            onClick={() => {
              Sound.playClick();
              onOpenMessages();
            }}
            className="relative w-8 h-8 sm:w-9 sm:h-9 hover:bg-white/10 active:scale-95 transition-all flex items-center justify-center cursor-pointer rounded-xl text-cyan-300 hover:text-cyan-200"
            title="Messages & Inbox"
            aria-label="Messages"
          >
            <MessageSquare className="w-4 h-4 sm:w-5 sm:h-5" />
            {unreadMessagesCount > 0 && (
              <span className="absolute top-1 right-1 min-w-[16px] h-[16px] px-0.5 rounded-full bg-rose-600 text-white text-[8px] font-black flex items-center justify-center border border-black animate-pulse">
                {unreadMessagesCount}
              </span>
            )}
          </button>

          {/* Language Toggle Button */}
          {onToggleLanguage && (
            <button
              id="nav-language-btn"
              onClick={() => {
                Sound.playClick();
                onToggleLanguage();
              }}
              className="px-2 py-1 rounded-xl bg-emerald-950/80 border border-emerald-500/50 hover:border-emerald-400 text-emerald-300 text-[11px] font-black active:scale-95 transition-all cursor-pointer flex items-center gap-1 shadow-sm"
              title={currentLanguage === 'en' ? 'বাংলা ভাষায় পরিবর্তন করুন' : 'Switch to English'}
              aria-label="Language Toggle"
            >
              <Globe className="w-3.5 h-3.5 text-emerald-400" />
              <span>{currentLanguage === 'en' ? 'EN' : 'বাং'}</span>
            </button>
          )}

          {/* Settings Button */}
          {onOpenSettings && (
            <button
              id="nav-settings-btn"
              onClick={() => {
                Sound.playClick();
                onOpenSettings();
              }}
              className="w-8 h-8 sm:w-9 sm:h-9 hover:bg-white/10 active:scale-95 transition-all flex items-center justify-center cursor-pointer rounded-xl text-amber-400 hover:text-amber-300"
              title="Settings"
              aria-label="Settings"
            >
              <Settings className="w-4 h-4 sm:w-5 sm:h-5" />
            </button>
          )}
        </div>
      </header>

      {/* ========================================================
          BOTTOM NAVIGATION BAR (Exact requested order):
          1. Home | 2. Reels | 3. Live | 4. Alerts | 5. Ludo | 6. Profile
          ======================================================== */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 bg-black/95 backdrop-blur-xl border-t border-slate-800 px-1 sm:px-4 py-1.5 flex items-center justify-center shadow-2xl select-none">
        <div className="w-full max-w-xl flex items-center justify-around gap-1 px-1">
          {/* 1. HOME Button */}
          <button
            id="bottom-nav-home-btn"
            onClick={() => {
              Sound.playButtonTick();
              onHomeClick();
            }}
            className={`flex flex-col items-center justify-center py-1 px-2 rounded-xl cursor-pointer active:scale-90 transition-all ${
              activeTab === 'home'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-400/50 shadow-md shadow-amber-500/20'
                : 'hover:bg-white/10 text-slate-400 hover:text-amber-200'
            }`}
            title="Home Feed"
            aria-label="Home"
          >
            <Home className="w-5 h-5 sm:w-6 sm:h-6" />
            <span className="text-[10px] sm:text-[11px] font-bold tracking-tight mt-0.5 whitespace-nowrap">
              Home
            </span>
          </button>

          {/* 2. Reels & Video Scroll */}
          <button
            id="bottom-nav-reels-btn"
            onClick={() => {
              Sound.playButtonTick();
              onReelsClick();
            }}
            className="relative flex flex-col items-center justify-center py-1 px-2 rounded-xl cursor-pointer active:scale-90 transition-all text-rose-400 hover:text-rose-300 hover:bg-white/10"
            title="Reels & Videos"
            aria-label="Reels"
          >
            <div className="relative">
              <Film className="w-5 h-5 sm:w-6 sm:h-6" />
              {hasActiveReels && (
                <span className="absolute top-0 -right-1 w-2 h-2 rounded-full bg-rose-500 animate-ping" />
              )}
            </div>
            <span className="text-[10px] sm:text-[11px] font-bold tracking-tight mt-0.5 whitespace-nowrap">
              Reels
            </span>
          </button>

          {/* 3. Live Audio Voice Adda (Live) */}
          <button
            id="bottom-nav-audio-live-btn"
            onClick={() => {
              Sound.playClick();
              if (onAudioLiveClick) {
                onAudioLiveClick();
              } else if (onCloseClick) {
                onCloseClick();
              }
            }}
            className="relative flex flex-col items-center justify-center py-1 px-2 rounded-2xl bg-gradient-to-tr from-rose-600 via-red-500 to-amber-500 hover:from-rose-500 hover:to-amber-400 text-white shadow-lg shadow-rose-600/40 active:scale-90 transition-all border border-rose-300/40"
            title="🎙️ 10-Player Live Audio Voice Room (Live)"
            aria-label="Live"
          >
            <div className="relative">
              <Mic className="w-5 h-5 sm:w-6 sm:h-6 animate-pulse" />
              <span className="absolute -top-1.5 -right-2 px-1 py-0.2 bg-emerald-400 text-slate-950 font-black text-[7px] rounded-full uppercase">
                LIVE
              </span>
            </div>
            <span className="text-[9px] sm:text-[10px] font-black tracking-tight mt-0.5 whitespace-nowrap">
              Live
            </span>
          </button>

          {/* 4. Alerts / Notifications */}
          <button
            id="bottom-nav-notifications-btn"
            onClick={() => {
              Sound.playButtonTick();
              onNotificationClick();
            }}
            className="relative flex flex-col items-center justify-center py-1 px-2 rounded-xl cursor-pointer active:scale-90 transition-all text-yellow-300 hover:text-yellow-200 hover:bg-white/10"
            title="Notifications & Alerts"
            aria-label="Alerts"
          >
            <div className="relative">
              <Bell className="w-5 h-5 sm:w-6 sm:h-6" />
              {unreadNotificationsCount > 0 && (
                <span className="absolute -top-1 -right-1 min-w-[15px] h-[15px] px-0.5 rounded-full bg-yellow-400 text-slate-950 text-[8px] font-black flex items-center justify-center border border-black">
                  {unreadNotificationsCount}
                </span>
              )}
            </div>
            <span className="text-[10px] sm:text-[11px] font-bold tracking-tight mt-0.5 whitespace-nowrap">
              Alerts
            </span>
          </button>

          {/* 5. Ludo Game / Board Screen */}
          <button
            id="bottom-nav-game-btn"
            onClick={() => {
              Sound.playButtonTick();
              onGameClick();
            }}
            className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-xl cursor-pointer active:scale-90 transition-all ${
              activeTab === 'game'
                ? 'bg-gradient-to-t from-emerald-600/30 to-emerald-500/10 text-emerald-300 border border-emerald-400/70 shadow-lg shadow-emerald-500/20'
                : isMyTurn
                ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 animate-pulse'
                : 'hover:bg-white/10 text-slate-300 hover:text-emerald-300'
            }`}
            title="Ludo Board & Game"
            aria-label="Ludo"
          >
            <div className="relative">
              <Gamepad2 className="w-5 h-5 sm:w-6 sm:h-6" />
              {isMyTurn && (
                <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-emerald-400 border border-slate-950 animate-ping" />
              )}
            </div>
            <span className="text-[10px] sm:text-[11px] font-black tracking-tight mt-0.5 whitespace-nowrap">
              Ludo
            </span>
          </button>

          {/* 6. Profile */}
          <button
            id="bottom-nav-profile-btn"
            onClick={() => {
              Sound.playButtonTick();
              onProfileClick();
            }}
            className="flex flex-col items-center justify-center py-1 px-2 rounded-xl cursor-pointer active:scale-90 transition-all text-cyan-300 hover:text-cyan-200 hover:bg-white/10"
            title="Profile & Account"
            aria-label="Profile"
          >
            <User className="w-5 h-5 sm:w-6 sm:h-6" />
            <span className="text-[10px] sm:text-[11px] font-bold tracking-tight mt-0.5 whitespace-nowrap">
              Profile
            </span>
          </button>
        </div>
      </nav>
    </>
  );
};
