import React from 'react';
import { Gamepad2, Users, Bot, Mic, Sparkles, X, Trophy, Play, Zap } from 'lucide-react';
import { Sound } from '../../utils/soundEffects';

interface GameModesModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectMode: (mode: '2p' | '4p' | 'vs_computer' | 'pass_play' | 'team_2v2' | 'adda_10p' | 'tournament') => void;
  isEn?: boolean;
}

export const GameModesModal: React.FC<GameModesModalProps> = ({
  isOpen,
  onClose,
  onSelectMode,
  isEn = true,
}) => {
  if (!isOpen) return null;

  const modes = [
    {
      id: '2p',
      title: isEn ? '2-Player Quick Match' : '২-প্লেয়ার কুইক ম্যাচ (2 Players)',
      desc: isEn ? 'Fast & thrilling 1v1 head-to-head Ludo battle' : 'দ্রুত এবং রোমাঞ্চকর ১ বনাম ১ হেড-টু-হেড লুডু ম্যাচ',
      badge: isEn ? '⚡ Fast Battle' : '⚡ ফাস্ট ব্যাটল',
      icon: '👥',
      color: 'from-blue-600 to-indigo-700',
    },
    {
      id: '4p',
      title: isEn ? '4-Player Classic Ludo' : '৪-প্লেয়ার ক্লাসিক (4 Players Classic)',
      desc: isEn ? 'Traditional 4-player competitive match' : 'ঐতিহ্যবাহী ৪ জনের রুদ্ধশ্বাস লুডু প্রতিযোগিতা',
      badge: isEn ? '🔥 Popular' : '🔥 জনপ্রিয়',
      icon: '🎲',
      color: 'from-amber-600 to-rose-600',
    },
    {
      id: 'team_2v2',
      title: isEn ? 'Team 2v2 Match' : '২ বনাম ২ টিম ম্যাচ (Team 2v2)',
      desc: isEn ? 'Partner with a friend and defeat opponents together' : 'বন্ধুর সাথে টিম গড়ে প্রতিপক্ষকে পরাজিত করুন',
      badge: isEn ? '🤝 Team Play' : '🤝 টিম প্লে',
      icon: '🛡️',
      color: 'from-emerald-600 to-teal-700',
    },
    {
      id: 'adda_10p',
      title: isEn ? '10-Player Voice Adda Club' : '১০-প্লেয়ার লাইভ ভয়েস আড্ডা (10-Player Adda)',
      desc: isEn ? 'Mega board with 10 players and live audio voice room' : '১০ জনের বিশাল মেগা বোর্ড ও লাইভ ভয়েস চ্যাট আড্ডা',
      badge: isEn ? '🎙️ Mega Room' : '🎙️ মেগা রুম',
      icon: '🎤',
      color: 'from-purple-600 to-pink-600',
    },
    {
      id: 'vs_computer',
      title: isEn ? 'Vs Computer (AI Practice)' : 'বনাম কম্পিউটার (AI Practice)',
      desc: isEn ? 'Sharpen your skills against smart AI bots' : 'ইন্টেলিজেন্ট এআই কম্পিউটারের সাথে প্র্যাকটিস ম্যাচ',
      badge: isEn ? '🤖 Practice' : '🤖 প্র্যাকটিস',
      icon: '💻',
      color: 'from-slate-700 to-slate-800',
    },
    {
      id: 'pass_play',
      title: isEn ? 'Pass & Play (Local Offline)' : 'পাস অ্যান্ড প্লে (Pass & Play)',
      desc: isEn ? 'Play offline on the same screen with friends and family' : 'একই ডিভাইসে বন্ধু ও পরিবারের সাথে অফলাইনে খেলা',
      badge: isEn ? '📱 Offline' : '📱 অফলাইন',
      icon: '👨‍👩‍👦',
      color: 'from-amber-700 to-yellow-600',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 animate-fade-in">
      <div className="w-full max-w-xl bg-slate-950 border-2 border-slate-700 rounded-3xl p-5 sm:p-6 text-white shadow-2xl space-y-4 max-h-[85vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-black border border-white/20 flex items-center justify-center text-white">
              <Gamepad2 className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-black text-white">
                {isEn ? 'Game Mode Selector' : 'গেইম মোড সিলেক্টর (Game Modes)'}
              </h3>
              <p className="text-[11px] text-slate-400">
                {isEn ? 'Select your favorite game mode to play' : 'আপনার পছন্দের লুডু ম্যাচ নির্বাচন করুন'}
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              Sound.playClick();
              onClose();
            }}
            className="w-8 h-8 rounded-full bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center cursor-pointer border border-slate-700"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Game Mode Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 overflow-y-auto pr-1 max-h-[380px]">
          {modes.map((mode) => (
            <div
              key={mode.id}
              onClick={() => {
                Sound.playClick();
                onSelectMode(mode.id as any);
                onClose();
              }}
              className="p-3.5 rounded-2xl bg-slate-900 hover:bg-slate-850 border border-slate-800 hover:border-slate-600 transition-all cursor-pointer flex flex-col justify-between group space-y-2"
            >
              <div className="flex items-center justify-between">
                <span className="text-2xl">{mode.icon}</span>
                <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-black/60 text-amber-300 border border-white/10">
                  {mode.badge}
                </span>
              </div>

              <div>
                <h4 className="text-xs font-black text-white group-hover:text-amber-300 transition-colors">
                  {mode.title}
                </h4>
                <p className="text-[11px] text-slate-400 mt-0.5 leading-snug">{mode.desc}</p>
              </div>

              <div className="pt-1 flex items-center justify-between text-[11px] font-bold text-amber-400">
                <span>{isEn ? 'Play Now' : 'ম্যাচ খেলুন'}</span>
                <div className="w-6 h-6 rounded-full bg-white text-slate-950 flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Play className="w-3 h-3 fill-slate-950 ml-0.5" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
