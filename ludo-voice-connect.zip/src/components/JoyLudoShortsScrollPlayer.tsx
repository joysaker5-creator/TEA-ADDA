import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  X,
  Heart,
  MessageCircle,
  Share2,
  Gift,
  Download,
  Check,
  Volume2,
  VolumeX,
  Play,
  Pause,
  ChevronUp,
  ChevronDown,
  Wifi,
  WifiOff,
  Sparkles,
  Award,
  DollarSign,
  TrendingUp,
  HardDrive,
  Trash2,
  Send,
  Music,
  Flame,
  Film,
  RotateCcw,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { VideoContent, UserProfile } from '../types';
import { Sound } from '../utils/soundEffects';
import {
  loadVideoFeed,
  saveVideoFeed,
  sendDiamondGiftToVideo,
  scanContentForPolicyViolation,
} from '../utils/videoMonetizationService';
import {
  getOfflineCachedVideos,
  isVideoOfflineCached,
  saveVideoToOfflineCache,
  removeVideoFromOfflineCache,
  getOfflineStorageMetrics,
  getOfflineSimulationMode,
  setOfflineSimulationMode,
  isAppInOfflineMode,
  OfflineStorageMetrics,
} from '../utils/offlineVideoService';

interface JoyLudoShortsScrollPlayerProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile;
  userDiamonds: number;
  onDeductDiamonds?: (count: number) => void;
  onOpenStudioModal?: () => void;
}

interface FloatingHeart {
  id: number;
  x: number;
  y: number;
}

export const JoyLudoShortsScrollPlayer: React.FC<JoyLudoShortsScrollPlayerProps> = ({
  isOpen,
  onClose,
  currentUser,
  userDiamonds,
  onDeductDiamonds,
  onOpenStudioModal,
}) => {
  // Video feed states
  const [allVideos, setAllVideos] = useState<VideoContent[]>(() => loadVideoFeed());
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [autoScrollNext, setAutoScrollNext] = useState<boolean>(true);
  const [videoProgress, setVideoProgress] = useState<number>(0);

  // Network & Offline States
  const [isOfflineMode, setIsOfflineMode] = useState<boolean>(() => isAppInOfflineMode());
  const [cachedVideoIds, setCachedVideoIds] = useState<Record<string, boolean>>({});
  const [storageMetrics, setStorageMetrics] = useState<OfflineStorageMetrics>({
    totalVideos: 0,
    totalSizeKB: 0,
    totalSizeMB: '0.0',
    cacheLimitVideos: 30,
  });
  const [isOfflineVaultOpen, setIsOfflineVaultOpen] = useState<boolean>(false);

  // Engagement States
  const [likedMap, setLikedMap] = useState<Record<string, boolean>>({});
  const [floatingHearts, setFloatingHearts] = useState<FloatingHeart[]>([]);
  const [isCommentDrawerOpen, setIsCommentDrawerOpen] = useState<boolean>(false);
  const [commentInput, setCommentInput] = useState<string>('');
  const [commentsMap, setCommentsMap] = useState<Record<string, string[]>>({
    'vid-joy-funny-01': [
      'হাসতে হাসতে শেষ ভাই! নিজের গুটি কাটার মতো মজা আর নেই 🤣',
      'অসাধারণ কমেডি রিঅ্যাকশন ❤️',
      'পরের পার্ট কবে আসবে?',
    ],
    'vid-joy-edu-02': [
      'স্টার পয়েন্ট লক করার এই টেকনিকটা জানতাম না! অনেক ধন্যবাদ 🧠',
      'প্রো টিপস! আমি আজকেই ট্রাই করে জিতলাম 🏆',
    ],
    'vid-joy-creative-03': [
      'সুস্থ বিনোদন ও চমৎকার পারিবারিক অনুভূতি ✨',
      'খুব সুন্দর কনটেন্ট ভাইয়া, শুভকামনা রইল 🌟',
    ],
    'vid-joy-funny-04': ['লাস্ট মোমেন্টে ১ পড়ার পর যা হলো হাহাহা 🤪', 'বসের ফেস এক্সপ্রেশন পুরাই মেমে! 😂'],
  });

  // Diamond Gift Modal States
  const [isGiftTipModalOpen, setIsGiftTipModalOpen] = useState<boolean>(false);
  const [selectedGiftDiamonds, setSelectedGiftDiamonds] = useState<number>(10);
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  // Touch Swipe & Wheel scroll tracking refs
  const touchStartYRef = useRef<number>(0);
  const isScrollingRef = useRef<boolean>(false);
  const progressTimerRef = useRef<any>(null);

  // Show Toast helper
  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 2500);
  };

  // Reload videos and offline cache status on open
  const reloadFeeds = useCallback(() => {
    const onlineFeed = loadVideoFeed();
    const offlineFeed = getOfflineCachedVideos();

    // Map cached IDs
    const idMap: Record<string, boolean> = {};
    offlineFeed.forEach((v) => {
      idMap[v.id] = true;
    });
    setCachedVideoIds(idMap);
    setStorageMetrics(getOfflineStorageMetrics());

    if (isOfflineMode || activeCategory === 'offline') {
      setAllVideos(offlineFeed);
    } else {
      setAllVideos(onlineFeed);
    }
  }, [isOfflineMode, activeCategory]);

  useEffect(() => {
    if (isOpen) {
      reloadFeeds();
      setCurrentIndex(0);
      setIsPlaying(true);
      setVideoProgress(0);
    }
  }, [isOpen, reloadFeeds]);

  // Listen to Online/Offline browser network events
  useEffect(() => {
    const handleOnline = () => {
      if (!getOfflineSimulationMode()) {
        setIsOfflineMode(false);
        showToast('📶 ইন্টারনেট সংযোগ ফিরে এসেছে! অনলাইন ফিড চালু হয়েছে।');
      }
    };
    const handleOffline = () => {
      setIsOfflineMode(true);
      showToast('⚡ অফলাইন মোড সক্রিয়: ক্যাশে থাকা ভিডিও চলছে!');
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Filtered Video List
  const filteredVideos = allVideos.filter((v) => {
    if (activeCategory === 'all') return true;
    if (activeCategory === 'offline') return cachedVideoIds[v.id];
    if (activeCategory === 'funny') return v.videoType === 'funny_moment';
    if (activeCategory === 'education') return v.videoType === 'educational_guide' || v.videoType === 'tutorial';
    if (activeCategory === 'creative') return v.videoType === 'creative_good_content';
    if (activeCategory === 'epic') return v.videoType === 'epic_win' || v.videoType === 'gameplay_highlight';
    if (activeCategory === 'adda') return v.videoType === 'voice_adda_clip';
    return true;
  });

  const currentVideo = filteredVideos[currentIndex] || filteredVideos[0] || allVideos[0];

  // Video playback timeline progress simulation
  useEffect(() => {
    if (!isOpen || !isPlaying || !currentVideo) {
      if (progressTimerRef.current) clearInterval(progressTimerRef.current);
      return;
    }

    const durationSec = currentVideo.durationSeconds || 30;
    const intervalMs = 200;
    const stepPercent = (intervalMs / (durationSec * 1000)) * 100;

    progressTimerRef.current = setInterval(() => {
      setVideoProgress((prev) => {
        if (prev >= 100) {
          if (autoScrollNext && filteredVideos.length > 1) {
            handleScrollNext();
            return 0;
          }
          return 0; // loop
        }
        return prev + stepPercent;
      });
    }, intervalMs);

    return () => {
      if (progressTimerRef.current) clearInterval(progressTimerRef.current);
    };
  }, [isOpen, isPlaying, currentIndex, currentVideo, autoScrollNext, filteredVideos.length]);

  // Scroll Navigation Handlers
  const handleScrollNext = () => {
    if (filteredVideos.length === 0) return;
    Sound.playButtonTick();
    setVideoProgress(0);
    setCurrentIndex((prev) => (prev < filteredVideos.length - 1 ? prev + 1 : 0));
  };

  const handleScrollPrev = () => {
    if (filteredVideos.length === 0) return;
    Sound.playButtonTick();
    setVideoProgress(0);
    setCurrentIndex((prev) => (prev > 0 ? prev - 1 : filteredVideos.length - 1));
  };

  // Keyboard navigation
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (isCommentDrawerOpen || isGiftTipModalOpen) return;
      if (e.key === 'ArrowDown' || e.key === 'j') {
        e.preventDefault();
        handleScrollNext();
      } else if (e.key === 'ArrowUp' || e.key === 'k') {
        e.preventDefault();
        handleScrollPrev();
      } else if (e.key === ' ') {
        e.preventDefault();
        setIsPlaying((p) => !p);
      } else if (e.key === 'm') {
        setIsMuted((m) => !m);
      } else if (e.key === 'Escape') {
        onClose();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, isCommentDrawerOpen, isGiftTipModalOpen, filteredVideos.length]);

  // Wheel scroll with throttle
  const handleWheel = (e: React.WheelEvent) => {
    if (isScrollingRef.current) return;
    if (Math.abs(e.deltaY) > 35) {
      isScrollingRef.current = true;
      if (e.deltaY > 0) {
        handleScrollNext();
      } else {
        handleScrollPrev();
      }
      setTimeout(() => {
        isScrollingRef.current = false;
      }, 450);
    }
  };

  // Touch Swipe Handlers for Mobile / Touchscreens
  const handleTouchStart = (e: React.TouchEvent) => {
    if (e.touches && e.touches.length > 0) {
      touchStartYRef.current = e.touches[0].clientY;
    }
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (!e.changedTouches || e.changedTouches.length === 0) return;
    const touchEndY = e.changedTouches[0].clientY;
    const diff = touchStartYRef.current - touchEndY;
    if (Math.abs(diff) > 45) {
      if (diff > 0) {
        handleScrollNext(); // swipe up -> next video
      } else {
        handleScrollPrev(); // swipe down -> prev video
      }
    }
  };

  // Double tap anywhere on video to like + heart burst
  const handleVideoAreaClick = (e: React.MouseEvent<HTMLDivElement>) => {
    // Check if double click/tap
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    // spawn heart
    const newHeart: FloatingHeart = { id: Date.now(), x, y };
    setFloatingHearts((prev) => [...prev, newHeart]);
    setTimeout(() => {
      setFloatingHearts((prev) => prev.filter((h) => h.id !== newHeart.id));
    }, 900);

    if (currentVideo && !likedMap[currentVideo.id]) {
      handleToggleLike();
    }
  };

  // Like video
  const handleToggleLike = () => {
    if (!currentVideo) return;
    Sound.playClick();
    const isLiked = likedMap[currentVideo.id];
    setLikedMap((prev) => ({ ...prev, [currentVideo.id]: !isLiked }));

    const updated = allVideos.map((v) => {
      if (v.id === currentVideo.id) {
        return {
          ...v,
          likesCount: isLiked ? Math.max(0, v.likesCount - 1) : v.likesCount + 1,
        };
      }
      return v;
    });
    setAllVideos(updated);
    saveVideoFeed(updated);

    if (!isLiked) {
      confetti({ particleCount: 25, spread: 45, origin: { y: 0.6 } });
    }
  };

  // Save / Toggle Offline Cache
  const handleToggleOfflineCache = (video: VideoContent) => {
    Sound.playClick();
    const isCached = cachedVideoIds[video.id];

    if (isCached) {
      const res = removeVideoFromOfflineCache(video.id);
      if (res.success) {
        setCachedVideoIds((prev) => ({ ...prev, [video.id]: false }));
        setStorageMetrics(getOfflineStorageMetrics());
        showToast('🗑️ ভিডিওটি অফলাইন ক্যাশ থেকে সরানো হয়েছে।');
      }
    } else {
      const res = saveVideoToOfflineCache(video);
      if (res.success) {
        setCachedVideoIds((prev) => ({ ...prev, [video.id]: true }));
        setStorageMetrics(getOfflineStorageMetrics());
        confetti({ particleCount: 30, spread: 50, origin: { y: 0.7 } });
        showToast('💾 ভিডিওটি অফলাইনে সেভ হয়েছে! ইন্টারনেট ছাড়াই চলবে।');
      } else {
        showToast(res.messageBn);
      }
    }
  };

  // Send Diamond Tip
  const handleSendGiftTip = () => {
    if (!currentVideo) return;
    if (userDiamonds < selectedGiftDiamonds) {
      Sound.playAlert();
      showToast(`পর্যাপ্ত ডায়মন্ড নেই! প্রয়োজন ${selectedGiftDiamonds}💎, আপনার আছে ${userDiamonds}💎`);
      return;
    }

    if (onDeductDiamonds) {
      onDeductDiamonds(selectedGiftDiamonds);
    }

    const res = sendDiamondGiftToVideo(currentVideo.id, selectedGiftDiamonds, currentUser);
    if (res.success && res.updatedVideo) {
      Sound.playRewardClaim();
      confetti({ particleCount: 65, spread: 70, origin: { y: 0.5 } });

      const updated = allVideos.map((v) => (v.id === currentVideo.id ? res.updatedVideo! : v));
      setAllVideos(updated);
      setIsGiftTipModalOpen(false);
      showToast(`🎉 ক্রিয়েটরকে ৳${res.earnedBDT.toFixed(2)} মূল্যের ${selectedGiftDiamonds}💎 পাঠানো হয়েছে!`);
    }
  };

  // Add Comment
  const handleAddComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentInput.trim() || !currentVideo) return;

    const check = scanContentForPolicyViolation(commentInput, '', []);
    if (!check.isSafe) {
      Sound.playAlert();
      showToast(check.reasonBn || 'অনুপযুক্ত শব্দ ফিল্টার করা হয়েছে!');
      return;
    }

    Sound.playClick();
    const vidId = currentVideo.id;
    const list = commentsMap[vidId] || [];
    setCommentsMap({
      ...commentsMap,
      [vidId]: [commentInput.trim(), ...list],
    });
    setCommentInput('');
    showToast('মন্তব্য যুক্ত হয়েছে ✓');
  };

  // Share Video
  const handleShare = () => {
    Sound.playClick();
    navigator.clipboard?.writeText(window.location.href);
    showToast('🔗 ভিডিও লিঙ্ক কপি হয়েছে! বন্ধুদের সাথে শেয়ার করুন।');
  };

  // Toggle Offline Simulation Mode Switch
  const handleToggleOfflineSimulation = () => {
    const next = !isOfflineMode;
    setIsOfflineMode(next);
    setOfflineSimulationMode(next);
    reloadFeeds();
    showToast(
      next
        ? '⚡ অফলাইন সিমুলেশন চালু: এখন আপনি ইন্টারনেট ছাড়া ভিডিও দেখার মোডে আছেন।'
        : '📶 অনলাইন মোড সক্রিয় করা হয়েছে।'
    );
  };

  if (!isOpen) return null;

  return (
    <div
      id="joy-ludo-shorts-fullscreen-container"
      className="fixed inset-0 z-50 bg-black/95 backdrop-blur-xl flex flex-col items-center justify-center select-none overflow-hidden"
      onWheel={handleWheel}
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
    >
      {/* Toast Notification */}
      {toastMsg && (
        <div className="absolute top-16 z-70 px-4 py-2 rounded-2xl bg-slate-900/95 border border-amber-400 text-amber-300 text-xs font-bold shadow-2xl animate-fade-in flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-amber-400 animate-spin" />
          <span>{toastMsg}</span>
        </div>
      )}

      {/* Floating Hearts from Double Taps */}
      {floatingHearts.map((heart) => (
        <div
          key={heart.id}
          className="absolute z-60 pointer-events-none animate-ping text-rose-500 font-bold"
          style={{ left: heart.x, top: heart.y }}
        >
          <Heart className="w-14 h-14 fill-rose-500 text-rose-500 drop-shadow-lg" />
        </div>
      ))}

      {/* Top Floating Control Bar */}
      <div className="absolute top-0 left-0 right-0 z-40 px-3 sm:px-6 py-2.5 bg-gradient-to-b from-black/90 via-black/50 to-transparent flex items-center justify-between text-white">
        {/* Left: Brand & Offline Badge */}
        <div className="flex items-center gap-2 sm:gap-3">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-amber-500 to-rose-600 flex items-center justify-center text-slate-950 font-black shadow-md">
            <Film className="w-4 h-4 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-xs sm:text-sm font-black text-white tracking-wide">
                লুডু ভিডিও (Video)
              </span>
              {isOfflineMode ? (
                <span className="px-2 py-0.2 rounded-full bg-cyan-500/30 text-cyan-300 text-[10px] font-black border border-cyan-400/50 flex items-center gap-1 animate-pulse">
                  <WifiOff className="w-3 h-3" /> অফলাইন মোড
                </span>
              ) : (
                <span className="px-2 py-0.2 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-bold border border-emerald-500/40 flex items-center gap-1">
                  <Wifi className="w-3 h-3" /> অনলাইন
                </span>
              )}
            </div>
            <span className="text-[10px] text-slate-400 hidden sm:inline">
              স্ক্রল করে আনলিমিটেড ভিডিও দেখুন • অফলাইনেও উপভোগযোগ্য
            </span>
          </div>
        </div>

        {/* Right Action Icons: Offline Vault, Sound, Studio & Close */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Offline Mode Toggle Button */}
          <button
            onClick={handleToggleOfflineSimulation}
            className={`px-2.5 py-1 rounded-xl text-[11px] font-black flex items-center gap-1 transition-all cursor-pointer border ${
              isOfflineMode
                ? 'bg-cyan-500 text-slate-950 border-cyan-400 shadow-md font-black'
                : 'bg-black/40 text-slate-300 border-white/20 hover:bg-slate-800'
            }`}
            title="অফলাইন মোড চালু/বন্ধ করুন"
          >
            {isOfflineMode ? <WifiOff className="w-3.5 h-3.5" /> : <Wifi className="w-3.5 h-3.5" />}
            <span className="hidden sm:inline">অফলাইন টেস্ট</span>
          </button>

          {/* Offline Storage Vault Manager */}
          <button
            onClick={() => {
              Sound.playClick();
              setIsOfflineVaultOpen(true);
            }}
            className="px-2.5 py-1 rounded-xl bg-black/40 hover:bg-slate-800 border border-white/20 text-amber-300 text-[11px] font-bold flex items-center gap-1 transition-all cursor-pointer"
            title="অফলাইনে সেভ করা ভিডিও তালিকা"
          >
            <HardDrive className="w-3.5 h-3.5" />
            <span>{storageMetrics.totalVideos} টি সেভড</span>
          </button>

          {/* Sound Toggle */}
          <button
            onClick={() => {
              Sound.playClick();
              setIsMuted(!isMuted);
            }}
            className="w-8 h-8 rounded-full bg-black/40 hover:bg-slate-800 border border-white/20 flex items-center justify-center text-white cursor-pointer"
            title={isMuted ? 'সাউন্ড আনমিউট' : 'সাউন্ড মিউট'}
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
          </button>

          {/* Close Player */}
          <button
            onClick={() => {
              Sound.playClick();
              onClose();
            }}
            className="w-8 h-8 rounded-full bg-rose-600/80 hover:bg-rose-600 text-white flex items-center justify-center transition-all cursor-pointer shadow-md"
            title="বন্ধ করুন"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Category Filter Chips (Top Overlay) */}
      <div className="absolute top-12 sm:top-14 z-40 flex items-center gap-1.5 px-3 py-1 overflow-x-auto max-w-full no-scrollbar">
        {[
          { id: 'all', label: '🔥 সব ট্রেন্ডিং' },
          { id: 'offline', label: `💾 অফলাইন (${storageMetrics.totalVideos})` },
          { id: 'funny', label: '😂 ফানি ভিডিও' },
          { id: 'education', label: '📚 এডু ও ট্রিকস' },
          { id: 'creative', label: '✨ সৃজনশীল' },
          { id: 'epic', label: '🏆 এপিক উইন' },
          { id: 'adda', label: '🎙️ লাইভ আড্ডা' },
        ].map((cat) => (
          <button
            key={cat.id}
            onClick={() => {
              Sound.playButtonTick();
              setActiveCategory(cat.id);
              setCurrentIndex(0);
              setVideoProgress(0);
            }}
            className={`px-3 py-1 rounded-full text-xs font-bold shrink-0 transition-all cursor-pointer backdrop-blur-md ${
              activeCategory === cat.id
                ? 'bg-amber-400 text-slate-950 font-black shadow-lg scale-102'
                : 'bg-black/60 text-slate-300 border border-white/10 hover:bg-slate-800'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Main TikTok Fullscreen Reel Video Container */}
      <div className="relative w-full max-w-[460px] h-[92vh] max-h-[820px] rounded-3xl bg-slate-950 border-2 border-slate-800 shadow-2xl overflow-hidden flex flex-col justify-between mt-10 sm:mt-12">
        {/* Video Canvas Stage / Visual Graphic Reel */}
        <div
          id="shorts-video-canvas"
          className="relative w-full h-full flex flex-col justify-between p-4 bg-gradient-to-b from-slate-950 via-slate-900 to-black overflow-hidden cursor-pointer"
          onClick={handleVideoAreaClick}
        >
          {/* Background Ambient Glow */}
          <div className="absolute inset-0 bg-radial from-amber-500/10 via-transparent to-black/80 pointer-events-none" />

          {/* Top Video Header in Stage */}
          <div className="z-20 flex items-center justify-between pt-2">
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded-full bg-red-600 text-white text-[10px] font-black uppercase tracking-wider animate-pulse shadow-md">
                SHORTS LIVE
              </span>
              <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 text-[10px] font-bold border border-amber-400/40">
                {currentVideo?.categoryLabelBn || '😂 ফানি'}
              </span>
            </div>

            {/* Offline Cache Status Badge */}
            {currentVideo && cachedVideoIds[currentVideo.id] && (
              <span className="px-2 py-0.5 rounded-full bg-cyan-500/30 text-cyan-300 text-[10px] font-bold border border-cyan-400/40 flex items-center gap-1">
                <Check className="w-3 h-3" /> অফলাইনে সংরক্ষিত
              </span>
            )}
          </div>

          {/* Center Ludo Interactive Animation Graphic */}
          <div className="z-10 flex flex-col items-center justify-center my-auto text-center space-y-4">
            {/* Animated Ludo Board Snippet Visual */}
            <div className="relative w-36 h-36 rounded-3xl bg-gradient-to-tr from-amber-600 via-rose-600 to-purple-700 p-1 shadow-2xl border-4 border-amber-300 transform hover:scale-105 transition-all">
              <div className="w-full h-full rounded-2xl bg-slate-950 flex flex-col items-center justify-center relative overflow-hidden">
                {/* Visual Category Emoji Character */}
                <span className="text-5xl animate-bounce">
                  {currentVideo?.videoType === 'funny_moment'
                    ? '🤣'
                    : currentVideo?.videoType === 'educational_guide' || currentVideo?.videoType === 'tutorial'
                    ? '🧠'
                    : currentVideo?.videoType === 'voice_adda_clip'
                    ? '🎤'
                    : currentVideo?.videoType === 'creative_good_content'
                    ? '✨'
                    : '🎲'}
                </span>

                {/* Floating Dice Roll Outcome Badge */}
                <div className="absolute top-2 right-2 px-2 py-0.5 rounded-full bg-yellow-400 text-slate-950 text-xs font-black shadow-md animate-pulse">
                  🎲 {currentVideo?.gameSnippet?.diceRoll || 6}
                </div>

                {/* Funny Comic / Strategy Bubble */}
                <div className="absolute bottom-1 px-2 py-0.5 bg-black/80 rounded-md text-[9px] font-bold text-amber-300 truncate max-w-[120px]">
                  {currentVideo?.videoType === 'funny_moment'
                    ? 'ও ভাই একি চাল! 🤣'
                    : currentVideo?.videoType === 'educational_guide'
                    ? 'সেফ জোন লক 🔒'
                    : 'জয় লুডু মোমেন্ট 🏆'}
                </div>
              </div>
            </div>

            {/* Video Highlight Details */}
            <div className="space-y-1 max-w-xs">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-black/70 backdrop-blur-md border border-slate-700 text-xs text-amber-200">
                <span>🏆 গুটি জয়: {currentVideo?.gameSnippet?.tokensCaptured || 2} টি</span>
                <span>•</span>
                <span>🪙 রিওয়ার্ড: +{(currentVideo?.gameSnippet?.coinsWon || 15000).toLocaleString()}</span>
              </div>
            </div>

            {/* Play/Pause Center Indicator (When Paused) */}
            {!isPlaying && (
              <div className="w-14 h-14 rounded-full bg-black/70 text-white flex items-center justify-center border border-white/30 shadow-2xl animate-fade-in">
                <Play className="w-7 h-7 ml-1 fill-white" />
              </div>
            )}
          </div>

          {/* Bottom Video Metadata Info */}
          <div className="z-20 space-y-2 bg-gradient-to-t from-black/95 via-black/70 to-transparent p-3 rounded-2xl">
            {/* Creator Profile line */}
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-full bg-amber-500/30 border-2 border-amber-400 flex items-center justify-center text-base shrink-0 shadow-md">
                {currentVideo?.creatorCountry === 'BD' ? '🇧🇩' : '👑'}
              </div>
              <div className="truncate">
                <div className="flex items-center gap-1.5">
                  <p className="text-xs font-black text-white truncate">{currentVideo?.creatorName}</p>
                  <span className="text-[9px] px-1.5 py-0.2 rounded bg-amber-400 text-slate-950 font-black">
                    ক্রিয়েটর
                  </span>
                </div>
                <p className="text-[10px] text-slate-400">
                  {currentVideo?.viewsCount?.toLocaleString()} ভিউ • {currentVideo?.durationSeconds}s
                </p>
              </div>
            </div>

            {/* Title & Description */}
            <p className="text-xs font-bold text-white line-clamp-2 leading-snug">
              {currentVideo?.title}
            </p>
            <p className="text-[11px] text-slate-300 line-clamp-1">
              {currentVideo?.description}
            </p>

            {/* Tags & Music Vinyl line */}
            <div className="flex items-center justify-between text-[10px] text-amber-300 pt-0.5">
              <div className="flex items-center gap-1.5 truncate max-w-[240px]">
                <Music className="w-3 h-3 animate-spin shrink-0" />
                <span className="truncate">
                  {currentVideo?.videoType === 'funny_moment'
                    ? '🎶 কমেডি লুডু রিমিক্স • জয় লুডু সাউন্ডট্র্যাক #১'
                    : '🎶 লুডু স্ট্র্যাটেজি মাস্টারক্লাস অডিও • অরিজিনাল'}
                </span>
              </div>
              <span className="font-mono text-emerald-400 font-bold shrink-0">
                ৳{currentVideo?.earningsBDT?.toFixed(2)} আয়
              </span>
            </div>
          </div>
        </div>

        {/* Right Floating TikTok Action Bar */}
        <div className="absolute right-2 bottom-16 z-30 flex flex-col items-center gap-3">
          {/* Like Button */}
          <div className="flex flex-col items-center">
            <button
              onClick={(e) => {
                e.stopPropagation();
                handleToggleLike();
              }}
              className={`w-11 h-11 rounded-full flex items-center justify-center shadow-xl transition-all active:scale-80 cursor-pointer ${
                currentVideo && likedMap[currentVideo.id]
                  ? 'bg-rose-600 text-white'
                  : 'bg-black/60 text-white border border-white/20 hover:bg-slate-800'
              }`}
            >
              <Heart
                className={`w-6 h-6 ${
                  currentVideo && likedMap[currentVideo.id] ? 'fill-white text-white' : ''
                }`}
              />
            </button>
            <span className="text-[10px] font-mono font-bold text-white mt-0.5 drop-shadow">
              {currentVideo?.likesCount || 0}
            </span>
          </div>

          {/* Comments Drawer Button */}
          <div className="flex flex-col items-center">
            <button
              onClick={(e) => {
                e.stopPropagation();
                Sound.playClick();
                setIsCommentDrawerOpen(true);
              }}
              className="w-11 h-11 rounded-full bg-black/60 hover:bg-slate-800 border border-white/20 flex items-center justify-center text-white shadow-xl transition-all active:scale-80 cursor-pointer"
            >
              <MessageCircle className="w-5 h-5 text-amber-300" />
            </button>
            <span className="text-[10px] font-mono font-bold text-white mt-0.5 drop-shadow">
              {(commentsMap[currentVideo?.id || '']?.length || currentVideo?.commentsCount || 0)}
            </span>
          </div>

          {/* Diamond Gift / Tip Button (১💎=৳১.০০) */}
          <div className="flex flex-col items-center">
            <button
              onClick={(e) => {
                e.stopPropagation();
                Sound.playClick();
                setIsGiftTipModalOpen(true);
              }}
              className="w-11 h-11 rounded-full bg-gradient-to-tr from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black flex items-center justify-center shadow-xl transition-all active:scale-80 cursor-pointer"
              title="ক্রিয়েটরকে ডায়মন্ড উপহার পাঠান"
            >
              <Gift className="w-5 h-5 text-slate-950 animate-bounce" />
            </button>
            <span className="text-[10px] font-bold text-amber-300 mt-0.5 drop-shadow">
              টিপস (৳)
            </span>
          </div>

          {/* Offline Download / Save Button */}
          <div className="flex flex-col items-center">
            <button
              onClick={(e) => {
                e.stopPropagation();
                if (currentVideo) handleToggleOfflineCache(currentVideo);
              }}
              className={`w-11 h-11 rounded-full flex items-center justify-center shadow-xl transition-all active:scale-80 cursor-pointer ${
                currentVideo && cachedVideoIds[currentVideo.id]
                  ? 'bg-cyan-500 text-slate-950 font-black'
                  : 'bg-black/60 text-cyan-300 border border-cyan-400/40 hover:bg-slate-800'
              }`}
              title={
                currentVideo && cachedVideoIds[currentVideo.id]
                  ? 'অফলাইন ক্যাশে সেভ করা আছে'
                  : 'ইন্টারনেট ছাড়া দেখতে অফলাইনে সেভ করুন'
              }
            >
              {currentVideo && cachedVideoIds[currentVideo.id] ? (
                <Check className="w-5 h-5" />
              ) : (
                <Download className="w-5 h-5" />
              )}
            </button>
            <span className="text-[9px] font-bold text-cyan-300 mt-0.5 drop-shadow">
              {currentVideo && cachedVideoIds[currentVideo.id] ? 'সেভড' : 'অফলাইন'}
            </span>
          </div>

          {/* Share Button */}
          <div className="flex flex-col items-center">
            <button
              onClick={(e) => {
                e.stopPropagation();
                handleShare();
              }}
              className="w-10 h-10 rounded-full bg-black/60 hover:bg-slate-800 border border-white/20 flex items-center justify-center text-white shadow-xl transition-all active:scale-80 cursor-pointer"
              title="শেয়ার করুন"
            >
              <Share2 className="w-4 h-4 text-emerald-400" />
            </button>
            <span className="text-[9px] font-mono text-slate-300 mt-0.5 drop-shadow">শেয়ার</span>
          </div>

          {/* Spinning Music Vinyl Disc */}
          <div className="w-9 h-9 rounded-full bg-slate-950 border-2 border-amber-400 flex items-center justify-center shadow-2xl animate-spin mt-1">
            <div className="w-3.5 h-3.5 rounded-full bg-amber-400" />
          </div>
        </div>

        {/* Video Progress Bar Line */}
        <div className="w-full h-1 bg-slate-800 relative z-30">
          <div
            className="h-full bg-gradient-to-r from-amber-400 to-rose-500 transition-all duration-200"
            style={{ width: `${videoProgress}%` }}
          />
        </div>
      </div>

      {/* Floating Up / Down Snap Navigation Buttons (Right of Screen on Desktop) */}
      <div className="hidden md:flex flex-col gap-2 absolute right-8 top-1/2 -translate-y-1/2 z-40">
        <button
          onClick={handleScrollPrev}
          className="w-10 h-10 rounded-2xl bg-slate-900/80 hover:bg-amber-500 hover:text-slate-950 text-white border border-slate-700 flex items-center justify-center transition-all cursor-pointer shadow-lg"
          title="পূর্ববর্তী ভিডিও (Up Arrow)"
        >
          <ChevronUp className="w-6 h-6" />
        </button>
        <div className="text-center text-[10px] font-mono text-slate-400 py-1">
          {currentIndex + 1}/{filteredVideos.length}
        </div>
        <button
          onClick={handleScrollNext}
          className="w-10 h-10 rounded-2xl bg-slate-900/80 hover:bg-amber-500 hover:text-slate-950 text-white border border-slate-700 flex items-center justify-center transition-all cursor-pointer shadow-lg"
          title="পরবর্তী ভিডিও (Down Arrow)"
        >
          <ChevronDown className="w-6 h-6" />
        </button>
      </div>

      {/* Slide-Up Comments Drawer / Bottom Sheet */}
      {isCommentDrawerOpen && (
        <div
          className="fixed inset-0 z-60 bg-black/75 backdrop-blur-sm flex justify-center items-end animate-fade-in"
          onClick={() => setIsCommentDrawerOpen(false)}
        >
          <div
            className="w-full max-w-[480px] bg-slate-950 border-t-2 border-amber-400 rounded-t-3xl p-4 text-white space-y-3 max-h-[60vh] flex flex-col justify-between"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Drawer Header */}
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="text-xs font-black text-amber-300 flex items-center gap-1.5">
                <MessageCircle className="w-4 h-4" />
                মন্তব্যসমূহ (
                {commentsMap[currentVideo?.id || '']?.length || currentVideo?.commentsCount || 0})
              </span>
              <button
                onClick={() => setIsCommentDrawerOpen(false)}
                className="w-7 h-7 rounded-full bg-slate-900 text-slate-400 hover:text-white flex items-center justify-center"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Comments List */}
            <div className="flex-1 overflow-y-auto space-y-2 pr-1 max-h-[220px]">
              {(commentsMap[currentVideo?.id || ''] || [
                'হাসতে হাসতে শেষ ভাই! 🤣',
                'অসাধারণ ভিডিও ❤️',
              ]).map((cmt, idx) => (
                <div
                  key={idx}
                  className="p-2.5 rounded-2xl bg-slate-900 border border-slate-800 text-xs space-y-1"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-amber-300 text-[11px]">লুডু ফ্যান #{idx + 1}</span>
                    <span className="text-[10px] text-slate-500">এখনই</span>
                  </div>
                  <p className="text-slate-200 text-[11px] leading-relaxed">{cmt}</p>
                </div>
              ))}
            </div>

            {/* Add Comment Input */}
            <form onSubmit={handleAddComment} className="flex items-center gap-2 pt-2 border-t border-slate-800">
              <input
                type="text"
                placeholder="একটি সুন্দর মন্তব্য লিখুন..."
                value={commentInput}
                onChange={(e) => setCommentInput(e.target.value)}
                className="flex-1 px-3.5 py-2 bg-slate-900 border border-slate-700 rounded-2xl text-xs text-white focus:outline-none focus:border-amber-400"
              />
              <button
                type="submit"
                className="p-2 rounded-2xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black cursor-pointer shadow-md"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Diamond Tip Gift Modal */}
      {isGiftTipModalOpen && currentVideo && (
        <div className="fixed inset-0 z-60 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in">
          <div className="w-full max-w-sm bg-slate-950 border-2 border-amber-400 rounded-3xl p-5 text-white text-center space-y-4 shadow-2xl">
            <div className="w-14 h-14 rounded-full bg-amber-500/20 border border-amber-400 text-amber-300 flex items-center justify-center mx-auto text-2xl">
              🎁
            </div>
            <div>
              <h3 className="text-base font-black text-white">ক্রিয়েটরকে ডায়মন্ড টিপস দিন</h3>
              <p className="text-xs text-slate-300 mt-0.5">
                ক্রিয়েটর: <strong>{currentVideo.creatorName}</strong>
              </p>
              <p className="text-[11px] text-amber-300 font-bold mt-0.5">
                (১ 💎 = ৳১.০০ সরাসরি বিকাশ/নগদ ইনকাম)
              </p>
            </div>

            {/* Amount Selectors */}
            <div className="grid grid-cols-4 gap-2">
              {[5, 10, 25, 50].map((amt) => (
                <button
                  key={amt}
                  type="button"
                  onClick={() => {
                    Sound.playButtonTick();
                    setSelectedGiftDiamonds(amt);
                  }}
                  className={`py-2 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                    selectedGiftDiamonds === amt
                      ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-md font-black'
                      : 'bg-slate-900 text-slate-300 border-slate-800'
                  }`}
                >
                  {amt} 💎
                </button>
              ))}
            </div>

            <div className="text-xs text-slate-400">
              আপনার ডায়মন্ড ব্যালেন্স: <strong className="text-amber-300">{userDiamonds} 💎</strong>
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsGiftTipModalOpen(false)}
                className="flex-1 py-2.5 rounded-2xl bg-slate-900 text-slate-300 text-xs font-bold"
              >
                বাতিল
              </button>
              <button
                type="button"
                onClick={handleSendGiftTip}
                className="flex-1 py-2.5 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 font-black text-xs shadow-md"
              >
                পাঠিয়ে দিন ({selectedGiftDiamonds}💎)
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Offline Video Storage Vault Modal */}
      {isOfflineVaultOpen && (
        <div className="fixed inset-0 z-60 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in">
          <div className="w-full max-w-md bg-slate-950 border-2 border-cyan-400 rounded-3xl p-5 text-white space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <HardDrive className="w-5 h-5 text-cyan-400" />
                <h3 className="text-sm font-black text-white">
                  💾 অফলাইন ভিডিও ভল্ট (Offline Video Cache)
                </h3>
              </div>
              <button
                onClick={() => setIsOfflineVaultOpen(false)}
                className="w-7 h-7 rounded-full bg-slate-900 text-slate-400 hover:text-white flex items-center justify-center"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Storage Metric Stats */}
            <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between text-xs">
              <div>
                <span className="text-slate-400 block text-[10px]">মোট সেভ করা ভিডিও</span>
                <strong className="text-base text-cyan-300 font-mono">
                  {storageMetrics.totalVideos} / {storageMetrics.cacheLimitVideos}
                </strong>
              </div>
              <div className="text-right">
                <span className="text-slate-400 block text-[10px]">ব্যবহৃত স্টোরেজ</span>
                <strong className="text-base text-amber-300 font-mono">
                  {storageMetrics.totalSizeMB} MB
                </strong>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              অফলাইনে আপনি পছন্দের যে-কোনো ভিডিও ডাউনলোড করে রাখতে পারবেন। ইন্টারনেট সংযোগ না থাকলেও এই ভিডিওগুলো মসৃণভাবে চলবে।
            </p>

            {/* List of Offline Cached Videos */}
            <div className="space-y-1.5 max-h-[190px] overflow-y-auto pr-1">
              {getOfflineCachedVideos().map((vid, idx) => (
                <div
                  key={vid.id}
                  className="p-2.5 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between text-xs"
                >
                  <div className="flex items-center gap-2 truncate">
                    <span className="text-base shrink-0">
                      {vid.videoType === 'funny_moment' ? '🤣' : vid.videoType === 'educational_guide' ? '🧠' : '✨'}
                    </span>
                    <div className="truncate">
                      <p className="font-bold text-white truncate text-[11px]">{vid.title}</p>
                      <p className="text-[10px] text-slate-400">{vid.categoryLabelBn}</p>
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      Sound.playClick();
                      removeVideoFromOfflineCache(vid.id);
                      reloadFeeds();
                      showToast('ভিডিও ডিলিট করা হয়েছে');
                    }}
                    className="p-1.5 rounded-xl bg-slate-950 text-rose-400 hover:bg-rose-950 hover:text-rose-300 transition-all ml-2 shrink-0"
                    title="ক্যাশ থেকে মুছুন"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>

            <button
              onClick={() => {
                Sound.playClick();
                setActiveCategory('offline');
                setIsOfflineVaultOpen(false);
                setCurrentIndex(0);
              }}
              className="w-full py-2.5 rounded-2xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-black text-xs shadow-md transition-all flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Play className="w-3.5 h-3.5 fill-slate-950" />
              <span>শুধুমাত্র অফলাইন ভিডিও প্লে করুন</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
