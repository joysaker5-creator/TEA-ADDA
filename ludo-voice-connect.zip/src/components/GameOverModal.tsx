import React from 'react';
import { Trophy, RotateCcw, Home, Award, Users2, Zap, ArrowRight, ShieldCheck, Sparkles, Gem } from 'lucide-react';
import { Player, GameMode, PlayerColor } from '../types';
import { COLOR_CONFIG } from '../utils/ludoConstants';
import { Sound } from '../utils/soundEffects';
import { AvatarDisplay } from './AvatarDisplay';
import { VipBadge } from './VipBadge';

interface GameOverModalProps {
  winner: Player;
  onRestart: () => void;
  onHome: () => void;
  prizeCoins: number;
  gameMode?: GameMode;
  teamWon?: 1 | 2;
  winningTeamPlayers?: Player[];
  onNextTournamentMatch?: () => void;
  isTournamentFinal?: boolean;
  xpEarned?: number;
  isEn?: boolean;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  winner,
  onRestart,
  onHome,
  prizeCoins,
  gameMode = 'vs-bot',
  teamWon,
  winningTeamPlayers = [],
  onNextTournamentMatch,
  isTournamentFinal,
  xpEarned = 400,
  isEn = true,
}) => {
  const config = (winner?.color && COLOR_CONFIG[winner.color]) || COLOR_CONFIG.red;
  const isTeamMode = gameMode === 'team-2v2';
  const isTournament = gameMode === 'tournament';
  const isQuickMatch = gameMode === 'quick-match';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in">
      <div
        id="game-over-modal"
        className="relative w-full max-w-md bg-white rounded-3xl p-6 shadow-2xl border-4 border-amber-400 border-b-8 border-b-amber-600 text-center text-slate-900 overflow-hidden"
      >
        {/* Animated Trophy Banner */}
        <div className="relative mx-auto mb-3.5 w-20 h-20 rounded-3xl bg-gradient-to-tr from-amber-500 to-yellow-300 border-b-4 border-amber-600 flex items-center justify-center shadow-xl">
          {isQuickMatch ? (
            <Zap className="w-11 h-11 text-amber-950 fill-yellow-200 animate-bounce" />
          ) : isTeamMode ? (
            <Users2 className="w-11 h-11 text-amber-950 animate-bounce" />
          ) : (
            <Trophy className="w-11 h-11 text-amber-950 fill-amber-300 animate-bounce" />
          )}
          <span className="absolute -top-2 -right-2 text-2xl">👑</span>
        </div>

        {/* Mode Tag */}
        <div className="mb-2">
          {isTeamMode ? (
            <span className="text-xs font-black text-indigo-800 uppercase tracking-wider bg-indigo-100 px-3 py-1 rounded-full border border-indigo-300 inline-flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-indigo-600" />
              {isEn ? 'Team 2v2 Winner!' : 'টিম প্লে (২ বনাম ২) বিজয়ী!'}
            </span>
          ) : isTournament ? (
            <span className="text-xs font-black text-rose-800 uppercase tracking-wider bg-rose-100 px-3 py-1 rounded-full border border-rose-300 inline-flex items-center gap-1">
              <Trophy className="w-3.5 h-3.5 text-rose-600" />
              {isTournamentFinal
                ? (isEn ? 'Grand Tournament Champion!' : 'গ্র্যান্ড টুর্নামেন্ট চ্যাম্পিয়ন!')
                : (isEn ? 'Round Won & Advanced!' : 'রাউন্ড সম্পন্ন ও জয়লাভ!')}
            </span>
          ) : isQuickMatch ? (
            <span className="text-xs font-black text-amber-900 uppercase tracking-wider bg-amber-200 px-3 py-1 rounded-full border border-amber-400 inline-flex items-center gap-1">
              <Zap className="w-3.5 h-3.5 fill-amber-600" />
              {isEn ? 'Quick Match Victory' : 'কুইক ম্যাচ বিজয়'}
            </span>
          ) : (
            <span className="text-xs font-black text-amber-700 uppercase tracking-widest bg-amber-100 px-3 py-1 rounded-full border border-amber-300 inline-block">
              {isEn ? 'Congratulations! Match Ended' : 'অভিনন্দন! খেলা সমাপ্ত'}
            </span>
          )}
        </div>

        {/* Title Announcement */}
        <h2 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
          {isTeamMode ? (
            isEn ? `Team ${teamWon || 1} Wins!` : `দল ${teamWon || 1} বিজয়ী হয়েছে!`
          ) : (
            isEn ? `${winner.name} Wins!` : `${winner.name} জয়ী হয়েছেন!`
          )}
        </h2>

        {/* Winner or Team Display */}
        {isTeamMode && winningTeamPlayers.length > 0 ? (
          <div className="mt-3 p-3 rounded-2xl bg-indigo-50/80 border-2 border-indigo-200">
            <span className="text-[11px] font-black text-indigo-900 uppercase tracking-wider block mb-2">
              {isEn ? 'Winning Team Partnership' : 'যৌথ বিজয়ী পার্টনারশিপ'}
            </span>
            <div className="flex items-center justify-center gap-3">
              {winningTeamPlayers.map((p, idx) => (
                <div
                  key={p.color}
                  className="flex items-center gap-2 px-2.5 py-1.5 rounded-xl bg-white border border-indigo-200 shadow-sm"
                >
                  <AvatarDisplay avatar={p.avatar} size={36} showBadge={true} badgeText="1st" vipFrameId={p.vipFrameId} />
                  <div className="text-left">
                    <div className="flex items-center gap-1">
                      <span className="text-xs font-black text-slate-900 block leading-tight">
                        {p.name}
                      </span>
                      {p.isVip && (
                        <VipBadge badgeId={p.vipBadge || 'vip_crown'} size="sm" showText={false} />
                      )}
                    </div>
                    <span
                      className="text-[10px] font-extrabold"
                      style={{ color: ((p.color && COLOR_CONFIG[p.color]) || COLOR_CONFIG.red).hex }}
                    >
                      {((p.color && COLOR_CONFIG[p.color]) || COLOR_CONFIG.red).name}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div
            className="mt-3 p-3 rounded-2xl border-2 flex items-center justify-center gap-3"
            style={{ backgroundColor: config.bgHex, borderColor: config.borderHex }}
          >
            {winner.avatar ? (
              <AvatarDisplay avatar={winner.avatar} size={44} showBadge={true} badgeText="1st" vipFrameId={winner.vipFrameId} />
            ) : (
              <span className="text-2xl">{config.avatar}</span>
            )}
            <div className="flex flex-col text-left">
              <div className="flex items-center gap-1.5">
                <span className="font-black text-base text-slate-900 leading-tight">
                  {winner.name}
                </span>
                {winner.isVip && (
                  <VipBadge badgeId={winner.vipBadge || 'vip_crown'} size="sm" />
                )}
              </div>
              <span className="font-bold text-xs" style={{ color: config.borderHex }}>
                {config.name} Team Wins 🏆
              </span>
            </div>
          </div>
        )}

        {/* Prize Pool & XP Payout */}
        <div className="mt-3.5 grid grid-cols-2 gap-2">
          <div className="p-2.5 rounded-2xl bg-amber-50 border-2 border-dashed border-amber-400 flex flex-col items-center justify-center shadow-xs">
            <span className="text-[11px] font-black text-amber-900 flex items-center gap-1">
              <Award className="w-3.5 h-3.5 text-amber-600" />
              {isEn ? 'Coin Bonus 🪙' : 'কয়েন বোনাস 🪙'}
            </span>
            <span className="text-sm sm:text-base font-black text-amber-700 mt-0.5">
              +{prizeCoins.toLocaleString('en-US')} {isEn ? 'Coins' : 'কয়েন বোনাস'}
            </span>
          </div>

          <div className="p-2.5 rounded-2xl bg-purple-50 border-2 border-dashed border-purple-300 flex flex-col items-center justify-center shadow-xs">
            <span className="text-[11px] font-black text-purple-900 flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-purple-600" />
              {isEn ? 'Experience (XP)' : 'অর্জিত অভিজ্ঞতা (XP)'}
            </span>
            <span className="text-sm sm:text-base font-black text-purple-700 mt-0.5">
              +{xpEarned.toLocaleString('en-US')} XP
            </span>
          </div>
        </div>

        {/* Zero-money Virtual Coin Bonus Guarantee Badge */}
        <div className="mt-3 py-1.5 px-3 rounded-xl bg-slate-100 border border-slate-200 flex items-center justify-center gap-1.5 text-[10px] text-slate-600 font-bold">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
          <span>{isEn ? 'Fair play virtual entertainment • Free coin rewards applied' : 'লুডু খেলার জন্য কোনো অর্থ দেওয়া বা নেওয়া হয় না • খেলায় জিতলে ফ্রি কয়েন বোনাস প্রযোজ্য'}</span>
        </div>

        {/* Action Buttons */}
        <div className="mt-5 flex flex-col sm:flex-row gap-2">
          {isTournament && onNextTournamentMatch && !isTournamentFinal ? (
            <button
              id="tournament-next-round-btn"
              onClick={() => {
                Sound.playClick();
                onNextTournamentMatch();
              }}
              className="flex-1 py-3 px-4 rounded-2xl bg-gradient-to-r from-red-500 to-rose-600 hover:from-red-600 hover:to-rose-700 text-white font-black text-xs uppercase tracking-wider shadow-lg border-b-4 border-red-800 active:translate-y-0.5 active:border-b-0 transition-all flex items-center justify-center gap-2"
            >
              <span>{isEn ? 'Play Next Round' : 'পরবর্তী রাউন্ড খেলুন'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          ) : (
            <button
              id="play-again-btn"
              onClick={() => {
                Sound.playClick();
                onRestart();
              }}
              className="flex-1 py-3 px-4 rounded-2xl bg-red-500 hover:bg-red-600 text-white font-black text-xs uppercase tracking-wider shadow-lg border-b-4 border-red-700 active:translate-y-0.5 active:border-b-0 transition-all flex items-center justify-center gap-2"
            >
              <RotateCcw className="w-4 h-4" />
              <span>{isEn ? 'Play Again' : 'আবার খেলুন'}</span>
            </button>
          )}

          <button
            id="back-to-home-btn"
            onClick={() => {
              Sound.playClick();
              onHome();
            }}
            className="px-4 py-3 rounded-2xl bg-amber-100 hover:bg-amber-200 text-amber-950 font-black text-xs border-b-4 border-amber-300 active:translate-y-0.5 active:border-b-0 transition-all flex items-center justify-center gap-1.5"
          >
            <Home className="w-4 h-4" />
            <span>{isEn ? 'Home Menu' : 'হোম মেনু'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
