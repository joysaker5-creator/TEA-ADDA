import React, { useState } from 'react';
import {
  Sparkles,
  Award,
  DollarSign,
  TrendingUp,
  Wallet,
  ArrowUpRight,
  Calculator,
  Gift,
  Flame,
  CheckCircle2,
  Users,
  ShieldCheck,
  Megaphone,
} from 'lucide-react';
import {
  UserProfile,
  CreatorMonetizationProfile,
  WithdrawalTransaction,
  VideoContent,
} from '../../types';
import {
  CREATOR_MONETIZATION_CATEGORIES,
  MONTHLY_CREATOR_LEADERBOARD,
  calculateEstimatedEarnings,
  claimCreatorQualityBonus,
} from '../../utils/videoMonetizationService';
import { Sound } from '../../utils/soundEffects';
import confetti from 'canvas-confetti';

interface CreatorMonetizationTabProps {
  currentUser: UserProfile;
  creatorProfile: CreatorMonetizationProfile;
  withdrawals: WithdrawalTransaction[];
  withdrawAmount: number;
  withdrawMethod: 'bkash' | 'nagad' | 'rocket' | 'bank';
  withdrawPhone: string;
  withdrawMsg: { success: boolean; text: string } | null;
  onWithdrawAmountChange: (amt: number) => void;
  onWithdrawMethodChange: (meth: 'bkash' | 'nagad' | 'rocket' | 'bank') => void;
  onWithdrawPhoneChange: (phone: string) => void;
  onWithdrawalSubmit: (e: React.FormEvent) => void;
  onOpenAdvertiserModal?: () => void;
  onBonusClaimed?: (newBalance: number) => void;
}

export const CreatorMonetizationTab: React.FC<CreatorMonetizationTabProps> = ({
  currentUser,
  creatorProfile,
  withdrawals,
  withdrawAmount,
  withdrawMethod,
  withdrawPhone,
  withdrawMsg,
  onWithdrawAmountChange,
  onWithdrawMethodChange,
  onWithdrawPhoneChange,
  onWithdrawalSubmit,
  onOpenAdvertiserModal,
  onBonusClaimed,
}) => {
  // Earnings Calculator State
  const [calcCategory, setCalcCategory] = useState<VideoContent['videoType']>('funny_moment');
  const [calcViews, setCalcViews] = useState<number>(25000);
  const [calcLikes, setCalcLikes] = useState<number>(1200);
  const [calcDiamonds, setCalcDiamonds] = useState<number>(50);

  const calcResult = calculateEstimatedEarnings(
    calcCategory,
    calcViews,
    calcLikes,
    calcDiamonds
  );

  const handleClaimBonus = (amt: number, reason: string) => {
    Sound.playRewardClaim();
    confetti({ particleCount: 50, spread: 60, origin: { y: 0.6 } });
    const res = claimCreatorQualityBonus(currentUser.id, amt, reason);
    if (res.success && onBonusClaimed) {
      onBonusClaimed(res.newBalanceBDT);
    }
  };

  return (
    <div className="space-y-5 max-w-3xl mx-auto animate-fade-in text-slate-200">
      {/* 6 Income Streams Banner */}
      <div className="p-4 rounded-3xl bg-gradient-to-r from-amber-600/90 via-rose-600/90 to-purple-700/90 border border-amber-400/40 shadow-xl space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-amber-300 animate-pulse" />
            <h3 className="text-sm font-black text-white">
              লুডু ক্রিয়েটরদের জন্য নিশ্চিত আয়ের ৬টি সুযোগ (Creator Economy)
            </h3>
          </div>
          <span className="px-2.5 py-0.5 rounded-full bg-amber-400 text-slate-950 text-[10px] font-black uppercase">
            Active in BD 🇧🇩
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
          <div className="p-2.5 rounded-2xl bg-black/40 border border-white/10 backdrop-blur-sm">
            <span className="font-black text-amber-300 block mb-0.5">১. ভিউ রেভিনিউ</span>
            <p className="text-[11px] text-slate-200">প্রতি ১,০০০ ভিউয়ে ৳৮০ - ৳১২০ নগদ আয়</p>
          </div>
          <div className="p-2.5 rounded-2xl bg-black/40 border border-white/10 backdrop-blur-sm">
            <span className="font-black text-rose-300 block mb-0.5">২. ফ্যান ডায়মন্ড টিপস</span>
            <p className="text-[11px] text-slate-200">১💎 = ৳১.০০ সরাসরি বিকাশ/নগদে</p>
          </div>
          <div className="p-2.5 rounded-2xl bg-black/40 border border-white/10 backdrop-blur-sm">
            <span className="font-black text-emerald-300 block mb-0.5">৩. কোয়ালিটি ক্যাশ বোনাস</span>
            <p className="text-[11px] text-slate-200">১০০০ লাইকে ৳২৫০ স্পেশাল বোনাস</p>
          </div>
          <div className="p-2.5 rounded-2xl bg-black/40 border border-white/10 backdrop-blur-sm">
            <span className="font-black text-blue-300 block mb-0.5">৪. মাসিক প্রাইজপুল</span>
            <p className="text-[11px] text-slate-200">টপ ক্রিয়েটরদের জন্য ৳৫০,০০০ ফান্ড</p>
          </div>
          <div className="p-2.5 rounded-2xl bg-black/40 border border-white/10 backdrop-blur-sm">
            <span className="font-black text-purple-300 block mb-0.5">৫. ব্র্যান্ড স্পন্সরশিপ</span>
            <p className="text-[11px] text-slate-200">বিজ্ঞাপন আয়ের ৬০% ক্রিয়েটর শেয়ার</p>
          </div>
          <div className="p-2.5 rounded-2xl bg-black/40 border border-white/10 backdrop-blur-sm">
            <span className="font-black text-teal-300 block mb-0.5">৬. ইনস্ট্যান্ট ক্যাশআউট</span>
            <p className="text-[11px] text-slate-200">সর্বনিম্ন ৳১০০ হলেই উত্তোলন</p>
          </div>
        </div>
      </div>

      {/* Earnings & Stats Overview Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-3.5 rounded-2xl bg-slate-900 border border-amber-500/40 text-center space-y-1">
          <span className="text-[10px] font-bold text-slate-400 uppercase">উত্তোলনযোগ্য ব্যালেন্স</span>
          <p className="text-xl font-mono font-black text-amber-300">
            ৳{creatorProfile.balanceBDT.toFixed(2)}
          </p>
          <span className="text-[9px] text-emerald-400 font-bold">ইনস্ট্যান্ট ক্যাশআউট</span>
        </div>

        <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 text-center space-y-1">
          <span className="text-[10px] font-bold text-slate-400 uppercase">মোট ইনকাম</span>
          <p className="text-xl font-mono font-black text-white">
            ৳{creatorProfile.totalEarnedBDT.toFixed(2)}
          </p>
          <span className="text-[9px] text-slate-400">সর্বমোট অর্জিত</span>
        </div>

        <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 text-center space-y-1">
          <span className="text-[10px] font-bold text-slate-400 uppercase">মোট ভিডিও ভিউ</span>
          <p className="text-xl font-mono font-black text-white">
            {creatorProfile.totalViews.toLocaleString()}
          </p>
          <span className="text-[9px] text-amber-400 font-bold">৳০.১০ / ভিউ গড়ে</span>
        </div>

        <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 text-center space-y-1">
          <span className="text-[10px] font-bold text-slate-400 uppercase">ডায়মন্ড টিপস</span>
          <p className="text-xl font-mono font-black text-amber-400">
            {creatorProfile.totalDiamondsGifted} 💎
          </p>
          <span className="text-[9px] text-emerald-400 font-bold">১ 💎 = ৳১.০০</span>
        </div>
      </div>

      {/* Special Content Categories Earning Breakdown */}
      <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 space-y-3">
        <h4 className="text-xs font-black text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
          <Award className="w-4 h-4 text-amber-400" />
          ক্যাটাগরি অনুযায়ী বিশেষ ইনকাম ও রিওয়ার্ড ফান্ড
        </h4>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
          {/* Funny Video Card */}
          <div className="p-3 rounded-2xl bg-gradient-to-b from-amber-950/40 to-slate-950 border border-amber-500/40 space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-black text-amber-300">😂 ফানি ও কমেডি ভিডিও</span>
              <span className="px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 text-[9px] font-bold">
                ৳১০০/1k ভিউ
              </span>
            </div>
            <p className="text-[11px] text-slate-300">
              মজার চালের ভুল ও কমেডি ডায়লগে ভাইরাল হয়ে ৫০০ লাইকে ৳১০০ নগদ ক্যাশ বোনাস!
            </p>
            <div className="pt-1 flex items-center justify-between text-[10px]">
              <span className="text-slate-400">আপনার আয়:</span>
              <span className="font-mono font-black text-amber-300">
                ৳{(creatorProfile.funnyVideosEarnedBDT || 350.0).toFixed(2)}
              </span>
            </div>
          </div>

          {/* Educational Guide Card */}
          <div className="p-3 rounded-2xl bg-gradient-to-b from-blue-950/40 to-slate-950 border border-blue-500/40 space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-black text-blue-300">📚 শিক্ষামূলক মাস্টারক্লাস</span>
              <span className="px-1.5 py-0.5 rounded bg-blue-500/20 text-blue-300 text-[9px] font-bold">
                ৳১২০/1k ভিউ
              </span>
            </div>
            <p className="text-[11px] text-slate-300">
              লুডুর চাল, সেফ জোন ট্রিকস ও টুর্নামেন্ট জেতার স্ট্র্যাটেজি শিখিয়ে প্রিমিয়াম আয় করুন।
            </p>
            <div className="pt-1 flex items-center justify-between text-[10px]">
              <span className="text-slate-400">আপনার আয়:</span>
              <span className="font-mono font-black text-blue-300">
                ৳{(creatorProfile.educationalVideosEarnedBDT || 280.0).toFixed(2)}
              </span>
            </div>
          </div>

          {/* Good Creative Content Card */}
          <div className="p-3 rounded-2xl bg-gradient-to-b from-purple-950/40 to-slate-950 border border-purple-500/40 space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-black text-purple-300">✨ ভালো ও সৃজনশীল কনটেন্ট</span>
              <span className="px-1.5 py-0.5 rounded bg-purple-500/20 text-purple-300 text-[9px] font-bold">
                ৳৯০/1k ভিউ
              </span>
            </div>
            <p className="text-[11px] text-slate-300">
              সুস্থ বিনোদন, গঠনমূলক আড্ডা ও অনুপ্রেরণামূলক গেমিং কনটেন্টে বিশেষ স্টার ফান্ড।
            </p>
            <div className="pt-1 flex items-center justify-between text-[10px]">
              <span className="text-slate-400">আপনার আয়:</span>
              <span className="font-mono font-black text-purple-300">
                ৳{(creatorProfile.creativeVideosEarnedBDT || 220.0).toFixed(2)}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Interactive Creator Earnings Calculator */}
      <div className="p-4 rounded-3xl bg-slate-900 border border-amber-500/30 space-y-3 shadow-lg">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
          <div className="flex items-center gap-2">
            <Calculator className="w-4 h-4 text-amber-400" />
            <h4 className="text-xs font-black text-white">
              💰 সম্ভাব্য আয় ক্যালকুলেটর (Earnings Estimator)
            </h4>
          </div>
          <span className="text-[10px] text-slate-400">হিসাব করুন কত টাকা আয় হতে পারে</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-3">
            {/* Category selection */}
            <div>
              <label className="text-[11px] font-bold text-slate-300 block mb-1">ভিডিও ক্যাটাগরি:</label>
              <select
                value={calcCategory}
                onChange={(e) => setCalcCategory(e.target.value as any)}
                className="w-full px-3 py-1.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-amber-400"
              >
                <option value="funny_moment">😂 ফানি ও কমেডি ভিডিও (RPM ৳১০০)</option>
                <option value="educational_guide">📚 শিক্ষামূলক ও স্ট্র্যাটেজি ভিডিও (RPM ৳১২০)</option>
                <option value="tutorial">💡 টিউটোরিয়াল ও ট্রিকস (RPM ৳১১০)</option>
                <option value="creative_good_content">✨ ভালো ও সৃজনশীল কনটেন্ট (RPM ৳৯০)</option>
                <option value="epic_win">🔥 এপিক জয় ও টুর্নামেন্ট উইন (RPM ৳৮৫)</option>
                <option value="voice_adda_clip">🎤 লাইভ আড্ডা ও গান (RPM ৳৯৫)</option>
              </select>
            </div>

            {/* Views Slider */}
            <div>
              <div className="flex justify-between text-[11px] mb-1">
                <span className="text-slate-300">আনুমানিক ভিউ:</span>
                <span className="font-mono font-bold text-amber-300">{calcViews.toLocaleString()} Views</span>
              </div>
              <input
                type="range"
                min={1000}
                max={100000}
                step={1000}
                value={calcViews}
                onChange={(e) => setCalcViews(parseInt(e.target.value))}
                className="w-full accent-amber-500"
              />
            </div>

            {/* Likes Slider */}
            <div>
              <div className="flex justify-between text-[11px] mb-1">
                <span className="text-slate-300">আনুমানিক লাইক (বোনাস ট্রিগার):</span>
                <span className="font-mono font-bold text-rose-300">{calcLikes.toLocaleString()} Likes</span>
              </div>
              <input
                type="range"
                min={50}
                max={5000}
                step={50}
                value={calcLikes}
                onChange={(e) => setCalcLikes(parseInt(e.target.value))}
                className="w-full accent-rose-500"
              />
            </div>

            {/* Diamond Tips Slider */}
            <div>
              <div className="flex justify-between text-[11px] mb-1">
                <span className="text-slate-300">ফ্যানদের ডায়মন্ড গিফট:</span>
                <span className="font-mono font-bold text-emerald-300">{calcDiamonds} 💎</span>
              </div>
              <input
                type="range"
                min={0}
                max={500}
                step={10}
                value={calcDiamonds}
                onChange={(e) => setCalcDiamonds(parseInt(e.target.value))}
                className="w-full accent-emerald-500"
              />
            </div>
          </div>

          {/* Calculator Output Card */}
          <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex flex-col justify-between space-y-2">
            <div>
              <span className="text-[10px] font-black text-slate-400 uppercase block">আপনার মোট সম্ভাব্য আয়</span>
              <p className="text-2xl font-mono font-black text-emerald-400 mt-1">
                ৳{calcResult.totalEstimatedBDT.toFixed(2)}
              </p>
              <span className="text-[10px] text-slate-400">সরাসরি বিকাশ / নগদ / রকেটে ক্যাশ আউটযোগ্য</span>
            </div>

            <div className="space-y-1 text-[11px] border-t border-slate-800 pt-2 text-slate-300">
              <div className="flex justify-between">
                <span>ভিউ রেভিনিউ ({calcResult.rpmRate} ৳/1k):</span>
                <span className="font-mono font-bold text-white">৳{calcResult.viewEarningsBDT.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span>কোয়ালিটি ক্যাশ বোনাস:</span>
                <span className="font-mono font-bold text-amber-300">৳{calcResult.qualityBonusBDT.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span>ডায়মন্ড গিফট টিপস (১💎=৳১):</span>
                <span className="font-mono font-bold text-emerald-300">৳{calcResult.tipsEarningsBDT.toFixed(2)}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Monthly Creator Leaderboard & Prize Pool */}
      <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 space-y-3">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
          <div className="flex items-center gap-2">
            <Award className="w-4 h-4 text-amber-400" />
            <h4 className="text-xs font-black text-white">
              🏆 মাসিক টপ ক্রিয়েটর প্রাইজপুল (৳৫০,০০০ নগদ পুরস্কার)
            </h4>
          </div>
          <span className="text-[10px] text-emerald-400 font-bold">এই মাসের লিডারবোর্ড</span>
        </div>

        <div className="space-y-1.5 max-h-[190px] overflow-y-auto pr-1">
          {MONTHLY_CREATOR_LEADERBOARD.map((creator) => (
            <div
              key={creator.rank}
              className="p-2.5 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between text-xs"
            >
              <div className="flex items-center gap-2.5 truncate">
                <span className="w-6 h-6 rounded-full bg-slate-900 border border-slate-700 flex items-center justify-center text-xs font-black text-amber-300 shrink-0">
                  #{creator.rank}
                </span>
                <span className="text-base shrink-0">{creator.avatarIcon}</span>
                <div className="truncate">
                  <span className="font-bold text-white block truncate">{creator.creatorName}</span>
                  <span className="text-[10px] text-slate-400">{creator.categoryBn}</span>
                </div>
              </div>

              <div className="text-right shrink-0 ml-2">
                <span className="font-mono font-black text-amber-400 block">{creator.badge}</span>
                <span className="text-[10px] text-slate-400 font-mono">
                  {creator.totalViews.toLocaleString()} ভিউ • ৳{creator.earningsBDT.toLocaleString()}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Withdrawal Request Form */}
      <div className="p-5 rounded-3xl bg-slate-900 border border-slate-800 space-y-4 shadow-xl">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h3 className="text-sm font-black text-white flex items-center gap-2">
            <Wallet className="w-4 h-4 text-emerald-400" />
            টাকা উত্তোলন করুন (Instant Cashout to bKash / Nagad / Rocket)
          </h3>
          <span className="text-xs text-slate-400">সর্বনিম্ন উত্তোলন: ৳১০০</span>
        </div>

        <form onSubmit={onWithdrawalSubmit} className="space-y-4">
          {/* Payment Method Selector */}
          <div>
            <label className="text-xs font-bold text-slate-300 block mb-1.5">
              পেমেন্ট মেথড নির্বাচন করুন:
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {[
                { id: 'bkash', label: 'বিকাশ (bKash)', icon: '🌸' },
                { id: 'nagad', label: 'নগদ (Nagad)', icon: '🟠' },
                { id: 'rocket', label: 'রকেট (Rocket)', icon: '🚀' },
                { id: 'bank', label: 'ব্যাংক ট্রান্সফার', icon: '🏦' },
              ].map((meth) => (
                <button
                  key={meth.id}
                  type="button"
                  onClick={() => {
                    Sound.playButtonTick();
                    onWithdrawMethodChange(meth.id as any);
                  }}
                  className={`p-2.5 rounded-xl border text-xs font-bold transition-all cursor-pointer text-center ${
                    withdrawMethod === meth.id
                      ? 'bg-emerald-500 text-slate-950 border-emerald-400 shadow-md font-black'
                      : 'bg-slate-950 text-slate-300 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <span className="mr-1">{meth.icon}</span>
                  <span>{meth.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Amount and Mobile Number Input */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-bold text-slate-300 block mb-1">
                উত্তোলনের পরিমাণ (টাকা ৳):
              </label>
              <input
                type="number"
                min={100}
                max={creatorProfile.balanceBDT}
                value={withdrawAmount}
                onChange={(e) => onWithdrawAmountChange(Math.max(0, parseInt(e.target.value) || 0))}
                className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs font-mono font-bold text-amber-300 focus:outline-none focus:border-emerald-400"
              />
            </div>
            <div>
              <label className="text-xs font-bold text-slate-300 block mb-1">
                {withdrawMethod === 'bank' ? 'ব্যাংক একাউন্ট নম্বর:' : 'মোবাইল নম্বর (Personal):'}
              </label>
              <input
                type="text"
                placeholder="যেমন: 01711223344"
                value={withdrawPhone}
                onChange={(e) => onWithdrawPhoneChange(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs font-mono font-bold text-white focus:outline-none focus:border-emerald-400"
              />
            </div>
          </div>

          {withdrawMsg && (
            <div
              className={`p-3 rounded-2xl border text-xs font-bold text-center ${
                withdrawMsg.success
                  ? 'bg-emerald-950/70 border-emerald-500 text-emerald-300'
                  : 'bg-rose-950/70 border-rose-500 text-rose-300'
              }`}
            >
              {withdrawMsg.text}
            </div>
          )}

          <button
            type="submit"
            disabled={creatorProfile.balanceBDT < 100}
            className="w-full py-3 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs shadow-lg active:scale-98 transition-all cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            <ArrowUpRight className="w-4 h-4" />
            <span>উত্তোলন নিশ্চিত করুন (Instant Cashout)</span>
          </button>
        </form>
      </div>

      {/* Transactions History */}
      <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 space-y-2.5">
        <span className="text-xs font-black text-slate-300 uppercase tracking-wider block">
          উত্তোলন হিস্টোরি ({withdrawals.length})
        </span>
        <div className="space-y-1.5 max-h-[130px] overflow-y-auto pr-1">
          {withdrawals.map((tx) => (
            <div
              key={tx.id}
              className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between text-xs"
            >
              <div>
                <span className="font-bold text-white uppercase">{tx.method}</span>
                <span className="text-slate-400 text-[11px] ml-2">({tx.accountNumber})</span>
                <div className="text-[10px] text-slate-500 font-mono">TxID: {tx.txId}</div>
              </div>
              <div className="text-right">
                <span className="font-mono font-black text-emerald-400">
                  -৳{tx.amountBDT.toFixed(2)}
                </span>
                <div className="text-[10px] text-emerald-300 font-bold">সফল (Completed) ✓</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Advertiser Callout */}
      {onOpenAdvertiserModal && (
        <div className="p-4 rounded-3xl bg-gradient-to-r from-amber-950/70 via-slate-900 to-orange-950/70 border-2 border-amber-500/50 flex items-center justify-between gap-3 shadow-lg">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-300 flex items-center justify-center border border-amber-400/40 shrink-0">
              <Megaphone className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-black text-white">বিজ্ঞাপন ও ব্র্যান্ড স্পনসরশিপ দিতে চান?</h4>
              <p className="text-[11px] text-amber-200">
                জয় লুডু ভিডিও ফিড ও টুর্নামেন্টে বিজ্ঞাপন প্রচারের জন্য সরাসরি আমাদের সাথে যোগাযোগ করুন।
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              Sound.playClick();
              onOpenAdvertiserModal();
            }}
            className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black text-xs shrink-0 shadow-md cursor-pointer transition-all active:scale-95"
          >
            বিজ্ঞাপন দিন ❯
          </button>
        </div>
      )}
    </div>
  );
};
