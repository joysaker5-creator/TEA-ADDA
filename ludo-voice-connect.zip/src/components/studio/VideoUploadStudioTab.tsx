import React from 'react';
import {
  Video,
  Upload,
  ShieldAlert,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  Sparkles,
  Award,
} from 'lucide-react';
import { VideoContent, PolicyScanResult } from '../../types';
import { CREATOR_MONETIZATION_CATEGORIES } from '../../utils/videoMonetizationService';
import { Sound } from '../../utils/soundEffects';

interface VideoUploadStudioTabProps {
  isAdultUser: boolean;
  videoTitle: string;
  videoDesc: string;
  videoTags: string;
  videoType: VideoContent['videoType'];
  scanResult: PolicyScanResult | null;
  uploadSuccessMsg: string | null;
  onVideoTitleChange: (val: string) => void;
  onVideoDescChange: (val: string) => void;
  onVideoTagsChange: (val: string) => void;
  onVideoTypeChange: (val: VideoContent['videoType']) => void;
  onSubmit: (e: React.FormEvent) => void;
}

export const VideoUploadStudioTab: React.FC<VideoUploadStudioTabProps> = ({
  isAdultUser,
  videoTitle,
  videoDesc,
  videoTags,
  videoType,
  scanResult,
  uploadSuccessMsg,
  onVideoTitleChange,
  onVideoDescChange,
  onVideoTagsChange,
  onVideoTypeChange,
  onSubmit,
}) => {
  if (!isAdultUser) {
    return (
      <div className="max-w-2xl mx-auto space-y-4 animate-fade-in">
        <div className="p-6 rounded-3xl bg-slate-900 border-2 border-rose-500/60 text-center space-y-4 shadow-xl">
          <div className="w-16 h-16 rounded-full bg-rose-500/20 text-rose-400 border border-rose-400/40 flex items-center justify-center mx-auto">
            <ShieldAlert className="w-8 h-8" />
          </div>
          <div>
            <span className="px-3 py-0.5 rounded-full bg-rose-500/20 text-rose-300 text-[10px] font-black uppercase">
              🔞 বয়স সীমা সতর্কতা (18+ Mandatory)
            </span>
            <h3 className="text-base font-black text-white mt-2">
              ১৮ বছরের নিচে কেউ ভিডিও আপলোড করতে পারবে না
            </h3>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed max-w-md mx-auto">
            শিশু ও কিশোরদের সুরক্ষার্থে সরকারি ও ডিজিটাল নিরাপত্তা নীতি অনুযায়ী ভিডিও তৈরি ও প্রকাশ করার জন্য বয়স ন্যূনতম <strong>১৮ বছর</strong> হতে হবে। আপনার বর্তমান বয়স অনুযায়ী কিডস/টিন সুরক্ষা মোড সক্রিয় রয়েছে।
          </p>
          <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 text-[11px] text-amber-300">
            💡 আপনি অ্যাপের হেডারে <strong>"বয়স সীমা"</strong> অপশনে গিয়ে বয়স ভেরিফিকেশন আপডেট করতে পারবেন।
          </div>
        </div>
      </div>
    );
  }

  const selectedCategoryMeta = CREATOR_MONETIZATION_CATEGORIES[videoType] || CREATOR_MONETIZATION_CATEGORIES.funny_moment;

  return (
    <div className="max-w-2xl mx-auto space-y-4 animate-fade-in text-slate-200">
      <form onSubmit={onSubmit} className="p-5 rounded-3xl bg-slate-900 border border-slate-800 space-y-4 shadow-xl">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <Video className="w-5 h-5 text-amber-400" />
            <h3 className="text-sm font-black text-white">নতুন ভিডিও প্রকাশ ও মনিটাইজেশন সক্রিয়করণ</h3>
          </div>
          <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-bold border border-emerald-500/40">
            ১৮+ ক্রিয়েটর অনুমোদিত ✓
          </span>
        </div>

        {/* Video Category Selection with Multipliers */}
        <div>
          <label className="text-xs font-bold text-slate-300 block mb-1.5">
            ভিডিওর ধরণ নির্বাচন করুন (বিশেষ ইনকাম ফান্ড): <span className="text-rose-400">*</span>
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {[
              { id: 'funny_moment', label: '😂 ফানি ও কমেডি', perk: 'RPM ৳১০০ • ভাইরাল বোনাস' },
              { id: 'educational_guide', label: '📚 শিক্ষামূলক ও স্ট্র্যাটেজি', perk: 'RPM ৳১২০ • এডু ফান্ড' },
              { id: 'tutorial', label: '💡 প্রো টিপস ও ট্রিকস', perk: 'RPM ৳১১০ • টিউটর ফান্ড' },
              { id: 'creative_good_content', label: '✨ ভালো ও সৃজনশীল', perk: 'RPM ৳৯০ • স্টার ফান্ড' },
              { id: 'epic_win', label: '🏆 এপিক গেমপ্লে জয়', perk: 'RPM ৳৮৫ • উইন রিওয়ার্ড' },
              { id: 'voice_adda_clip', label: '🎙️ লাইভ আড্ডা ও গান', perk: 'RPM ৳৯৫ • ফ্যান টিপস' },
            ].map((cat) => (
              <button
                key={cat.id}
                type="button"
                onClick={() => {
                  Sound.playButtonTick();
                  onVideoTypeChange(cat.id as any);
                }}
                className={`p-2.5 rounded-xl border text-left text-xs font-bold transition-all cursor-pointer ${
                  videoType === cat.id
                    ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-md scale-101'
                    : 'bg-slate-950 text-slate-300 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="block font-black">{cat.label}</div>
                <div className={`text-[10px] ${videoType === cat.id ? 'text-slate-900 font-bold' : 'text-amber-400'}`}>
                  {cat.perk}
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Active Category Highlight Card */}
        {selectedCategoryMeta && (
          <div className="p-3.5 rounded-2xl bg-slate-950 border border-amber-500/30 space-y-1 text-xs">
            <div className="flex items-center justify-between">
              <span className="font-black text-amber-300 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                {selectedCategoryMeta.programNameBn}
              </span>
              <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-[10px] font-bold">
                ৳{selectedCategoryMeta.rpmRateBDT}/1k ভিউ
              </span>
            </div>
            <p className="text-[11px] text-slate-300">{selectedCategoryMeta.descriptionBn}</p>
            <p className="text-[10px] text-emerald-400 font-bold pt-0.5">
              🎁 বোনাস সুবিধা: {selectedCategoryMeta.bonusPerkBn}
            </p>
          </div>
        )}

        {/* Title */}
        <div>
          <label className="text-xs font-bold text-slate-300 block mb-1">
            ভিডিওর শিরোনাম (Title): <span className="text-rose-400">*</span>
          </label>
          <input
            type="text"
            required
            placeholder="যেমন: শেষ চালে ছক্কা মেরে ৩ গুটি কেটে অসম্ভব ম্যাচ জয়!"
            value={videoTitle}
            onChange={(e) => onVideoTitleChange(e.target.value)}
            className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-2xl text-xs text-white focus:outline-none focus:border-amber-400"
          />
        </div>

        {/* Description & Tags */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="text-xs font-bold text-slate-300 block mb-1">বিবরণ (Description):</label>
            <textarea
              rows={2}
              placeholder="আপনার মজার ঘটনা বা শেখানোর পয়েন্টগুলো লিখুন..."
              value={videoDesc}
              onChange={(e) => onVideoDescChange(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-amber-400"
            />
          </div>
          <div>
            <label className="text-xs font-bold text-slate-300 block mb-1">ট্যাগসমূহ (Tags):</label>
            <input
              type="text"
              placeholder="ফানি, কমেডি, লুডুশিক্ষা, টিউটোরিয়াল, জয়লুডু"
              value={videoTags}
              onChange={(e) => onVideoTagsChange(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-amber-400"
            />
          </div>
        </div>

        {/* Automated AI Policy Scanner Indicator */}
        {scanResult && (
          <div
            className={`p-3.5 rounded-2xl border text-xs font-bold space-y-1 transition-all ${
              scanResult.isSafe
                ? 'bg-emerald-950/40 border-emerald-500/60 text-emerald-300'
                : 'bg-rose-950/60 border-rose-500 text-rose-300'
            }`}
          >
            <div className="flex items-center gap-2">
              {scanResult.isSafe ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              ) : (
                <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
              )}
              <span>
                {scanResult.isSafe
                  ? 'কমিউনিটি নির্দেশিকা স্ক্যান সম্পন্ন: কন্টেন্ট সম্পূর্ণ নিরাপদ ও মনিটাইজেশনের জন্য প্রস্তুত ✓'
                  : 'নিরাপত্তা পলিসি লঙ্ঘন শনাক্ত হয়েছে!'}
              </span>
            </div>
            {!scanResult.isSafe && (
              <p className="text-[11px] text-rose-200/90 pl-6 leading-relaxed">
                {scanResult.reasonBn}
              </p>
            )}
          </div>
        )}

        {/* Zero Tolerance Guidelines Box */}
        <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 text-xs text-slate-300 space-y-1">
          <span className="font-black text-amber-300 flex items-center gap-1.5">
            <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />
            স্বয়ংক্রিয় নীতি ও শিশু সুরক্ষা (Zero Tolerance Policy):
          </span>
          <p className="text-[11px] text-slate-400 leading-relaxed">
            • <strong>বাচ্চাদের ছবি/ভিডিও:</strong> কোনো শিশুর ফটো বা ভিডিও আপলোড করা হলে তা স্বয়ংক্রিয়ভাবে বাতিল ও ডিলিট করা হবে।<br />
            • <strong>রাজনীতি, ধর্মীয় বিদ্বেষ, গুজব, গালাগালি ও উস্কানি:</strong> সম্পূর্ণ নিষিদ্ধ ও তাৎক্ষণিক অ্যাকাউন্ট ব্যানযোগ্য।
          </p>
        </div>

        {uploadSuccessMsg && (
          <div className="p-3 rounded-2xl bg-emerald-950 border border-emerald-500 text-emerald-300 text-xs font-bold text-center">
            {uploadSuccessMsg}
          </div>
        )}

        <button
          type="submit"
          disabled={scanResult ? !scanResult.isSafe : false}
          className="w-full py-3 rounded-2xl bg-gradient-to-r from-amber-500 via-rose-500 to-purple-600 hover:from-amber-400 hover:to-purple-500 text-slate-950 font-black text-xs shadow-lg active:scale-98 transition-all cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
        >
          <Upload className="w-4 h-4" />
          <span>ভিডিও প্রকাশ করুন ও মনিটাইজেশন শুরু করুন</span>
        </button>
      </form>
    </div>
  );
};
