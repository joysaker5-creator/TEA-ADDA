import React, { useState } from 'react';
import {
  Play,
  Pause,
  Heart,
  MessageCircle,
  Gift,
  DollarSign,
  Send,
  TrendingUp,
  Sparkles,
  Award,
} from 'lucide-react';
import { VideoContent, UserProfile } from '../../types';
import { Sound } from '../../utils/soundEffects';

interface VideoFeedPlayerTabProps {
  videos: VideoContent[];
  selectedVideoIndex: number;
  isPlaying: boolean;
  likedVideoIds: Record<string, boolean>;
  localComments: Record<string, string[]>;
  commentInput: string;
  onSelectVideoIndex: (idx: number) => void;
  onTogglePlay: () => void;
  onToggleLike: (video: VideoContent) => void;
  onOpenGiftModal: () => void;
  onCommentInputChange: (val: string) => void;
  onAddComment: (e: React.FormEvent) => void;
  onOpenShortsScrollPlayer?: () => void;
}

export const VideoFeedPlayerTab: React.FC<VideoFeedPlayerTabProps> = ({
  videos,
  selectedVideoIndex,
  isPlaying,
  likedVideoIds,
  localComments,
  commentInput,
  onSelectVideoIndex,
  onTogglePlay,
  onToggleLike,
  onOpenGiftModal,
  onCommentInputChange,
  onAddComment,
  onOpenShortsScrollPlayer,
}) => {
  const [activeCategoryFilter, setActiveCategoryFilter] = useState<string>('all');

  const filteredVideos = videos.filter((v) => {
    if (activeCategoryFilter === 'all') return true;
    if (activeCategoryFilter === 'funny') return v.videoType === 'funny_moment';
    if (activeCategoryFilter === 'education') return v.videoType === 'educational_guide' || v.videoType === 'tutorial';
    if (activeCategoryFilter === 'creative') return v.videoType === 'creative_good_content';
    if (activeCategoryFilter === 'epic') return v.videoType === 'epic_win' || v.videoType === 'gameplay_highlight';
    if (activeCategoryFilter === 'adda') return v.videoType === 'voice_adda_clip';
    return true;
  });

  const currentVideo = filteredVideos[selectedVideoIndex] || filteredVideos[0] || videos[0];

  return (
    <div className="space-y-4 h-full animate-fade-in text-slate-200">
      {/* Top Banner: TikTok Vertical Scroll Mode Launcher */}
      <div className="p-3 sm:p-4 rounded-3xl bg-gradient-to-r from-rose-600 via-purple-600 to-amber-500 border border-amber-300/40 shadow-xl flex flex-col sm:flex-row items-center justify-between gap-3 text-white">
        <div className="flex items-center gap-3 text-center sm:text-left">
          <div className="w-10 h-10 rounded-2xl bg-black/40 border border-white/20 flex items-center justify-center text-xl shrink-0">
            🎬
          </div>
          <div>
            <h4 className="text-xs sm:text-sm font-black flex items-center gap-2 justify-center sm:justify-start">
              <span>লুডু ভিডিও • ভার্টিক্যাল স্ক্রল ও অফলাইন ভিউয়ার</span>
              <span className="px-1.5 py-0.2 rounded-full bg-yellow-400 text-slate-950 text-[9px] font-black uppercase">
                NEW
              </span>
            </h4>
            <p className="text-[11px] text-amber-100 font-medium">
              উপরে-নিচে সোয়াইপ করে ফুলস্ক্রিন ভিডিও দেখুন এবং ইন্টারনেট ছাড়াও অফলাইনে উপভোগ করুন!
            </p>
          </div>
        </div>

        {onOpenShortsScrollPlayer && (
          <button
            onClick={() => {
              Sound.playClick();
              onOpenShortsScrollPlayer();
            }}
            className="px-4 py-2 rounded-2xl bg-white hover:bg-amber-100 text-slate-950 text-xs font-black shadow-lg transition-all active:scale-95 shrink-0 flex items-center gap-1.5 cursor-pointer border border-amber-300"
          >
            <Play className="w-3.5 h-3.5 fill-slate-950" />
            <span>ফুলস্ক্রিন স্ক্রল প্লেয়ার খুলুন ❯</span>
          </button>
        )}
      </div>

      {/* Category Filter Chips Bar */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
        {[
          { id: 'all', label: '🔥 সব ট্রেন্ডিং' },
          { id: 'funny', label: '😂 ফানি ভিডিও' },
          { id: 'education', label: '📚 শিক্ষামূলক ও ট্রিকস' },
          { id: 'creative', label: '✨ ভালো ও সৃজনশীল' },
          { id: 'epic', label: '🏆 এপিক গেমপ্লে' },
          { id: 'adda', label: '🎙️ লাইভ আড্ডা' },
        ].map((filter) => (
          <button
            key={filter.id}
            onClick={() => {
              Sound.playButtonTick();
              setActiveCategoryFilter(filter.id);
              onSelectVideoIndex(0);
            }}
            className={`px-3 py-1.5 rounded-full text-xs font-bold shrink-0 transition-all cursor-pointer ${
              activeCategoryFilter === filter.id
                ? 'bg-amber-400 text-slate-950 font-black shadow-md'
                : 'bg-slate-900 text-slate-400 hover:bg-slate-800 hover:text-slate-200 border border-slate-800'
            }`}
          >
            {filter.label}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left Main Video Player / Canvas (7 Cols) */}
        <div className="lg:col-span-7 flex flex-col bg-slate-900 rounded-3xl border border-slate-800 p-4 relative overflow-hidden shadow-xl justify-between min-h-[420px]">
          {/* Video Stage Simulation Canvas */}
          <div className="relative w-full aspect-[9/13] max-h-[380px] rounded-2xl bg-gradient-to-tr from-slate-950 via-indigo-950 to-purple-950 border border-slate-800 overflow-hidden flex flex-col justify-between p-4 shadow-inner">
            {/* Top Video Tags & Creator Badge */}
            <div className="flex items-center justify-between z-10">
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-full bg-red-600 text-white text-[10px] font-black uppercase animate-pulse">
                  LIVE SHORTS
                </span>
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-bold border border-emerald-500/40">
                  {currentVideo?.categoryLabelBn || '৳ মনিটাইজড'}
                </span>
              </div>

              <div className="flex items-center gap-1.5 bg-black/60 px-2.5 py-1 rounded-full text-xs text-amber-300 border border-amber-400/30">
                <DollarSign className="w-3.5 h-3.5" />
                <span className="font-mono font-bold">৳{currentVideo?.earningsBDT?.toFixed(2) || '0.00'}</span>
              </div>
            </div>

            {/* Center Ludo Visual Graphics */}
            <div className="flex flex-col items-center justify-center my-auto text-center space-y-3 z-10">
              <div className="relative w-24 h-24 rounded-3xl bg-gradient-to-tr from-amber-500 via-red-500 to-rose-600 flex items-center justify-center border-4 border-amber-300 shadow-2xl transform hover:scale-105 transition-all">
                <span className="text-4xl animate-bounce">
                  {currentVideo?.videoType === 'funny_moment' ? '🤣' : currentVideo?.videoType === 'educational_guide' || currentVideo?.videoType === 'tutorial' ? '🧠' : currentVideo?.videoType === 'voice_adda_clip' ? '🎤' : '🎲'}
                </span>
                <div className="absolute -top-2 -right-2 px-2 py-0.5 rounded-full bg-yellow-400 text-slate-950 text-[10px] font-black shadow-md">
                  {currentVideo?.gameSnippet?.diceRoll || 6}
                </div>
              </div>

              <div className="px-3 py-1.5 rounded-full bg-black/70 backdrop-blur-sm border border-slate-700 text-xs font-bold text-slate-100 max-w-xs truncate">
                {currentVideo?.title}
              </div>

              <div className="flex items-center gap-3 text-xs text-amber-200">
                <span>🏆 গুটি জয়: {currentVideo?.gameSnippet?.tokensCaptured || 2} টি</span>
                <span>•</span>
                <span>🪙 রিওয়ার্ড: +{currentVideo?.gameSnippet?.coinsWon?.toLocaleString() || '15,000'}</span>
              </div>
            </div>

            {/* Video Bottom Overlay & Controls */}
            <div className="z-10 bg-gradient-to-t from-black/95 via-black/65 to-transparent p-3 rounded-xl">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-amber-500/20 border border-amber-400 flex items-center justify-center text-amber-300 font-black text-xs">
                    {currentVideo?.creatorCountry === 'BD' ? '🇧🇩' : '🌐'}
                  </div>
                  <div>
                    <p className="text-xs font-black text-white">{currentVideo?.creatorName}</p>
                    <p className="text-[10px] text-slate-400">
                      {currentVideo?.viewsCount?.toLocaleString()} ভিউ • {currentVideo?.durationSeconds}s
                    </p>
                  </div>
                </div>

                {/* Play/Pause Toggle */}
                <button
                  onClick={() => {
                    Sound.playClick();
                    onTogglePlay();
                  }}
                  className="w-9 h-9 rounded-full bg-amber-500 text-slate-950 flex items-center justify-center shadow-lg active:scale-95 cursor-pointer"
                >
                  {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
                </button>
              </div>
            </div>
          </div>

          {/* Interactive Action Bar */}
          <div className="flex items-center justify-between pt-3 border-t border-slate-800 mt-2">
            <div className="flex items-center gap-2">
              {/* Like Button */}
              <button
                onClick={() => currentVideo && onToggleLike(currentVideo)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  currentVideo && likedVideoIds[currentVideo.id]
                    ? 'bg-rose-600 text-white'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                <Heart
                  className={`w-4 h-4 ${
                    currentVideo && likedVideoIds[currentVideo.id] ? 'fill-white' : ''
                  }`}
                />
                <span>{currentVideo?.likesCount || 0}</span>
              </button>

              {/* Diamond Tip / Gift Button */}
              <button
                onClick={() => {
                  Sound.playClick();
                  onOpenGiftModal();
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 text-xs font-black shadow-md cursor-pointer active:scale-95"
              >
                <Gift className="w-4 h-4" />
                <span>ডায়মন্ড টিপ উপহার (৳)</span>
              </button>
            </div>

            {/* Next / Previous video */}
            <div className="flex items-center gap-1">
              <button
                onClick={() => {
                  Sound.playButtonTick();
                  onSelectVideoIndex(
                    selectedVideoIndex > 0 ? selectedVideoIndex - 1 : filteredVideos.length - 1
                  );
                }}
                className="px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold cursor-pointer"
              >
                পূর্ববর্তী
              </button>
              <button
                onClick={() => {
                  Sound.playButtonTick();
                  onSelectVideoIndex(
                    selectedVideoIndex < filteredVideos.length - 1 ? selectedVideoIndex + 1 : 0
                  );
                }}
                className="px-2.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black cursor-pointer shadow-sm"
              >
                পরবর্তী ❯
              </button>
            </div>
          </div>
        </div>

        {/* Right Side: Feed List & Live Comments (5 Cols) */}
        <div className="lg:col-span-5 flex flex-col space-y-4">
          {/* Video Playlist Quick Selector */}
          <div className="bg-slate-900 rounded-3xl border border-slate-800 p-3.5 space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-black text-amber-300 uppercase tracking-wider flex items-center gap-1.5">
                <TrendingUp className="w-3.5 h-3.5" />
                ভিডিও তালিকা ({filteredVideos.length})
              </span>
              <span className="text-[10px] text-emerald-400 font-bold">প্রতি ভিউয়ে নগদ ইনকাম</span>
            </div>

            <div className="space-y-1.5 max-h-[160px] overflow-y-auto pr-1">
              {filteredVideos.map((vid, idx) => (
                <button
                  key={vid.id}
                  onClick={() => {
                    Sound.playButtonTick();
                    onSelectVideoIndex(idx);
                  }}
                  className={`w-full p-2 rounded-2xl text-left text-xs transition-all flex items-center justify-between cursor-pointer ${
                    selectedVideoIndex === idx
                      ? 'bg-amber-500/20 border border-amber-400 text-amber-200'
                      : 'bg-slate-950/80 border border-slate-800/80 text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <div className="flex items-center gap-2 truncate">
                    <span className="text-base shrink-0">
                      {vid.videoType === 'funny_moment' ? '😂' : vid.videoType === 'educational_guide' || vid.videoType === 'tutorial' ? '📚' : vid.videoType === 'voice_adda_clip' ? '🎤' : '🎲'}
                    </span>
                    <span className="truncate font-bold text-[11px]">{vid.title}</span>
                  </div>
                  <span className="text-[10px] font-mono font-bold text-amber-400 shrink-0 ml-2">
                    ৳{vid.earningsBDT?.toFixed(2)}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Real-time Comments Box */}
          <div className="bg-slate-900 rounded-3xl border border-slate-800 p-4 flex-1 flex flex-col justify-between space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="text-xs font-black text-white flex items-center gap-1.5">
                <MessageCircle className="w-3.5 h-3.5 text-amber-400" />
                মন্তব্য ও আড্ডা
              </span>
              <span className="text-[10px] text-emerald-400 font-bold">🛡️ ফিল্টার্ড ও নিরাপদ</span>
            </div>

            {/* Comments Feed */}
            <div className="space-y-2 max-h-[170px] overflow-y-auto pr-1">
              {(localComments[currentVideo?.id || ''] || ['অসাধারণ কনটেন্ট ভাই! 🔥', 'অনেক কিছু শিখলাম ❤️']).map(
                (cmt, i) => (
                  <div
                    key={i}
                    className="p-2 rounded-xl bg-slate-950 border border-slate-800 text-[11px] text-slate-300"
                  >
                    <div className="flex items-center justify-between mb-0.5">
                      <span className="font-bold text-amber-400 text-[10px]">খেলোয়াড় #{i + 1}</span>
                      <span className="text-[9px] text-slate-500">এখনই</span>
                    </div>
                    <p>{cmt}</p>
                  </div>
                )
              )}
            </div>

            {/* Add Comment Form */}
            <form onSubmit={onAddComment} className="flex items-center gap-2 pt-2 border-t border-slate-800">
              <input
                type="text"
                placeholder="ভদ্র ও গঠনমূলক মন্তব্য লিখুন..."
                value={commentInput}
                onChange={(e) => onCommentInputChange(e.target.value)}
                className="flex-1 px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-amber-400"
              />
              <button
                type="submit"
                className="p-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 transition-all cursor-pointer shadow-md"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};
