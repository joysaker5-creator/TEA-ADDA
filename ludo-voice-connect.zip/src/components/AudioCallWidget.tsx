import React, { useEffect, useRef, useState } from 'react';
import { Mic, MicOff, Volume2, VolumeX, Radio, Sparkles, MessageSquare, Crown } from 'lucide-react';
import { Player, PlayerColor, VoiceMessage } from '../types';
import { COLOR_CONFIG, VOICE_REACTIONS } from '../utils/ludoConstants';
import { Sound } from '../utils/soundEffects';
import { AvatarDisplay } from './AvatarDisplay';
import { VipBadge } from './VipBadge';

interface AudioCallWidgetProps {
  players: Player[];
  localPlayerColor: PlayerColor;
  onSendVoiceReaction: (reaction: { text: string; soundKey: string }) => void;
  recentVoiceMessage: VoiceMessage | null;
  isEn?: boolean;
}

export const AudioCallWidget: React.FC<AudioCallWidgetProps> = ({
  players,
  localPlayerColor,
  onSendVoiceReaction,
  recentVoiceMessage,
  isEn = true,
}) => {
  const [isMicOn, setIsMicOn] = useState<boolean>(true);
  const [isDeafened, setIsDeafened] = useState<boolean>(false);
  const [micPermission, setMicPermission] = useState<'prompt' | 'granted' | 'denied' | 'unsupported'>('prompt');
  const [localAudioLevel, setLocalAudioLevel] = useState<number>(0);
  const [showSoundboard, setShowSoundboard] = useState<boolean>(false);

  const audioStreamRef = useRef<MediaStream | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const animationFrameRef = useRef<number | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);

  // Initialize Microphone
  const startMicrophone = async () => {
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setMicPermission('unsupported');
        return;
      }

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      audioStreamRef.current = stream;
      setMicPermission('granted');
      setIsMicOn(true);

      // Create Analyser to detect speech volume for visual indicator
      const AudioCtxClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      const audioCtx = new AudioCtxClass();
      audioContextRef.current = audioCtx;
      const source = audioCtx.createMediaStreamSource(stream);
      const analyser = audioCtx.createAnalyser();
      analyser.fftSize = 64;
      source.connect(analyser);
      analyserRef.current = analyser;

      const dataArray = new Uint8Array(analyser.frequencyBinCount);

      const checkAudioLevel = () => {
        const audioTracks = stream.getAudioTracks();
        if (!analyserRef.current || !audioTracks || !audioTracks[0]?.enabled) {
          setLocalAudioLevel(0);
        } else {
          analyserRef.current.getByteFrequencyData(dataArray);
          let sum = 0;
          for (let i = 0; i < dataArray.length; i++) {
            sum += dataArray[i];
          }
          const average = sum / dataArray.length;
          // Scale from 0 to 100
          const level = Math.min(Math.round((average / 128) * 100), 100);
          setLocalAudioLevel(level > 15 ? level : 0);
        }
        animationFrameRef.current = requestAnimationFrame(checkAudioLevel);
      };

      checkAudioLevel();
    } catch {
      setMicPermission('denied');
      setIsMicOn(false);
    }
  };

  useEffect(() => {
    startMicrophone();

    return () => {
      if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
      if (audioStreamRef.current) {
        audioStreamRef.current.getTracks().forEach((track) => track.stop());
      }
      if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
        audioContextRef.current.close().catch(() => {});
      }
    };
  }, []);

  const toggleMic = () => {
    if (micPermission !== 'granted') {
      startMicrophone();
      return;
    }

    if (audioStreamRef.current) {
      const tracks = audioStreamRef.current.getAudioTracks();
      const audioTrack = tracks && tracks.length > 0 ? tracks[0] : null;
      if (audioTrack) {
        audioTrack.enabled = !isMicOn;
        setIsMicOn(!isMicOn);
        Sound.playMicToggle(isMicOn);
      }
    } else {
      setIsMicOn(!isMicOn);
      Sound.playMicToggle(isMicOn);
    }
  };

  const toggleDeafen = () => {
    setIsDeafened(!isDeafened);
    Sound.playButtonTick();
  };

  const handleVoiceReactionClick = (reaction: { text: string; soundKey: string }) => {
    Sound.playButtonTick();
    onSendVoiceReaction(reaction);
    setShowSoundboard(false);
  };

  return (
    <div id="audio-call-container" className="w-full bg-indigo-600 rounded-3xl p-4 text-white shadow-lg border-b-4 border-indigo-800 transition-all">
      <div className="flex flex-wrap items-center justify-between gap-2">
        {/* Call status header */}
        <div className="flex items-center gap-2">
          <div className="relative flex items-center justify-center">
            <span className="relative flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-80"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-400"></span>
            </span>
          </div>
          <div className="flex items-center gap-1.5">
            <Radio className="w-4 h-4 text-emerald-300" />
            <span className="text-sm font-black text-white tracking-wide">
              {isEn ? 'Voice Call' : 'অডিও কল'}
            </span>
          </div>
          <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-indigo-800/80 text-indigo-100 border border-indigo-500/40">
            {players.length} {isEn ? 'Live' : 'জন লাইভ'}
          </span>
          <span className="hidden md:inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/30 text-emerald-200 border border-emerald-400/40">
            {isEn ? '🌐 Global 195 Countries' : '🌐 ১৯৫টি দেশে VPN মুক্ত'}
          </span>
        </div>

        {/* Call Controls */}
        <div className="flex items-center gap-2">
          {/* Mic Toggle Button */}
          <button
            id="mic-toggle-btn"
            onClick={toggleMic}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-2xl text-xs font-bold transition-all shadow-md active:translate-y-0.5 ${
              isMicOn
                ? 'bg-emerald-500 hover:bg-emerald-400 text-white border-b-2 border-emerald-700'
                : 'bg-rose-500 hover:bg-rose-400 text-white border-b-2 border-rose-700'
            }`}
            title={isMicOn ? (isEn ? 'Mute Mic' : 'মাইক মিউট করুন') : (isEn ? 'Turn On Mic' : 'মাইক চালু করুন')}
          >
            {isMicOn ? <Mic className="w-3.5 h-3.5" /> : <MicOff className="w-3.5 h-3.5" />}
            <span>{isMicOn ? (isEn ? 'Mic ON' : 'মাইক অন') : (isEn ? 'Mic OFF' : 'মাইক অফ')}</span>
            {isMicOn && localAudioLevel > 15 && (
              <span className="w-2 h-2 rounded-full bg-white animate-pulse" />
            )}
          </button>

          {/* Speaker Mute Button */}
          <button
            id="speaker-toggle-btn"
            onClick={toggleDeafen}
            className={`p-2 rounded-2xl text-xs transition-all border-b-2 ${
              isDeafened
                ? 'bg-amber-500 border-amber-700 text-white'
                : 'bg-white/20 hover:bg-white/30 border-indigo-700 text-white'
            }`}
            title={isDeafened ? (isEn ? 'Unmute Audio' : 'সাউন্ড আনমিউট করুন') : (isEn ? 'Mute Audio' : 'সাউন্ড মিউট করুন')}
          >
            {isDeafened ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </button>

          {/* Voice Soundboard Toggle Button */}
          <button
            id="voice-soundboard-btn"
            onClick={() => setShowSoundboard(!showSoundboard)}
            className="flex items-center gap-1 px-3 py-1.5 rounded-2xl text-xs font-bold bg-amber-400 hover:bg-amber-300 text-amber-950 border-b-2 border-amber-600 transition-all shadow-sm active:translate-y-0.5"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-900" />
            <span>{isEn ? 'Reactions' : 'ডায়লগ'}</span>
          </button>
        </div>
      </div>

      {/* Connected Players Voice Bar */}
      <div className="mt-3 pt-3 border-t border-indigo-500/50 flex items-center justify-between gap-2 overflow-x-auto pb-1 scrollbar-none">
        <div className="flex items-center gap-2">
          {players.map((p) => {
            const isLocal = p.color === localPlayerColor;
            const speaking = isLocal ? isMicOn && localAudioLevel > 15 : p.isSpeaking;
            const config = (p.color && COLOR_CONFIG[p.color]) || COLOR_CONFIG.red;

            return (
              <div
                key={p.id}
                className={`relative flex items-center gap-2 px-2.5 py-1.5 rounded-2xl border-2 transition-all ${
                  speaking
                    ? 'border-emerald-300 bg-indigo-700 shadow-md ring-2 ring-emerald-400/50'
                    : 'border-indigo-400/30 bg-indigo-700/60'
                }`}
              >
                {/* Avatar with speaking wave */}
                <div className="relative">
                  {p.avatar ? (
                    <AvatarDisplay avatar={p.avatar} size={32} isSpeaking={speaking} vipFrameId={p.vipFrameId} />
                  ) : (
                    <div
                      className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold shadow-md border-2 border-white"
                      style={{ backgroundColor: config.hex, color: '#fff' }}
                    >
                      {config.avatar}
                    </div>
                  )}
                  {speaking ? (
                    <span className="absolute -top-1 -right-1 flex h-3.5 w-3.5 z-20">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-300 opacity-80"></span>
                      <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-emerald-400 border-2 border-indigo-600"></span>
                    </span>
                  ) : (
                    <div className="absolute -bottom-0.5 -right-0.5 bg-emerald-400 w-2.5 h-2.5 rounded-full border-2 border-indigo-600 z-20" />
                  )}
                </div>

                <div className="flex flex-col min-w-0">
                  <div className="flex items-center gap-1">
                    <span className="text-xs font-bold text-white leading-tight truncate max-w-[90px]">
                      {p.name} {isLocal && (isEn ? '(You)' : '(আপনি)')}
                    </span>
                    {p.isVip && (
                      <VipBadge badgeId={p.vipBadge || 'vip_crown'} size="sm" showText={false} />
                    )}
                  </div>
                  <div className="flex items-center gap-1">
                    {isLocal ? (
                      isMicOn ? (
                        <span className="text-[10px] text-emerald-200 font-semibold">{isEn ? 'Speaking' : 'কথা বলছেন'}</span>
                      ) : (
                        <span className="text-[10px] text-rose-200 font-semibold">{isEn ? 'Muted' : 'মিউট আছেন'}</span>
                      )
                    ) : (
                      <span className="text-[10px] text-indigo-200 font-medium">
                        {p.isBot ? (isEn ? 'Bot' : 'রোবট') : (isEn ? 'Connected' : 'যুক্ত আছেন')}
                      </span>
                    )}
                  </div>
                </div>

                {/* Animated voice frequency bars when speaking */}
                {speaking && (
                  <div className="flex items-end gap-0.5 h-3 ml-1">
                    <span className="w-0.5 h-2 bg-emerald-300 animate-bounce rounded-full" style={{ animationDelay: '0ms' }} />
                    <span className="w-0.5 h-3 bg-emerald-300 animate-bounce rounded-full" style={{ animationDelay: '150ms' }} />
                    <span className="w-0.5 h-1.5 bg-emerald-300 animate-bounce rounded-full" style={{ animationDelay: '300ms' }} />
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Live Audio Equalizer Meter for Local Player */}
        {isMicOn && (
          <div className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 bg-indigo-700/80 rounded-xl border border-indigo-400/40">
            <span className="text-[10px] font-bold text-indigo-200">{isEn ? 'Volume:' : 'ভলিউম:'}</span>
            <div className="w-16 h-2 bg-indigo-900 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-emerald-400 to-amber-300 transition-all duration-75"
                style={{ width: `${localAudioLevel}%` }}
              />
            </div>
          </div>
        )}
      </div>

      {/* Voice Soundboard Popup */}
      {showSoundboard && (
        <div className="mt-3 pt-3 border-t border-indigo-500/50 bg-indigo-800/95 rounded-2xl p-3 shadow-inner">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
              <MessageSquare className="w-3.5 h-3.5" />
              {isEn ? 'Voice Reactions (Broadcasts to all):' : 'ভয়েস রিঅ্যাকশন (স্পিকারে সবাইকে শোনাবে):'}
            </span>
            <button
              onClick={() => setShowSoundboard(false)}
              className="text-xs text-indigo-200 hover:text-white px-2 py-0.5 bg-indigo-700 rounded-lg"
            >
              ✕
            </button>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5">
            {VOICE_REACTIONS.map((reaction) => (
              <button
                key={reaction.id}
                onClick={() => handleVoiceReactionClick(reaction)}
                className="flex items-center gap-1.5 px-2.5 py-1.5 bg-indigo-700 hover:bg-amber-400 hover:text-amber-950 text-white rounded-xl text-left text-xs font-bold transition-all shadow-sm active:scale-95"
              >
                <span>{reaction.icon}</span>
                <span className="text-[11px] truncate">{reaction.text}</span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Recent Voice Reaction Floating Toast */}
      {recentVoiceMessage && (
        <div className="mt-2.5 flex items-center gap-2 p-2 bg-amber-400 text-amber-950 rounded-2xl text-xs font-bold shadow-md animate-fade-in border border-amber-300">
          <span className="text-base">📢</span>
          <span className="font-extrabold">{recentVoiceMessage.senderName}:</span>
          <span>"{recentVoiceMessage.text}"</span>
        </div>
      )}
    </div>
  );
};
