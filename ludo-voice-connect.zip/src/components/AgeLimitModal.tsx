import React, { useState, useEffect } from 'react';
import {
  X,
  Shield,
  ShieldCheck,
  ShieldAlert,
  Lock,
  Unlock,
  Clock,
  Mic,
  MicOff,
  MessageSquare,
  Baby,
  UserCheck,
  CheckCircle2,
  AlertTriangle,
  Heart,
  Save,
  KeyRound,
  Eye,
  EyeOff,
  Sparkles,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { UserProfile, AgeVerificationConfig, AgeCategory } from '../types';
import {
  loadUserAgeConfig,
  saveUserAgeConfig,
  calculateAgeFromDOB,
  getAgeCategory,
  getTodayScreenTimeMinutes,
  AGE_CATEGORY_DETAILS,
  buildDefaultAgeConfig,
} from '../utils/ageLimitService';
import { Sound } from '../utils/soundEffects';

interface AgeLimitModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile;
  onAgeConfigUpdated?: (config: AgeVerificationConfig) => void;
}

export const AgeLimitModal: React.FC<AgeLimitModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onAgeConfigUpdated,
}) => {
  const [config, setConfig] = useState<AgeVerificationConfig>(() => loadUserAgeConfig(currentUser));
  const [activeTab, setActiveTab] = useState<'verify' | 'parental_controls' | 'screen_time'>('verify');

  // Input states
  const [selectedAge, setSelectedAge] = useState<number>(config.age || 18);
  const [birthDateInput, setBirthDateInput] = useState<string>(config.birthDate || '');
  const [dailyLimit, setDailyLimit] = useState<number>(config.dailyScreenTimeLimitMinutes || 0);
  const [childSafe, setChildSafe] = useState<boolean>(config.childSafeMode);
  const [voiceAllowed, setVoiceAllowed] = useState<boolean>(config.voiceChatAllowed);

  // Parental PIN setup
  const [parentPin, setParentPin] = useState<string>('');
  const [confirmParentPin, setConfirmParentPin] = useState<string>('');
  const [pinUnlockInput, setPinUnlockInput] = useState<string>('');
  const [isPinLocked, setIsPinLocked] = useState<boolean>(config.hasParentalPin && !!config.parentalPin);
  const [pinError, setPinError] = useState<string | null>(null);
  const [saveSuccessMsg, setSaveSuccessMsg] = useState<string | null>(null);
  const [showPinText, setShowPinText] = useState(false);

  // Screen time stats
  const [todayPlayedMinutes, setTodayPlayedMinutes] = useState<number>(0);

  useEffect(() => {
    if (isOpen) {
      const loaded = loadUserAgeConfig(currentUser);
      setConfig(loaded);
      setSelectedAge(loaded.age || 18);
      setBirthDateInput(loaded.birthDate || '');
      setDailyLimit(loaded.dailyScreenTimeLimitMinutes || 0);
      setChildSafe(loaded.childSafeMode);
      setVoiceAllowed(loaded.voiceChatAllowed);
      setIsPinLocked(loaded.hasParentalPin && !!loaded.parentalPin);
      setPinError(null);
      setSaveSuccessMsg(null);
      setTodayPlayedMinutes(getTodayScreenTimeMinutes(currentUser.id));
    }
  }, [isOpen, currentUser]);

  if (!isOpen) return null;

  const currentCategory = getAgeCategory(selectedAge);
  const categoryInfo = AGE_CATEGORY_DETAILS[currentCategory];

  // Handle Birthday input change
  const handleDOBChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setBirthDateInput(val);
    if (val) {
      const calcAge = calculateAgeFromDOB(val);
      setSelectedAge(calcAge);
      if (calcAge < 13) {
        setChildSafe(true);
        setVoiceAllowed(false);
        if (dailyLimit === 0) setDailyLimit(60);
      }
    }
  };

  // Select preset category directly
  const handlePresetSelect = (presetCategory: AgeCategory) => {
    Sound.playButtonTick();
    let targetAge = 18;
    if (presetCategory === 'under_13') {
      targetAge = 10;
      setChildSafe(true);
      setVoiceAllowed(false);
      if (dailyLimit === 0) setDailyLimit(60);
    } else if (presetCategory === 'teen_13_17') {
      targetAge = 15;
      setChildSafe(false);
      setVoiceAllowed(true);
      if (dailyLimit === 0) setDailyLimit(120);
    } else {
      targetAge = 22;
      setChildSafe(false);
      setVoiceAllowed(true);
    }
    setSelectedAge(targetAge);
  };

  // Unlock with Parental PIN
  const handleUnlockPin = (e: React.FormEvent) => {
    e.preventDefault();
    if (config.parentalPin && pinUnlockInput === config.parentalPin) {
      Sound.playRewardClaim();
      setIsPinLocked(false);
      setPinError(null);
      setPinUnlockInput('');
    } else {
      Sound.playAlert();
      setPinError('ভুল অভিভাবকীয় পিন! পুনরায় চেষ্টা করুন।');
    }
  };

  // Save Age & Safety Settings
  const handleSaveSettings = () => {
    // If under 13, voice chat must stay disabled
    const finalCategory = getAgeCategory(selectedAge);
    const finalVoiceAllowed = finalCategory === 'under_13' ? false : voiceAllowed;
    const finalChildSafe = finalCategory === 'under_13' ? true : childSafe;

    // Check if new PIN is being set
    let updatedHasPin = config.hasParentalPin;
    let updatedPin = config.parentalPin || '';

    if (parentPin.trim()) {
      if (parentPin.length < 4 || parentPin.length > 6) {
        setPinError('অভিভাবকীয় পিন অবশ্যই ৪ থেকে ৬ সংখ্যার হতে হবে!');
        Sound.playAlert();
        return;
      }
      if (parentPin !== confirmParentPin) {
        setPinError('দুটি পিন কোড মিলছে না!');
        Sound.playAlert();
        return;
      }
      updatedHasPin = true;
      updatedPin = parentPin;
    }

    const updatedConfig: AgeVerificationConfig = {
      isAgeVerified: true,
      age: selectedAge,
      birthDate: birthDateInput,
      ageCategory: finalCategory,
      childSafeMode: finalChildSafe,
      dailyScreenTimeLimitMinutes: dailyLimit,
      hasParentalPin: updatedHasPin,
      parentalPin: updatedPin,
      verifiedAt: Date.now(),
      voiceChatAllowed: finalVoiceAllowed,
      textChatAllowed: true,
    };

    saveUserAgeConfig(currentUser.id, updatedConfig);
    setConfig(updatedConfig);
    if (onAgeConfigUpdated) {
      onAgeConfigUpdated(updatedConfig);
    }

    Sound.playRewardClaim();
    confetti({
      particleCount: 50,
      spread: 60,
      origin: { y: 0.6 },
    });

    setSaveSuccessMsg('বয়স সীমা ও নিরাপত্তা সেটিংস সফলভাবে সংরক্ষিত হয়েছে! ✓');
    setTimeout(() => {
      setSaveSuccessMsg(null);
      onClose();
    }, 1500);
  };

  // Calculate screen time progress
  const screenTimeLimitMinutes = config.dailyScreenTimeLimitMinutes || 0;
  const progressPercent = screenTimeLimitMinutes > 0
    ? Math.min(100, Math.round((todayPlayedMinutes / screenTimeLimitMinutes) * 100))
    : 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/80 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-2xl bg-slate-950 text-white rounded-3xl border-2 border-emerald-500/50 shadow-2xl flex flex-col max-h-[92vh] overflow-hidden">
        {/* Header */}
        <div className="px-5 py-4 bg-gradient-to-r from-emerald-700 via-teal-700 to-emerald-800 flex items-center justify-between border-b border-emerald-400/30 shrink-0 shadow-md">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-950/40 border border-emerald-300/40 flex items-center justify-center text-emerald-300 shadow-inner">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-black text-white tracking-wide">
                  🛡️ বয়স সীমা ও ডিজিটাল নিরাপত্তা
                </h2>
                <span className="px-2 py-0.5 rounded-full bg-emerald-300 text-slate-950 text-[10px] font-black uppercase">
                  Age Safety
                </span>
              </div>
              <p className="text-xs text-emerald-100 font-medium">
                খেলোয়াড়ের বয়স অনুযায়ী নিরাপদ আড্ডা, ভয়েস চ্যাট ও চাইল্ড প্রটেকশন
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              Sound.playClick();
              onClose();
            }}
            className="w-9 h-9 rounded-2xl bg-emerald-950/50 hover:bg-rose-600/80 text-white flex items-center justify-center transition-all cursor-pointer border border-emerald-300/30"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-1.5 px-4 pt-3 pb-1 bg-slate-900/90 border-b border-slate-800 shrink-0 overflow-x-auto">
          {[
            { id: 'verify', label: 'বয়স ভেরিফিকেশন', icon: UserCheck },
            { id: 'parental_controls', label: 'অভিভাবকীয় নিয়ন্ত্রণ ও পিন', icon: Lock },
            { id: 'screen_time', label: 'স্ক্রিন টাইম লিমিট', icon: Clock },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => {
                  Sound.playClick();
                  setActiveTab(tab.id as any);
                }}
                className={`px-3.5 py-2 rounded-2xl text-xs font-black shrink-0 transition-all flex items-center gap-1.5 cursor-pointer ${
                  isActive
                    ? 'bg-emerald-500 text-slate-950 shadow-md scale-102'
                    : 'bg-slate-950 text-slate-400 hover:bg-slate-800 hover:text-slate-200'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-5 bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950">
          {/* PIN Lock Barrier if locked */}
          {isPinLocked && activeTab === 'verify' ? (
            <div className="p-6 rounded-3xl bg-slate-900 border border-amber-500/50 text-center space-y-4 max-w-md mx-auto">
              <div className="w-14 h-14 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center mx-auto">
                <Lock className="w-7 h-7" />
              </div>
              <h3 className="text-base font-black text-white">অভিভাবকীয় পিন সুরক্ষিত</h3>
              <p className="text-xs text-slate-300">
                এই অ্যাকাউন্টে বয়স বা নিরাপত্তা সেটিংস পরিবর্তন করতে অভিভাবকীয় পিন (Parental PIN) প্রবেশ করান।
              </p>

              <form onSubmit={handleUnlockPin} className="space-y-3">
                <input
                  type="password"
                  maxLength={6}
                  placeholder="৪-৬ সংখ্যার পিন লিখুন"
                  value={pinUnlockInput}
                  onChange={(e) => setPinUnlockInput(e.target.value)}
                  className="w-full px-4 py-2.5 bg-slate-950 border border-slate-700 focus:border-amber-400 rounded-2xl text-center text-sm font-mono tracking-widest text-white focus:outline-none"
                />
                {pinError && <p className="text-xs text-rose-400 font-bold">{pinError}</p>}
                <button
                  type="submit"
                  className="w-full py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-2xl text-xs transition-all shadow-md cursor-pointer"
                >
                  আনলক করুন
                </button>
              </form>
            </div>
          ) : (
            <>
              {/* TAB 1: AGE SELECTION & VERIFICATION */}
              {activeTab === 'verify' && (
                <div className="space-y-5 animate-fade-in">
                  {/* Category Selection Cards */}
                  <div>
                    <label className="text-xs font-black text-slate-300 mb-2 block uppercase tracking-wider">
                      ১. আপনার বয়স শ্রেণী নির্বাচন করুন:
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                      {/* Under 13 */}
                      <button
                        type="button"
                        onClick={() => handlePresetSelect('under_13')}
                        className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer relative ${
                          currentCategory === 'under_13'
                            ? 'bg-emerald-950/60 border-emerald-400 ring-2 ring-emerald-500/40 shadow-lg'
                            : 'bg-slate-900/80 border-slate-800 hover:border-slate-700'
                        }`}
                      >
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-xl">🧒</span>
                          <span className="text-xs font-black text-emerald-400">১৩ বছরের নিচে</span>
                        </div>
                        <span className="text-[10px] text-slate-400 block leading-tight">
                          কিডস মোড • উন্মুক্ত ভয়েস বন্ধ • নিরাপদ চ্যাট
                        </span>
                        {currentCategory === 'under_13' && (
                          <div className="absolute top-2.5 right-2.5 w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                        )}
                      </button>

                      {/* 13-17 */}
                      <button
                        type="button"
                        onClick={() => handlePresetSelect('teen_13_17')}
                        className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer relative ${
                          currentCategory === 'teen_13_17'
                            ? 'bg-amber-950/60 border-amber-400 ring-2 ring-amber-500/40 shadow-lg'
                            : 'bg-slate-900/80 border-slate-800 hover:border-slate-700'
                        }`}
                      >
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-xl">🛡️</span>
                          <span className="text-xs font-black text-amber-400">১৩ - ১৭ বছর</span>
                        </div>
                        <span className="text-[10px] text-slate-400 block leading-tight">
                          টিন মোড • পরিমিত ভয়েস • স্ক্রিন টাইম রিমাইন্ডার
                        </span>
                        {currentCategory === 'teen_13_17' && (
                          <div className="absolute top-2.5 right-2.5 w-2 h-2 rounded-full bg-amber-400 animate-ping" />
                        )}
                      </button>

                      {/* 18+ */}
                      <button
                        type="button"
                        onClick={() => handlePresetSelect('adult_18_plus')}
                        className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer relative ${
                          currentCategory === 'adult_18_plus'
                            ? 'bg-purple-950/60 border-purple-400 ring-2 ring-purple-500/40 shadow-lg'
                            : 'bg-slate-900/80 border-slate-800 hover:border-slate-700'
                        }`}
                      >
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-xl">👑</span>
                          <span className="text-xs font-black text-purple-300">১৮+ বছর</span>
                        </div>
                        <span className="text-[10px] text-slate-400 block leading-tight">
                          আনরেস্ট্রিক্টেড • সকল লাইভ স্টেজ ও আড্ডা
                        </span>
                        {currentCategory === 'adult_18_plus' && (
                          <div className="absolute top-2.5 right-2.5 w-2 h-2 rounded-full bg-purple-400 animate-ping" />
                        )}
                      </button>
                    </div>
                  </div>

                  {/* Manual Age Input / DOB Picker */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-4 rounded-2xl bg-slate-900/90 border border-slate-800">
                    <div>
                      <label className="text-xs font-bold text-slate-300 mb-1.5 block">
                        সরাসরি বয়স নির্বাচন করুন:
                      </label>
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => {
                            Sound.playButtonTick();
                            setSelectedAge((prev) => Math.max(5, prev - 1));
                          }}
                          className="w-9 h-9 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-black text-base flex items-center justify-center cursor-pointer"
                        >
                          -
                        </button>
                        <div className="flex-1 px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-center">
                          <span className="text-base font-black text-emerald-400 font-mono">
                            {selectedAge}
                          </span>
                          <span className="text-xs text-slate-400 font-bold ml-1">বছর</span>
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            Sound.playButtonTick();
                            setSelectedAge((prev) => Math.min(100, prev + 1));
                          }}
                          className="w-9 h-9 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-black text-base flex items-center justify-center cursor-pointer"
                        >
                          +
                        </button>
                      </div>
                    </div>

                    <div>
                      <label className="text-xs font-bold text-slate-300 mb-1.5 block">
                        জন্ম তারিখ (ঐচ্ছিক):
                      </label>
                      <input
                        type="date"
                        value={birthDateInput}
                        onChange={handleDOBChange}
                        className="w-full px-3 py-2 bg-slate-950 border border-slate-700 focus:border-emerald-400 rounded-xl text-xs text-white focus:outline-none"
                      />
                    </div>
                  </div>

                  {/* Category Safety Details Box */}
                  <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-black text-white flex items-center gap-1.5">
                        <ShieldCheck className="w-4 h-4 text-emerald-400" />
                        বর্তমান সুরক্ষা স্তর: {categoryInfo.titleBn}
                      </span>
                      <span className="px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-300 text-[10px] font-bold">
                        {categoryInfo.badgeBn}
                      </span>
                    </div>
                    <p className="text-xs text-slate-400 leading-relaxed">{categoryInfo.descriptionBn}</p>
                    <ul className="space-y-1 pt-1">
                      {categoryInfo.safetyPoints.map((pt, idx) => (
                        <li key={idx} className="text-[11px] text-slate-300 flex items-center gap-1.5">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                          <span>{pt}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              )}

              {/* TAB 2: PARENTAL CONTROLS & PIN */}
              {activeTab === 'parental_controls' && (
                <div className="space-y-4 animate-fade-in">
                  <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
                    <h3 className="text-xs font-black text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                      <Lock className="w-3.5 h-3.5" />
                      অভিভাবকীয় পিন সুরক্ষা (Parental PIN)
                    </h3>
                    <p className="text-xs text-slate-400">
                      একটি ৪-৬ সংখ্যার পিন কোড সেট করে রাখলে শিশুরা আপনার অনুমতি ছাড়া বয়স বা নিরাপত্তা সেটিংস পরিবর্তন করতে পারবে না।
                    </p>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                      <div>
                        <label className="text-[11px] font-bold text-slate-300 block mb-1">
                          নতুন ৪-সংখ্যার পিন:
                        </label>
                        <input
                          type={showPinText ? 'text' : 'password'}
                          maxLength={6}
                          placeholder="যেমন: ১২৩৪"
                          value={parentPin}
                          onChange={(e) => setParentPin(e.target.value.replace(/\D/g, ''))}
                          className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-center text-xs font-mono font-bold text-white tracking-widest focus:outline-none focus:border-emerald-400"
                        />
                      </div>
                      <div>
                        <label className="text-[11px] font-bold text-slate-300 block mb-1">
                          পিন নিশ্চিত করুন:
                        </label>
                        <input
                          type={showPinText ? 'text' : 'password'}
                          maxLength={6}
                          placeholder="পুনরায় পিন লিখুন"
                          value={confirmParentPin}
                          onChange={(e) => setConfirmParentPin(e.target.value.replace(/\D/g, ''))}
                          className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-center text-xs font-mono font-bold text-white tracking-widest focus:outline-none focus:border-emerald-400"
                        />
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => setShowPinText(!showPinText)}
                      className="text-[11px] text-slate-400 hover:text-slate-200 flex items-center gap-1 cursor-pointer"
                    >
                      {showPinText ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                      <span>{showPinText ? 'পিন লুকিয়ে রাখুন' : 'পিন দেখুন'}</span>
                    </button>
                  </div>

                  {/* Feature Permissions Toggles */}
                  <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
                    <h3 className="text-xs font-black text-slate-300 uppercase tracking-wider">
                      ফিচার পারমিশন নিয়ন্ত্রণ:
                    </h3>

                    {/* Live Voice Chat Toggle */}
                    <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950 border border-slate-800">
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                          {voiceAllowed ? <Mic className="w-4 h-4" /> : <MicOff className="w-4 h-4 text-rose-400" />}
                        </div>
                        <div>
                          <span className="text-xs font-bold text-white block">লাইভ ভয়েস চ্যাট অনুমতি</span>
                          <span className="text-[10px] text-slate-400">
                            {selectedAge < 13
                              ? '১৩ বছরের নিচের জন্য স্বয়ংক্রিয়ভাবে বন্ধ রাখা হয়েছে'
                              : '১০ জনের লাইভ আড্ডা বোর্ডে ভয়েস কথা বলার অনুমতি'}
                          </span>
                        </div>
                      </div>
                      <input
                        type="checkbox"
                        disabled={selectedAge < 13}
                        checked={voiceAllowed && selectedAge >= 13}
                        onChange={(e) => setVoiceAllowed(e.target.checked)}
                        className="w-5 h-5 accent-emerald-500 cursor-pointer disabled:opacity-40"
                      />
                    </div>

                    {/* Child Safe Filter */}
                    <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950 border border-slate-800">
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-lg bg-teal-500/20 text-teal-400 flex items-center justify-center">
                          <ShieldCheck className="w-4 h-4" />
                        </div>
                        <div>
                          <span className="text-xs font-bold text-white block">চাইল্ড-সেফ মেসেজ ফিল্টার</span>
                          <span className="text-[10px] text-slate-400">
                            সব ধরনের অনুপযুক্ত শব্দ ও স্প্যাম স্বয়ংক্রিয়ভাবে ফিল্টার হবে
                          </span>
                        </div>
                      </div>
                      <input
                        type="checkbox"
                        checked={childSafe}
                        onChange={(e) => setChildSafe(e.target.checked)}
                        className="w-5 h-5 accent-emerald-500 cursor-pointer"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 3: SCREEN TIME LIMITS & WELLBEING */}
              {activeTab === 'screen_time' && (
                <div className="space-y-4 animate-fade-in">
                  <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
                    <div className="flex items-center justify-between">
                      <h3 className="text-xs font-black text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                        <Clock className="w-3.5 h-3.5" />
                        দৈনিক স্ক্রিন টাইম ট্র্যাকার ও লিমিট
                      </h3>
                      <span className="text-xs font-mono font-black text-amber-300">
                        আজ খেলা হয়েছে: {todayPlayedMinutes} মিনিট
                      </span>
                    </div>

                    {/* Progress */}
                    {dailyLimit > 0 && (
                      <div className="space-y-1">
                        <div className="flex justify-between text-[11px] text-slate-400 font-bold">
                          <span>ব্যবহার: {todayPlayedMinutes} মিনিট</span>
                          <span>সর্বোচ্চ সীমা: {dailyLimit} মিনিট</span>
                        </div>
                        <div className="w-full bg-slate-950 rounded-full h-2.5 overflow-hidden border border-slate-800">
                          <div
                            className={`h-full transition-all duration-300 ${
                              progressPercent >= 100
                                ? 'bg-rose-500'
                                : progressPercent >= 75
                                ? 'bg-amber-500'
                                : 'bg-emerald-500'
                            }`}
                            style={{ width: `${progressPercent}%` }}
                          />
                        </div>
                      </div>
                    )}

                    {/* Limit Option Selectors */}
                    <div className="pt-2">
                      <label className="text-[11px] font-bold text-slate-300 block mb-2">
                        দৈনিক খেলার সময়সীমা নির্বাচন করুন:
                      </label>
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                        {[
                          { min: 0, label: 'কোনো সীমা নেই (Unlimited)' },
                          { min: 30, label: '৩০ মিনিট / দিন' },
                          { min: 60, label: '১ ঘণ্টা / দিন' },
                          { min: 120, label: '২ ঘণ্টা / দিন' },
                        ].map((opt) => (
                          <button
                            key={opt.min}
                            type="button"
                            onClick={() => {
                              Sound.playButtonTick();
                              setDailyLimit(opt.min);
                            }}
                            className={`p-2.5 rounded-xl border text-xs font-bold transition-all cursor-pointer text-center ${
                              dailyLimit === opt.min
                                ? 'bg-emerald-500 text-slate-950 border-emerald-400 shadow-md'
                                : 'bg-slate-950 text-slate-300 border-slate-800 hover:border-slate-700'
                            }`}
                          >
                            {opt.label}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="p-4 rounded-2xl bg-amber-950/30 border border-amber-500/40 flex items-start gap-3">
                    <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                    <p className="text-xs text-amber-200/90 leading-relaxed">
                      <strong>ডিজিটাল সুস্থতা পরামর্শ:</strong> চোখের যত্ন ও স্বাভাবিক পড়াশোনার জন্য শিশুদের ক্ষেত্রে প্রতিদিন সর্বোচ্চ ৩০ থেকে ৬০ মিনিটের বেশি একটানা না খেলার পরামর্শ দেওয়া হচ্ছে।
                    </p>
                  </div>
                </div>
              )}
            </>
          )}

          {/* Feedback messages */}
          {pinError && (
            <div className="p-3 rounded-2xl bg-rose-950/60 border border-rose-500 text-rose-300 text-xs font-bold text-center">
              {pinError}
            </div>
          )}

          {saveSuccessMsg && (
            <div className="p-3 rounded-2xl bg-emerald-950/60 border border-emerald-500 text-emerald-300 text-xs font-bold text-center animate-fade-in">
              {saveSuccessMsg}
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="px-5 py-3.5 bg-slate-900 border-t border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-1.5 text-xs text-slate-400">
            <Shield className="w-3.5 h-3.5 text-emerald-400" />
            <span>নিরাপদ গেমিং নির্দেশিকা</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => {
                Sound.playClick();
                onClose();
              }}
              className="px-4 py-2 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition-all cursor-pointer"
            >
              বাতিল
            </button>
            <button
              type="button"
              onClick={handleSaveSettings}
              className="px-5 py-2 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 text-xs font-black shadow-md flex items-center gap-1.5 active:scale-95 transition-all cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>সেটিংস সংরক্ষণ করুন</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
