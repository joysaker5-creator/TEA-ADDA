import React from 'react';
import { AvatarConfig, VipFrameId } from '../types';

interface AvatarDisplayProps {
  avatar?: AvatarConfig;
  size?: number | string;
  className?: string;
  showBadge?: boolean;
  badgeText?: string;
  isSpeaking?: boolean;
  vipFrameId?: VipFrameId | string;
}

export const DEFAULT_AVATAR: AvatarConfig = {
  skinColor: '#fcd34d',
  hairStyle: 'short',
  hairColor: '#1f2937',
  eyes: 'happy',
  mouth: 'smile',
  clothing: 'punjabi',
  clothingColor: '#dc2626',
  accessory: 'glasses',
  bgGradient: 'from-amber-400 to-red-500',
};

export const AvatarDisplay: React.FC<AvatarDisplayProps> = ({
  avatar = DEFAULT_AVATAR,
  size = 48,
  className = '',
  showBadge = false,
  badgeText,
  isSpeaking = false,
  vipFrameId,
}) => {
  const cfg = { ...DEFAULT_AVATAR, ...avatar };
  const activeFrame = vipFrameId || (avatar as unknown as { vipFrameId?: string })?.vipFrameId || 'none';

  // Calculate dimension
  const dimensionStyle =
    typeof size === 'number'
      ? { width: `${size}px`, height: `${size}px` }
      : { width: size, height: size };

  const isPhotoAvatar = cfg.avatarType === 'photo' || (!!cfg.photoUrl && cfg.avatarType !== 'vector');

  // Filter styles
  let filterStyle = 'none';
  if (cfg.photoFilter === 'vivid') filterStyle = 'contrast(1.15) saturate(1.25)';
  else if (cfg.photoFilter === 'warm') filterStyle = 'sepia(0.2) saturate(1.15) brightness(1.03)';
  else if (cfg.photoFilter === 'cool') filterStyle = 'hue-rotate(20deg) saturate(1.1) brightness(1.02)';
  else if (cfg.photoFilter === 'golden') filterStyle = 'sepia(0.35) saturate(1.35) contrast(1.1)';
  else if (cfg.photoFilter === 'bw') filterStyle = 'grayscale(1) contrast(1.2)';

  const scale = cfg.photoScale || 1;

  return (
    <div
      className={`relative inline-flex items-center justify-center rounded-full overflow-visible ${className} ${
        isSpeaking ? 'ring-4 ring-emerald-400 animate-pulse' : ''
      }`}
      style={dimensionStyle}
    >
      <div
        className={`w-full h-full rounded-full bg-gradient-to-tr ${
          cfg.bgGradient || 'from-amber-400 to-red-500'
        } p-0.5 shadow-md flex items-center justify-center overflow-hidden border-2 border-white/80`}
      >
        {isPhotoAvatar && cfg.photoUrl ? (
          <div className="w-full h-full rounded-full overflow-hidden bg-slate-900 flex items-center justify-center">
            <img
              src={cfg.photoUrl}
              alt="Profile"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover rounded-full select-none pointer-events-none transition-transform"
              style={{
                transform: `scale(${scale})`,
                filter: filterStyle,
              }}
              onError={(e) => {
                // If photo URL fails to load, gracefully fallback to default
                (e.currentTarget as HTMLElement).style.display = 'none';
              }}
            />
          </div>
        ) : (
          <svg
            viewBox="0 0 100 100"
            className="w-full h-full"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            {/* Background circle */}
            <circle cx="50" cy="50" r="48" fill="#f8fafc" opacity="0.9" />

          {/* Torso & Clothing */}
          {cfg.clothing === 'punjabi' && (
            <g>
              {/* Traditional Bengali Punjabi / Kurta */}
              <path
                d="M20 100 C20 74 35 70 50 70 C65 70 80 74 80 100 Z"
                fill={cfg.clothingColor}
              />
              {/* Punjabi collar button line */}
              <path d="M47 70 L47 88 L53 88 L53 70 Z" fill="#ffffff" opacity="0.3" />
              <circle cx="50" cy="74" r="1.5" fill="#fef08a" />
              <circle cx="50" cy="79" r="1.5" fill="#fef08a" />
              <circle cx="50" cy="84" r="1.5" fill="#fef08a" />
            </g>
          )}

          {cfg.clothing === 'hoodie' && (
            <g>
              {/* Modern Casual Hoodie */}
              <path
                d="M18 100 C18 72 32 68 50 68 C68 68 82 72 82 100 Z"
                fill={cfg.clothingColor}
              />
              {/* Hoodie cowl */}
              <path
                d="M36 68 C36 78 64 78 64 68 Z"
                fill="#000000"
                opacity="0.25"
              />
              {/* Hoodie strings */}
              <path d="M42 74 L42 86" stroke="#ffffff" strokeWidth="1.5" strokeLinecap="round" />
              <path d="M58 74 L58 86" stroke="#ffffff" strokeWidth="1.5" strokeLinecap="round" />
            </g>
          )}

          {cfg.clothing === 'tshirt' && (
            <g>
              <path
                d="M22 100 C22 75 34 71 50 71 C66 71 78 75 78 100 Z"
                fill={cfg.clothingColor}
              />
              {/* Crew neck */}
              <path
                d="M40 71 C40 79 60 79 60 71 Z"
                fill={cfg.skinColor}
              />
            </g>
          )}

          {cfg.clothing === 'suit' && (
            <g>
              <path
                d="M20 100 C20 74 35 70 50 70 C65 70 80 74 80 100 Z"
                fill="#1e293b"
              />
              {/* Shirt */}
              <polygon points="42,70 58,70 50,88" fill="#ffffff" />
              {/* Tie */}
              <polygon points="48,72 52,72 54,86 50,91 46,86" fill={cfg.clothingColor} />
            </g>
          )}

          {cfg.clothing === 'jersey' && (
            <g>
              {/* Sports Jersey */}
              <path
                d="M20 100 C20 73 34 69 50 69 C66 69 80 73 80 100 Z"
                fill={cfg.clothingColor}
              />
              {/* Jersey stripes */}
              <path d="M30 75 L30 100" stroke="#ffffff" strokeWidth="3" />
              <path d="M70 75 L70 100" stroke="#ffffff" strokeWidth="3" />
              <text x="50" y="88" fontSize="11" fontWeight="bold" textAnchor="middle" fill="#ffffff">
                7
              </text>
            </g>
          )}

          {cfg.clothing === 'royal_robe' && (
            <g>
              {/* Royal Ludo Robe */}
              <path
                d="M18 100 C18 72 32 67 50 67 C68 67 82 72 82 100 Z"
                fill={cfg.clothingColor}
              />
              {/* Gold embroidery border */}
              <path
                d="M35 68 L50 82 L65 68"
                stroke="#facc15"
                strokeWidth="2.5"
                fill="none"
              />
              <circle cx="50" cy="85" r="3" fill="#facc15" />
            </g>
          )}

          {/* Gold Chain Accessory */}
          {cfg.accessory === 'golden_chain' && (
            <path
              d="M38 71 C38 82 62 82 62 71"
              stroke="#fbbf24"
              strokeWidth="2.5"
              strokeLinecap="round"
              fill="none"
            />
          )}

          {/* Neck */}
          <rect x="44" y="58" width="12" height="14" rx="3" fill={cfg.skinColor} />

          {/* Head Base */}
          <ellipse cx="50" cy="46" rx="22" ry="24" fill={cfg.skinColor} />

          {/* Ears */}
          <ellipse cx="28" cy="47" rx="3.5" ry="5.5" fill={cfg.skinColor} />
          <ellipse cx="72" cy="47" rx="3.5" ry="5.5" fill={cfg.skinColor} />

          {/* Eyes */}
          {cfg.eyes === 'normal' && (
            <g>
              <circle cx="41" cy="43" r="3" fill="#1e293b" />
              <circle cx="59" cy="43" r="3" fill="#1e293b" />
              <circle cx="42" cy="42" r="1" fill="#ffffff" />
              <circle cx="60" cy="42" r="1" fill="#ffffff" />
            </g>
          )}

          {cfg.eyes === 'happy' && (
            <g>
              <path
                d="M37 44 C37 40 45 40 45 44"
                stroke="#1e293b"
                strokeWidth="2.5"
                strokeLinecap="round"
                fill="none"
              />
              <path
                d="M55 44 C55 40 63 40 63 44"
                stroke="#1e293b"
                strokeWidth="2.5"
                strokeLinecap="round"
                fill="none"
              />
            </g>
          )}

          {cfg.eyes === 'wink' && (
            <g>
              <path
                d="M37 43 L45 43"
                stroke="#1e293b"
                strokeWidth="2.5"
                strokeLinecap="round"
              />
              <circle cx="59" cy="43" r="3" fill="#1e293b" />
              <circle cx="60" cy="42" r="1" fill="#ffffff" />
            </g>
          )}

          {cfg.eyes === 'cool' && (
            <g>
              {/* Narrow squint */}
              <ellipse cx="41" cy="43" rx="4" ry="2" fill="#1e293b" />
              <ellipse cx="59" cy="43" rx="4" ry="2" fill="#1e293b" />
            </g>
          )}

          {cfg.eyes === 'sparkle' && (
            <g>
              <circle cx="41" cy="43" r="3.5" fill="#3b82f6" />
              <circle cx="59" cy="43" r="3.5" fill="#3b82f6" />
              <polygon points="41,40 42,42 44,42 42,43 43,45 41,43 39,45 40,43 38,42 40,42" fill="#ffffff" />
              <polygon points="59,40 60,42 62,42 60,43 61,45 59,43 57,45 58,43 56,42 58,42" fill="#ffffff" />
            </g>
          )}

          {/* Cheeks Blush */}
          <circle cx="35" cy="49" r="3.5" fill="#f43f5e" opacity="0.25" />
          <circle cx="65" cy="49" r="3.5" fill="#f43f5e" opacity="0.25" />

          {/* Nose */}
          <path
            d="M49 46 C49 49 51 49 51 46"
            stroke="#9a3412"
            strokeWidth="1.2"
            strokeLinecap="round"
            fill="none"
          />

          {/* Mustache Accessory */}
          {cfg.accessory === 'mustache' && (
            <path
              d="M40 54 C45 52 49 54 50 55 C51 54 55 52 60 54 C57 56 52 57 50 56 C48 57 43 56 40 54 Z"
              fill={cfg.hairColor}
            />
          )}

          {/* Mouth */}
          {cfg.mouth === 'smile' && (
            <path
              d="M43 53 C43 58 57 58 57 53"
              stroke="#b91c1c"
              strokeWidth="2"
              strokeLinecap="round"
              fill="none"
            />
          )}

          {cfg.mouth === 'laugh' && (
            <path
              d="M41 52 C41 60 59 60 59 52 Z"
              fill="#b91c1c"
            />
          )}

          {cfg.mouth === 'smirk' && (
            <path
              d="M45 55 C48 56 56 54 57 51"
              stroke="#b91c1c"
              strokeWidth="2"
              strokeLinecap="round"
              fill="none"
            />
          )}

          {cfg.mouth === 'open' && (
            <ellipse cx="50" cy="54" rx="4" ry="5" fill="#991b1b" />
          )}

          {/* Glasses / Sunglasses Accessory */}
          {cfg.accessory === 'glasses' && (
            <g>
              <rect x="34" y="38" width="13" height="10" rx="3" stroke="#0f172a" strokeWidth="2" fill="#ffffff" fillOpacity="0.2" />
              <rect x="53" y="38" width="13" height="10" rx="3" stroke="#0f172a" strokeWidth="2" fill="#ffffff" fillOpacity="0.2" />
              <line x1="47" y1="42" x2="53" y2="42" stroke="#0f172a" strokeWidth="2" />
            </g>
          )}

          {cfg.accessory === 'sunglasses' && (
            <g>
              <rect x="33" y="37" width="15" height="11" rx="3" fill="#0f172a" />
              <rect x="52" y="37" width="15" height="11" rx="3" fill="#0f172a" />
              <line x1="48" y1="41" x2="52" y2="41" stroke="#0f172a" strokeWidth="2.5" />
              <line x1="36" y1="39" x2="45" y2="46" stroke="#94a3b8" strokeWidth="1" strokeLinecap="round" />
              <line x1="55" y1="39" x2="64" y2="46" stroke="#94a3b8" strokeWidth="1" strokeLinecap="round" />
            </g>
          )}

          {/* Hairstyles & Headwear */}
          {cfg.hairStyle === 'short' && (
            <path
              d="M26 38 C26 23 40 18 50 18 C60 18 74 23 74 38 C68 33 58 31 50 31 C40 31 32 33 26 38 Z"
              fill={cfg.hairColor}
            />
          )}

          {cfg.hairStyle === 'curly' && (
            <g fill={cfg.hairColor}>
              <circle cx="32" cy="28" r="8" />
              <circle cx="43" cy="22" r="8" />
              <circle cx="57" cy="22" r="8" />
              <circle cx="68" cy="28" r="8" />
              <circle cx="28" cy="36" r="7" />
              <circle cx="72" cy="36" r="7" />
            </g>
          )}

          {cfg.hairStyle === 'wavy' && (
            <path
              d="M25 45 C23 32 30 18 50 18 C70 18 77 32 75 45 C70 30 65 26 50 26 C35 26 30 30 25 45 Z"
              fill={cfg.hairColor}
            />
          )}

          {cfg.hairStyle === 'cap' && (
            <g>
              {/* Baseball cap / cricket cap */}
              <path
                d="M26 36 C26 24 38 18 50 18 C62 18 74 24 74 36 Z"
                fill="#dc2626"
              />
              <path
                d="M22 36 C34 33 66 33 78 36 L86 38 C68 37 32 37 14 38 Z"
                fill="#b91c1c"
              />
              <circle cx="50" cy="18" r="2" fill="#fef08a" />
            </g>
          )}

          {cfg.hairStyle === 'crown' && (
            <g>
              {/* Royal Ludo Champion Crown */}
              <polygon
                points="28,34 32,18 42,26 50,14 58,26 68,18 72,34"
                fill="#f59e0b"
                stroke="#b45309"
                strokeWidth="1.5"
              />
              <circle cx="32" cy="18" r="2" fill="#ef4444" />
              <circle cx="50" cy="14" r="2.5" fill="#3b82f6" />
              <circle cx="68" cy="18" r="2" fill="#10b981" />
            </g>
          )}

          {cfg.hairStyle === 'turban' && (
            <g>
              {/* Festive Turban / Pagri */}
              <ellipse cx="50" cy="27" rx="25" ry="12" fill="#ea580c" />
              <ellipse cx="50" cy="22" rx="21" ry="9" fill="#c2410c" />
              <circle cx="50" cy="27" r="4" fill="#facc15" />
              <circle cx="50" cy="27" r="2" fill="#ef4444" />
            </g>
          )}

          {cfg.hairStyle === 'hijab' && (
            <g>
              {/* Graceful Hijab */}
              <path
                d="M22 45 C20 22 35 15 50 15 C65 15 80 22 78 45 C78 68 72 74 72 74 C60 76 40 76 28 74 C28 74 22 68 22 45 Z"
                fill={cfg.clothingColor}
                opacity="0.95"
              />
              <ellipse cx="50" cy="47" rx="16" ry="18" fill={cfg.skinColor} />
            </g>
          )}

          {cfg.hairStyle === 'ponytail' && (
            <g>
              <path
                d="M26 36 C26 23 40 18 50 18 C60 18 74 23 74 36 C68 31 58 29 50 29 C42 29 32 31 26 36 Z"
                fill={cfg.hairColor}
              />
              {/* Ponytail puff */}
              <path
                d="M68 24 C78 20 84 28 82 40 C80 32 74 28 68 24 Z"
                fill={cfg.hairColor}
              />
            </g>
          )}

          {/* Headphones Accessory */}
          {cfg.accessory === 'headphone' && (
            <g>
              <path
                d="M24 45 C24 24 76 24 76 45"
                stroke="#334155"
                strokeWidth="4"
                strokeLinecap="round"
                fill="none"
              />
              <rect x="20" y="38" width="6" height="14" rx="3" fill="#0284c7" stroke="#0369a1" strokeWidth="1" />
              <rect x="74" y="38" width="6" height="14" rx="3" fill="#0284c7" stroke="#0369a1" strokeWidth="1" />
            </g>
          )}
        </svg>
        )}
      </div>

      {/* VIP Frame Overlays */}
      {activeFrame === 'vip_gold_dragon' && (
        <div className="absolute -inset-1.5 sm:-inset-2 pointer-events-none z-10 flex items-center justify-center">
          <svg viewBox="0 0 120 120" className="w-full h-full drop-shadow-md animate-pulse">
            {/* Outer Dragon Gold Ring */}
            <circle cx="60" cy="60" r="54" fill="none" stroke="url(#goldDragonGrad)" strokeWidth="5" strokeDasharray="6 3" />
            <circle cx="60" cy="60" r="50" fill="none" stroke="#f59e0b" strokeWidth="1.5" opacity="0.8" />
            {/* Dragon Crest Top */}
            <path d="M50 14 Q60 4 70 14 Q60 10 50 14 Z" fill="#dc2626" stroke="#fbbf24" strokeWidth="1" />
            <circle cx="60" cy="11" r="3.5" fill="#ef4444" stroke="#fef08a" strokeWidth="1" />
            {/* Dragon Claws / Wings side accents */}
            <path d="M12 55 Q6 60 12 65 Q16 60 12 55 Z" fill="#fbbf24" stroke="#b45309" strokeWidth="1" />
            <path d="M108 55 Q114 60 108 65 Q104 60 108 55 Z" fill="#fbbf24" stroke="#b45309" strokeWidth="1" />
            {/* Bottom Gem */}
            <circle cx="60" cy="110" r="3" fill="#f59e0b" stroke="#fff" strokeWidth="1" />
            <defs>
              <linearGradient id="goldDragonGrad" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stopColor="#f59e0b" />
                <stop offset="50%" stopColor="#fef08a" />
                <stop offset="100%" stopColor="#d97706" />
              </linearGradient>
            </defs>
          </svg>
        </div>
      )}

      {activeFrame === 'vip_diamond_crown' && (
        <div className="absolute -inset-1.5 sm:-inset-2 pointer-events-none z-10 flex items-center justify-center">
          <svg viewBox="0 0 120 120" className="w-full h-full drop-shadow-md">
            {/* Diamond Crystal Halo */}
            <circle cx="60" cy="60" r="53" fill="none" stroke="url(#diamondHaloGrad)" strokeWidth="4.5" />
            <circle cx="60" cy="60" r="49" fill="none" stroke="#38bdf8" strokeWidth="1.5" opacity="0.6" strokeDasharray="3 3" />
            {/* Crown Crest Top */}
            <path d="M44 18 L50 24 L60 10 L70 24 L76 18 L72 26 L48 26 Z" fill="#38bdf8" stroke="#ffffff" strokeWidth="1.5" />
            <circle cx="60" cy="9" r="2.5" fill="#ffffff" />
            <circle cx="44" cy="17" r="1.5" fill="#bae6fd" />
            <circle cx="76" cy="17" r="1.5" fill="#bae6fd" />
            {/* Diamond Sparkle nodes */}
            <polygon points="12,60 16,57 20,60 16,63" fill="#e0f2fe" />
            <polygon points="108,60 104,57 100,60 104,63" fill="#e0f2fe" />
            <polygon points="60,111 63,107 60,103 57,107" fill="#e0f2fe" />
            <defs>
              <linearGradient id="diamondHaloGrad" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stopColor="#38bdf8" />
                <stop offset="50%" stopColor="#e0f2fe" />
                <stop offset="100%" stopColor="#0284c7" />
              </linearGradient>
            </defs>
          </svg>
        </div>
      )}

      {activeFrame === 'vip_neon_cyber' && (
        <div className="absolute -inset-1.5 sm:-inset-2 pointer-events-none z-10 flex items-center justify-center">
          <svg viewBox="0 0 120 120" className="w-full h-full drop-shadow-md">
            {/* Cyber Ring */}
            <circle cx="60" cy="60" r="53" fill="none" stroke="url(#cyberNeonGrad)" strokeWidth="4" strokeDasharray="14 4 4 4" />
            {/* High Tech Corner nodes */}
            <rect x="55" y="4" width="10" height="4" rx="2" fill="#06b6d4" />
            <rect x="55" y="112" width="10" height="4" rx="2" fill="#d946ef" />
            <rect x="4" y="55" width="4" height="10" rx="2" fill="#06b6d4" />
            <rect x="112" y="55" width="4" height="10" rx="2" fill="#d946ef" />
            {/* Circuit Dots */}
            <circle cx="24" cy="24" r="2.5" fill="#22d3ee" />
            <circle cx="96" cy="24" r="2.5" fill="#f43f5e" />
            <circle cx="24" cy="96" r="2.5" fill="#a855f7" />
            <circle cx="96" cy="96" r="2.5" fill="#06b6d4" />
            <defs>
              <linearGradient id="cyberNeonGrad" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stopColor="#06b6d4" />
                <stop offset="50%" stopColor="#d946ef" />
                <stop offset="100%" stopColor="#3b82f6" />
              </linearGradient>
            </defs>
          </svg>
        </div>
      )}

      {activeFrame === 'vip_flame_phoenix' && (
        <div className="absolute -inset-2 sm:-inset-2.5 pointer-events-none z-10 flex items-center justify-center">
          <svg viewBox="0 0 120 120" className="w-full h-full drop-shadow-lg animate-pulse">
            {/* Flame Solar Ring */}
            <circle cx="60" cy="60" r="52" fill="none" stroke="url(#phoenixFlameGrad)" strokeWidth="5" />
            {/* Top Phoenix Fire Crest */}
            <path d="M46 16 Q52 4 60 0 Q68 4 74 16 Q66 10 60 14 Q54 10 46 16 Z" fill="url(#phoenixFlameGrad)" />
            <path d="M53 14 Q60 5 67 14 Q60 10 53 14 Z" fill="#fef08a" />
            {/* Side Flames */}
            <path d="M10 48 Q3 58 10 68 Q14 58 10 48 Z" fill="#f97316" />
            <path d="M110 48 Q117 58 110 68 Q106 58 110 48 Z" fill="#f97316" />
            <circle cx="60" cy="112" r="3" fill="#f97316" stroke="#fed7aa" strokeWidth="1" />
            <defs>
              <linearGradient id="phoenixFlameGrad" x1="0" y1="1" x2="0" y2="0">
                <stop offset="0%" stopColor="#ea580c" />
                <stop offset="50%" stopColor="#f97316" />
                <stop offset="100%" stopColor="#fde047" />
              </linearGradient>
            </defs>
          </svg>
        </div>
      )}

      {activeFrame === 'vip_galaxy_star' && (
        <div className="absolute -inset-1.5 sm:-inset-2 pointer-events-none z-10 flex items-center justify-center">
          <svg viewBox="0 0 120 120" className="w-full h-full drop-shadow-md">
            {/* Cosmic Orbit Ring */}
            <circle cx="60" cy="60" r="53" fill="none" stroke="url(#galaxyGrad)" strokeWidth="4.5" strokeDasharray="18 4" />
            <circle cx="60" cy="60" r="49" fill="none" stroke="#c084fc" strokeWidth="1.5" opacity="0.7" />
            {/* Stars */}
            <polygon points="60,4 63,12 71,12 65,17 67,25 60,20 53,25 55,17 49,12 57,12" fill="#fbbf24" stroke="#fff" strokeWidth="0.5" />
            <polygon points="14,60 16,64 20,64 17,66 18,70 14,68 10,70 11,66 8,64 12,64" fill="#fbbf24" />
            <polygon points="106,60 108,64 112,64 109,66 110,70 106,68 102,70 103,66 100,64 104,64" fill="#fbbf24" />
            <circle cx="34" cy="94" r="2" fill="#fdf4ff" />
            <circle cx="86" cy="94" r="2" fill="#fdf4ff" />
            <defs>
              <linearGradient id="galaxyGrad" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stopColor="#818cf8" />
                <stop offset="50%" stopColor="#c084fc" />
                <stop offset="100%" stopColor="#ec4899" />
              </linearGradient>
            </defs>
          </svg>
        </div>
      )}

      {activeFrame === 'vip_royal_emperor' && (
        <div className="absolute -inset-2 sm:-inset-2.5 pointer-events-none z-10 flex items-center justify-center">
          <svg viewBox="0 0 120 120" className="w-full h-full drop-shadow-lg">
            {/* Emperor Gold Ring */}
            <circle cx="60" cy="60" r="52" fill="none" stroke="url(#emperorGoldGrad)" strokeWidth="6" />
            {/* Gold Laurel Leaves Wreath & Top Fleur-de-lis */}
            <path d="M53 16 Q60 2 67 16 Q60 11 53 16 Z" fill="#fbbf24" stroke="#78350f" strokeWidth="1" />
            <path d="M45 20 Q48 10 55 17 Z" fill="#f59e0b" />
            <path d="M75 20 Q72 10 65 17 Z" fill="#f59e0b" />
            {/* Wreath side leaves */}
            <circle cx="11" cy="40" r="3" fill="#fde047" stroke="#b45309" strokeWidth="0.5" />
            <circle cx="9" cy="60" r="3.5" fill="#fbbf24" stroke="#b45309" strokeWidth="0.5" />
            <circle cx="11" cy="80" r="3" fill="#f59e0b" stroke="#b45309" strokeWidth="0.5" />
            <circle cx="109" cy="40" r="3" fill="#fde047" stroke="#b45309" strokeWidth="0.5" />
            <circle cx="111" cy="60" r="3.5" fill="#fbbf24" stroke="#b45309" strokeWidth="0.5" />
            <circle cx="109" cy="80" r="3" fill="#f59e0b" stroke="#b45309" strokeWidth="0.5" />
            {/* Bottom Royal Crest */}
            <circle cx="60" cy="112" r="4.5" fill="#dc2626" stroke="#fde047" strokeWidth="1.5" />
            <defs>
              <linearGradient id="emperorGoldGrad" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stopColor="#fde047" />
                <stop offset="50%" stopColor="#f59e0b" />
                <stop offset="100%" stopColor="#b45309" />
              </linearGradient>
            </defs>
          </svg>
        </div>
      )}

      {/* Floating Badge */}
      {showBadge && (
        <span className="absolute -bottom-1 -right-1 px-1.5 py-0.5 rounded-full bg-amber-500 text-slate-950 font-black text-[9px] border-2 border-white shadow-sm z-20">
          {badgeText || '★'}
        </span>
      )}
    </div>
  );
};
