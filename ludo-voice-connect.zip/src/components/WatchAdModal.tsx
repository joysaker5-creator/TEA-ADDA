import React, { useState, useEffect } from 'react';
import { X, Play, Gift, Sparkles, CheckCircle, Flame, Tv } from 'lucide-react';
import { Sound } from '../utils/soundEffects';

interface WatchAdModalProps {
  isOpen: boolean;
  onClose: () => void;
  onRewardClaimed: (rewardCoins: number, rewardDiamonds?: number) => void;
}

export const WatchAdModal: React.FC<WatchAdModalProps> = ({
  isOpen,
  onClose,
  onRewardClaimed,
}) => {
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [secondsRemaining, setSecondsRemaining] = useState<number>(6);
  const [canClaim, setCanClaim] = useState<boolean>(false);
  const [claimed, setClaimed] = useState<boolean>(false);

  useEffect(() => {
    if (!isOpen) {
      setIsPlaying(false);
      setSecondsRemaining(6);
      setCanClaim(false);
      setClaimed(false);
      return;
    }

    // Auto-start video ad on open
    setIsPlaying(true);
    setSecondsRemaining(6);
    setCanClaim(false);
    setClaimed(false);
  }, [isOpen]);

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isPlaying && secondsRemaining > 0) {
      timer = setTimeout(() => {
        setSecondsRemaining((prev) => prev - 1);
      }, 1000);
    } else if (isPlaying && secondsRemaining === 0) {
      setCanClaim(true);
      Sound.playCapture();
    }
    return () => clearTimeout(timer);
  }, [isPlaying, secondsRemaining]);

  if (!isOpen) return null;

  const handleClaim = async () => {
    Sound.playWin();
    setClaimed(true);

    try {
      const res = await fetch('/api/ads/reward', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
      const data = await res.json();
      const rewardedCoins = data.reward || 350;
      onRewardClaimed(rewardedCoins, 2);
    } catch {
      onRewardClaimed(350, 2);
    }

    setTimeout(() => {
      onClose();
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-sm animate-fade-in">
      <div
        id="watch-ad-modal"
        className="relative w-full max-w-md bg-white rounded-3xl p-5 shadow-2xl border-4 border-purple-400 border-b-8 border-b-purple-600 text-slate-900 overflow-hidden"
      >
        {/* Close Button (disabled while ad is forced to ensure genuine watch) */}
        <button
          disabled={!canClaim && !claimed}
          onClick={onClose}
          className={`absolute top-4 right-4 p-2 rounded-full transition-colors z-20 ${
            canClaim || claimed
              ? 'bg-purple-100 hover:bg-purple-200 text-purple-900 font-bold'
              : 'opacity-40 cursor-not-allowed bg-slate-100 text-slate-400'
          }`}
          title={canClaim ? 'বন্ধ করুন' : 'এড শেষ হওয়া পর্যন্ত অপেক্ষা করুন'}
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 mb-4">
          <div className="w-11 h-11 rounded-2xl bg-gradient-to-r from-purple-500 to-indigo-600 flex items-center justify-center text-white shadow-md border-b-2 border-indigo-800">
            <Tv className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-black text-slate-900">ভিডিও এড দেখে ফ্রি রিওয়ার্ড</h2>
            <p className="text-xs text-purple-700 font-bold flex items-center gap-1">
              <Flame className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
              প্রতি এডে পাবেন +৩৫০ কয়েন ও +২ ডায়মন্ড 💎!
            </p>
          </div>
        </div>

        {/* Video Ad Player Simulation */}
        <div className="relative aspect-video w-full rounded-2xl bg-gradient-to-br from-indigo-950 via-purple-950 to-slate-900 border-2 border-purple-300 overflow-hidden shadow-inner flex flex-col items-center justify-center text-white p-4">
          {/* Ad Sponsor Tag */}
          <div className="absolute top-2.5 left-2.5 bg-black/60 backdrop-blur-md px-2 py-0.5 rounded-md text-[10px] font-bold text-amber-300 border border-amber-400/30">
            বিজ্ঞাপন • Sponsor Ad
          </div>

          {/* Ad Countdown Badge */}
          <div className="absolute top-2.5 right-2.5 bg-purple-600/90 px-2.5 py-0.5 rounded-full text-xs font-black text-white shadow-sm border border-purple-400">
            {secondsRemaining > 0 ? `${secondsRemaining} সে.` : 'সম্পন্ন!'}
          </div>

          {/* Ad Screen Content */}
          <div className="text-center flex flex-col items-center justify-center space-y-2">
            <div className="w-14 h-14 rounded-2xl bg-amber-400 border-b-4 border-amber-600 flex items-center justify-center shadow-lg text-amber-950 animate-bounce">
              <Gift className="w-8 h-8 fill-amber-200" />
            </div>
            <h3 className="text-lg font-black text-amber-300 tracking-tight">লুডু রয়্যাল প্রিমিয়াম লাক বক্স</h3>
            <p className="text-xs text-slate-200 font-medium max-w-[240px]">
              প্রতিদিন নতুন রিওয়ার্ড জিতুন এবং বন্ধুদের সাথে ভয়েস চ্যাটে সরাসরি খেলুন!
            </p>
          </div>

          {/* Ad Progress Bar */}
          <div className="absolute bottom-0 left-0 right-0 h-2 bg-purple-950">
            <div
              className="h-full bg-gradient-to-r from-amber-400 to-emerald-400 transition-all duration-1000"
              style={{ width: `${((6 - secondsRemaining) / 6) * 100}%` }}
            />
          </div>
        </div>

        {/* Reward Status & Claim Button */}
        <div className="mt-4">
          {claimed ? (
            <div className="py-3 bg-emerald-50 border-2 border-emerald-300 rounded-2xl flex items-center justify-center gap-2 text-emerald-800 font-black animate-scale-up">
              <CheckCircle className="w-6 h-6 text-emerald-600" />
              <span>+৩৫০ কয়েন ও +২ ডায়মন্ড 💎 ব্যালেন্সে যোগ হয়েছে!</span>
            </div>
          ) : canClaim ? (
            <button
              id="claim-ad-reward-btn"
              onClick={handleClaim}
              className="w-full py-3.5 rounded-2xl bg-emerald-500 hover:bg-emerald-600 text-white font-black text-base uppercase tracking-wider shadow-lg border-b-4 border-emerald-700 active:translate-y-1 active:border-b-0 transition-all flex items-center justify-center gap-2 animate-bounce cursor-pointer"
            >
              <Sparkles className="w-5 h-5" />
              <span>+৩৫০ কয়েন ও +২ ডায়মন্ড সংগ্রহ করুন</span>
            </button>
          ) : (
            <div className="w-full py-3.5 rounded-2xl bg-slate-100 border-2 border-slate-300 text-slate-600 font-bold text-center text-sm flex items-center justify-center gap-2">
              <Play className="w-4 h-4 animate-spin" />
              <span>এড দেখা শেষ হলে রিওয়ার্ড ক্লেইম করুন ({secondsRemaining} সে.)</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
