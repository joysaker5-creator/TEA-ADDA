import React from 'react';
import { Crown, Sparkles, Diamond, Flame } from 'lucide-react';
import { VipBadgeId, VipTierId } from '../types';
import { VIP_BADGES } from '../utils/vipConstants';

interface VipBadgeProps {
  badgeId?: VipBadgeId | string;
  tier?: VipTierId;
  size?: 'sm' | 'md' | 'lg';
  showText?: boolean;
  className?: string;
  animate?: boolean;
}

export const VipBadge: React.FC<VipBadgeProps> = ({
  badgeId = 'vip_crown',
  tier = 'vip_gold',
  size = 'sm',
  showText = true,
  className = '',
  animate = true,
}) => {
  const badgeDef = VIP_BADGES.find((b) => b.id === badgeId) || VIP_BADGES[0];

  // Sizing styles
  let sizeClasses = 'px-1.5 py-0.2 text-[9px] gap-1';
  let iconSize = 'w-2.5 h-2.5';
  if (size === 'md') {
    sizeClasses = 'px-2 py-0.5 text-[10px] gap-1.5 font-black';
    iconSize = 'w-3.5 h-3.5';
  } else if (size === 'lg') {
    sizeClasses = 'px-3 py-1 text-xs gap-2 font-black tracking-wider';
    iconSize = 'w-4 h-4';
  }

  return (
    <span
      className={`inline-flex items-center rounded-full font-black select-none shadow-xs border ${
        badgeDef.styleClass
      } ${badgeDef.borderClass} ${sizeClasses} ${className} ${
        animate ? 'animate-pulse hover:scale-105 transition-transform' : ''
      }`}
      title={`${badgeDef.nameBn} - জয় লুডু প্রিমিয়াম প্লেয়ার`}
    >
      <span className="relative flex items-center justify-center">
        {badgeDef.id === 'vip_diamond' ? (
          <Diamond className={`${iconSize} fill-cyan-200 text-cyan-900`} />
        ) : badgeDef.id === 'vip_flame' ? (
          <Flame className={`${iconSize} fill-amber-300 text-rose-900`} />
        ) : badgeDef.id === 'vip_gold' ? (
          <Sparkles className={`${iconSize} fill-amber-200 text-amber-900`} />
        ) : (
          <Crown className={`${iconSize} fill-amber-200 text-amber-900`} />
        )}
      </span>

      {showText && (
        <span className="leading-none tracking-tight font-black uppercase drop-shadow-xs">
          VIP
        </span>
      )}
    </span>
  );
};
