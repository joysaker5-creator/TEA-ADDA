import React, { useState } from 'react';
import {
  Globe,
  Zap,
  Plus,
  LogIn,
  Users,
  Copy,
  Check,
  X,
  Coins,
  Radio,
  Sparkles,
  RefreshCw,
} from 'lucide-react';
import { Player, PlayerColor, AvatarConfig } from '../types';
import { AvatarDisplay } from './AvatarDisplay';
import { COLOR_CONFIG } from '../utils/ludoConstants';
import { Sound } from '../utils/soundEffects';

interface OnlineRoomModalProps {
  isOpen: boolean;
  onClose: () => void;
  userCoins: number;
  userAvatar: AvatarConfig;
  currentRoomId: string | null;
  onlinePlayers: Player[];
  isHost: boolean;
  isSearchingMatch: boolean;
  onQuickMatch: (entryFee: number) => void;
  onCreateRoom: (entryFee: number) => void;
  onJoinRoom: (roomId: string) => void;
  onStartGame: () => void;
  onLeaveRoom: () => void;
}

export const OnlineRoomModal: React.FC<OnlineRoomModalProps> = ({
  isOpen,
  onClose,
  userCoins,
  userAvatar,
  currentRoomId,
  onlinePlayers,
  isHost,
  isSearchingMatch,
  onQuickMatch,
  onCreateRoom,
  onJoinRoom,
  onStartGame,
  onLeaveRoom,
}) => {
  const [tab, setTab] = useState<'quick' | 'create' | 'join'>('quick');
  const [selectedFee, setSelectedFee] = useState<number>(50);
  const [inputRoomCode, setInputRoomCode] = useState<string>('');
  const [copied, setCopied] = useState<boolean>(false);

  if (!isOpen) return null;

  const handleCopyCode = () => {
    if (!currentRoomId) return;
    navigator.clipboard?.writeText(currentRoomId);
    setCopied(true);
    Sound.playClick();
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in">
      <div
        id="online-room-modal"
        className="relative w-full max-w-lg bg-white rounded-3xl p-5 sm:p-6 shadow-2xl border-4 border-amber-300 border-b-8 border-b-amber-500 text-slate-900 overflow-hidden flex flex-col max-h-[90vh]"
      >
        {/* Close Button */}
        <button
          id="close-online-modal-btn"
          onClick={() => {
            Sound.playClick();
            onClose();
          }}
          className="absolute top-4 right-4 p-2 rounded-2xl bg-amber-100 hover:bg-amber-200 text-amber-900 border border-amber-300 transition-all active:scale-95"
          title="বন্ধ করুন"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-red-500 to-amber-500 flex items-center justify-center text-white shadow-md border-b-2 border-red-700">
            <Globe className="w-6 h-6 animate-spin-slow" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-black text-amber-950 tracking-tight leading-none">
                লাইভ অনলাইন লুডু
              </h2>
              <span className="bg-red-500 text-white text-[10px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider animate-pulse">
                রিয়েল-টাইম
              </span>
            </div>
            <p className="text-xs text-amber-800 font-bold mt-1">
              যেকোনো খেলোয়াড়ের সাথে ম্যাচিং ও লাইভ ভয়েস চ্যাট
            </p>
          </div>
        </div>

        {/* Current Room Active Lobby View */}
        {currentRoomId ? (
          <div className="flex flex-col gap-4 overflow-y-auto pr-1">
            {/* Room Info Banner */}
            <div className="bg-gradient-to-r from-amber-500 to-red-500 text-white p-4 rounded-2xl shadow-md flex items-center justify-between">
              <div>
                <span className="text-xs font-bold text-amber-200 uppercase tracking-wider block">
                  রুম কোড
                </span>
                <span className="text-2xl font-black tracking-widest">{currentRoomId}</span>
              </div>
              <button
                onClick={handleCopyCode}
                className="flex items-center gap-1.5 px-3 py-2 bg-white/20 hover:bg-white/30 active:bg-white/40 rounded-xl text-xs font-bold transition-all border border-white/30"
              >
                {copied ? <Check className="w-4 h-4 text-emerald-300" /> : <Copy className="w-4 h-4" />}
                <span>{copied ? 'কপি হয়েছে' : 'কোড কপি'}</span>
              </button>
            </div>

            {/* Players in Room */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-black text-amber-950 uppercase tracking-wider">
                  রুমে যুক্ত খেলোয়াড় ({onlinePlayers.length}/৪)
                </span>
                <span className="text-xs text-emerald-700 font-extrabold flex items-center gap-1">
                  <Radio className="w-3.5 h-3.5 animate-pulse" />
                  ভয়েস কানেক্টেড
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                {[0, 1, 2, 3].map((slotIdx) => {
                  const player = onlinePlayers[slotIdx];
                  const colors: PlayerColor[] = ['red', 'green', 'yellow', 'blue'];
                  const slotColor = colors[slotIdx];
                  const config = (slotColor && COLOR_CONFIG[slotColor]) || COLOR_CONFIG.red;

                  if (player) {
                    return (
                      <div
                        key={player.id}
                        className="p-2.5 rounded-2xl border-2 bg-white shadow-sm flex items-center gap-2.5"
                        style={{ borderColor: config.borderHex }}
                      >
                        <AvatarDisplay avatar={player.avatar || userAvatar} size={38} />
                        <div className="flex flex-col min-w-0">
                          <span className="text-xs font-black text-slate-900 truncate">
                            {player.name}
                          </span>
                          <span
                            className="text-[10px] font-bold"
                            style={{ color: config.borderHex }}
                          >
                            {config.name} Team
                          </span>
                        </div>
                      </div>
                    );
                  }

                  return (
                    <div
                      key={`empty_${slotIdx}`}
                      className="p-3 rounded-2xl border-2 border-dashed border-slate-300 bg-slate-50 flex items-center justify-center gap-2 text-slate-400"
                    >
                      <RefreshCw className="w-4 h-4 animate-spin text-slate-400" />
                      <span className="text-xs font-bold">অপেক্ষারত...</span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center gap-3 mt-2">
              <button
                onClick={() => {
                  Sound.playClick();
                  onLeaveRoom();
                }}
                className="flex-1 py-2.5 px-4 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-black text-xs transition-all border border-slate-300"
              >
                রুম ত্যাগ করুন
              </button>

              {isHost ? (
                <button
                  id="start-online-game-btn"
                  onClick={() => {
                    Sound.playClick();
                    onStartGame();
                  }}
                  disabled={onlinePlayers.length < 2}
                  className={`flex-1 py-2.5 px-4 rounded-2xl text-xs font-black transition-all shadow-md border-b-4 ${
                    onlinePlayers.length >= 2
                      ? 'bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white border-green-800 active:translate-y-0.5'
                      : 'bg-slate-300 text-slate-500 border-slate-400 cursor-not-allowed'
                  }`}
                >
                  {onlinePlayers.length < 2 ? 'কমপক্ষে ২ জন প্রয়োজন' : 'খেলা শুরু করুন 🎲'}
                </button>
              ) : (
                <div className="flex-1 text-center py-2 bg-amber-100 rounded-2xl border border-amber-300 text-amber-900 text-xs font-bold">
                  হোস্ট খেলা শুরু করার জন্য অপেক্ষা করুন...
                </div>
              )}
            </div>
          </div>
        ) : (
          /* Matchmaking & Room Discovery Tabs */
          <div className="flex flex-col gap-4 overflow-y-auto pr-1">
            {/* Top Navigation Tabs */}
            <div className="grid grid-cols-3 gap-1.5 p-1 bg-amber-100 rounded-2xl border border-amber-300">
              <button
                onClick={() => setTab('quick')}
                className={`py-2 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-1 ${
                  tab === 'quick'
                    ? 'bg-red-500 text-white shadow-sm'
                    : 'text-amber-900 hover:bg-amber-200/60'
                }`}
              >
                <Zap className="w-3.5 h-3.5" />
                <span>দ্রুত ম্যাচ</span>
              </button>

              <button
                onClick={() => setTab('create')}
                className={`py-2 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-1 ${
                  tab === 'create'
                    ? 'bg-red-500 text-white shadow-sm'
                    : 'text-amber-900 hover:bg-amber-200/60'
                }`}
              >
                <Plus className="w-3.5 h-3.5" />
                <span>নতুন রুম</span>
              </button>

              <button
                onClick={() => setTab('join')}
                className={`py-2 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-1 ${
                  tab === 'join'
                    ? 'bg-red-500 text-white shadow-sm'
                    : 'text-amber-900 hover:bg-amber-200/60'
                }`}
              >
                <LogIn className="w-3.5 h-3.5" />
                <span>যোগ দিন</span>
              </button>
            </div>

            {/* Profile Avatar Ready Card */}
            <div className="bg-amber-50 rounded-2xl p-3 border-2 border-amber-200 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <AvatarDisplay avatar={userAvatar} size={44} />
                <div>
                  <span className="text-xs font-black text-amber-950 block">আপনার অবতার প্রস্তুত</span>
                  <span className="text-[10px] text-emerald-700 font-extrabold flex items-center gap-1">
                    <Check className="w-3 h-3 text-emerald-600" />
                    অনলাইন ম্যাচে এই অবতার প্রদর্শিত হবে
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-1 text-amber-900 text-xs font-black bg-amber-200/80 px-2.5 py-1 rounded-xl">
                <Coins className="w-3.5 h-3.5 fill-amber-500 text-amber-600" />
                <span>{userCoins.toLocaleString('bn-BD')} কয়েন</span>
              </div>
            </div>

            {/* TAB 1: QUICK MATCH (যেকোনো খেলোয়াড়ের সাথে লাইভ ম্যাচ) */}
            {tab === 'quick' && (
              <div className="flex flex-col gap-3">
                <div>
                  <label className="text-xs font-black text-amber-950 uppercase tracking-wider block mb-1.5">
                    এন্ট্রি ফি নির্ধারণ করুন (কয়েন)
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    {[50, 100, 500].map((fee) => (
                      <button
                        key={fee}
                        onClick={() => setSelectedFee(fee)}
                        className={`p-3 rounded-2xl border-2 text-center transition-all ${
                          selectedFee === fee
                            ? 'border-red-500 bg-red-50 text-red-950 font-black shadow-sm'
                            : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50 font-bold'
                        }`}
                      >
                        <span className="text-base font-black block">{fee}</span>
                        <span className="text-[10px] text-slate-500 font-semibold">কয়েন</span>
                      </button>
                    ))}
                  </div>
                </div>

                <div className="p-3.5 rounded-2xl bg-gradient-to-br from-purple-50 to-indigo-50 border border-purple-200 text-purple-950 text-xs flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-purple-600 shrink-0" />
                  <span>
                    <strong>যে কারো সাথে খেলুন:</strong> সিস্টেম আপনাকে যেকোনো সক্রিয় খেলোয়াড়ের সাথে লাইভ টেবিলে যুক্ত করবে।
                  </span>
                </div>

                <button
                  id="btn-start-quick-match"
                  onClick={() => {
                    Sound.playClick();
                    onQuickMatch(selectedFee);
                  }}
                  disabled={isSearchingMatch || userCoins < selectedFee}
                  className={`w-full py-3 px-4 rounded-2xl text-xs font-black transition-all shadow-md border-b-4 flex items-center justify-center gap-2 ${
                    isSearchingMatch
                      ? 'bg-amber-400 text-amber-950 border-amber-600 cursor-wait'
                      : userCoins < selectedFee
                      ? 'bg-slate-300 text-slate-500 border-slate-400 cursor-not-allowed'
                      : 'bg-gradient-to-r from-red-500 to-amber-500 hover:from-red-600 hover:to-amber-600 text-white border-red-700 active:translate-y-0.5'
                  }`}
                >
                  {isSearchingMatch ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>খেলোয়াড় খোঁজা হচ্ছে...</span>
                    </>
                  ) : userCoins < selectedFee ? (
                    <span>পর্যাপ্ত কয়েন নেই (রিচার্জ করুন)</span>
                  ) : (
                    <>
                      <Zap className="w-4 h-4" />
                      <span>যে কারো সাথে এখনই খেলুন ({selectedFee} কয়েন)</span>
                    </>
                  )}
                </button>
              </div>
            )}

            {/* TAB 2: CREATE PRIVATE ROOM */}
            {tab === 'create' && (
              <div className="flex flex-col gap-3">
                <div>
                  <label className="text-xs font-black text-amber-950 uppercase tracking-wider block mb-1.5">
                    রুম এন্ট্রি ফি নির্ধারণ করুন
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    {[50, 100, 500].map((fee) => (
                      <button
                        key={fee}
                        onClick={() => setSelectedFee(fee)}
                        className={`p-3 rounded-2xl border-2 text-center transition-all ${
                          selectedFee === fee
                            ? 'border-red-500 bg-red-50 text-red-950 font-black shadow-sm'
                            : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50 font-bold'
                        }`}
                      >
                        <span className="text-base font-black block">{fee}</span>
                        <span className="text-[10px] text-slate-500 font-semibold">কয়েন</span>
                      </button>
                    ))}
                  </div>
                </div>

                <div className="p-3.5 rounded-2xl bg-amber-50 border border-amber-200 text-amber-950 text-xs">
                  রুম তৈরি করার পর আপনি একটি ৬ অক্ষরের কোড পাবেন, যা বন্ধুদের দিয়ে একই টেবিলে আমন্ত্রণ জানাতে পারবেন।
                </div>

                <button
                  id="btn-create-room"
                  onClick={() => {
                    Sound.playClick();
                    onCreateRoom(selectedFee);
                  }}
                  disabled={userCoins < selectedFee}
                  className="w-full py-3 px-4 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white text-xs font-black transition-all shadow-md border-b-4 border-emerald-800 active:translate-y-0.5 flex items-center justify-center gap-2"
                >
                  <Plus className="w-4 h-4" />
                  <span>নতুন প্রাইভেট রুম তৈরি করুন</span>
                </button>
              </div>
            )}

            {/* TAB 3: JOIN ROOM WITH CODE */}
            {tab === 'join' && (
              <div className="flex flex-col gap-3">
                <div>
                  <label className="text-xs font-black text-amber-950 uppercase tracking-wider block mb-1.5">
                    বন্ধুর দেওয়া রুম কোড দিন
                  </label>
                  <input
                    type="text"
                    value={inputRoomCode}
                    onChange={(e) => setInputRoomCode(e.target.value.toUpperCase())}
                    placeholder="উদাহরণ: LUDO-8821"
                    className="w-full p-3 rounded-2xl border-2 border-amber-300 focus:border-red-500 focus:outline-none text-base font-black tracking-widest text-center uppercase"
                  />
                </div>

                <button
                  id="btn-join-room"
                  onClick={() => {
                    if (inputRoomCode.trim()) {
                      Sound.playClick();
                      onJoinRoom(inputRoomCode.trim());
                    }
                  }}
                  disabled={!inputRoomCode.trim()}
                  className={`w-full py-3 px-4 rounded-2xl text-xs font-black transition-all shadow-md border-b-4 flex items-center justify-center gap-2 ${
                    inputRoomCode.trim()
                      ? 'bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 text-white border-indigo-800 active:translate-y-0.5'
                      : 'bg-slate-300 text-slate-500 border-slate-400 cursor-not-allowed'
                  }`}
                >
                  <LogIn className="w-4 h-4" />
                  <span>রুমে প্রবেশ করুন</span>
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
