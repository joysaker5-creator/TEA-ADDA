import React from 'react';
import { PlayerColor, TokenStyleId } from '../types';
import { COLOR_CONFIG } from '../utils/ludoConstants';

interface TokenPieceProps {
  color: PlayerColor;
  styleId?: TokenStyleId;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  isEligible?: boolean;
  isStacked?: boolean;
  onClick?: () => void;
  disabled?: boolean;
  title?: string;
  className?: string;
}

export const TokenPiece: React.FC<TokenPieceProps> = ({
  color,
  styleId = 'classic',
  size = 'md',
  isEligible = false,
  isStacked = false,
  onClick,
  disabled = false,
  title,
  className = '',
}) => {
  const config = (color && COLOR_CONFIG[color]) || COLOR_CONFIG.red;

  // Sizing map
  const sizeClasses = {
    sm: 'w-5 h-5 sm:w-6 sm:h-6',
    md: isStacked ? 'w-5 h-5 sm:w-6 sm:h-6' : 'w-6 h-6 sm:w-7 sm:h-7',
    lg: 'w-8 h-8 sm:w-9 sm:h-9',
    xl: 'w-11 h-11 sm:w-12 sm:h-12',
  }[size];

  // Team gradient backgrounds
  const colorGradients: Record<PlayerColor, { from: string; to: string; border: string; glow: string }> = {
    red: { from: '#f43f5e', to: '#be123c', border: '#881337', glow: '#f43f5e' },
    green: { from: '#22c55e', to: '#15803d', border: '#052e16', glow: '#22c55e' },
    yellow: { from: '#fde047', to: '#d97706', border: '#78350f', glow: '#eab308' },
    blue: { from: '#38bdf8', to: '#1d4ed8', border: '#0f172a', glow: '#38bdf8' },
  };

  const clr = (color && colorGradients[color]) || colorGradients.red;

  // Render style-specific interior
  const renderInterior = () => {
    switch (styleId) {
      case 'crown':
        return (
          <div className="relative w-full h-full flex items-center justify-center">
            {/* Golden Crown Icon */}
            <svg viewBox="0 0 24 24" className="w-[72%] h-[72%] drop-shadow-md">
              <defs>
                <linearGradient id={`crownGold_${color}`} x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#fef08a" />
                  <stop offset="50%" stopColor="#eab308" />
                  <stop offset="100%" stopColor="#ca8a04" />
                </linearGradient>
              </defs>
              <path
                d="M2 19h20v2H2zM4 17h16l-2-10-4.5 5L12 4 8.5 12 4 7z"
                fill={`url(#crownGold_${color})`}
                stroke="#854d0e"
                strokeWidth="1.2"
                strokeLinejoin="round"
              />
              {/* Crown jewels */}
              <circle cx="4" cy="7" r="1.5" fill="#f43f5e" />
              <circle cx="12" cy="4" r="1.8" fill="#fef08a" />
              <circle cx="20" cy="7" r="1.5" fill="#38bdf8" />
            </svg>
          </div>
        );

      case 'shield':
        return (
          <div className="relative w-full h-full flex items-center justify-center">
            {/* Warrior Shield */}
            <svg viewBox="0 0 24 24" className="w-[75%] h-[75%] drop-shadow-md">
              <defs>
                <linearGradient id={`shieldGrad_${color}`} x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#ffffff" stopOpacity="0.9" />
                  <stop offset="100%" stopColor="#cbd5e1" stopOpacity="0.4" />
                </linearGradient>
              </defs>
              <path
                d="M12 2L4 5v6.09c0 5.05 3.41 9.76 8 10.91 4.59-1.15 8-5.86 8-10.91V5l-8-3z"
                fill={`url(#shieldGrad_${color})`}
                stroke="#ffffff"
                strokeWidth="1.4"
                strokeLinejoin="round"
              />
              <path
                d="M12 5v14c3.2-.9 5.8-4.5 5.8-8.5V7.2L12 5z"
                fill="#ffffff"
                fillOpacity="0.3"
              />
              {/* Center emblem */}
              <path
                d="M12 8l1.5 3.5H17l-3 2.5 1.2 3.8-3.2-2.3-3.2 2.3 1.2-3.8-3-2.5h3.5z"
                fill="#ffffff"
              />
            </svg>
          </div>
        );

      case 'diamond':
        return (
          <div className="relative w-full h-full flex items-center justify-center">
            {/* Crystal Gem */}
            <svg viewBox="0 0 24 24" className="w-[78%] h-[78%] drop-shadow-md">
              <defs>
                <linearGradient id={`diamondGlow_${color}`} x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#ffffff" />
                  <stop offset="60%" stopColor="#bae6fd" />
                  <stop offset="100%" stopColor="#38bdf8" />
                </linearGradient>
              </defs>
              <polygon
                points="6,3 18,3 22,9 12,22 2,9"
                fill={`url(#diamondGlow_${color})`}
                stroke="#ffffff"
                strokeWidth="1.2"
              />
              <polygon points="6,3 18,3 15,9 9,9" fill="#ffffff" fillOpacity="0.5" />
              <polygon points="2,9 9,9 12,22" fill="#0284c7" fillOpacity="0.35" />
              <polygon points="18,3 22,9 15,9" fill="#ffffff" fillOpacity="0.6" />
              <polygon points="15,9 22,9 12,22" fill="#0369a1" fillOpacity="0.4" />
            </svg>
          </div>
        );

      case 'star':
        return (
          <div className="relative w-full h-full flex items-center justify-center">
            {/* Champion Star Medallion */}
            <svg viewBox="0 0 24 24" className="w-[76%] h-[76%] drop-shadow-md">
              <defs>
                <linearGradient id={`starGold_${color}`} x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#ffffff" />
                  <stop offset="40%" stopColor="#fde047" />
                  <stop offset="100%" stopColor="#ca8a04" />
                </linearGradient>
              </defs>
              <polygon
                points="12,2 15.09,8.26 22,9.27 17,14.14 18.18,21.02 12,17.77 5.82,21.02 7,14.14 2,9.27 8.91,8.26"
                fill={`url(#starGold_${color})`}
                stroke="#854d0e"
                strokeWidth="1.2"
                strokeLinejoin="round"
              />
              <circle cx="12" cy="12" r="2.5" fill="#ffffff" fillOpacity="0.9" />
            </svg>
          </div>
        );

      case 'classic':
      default:
        return (
          <div className="relative w-full h-full flex items-center justify-center">
            {/* Concentric Glossy Disc Rings */}
            <div className="w-[72%] h-[72%] rounded-full bg-white/35 border border-white/60 flex items-center justify-center shadow-inner">
              <div className="w-[45%] h-[45%] rounded-full bg-white shadow-sm" />
            </div>
          </div>
        );
    }
  };

  const Component = onClick ? 'button' : 'div';

  return (
    <Component
      disabled={disabled || !onClick}
      onClick={onClick}
      title={title || `${config?.name || 'Token'} Piece`}
      className={`relative ${sizeClasses} rounded-full flex items-center justify-center transition-all select-none ${
        isEligible
          ? 'cursor-pointer animate-bounce ring-4 ring-amber-400 ring-offset-2 shadow-amber-500/50 z-30'
          : disabled
          ? 'cursor-default opacity-85'
          : 'cursor-pointer active:scale-95'
      } ${className}`}
      style={{
        background: `radial-gradient(circle at 35% 35%, ${clr.from}, ${clr.to})`,
        border: `2px solid ${clr.border}`,
        boxShadow: isEligible
          ? `0 0 16px ${clr.glow}, 0 0 8px #F59E0B, 0 3px 6px rgba(0,0,0,0.5)`
          : `0 3px 6px rgba(0,0,0,0.4), inset 0 1px 2px rgba(255,255,255,0.6)`,
      }}
    >
      {/* Top light reflection glare */}
      <div className="absolute top-0.5 left-1/2 -translate-x-1/2 w-[65%] h-[28%] bg-white/45 rounded-full pointer-events-none blur-[0.5px]" />

      {/* Main interior icon / shape */}
      {renderInterior()}
    </Component>
  );
};
