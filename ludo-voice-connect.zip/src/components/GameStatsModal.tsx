import React from 'react';
import { X, BarChart3, Trophy, Sparkles } from 'lucide-react';
import { PlayerStats } from '../types';
import { GameStats } from './GameStats';

interface GameStatsModalProps {
  isOpen: boolean;
  onClose: () => void;
  stats: PlayerStats;
  onResetStats?: () => void;
  onClaimAchievementReward?: (coins: number) => void;
  userCoins?: number;
}

export const GameStatsModal: React.FC<GameStatsModalProps> = ({
  isOpen,
  onClose,
  stats,
  onResetStats,
  onClaimAchievementReward,
  userCoins,
}) => {
  if (!isOpen) return null;

  return (
    <div
      id="game-stats-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        id="game-stats-modal-card"
        className="relative w-full max-w-2xl bg-amber-50/95 rounded-3xl shadow-2xl border-4 border-amber-300 overflow-hidden flex flex-col max-h-[90vh]"
      >
        {/* Modal Top Header */}
        <div className="flex items-center justify-between px-5 sm:px-6 py-3.5 bg-gradient-to-r from-amber-500 via-amber-600 to-amber-700 text-white border-b-2 border-amber-600 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-white/20 backdrop-blur-xs flex items-center justify-center shadow-inner">
              <BarChart3 className="w-5 h-5 text-yellow-200" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black tracking-tight leading-tight flex items-center gap-1.5">
                <span>খেলোয়াড় পরিসংখ্যান ও অগ্রগতি</span>
                <Sparkles className="w-4 h-4 text-yellow-300" />
              </h2>
              <p className="text-[11px] font-bold text-amber-100 leading-tight">
                ম্যাচ বিশ্লেষণ, উইন রেট ও দীর্ঘমেয়াদী রেকর্ড
              </p>
            </div>
          </div>

          <button
            id="close-game-stats-modal-btn"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/20 hover:bg-white/30 text-white flex items-center justify-center transition-all active:scale-95 cursor-pointer"
            title="বন্ধ করুন"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Modal Body */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1 custom-scrollbar">
          <GameStats
            stats={stats}
            onResetStats={onResetStats}
            onClaimAchievementReward={onClaimAchievementReward}
            userCoins={userCoins}
          />
        </div>
      </div>
    </div>
  );
};

export default GameStatsModal;
