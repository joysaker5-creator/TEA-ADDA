import React, { useState } from 'react';
import {
  X,
  Sparkles,
  Crown,
  Trophy,
  Award,
  CheckCircle2,
  Lock,
  Zap,
  Gift,
  Coins,
  ChevronRight,
  TrendingUp,
  Info,
} from 'lucide-react';
import { AccountLevelState, LevelReward } from '../types';
import {
  LEVEL_REWARDS,
  getTierByLevel,
  getXPRequiredForLevel,
  XP_REWARDS,
} from '../utils/levelConstants';
import { Sound } from '../utils/soundEffects';

interface LevelRoadmapModalProps {
  isOpen: boolean;
  onClose: () => void;
  levelState: AccountLevelState;
  userDiamonds: number;
  userCoins: number;
  onClaimLevelReward: (level: number, coins: number, diamonds: number) => void;
}

export const LevelRoadmapModal: React.FC<LevelRoadmapModalProps> = ({
  isOpen,
  onClose,
  levelState,
  userDiamonds,
  userCoins,
  onClaimLevelReward,
}) => {
  const [filterTab, setFilterTab] = useState<'all' | 'milestones' | 'unclaimed'>('all');
  const [claimingLevel, setClaimingLevel] = useState<number | null>(null);

  if (!isOpen) return null;

  const currentTier = getTierByLevel(levelState.currentLevel);
  const nextTier = getTierByLevel(levelState.currentLevel + 5);
  const currentLevelRequiredXP = getXPRequiredForLevel(levelState.currentLevel);
  const progressPercent = Math.min(
    100,
    Math.round((levelState.currentXP / currentLevelRequiredXP) * 100)
  );

  const claimedSet = new Set(levelState.claimedLevelRewards);

  // Filter rewards list
  const filteredRewards = LEVEL_REWARDS.filter((r) => {
    if (filterTab === 'milestones') return r.isMilestone;
    if (filterTab === 'unclaimed') {
      return r.level <= levelState.currentLevel && !claimedSet.has(r.level);
    }
    return true;
  });

  const unclaimedCount = LEVEL_REWARDS.filter(
    (r) => r.level <= levelState.currentLevel && !claimedSet.has(r.level)
  ).length;

  const handleClaim = (reward: LevelReward) => {
    if (reward.level > levelState.currentLevel || claimedSet.has(reward.level)) return;

    setClaimingLevel(reward.level);
    Sound.playDiamondCollect();
    Sound.playCoinSound();

    setTimeout(() => {
      onClaimLevelReward(reward.level, reward.rewardCoins, reward.rewardDiamonds);
      setClaimingLevel(null);
    }, 400);
  };

  const handleClaimAll = () => {
    const unclaimed = LEVEL_REWARDS.filter(
      (r) => r.level <= levelState.currentLevel && !claimedSet.has(r.level)
    );
    if (unclaimed.length === 0) return;

    Sound.playLevelUp();
    Sound.playDiamondCollect();

    unclaimed.forEach((r) => {
      onClaimLevelReward(r.level, r.rewardCoins, r.rewardDiamonds);
    });
  };

  return (
    <div
      id="level-roadmap-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200"
    >
      <div className="relative w-full max-w-2xl max-h-[92vh] bg-slate-900 rounded-3xl text-white border-2 border-indigo-500/40 shadow-2xl flex flex-col overflow-hidden">
        {/* Modal Header with Current Level & Tier Hero Banner */}
        <div className="relative p-5 sm:p-6 bg-gradient-to-br from-indigo-900 via-slate-900 to-slate-950 border-b border-indigo-500/30 overflow-hidden">
          {/* Ambient light glow */}
          <div className="absolute top-0 right-0 w-72 h-72 bg-indigo-500/15 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute bottom-0 left-0 w-72 h-72 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

          {/* Close button */}
          <button
            id="close-level-roadmap-modal"
            onClick={() => {
              Sound.playClick();
              onClose();
            }}
            className="absolute top-4 right-4 p-2 rounded-full bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer border border-slate-700 z-10"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Title & Balances */}
          <div className="flex flex-wrap items-center justify-between gap-3 mb-4 pr-10">
            <div>
              <span className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-amber-400/20 border border-amber-400/40 text-amber-300 text-xs font-black uppercase tracking-wider">
                <Crown className="w-3.5 h-3.5 text-amber-400" />
                <span>লেভেল ও র‍্যাঙ্ক রোডম্যাপ</span>
              </span>
              <h2 className="text-xl sm:text-2xl font-black text-white mt-1">
                অ্যাকাউন্ট অগ্রগতি ও রিওয়ার্ডস
              </h2>
            </div>

            {/* Quick Balances */}
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1.5 px-3 py-1 rounded-xl bg-amber-500/15 border border-amber-400/30 text-amber-300 text-xs font-black">
                <span>🪙</span>
                <span>{userCoins.toLocaleString('bn-BD')}</span>
              </div>
              <div className="flex items-center gap-1.5 px-3 py-1 rounded-xl bg-cyan-500/15 border border-cyan-400/30 text-cyan-300 text-xs font-black">
                <span>💎</span>
                <span>{userDiamonds.toLocaleString('bn-BD')}</span>
              </div>
            </div>
          </div>

          {/* Player Level Card & XP Progress */}
          <div className="bg-slate-800/80 backdrop-blur-md rounded-2xl p-4 border border-indigo-400/30 shadow-inner">
            <div className="flex items-center gap-3.5 mb-3">
              {/* Level Badge Circle */}
              <div className="relative w-14 h-14 rounded-2xl bg-gradient-to-tr from-amber-500 to-yellow-400 flex flex-col items-center justify-center text-slate-950 font-black shadow-md shrink-0 border-2 border-yellow-200">
                <span className="text-[10px] uppercase font-extrabold leading-none">LVL</span>
                <span className="text-2xl font-black leading-none">
                  {levelState.currentLevel.toLocaleString('bn-BD')}
                </span>
              </div>

              {/* Tier & Total XP */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="text-base sm:text-lg font-black text-white truncate">
                      {currentTier.nameBn}
                    </span>
                  </div>
                  <span className="text-xs font-bold text-indigo-300 shrink-0">
                    মোট XP: {levelState.totalAccumulatedXP.toLocaleString('bn-BD')}
                  </span>
                </div>

                {/* XP Progress Bar */}
                <div className="mt-2">
                  <div className="flex justify-between text-[11px] font-extrabold text-slate-300 mb-1">
                    <span>অগ্রগতি ({progressPercent}%)</span>
                    <span>
                      {levelState.currentXP.toLocaleString('bn-BD')} /{' '}
                      {currentLevelRequiredXP.toLocaleString('bn-BD')} XP
                    </span>
                  </div>
                  <div className="w-full h-3 bg-slate-900 rounded-full overflow-hidden p-0.5 border border-slate-700">
                    <div
                      className="h-full bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 rounded-full transition-all duration-500 shadow-sm"
                      style={{ width: `${progressPercent}%` }}
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Quick XP Earn guide strip */}
            <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-slate-700/60 text-[11px] text-slate-300">
              <span className="font-bold text-amber-300 flex items-center gap-1">
                <Zap className="w-3.5 h-3.5 text-amber-400" />
                XP অর্জনের উপায়:
              </span>
              <span className="bg-slate-900/60 px-2 py-0.5 rounded-lg border border-slate-700">
                ম্যাচ জয় +{XP_REWARDS.MATCH_WIN} XP
              </span>
              <span className="bg-slate-900/60 px-2 py-0.5 rounded-lg border border-slate-700">
                গুটি কাটা +{XP_REWARDS.TOKEN_CAPTURED} XP
              </span>
              <span className="bg-slate-900/60 px-2 py-0.5 rounded-lg border border-slate-700">
                ঘরে গুটি +{XP_REWARDS.TOKEN_HOME} XP
              </span>
              <span className="bg-slate-900/60 px-2 py-0.5 rounded-lg border border-slate-700">
                ছক্কা +{XP_REWARDS.SIX_ROLLED} XP
              </span>
            </div>
          </div>
        </div>

        {/* Filter Tabs & Bulk Claim */}
        <div className="px-5 py-3 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between gap-3">
          <div className="flex items-center gap-1.5 overflow-x-auto py-0.5">
            <button
              onClick={() => {
                Sound.playClick();
                setFilterTab('all');
              }}
              className={`px-3 py-1 rounded-xl text-xs font-bold transition-colors cursor-pointer shrink-0 ${
                filterTab === 'all'
                  ? 'bg-indigo-600 text-white'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              সকল লেভেল ({LEVEL_REWARDS.length.toLocaleString('bn-BD')})
            </button>
            <button
              onClick={() => {
                Sound.playClick();
                setFilterTab('milestones');
              }}
              className={`px-3 py-1 rounded-xl text-xs font-bold transition-colors cursor-pointer shrink-0 ${
                filterTab === 'milestones'
                  ? 'bg-amber-600 text-white'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              🌟 মাইলস্টোন ও স্পেশাল
            </button>
            <button
              onClick={() => {
                Sound.playClick();
                setFilterTab('unclaimed');
              }}
              className={`px-3 py-1 rounded-xl text-xs font-bold transition-colors cursor-pointer shrink-0 flex items-center gap-1 ${
                filterTab === 'unclaimed'
                  ? 'bg-emerald-600 text-white'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              <span>দাবিযোগ্য</span>
              {unclaimedCount > 0 && (
                <span className="px-1.5 py-0.2 rounded-full bg-emerald-400 text-slate-950 font-black text-[10px]">
                  {unclaimedCount}
                </span>
              )}
            </button>
          </div>

          {unclaimedCount > 0 && (
            <button
              onClick={handleClaimAll}
              className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs shadow-md transition-all active:scale-95 flex items-center gap-1.5 shrink-0 cursor-pointer"
            >
              <Gift className="w-3.5 h-3.5 text-slate-950" />
              <span>সব সংগ্রহ ({unclaimedCount})</span>
            </button>
          )}
        </div>

        {/* Scrollable Level Rewards Roadmap List */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-2.5 custom-scrollbar">
          {filteredRewards.length === 0 ? (
            <div className="text-center py-12 text-slate-400 text-xs">
              <Gift className="w-10 h-10 mx-auto mb-2 text-slate-600 opacity-60" />
              <p>কোনো দাবিযোগ্য রিওয়ার্ড অবশিষ্ট নেই। নতুন লেভেলে পৌঁছাতে খেলা চালিয়ে যান!</p>
            </div>
          ) : (
            filteredRewards.map((item) => {
              const isCurrent = item.level === levelState.currentLevel;
              const isUnlocked = item.level <= levelState.currentLevel;
              const isClaimed = claimedSet.has(item.level);
              const tier = getTierByLevel(item.level);

              return (
                <div
                  key={item.level}
                  className={`relative p-3.5 rounded-2xl border transition-all flex items-center justify-between gap-3 ${
                    isCurrent
                      ? 'bg-gradient-to-r from-indigo-950/80 via-slate-850 to-slate-900 border-amber-400/80 shadow-md shadow-amber-500/10'
                      : isUnlocked
                      ? isClaimed
                        ? 'bg-slate-900/60 border-slate-800/80 text-slate-400 opacity-75'
                        : 'bg-gradient-to-r from-emerald-950/40 via-slate-900 to-slate-900 border-emerald-500/60 shadow-sm'
                      : 'bg-slate-900/40 border-slate-800/60 opacity-60'
                  }`}
                >
                  {/* Left: Level Icon & Tier Details */}
                  <div className="flex items-center gap-3 min-w-0">
                    <div
                      className={`w-11 h-11 rounded-xl flex flex-col items-center justify-center font-black shrink-0 border ${
                        isCurrent
                          ? 'bg-gradient-to-br from-amber-400 to-yellow-500 text-slate-950 border-yellow-200 shadow-md'
                          : isUnlocked
                          ? isClaimed
                            ? 'bg-slate-800 text-slate-400 border-slate-700'
                            : 'bg-emerald-600 text-white border-emerald-400 shadow-sm'
                          : 'bg-slate-800 text-slate-500 border-slate-700'
                      }`}
                    >
                      <span className="text-[9px] uppercase leading-none">LV</span>
                      <span className="text-base font-black leading-none">
                        {item.level.toLocaleString('bn-BD')}
                      </span>
                    </div>

                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="text-xs sm:text-sm font-black text-white">
                          {item.titleBn}
                        </span>
                        {item.badge && (
                          <span className="px-2 py-0.5 rounded-full bg-amber-400/20 text-amber-300 border border-amber-400/40 text-[10px] font-black">
                            {item.badge}
                          </span>
                        )}
                        {isCurrent && (
                          <span className="px-2 py-0.2 rounded-full bg-indigo-500/30 text-indigo-300 border border-indigo-400/40 text-[9px] font-extrabold">
                            বর্তমান লেভেল
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] text-slate-400 mt-0.5 truncate">
                        <span>{item.tierNameBn}</span>
                        {item.exclusiveItem && (
                          <span className="text-purple-300 font-bold ml-1.5">
                            • {item.exclusiveItem}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Right: Rewards Badges & Action Button */}
                  <div className="flex items-center gap-2 sm:gap-3 shrink-0">
                    {/* Rewards pill */}
                    <div className="flex items-center gap-1.5">
                      <div className="flex items-center gap-1 px-2.5 py-1 rounded-xl bg-amber-500/10 border border-amber-400/30 text-amber-300 text-xs font-black">
                        <span>🪙</span>
                        <span>+{item.rewardCoins.toLocaleString('bn-BD')}</span>
                      </div>
                      <div className="flex items-center gap-1 px-2.5 py-1 rounded-xl bg-cyan-500/10 border border-cyan-400/30 text-cyan-300 text-xs font-black">
                        <span>💎</span>
                        <span>+{item.rewardDiamonds.toLocaleString('bn-BD')}</span>
                      </div>
                    </div>

                    {/* Claim / Status button */}
                    {isClaimed ? (
                      <div className="px-3 py-1.5 rounded-xl bg-slate-800 text-slate-400 text-xs font-bold flex items-center gap-1 border border-slate-700">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                        <span>সংগৃহীত</span>
                      </div>
                    ) : isUnlocked ? (
                      <button
                        onClick={() => handleClaim(item)}
                        disabled={claimingLevel === item.level}
                        className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs shadow-md transition-all active:scale-95 flex items-center gap-1 cursor-pointer"
                      >
                        <Gift className="w-3.5 h-3.5 text-slate-950" />
                        <span>দাবি করুন</span>
                      </button>
                    ) : (
                      <div className="px-3 py-1.5 rounded-xl bg-slate-800/80 text-slate-500 text-xs font-bold flex items-center gap-1 border border-slate-700/60">
                        <Lock className="w-3.5 h-3.5 text-slate-500" />
                        <span>লকড</span>
                      </div>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Modal Footer Info */}
        <div className="p-3.5 sm:p-4 bg-slate-950 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <span className="flex items-center gap-1.5">
            <Info className="w-4 h-4 text-indigo-400" />
            <span>প্রতি লেভেল আপে ফ্রি কয়েন ও ডায়মন্ড অর্জন করা যায়।</span>
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold transition-colors cursor-pointer"
          >
            বন্ধ করুন
          </button>
        </div>
      </div>
    </div>
  );
};
