import React, { useState, useEffect } from 'react';
import {
  X,
  Smartphone,
  Download,
  Copy,
  Check,
  ExternalLink,
  Sparkles,
  ShieldCheck,
  Layers,
  HelpCircle,
  ChevronRight,
  ArrowRight,
} from 'lucide-react';
import { Sound } from '../utils/soundEffects';

interface ApkInstallModalProps {
  isOpen: boolean;
  onClose: () => void;
  isEn?: boolean;
}

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>;
}

export const ApkInstallModal: React.FC<ApkInstallModalProps> = ({
  isOpen,
  onClose,
  isEn = false,
}) => {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isInstalled, setIsInstalled] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'quick' | 'pwabuilder' | 'checklist'>('quick');

  // Track if running standalone
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const isStandalone =
        window.matchMedia('(display-mode: standalone)').matches ||
        (window.navigator as unknown as { standalone?: boolean }).standalone === true;
      setIsInstalled(isStandalone);

      const handleBeforeInstall = (e: Event) => {
        e.preventDefault();
        setDeferredPrompt(e as BeforeInstallPromptEvent);
      };

      const handleAppInstalled = () => {
        setIsInstalled(true);
        setDeferredPrompt(null);
      };

      window.addEventListener('beforeinstallprompt', handleBeforeInstall);
      window.addEventListener('appinstalled', handleAppInstalled);

      return () => {
        window.removeEventListener('beforeinstallprompt', handleBeforeInstall);
        window.removeEventListener('appinstalled', handleAppInstalled);
      };
    }
  }, []);

  if (!isOpen) return null;

  const currentAppUrl = typeof window !== 'undefined' ? window.location.href.split('?')[0] : 'https://joyludo.game';

  const handleCopyUrl = () => {
    Sound.playClick();
    if (navigator.clipboard) {
      navigator.clipboard.writeText(currentAppUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  const handleNativeInstall = async () => {
    Sound.playClick();
    if (deferredPrompt) {
      await deferredPrompt.prompt();
      const choice = await deferredPrompt.userChoice;
      if (choice.outcome === 'accepted') {
        setIsInstalled(true);
        setDeferredPrompt(null);
      }
    } else {
      // Fallback instructions alert
      alert(
        isEn
          ? 'To install directly: In your mobile browser (Chrome), tap the 3 dots (⋮) in the top-right corner, then tap "Install app" or "Add to Home screen".'
          : 'সরাসরি ইনস্টল করতে: আপনার মোবাইলের Chrome ব্রাউজারের উপরে ডানে ৩টি ডট (⋮) মেনুতে ক্লিক করে "Install app" বা "Add to Home screen" চাপুন।'
      );
    }
  };

  const openPWABuilder = () => {
    Sound.playClick();
    const pwaUrl = `https://www.pwabuilder.com/reportcard?site=${encodeURIComponent(currentAppUrl)}`;
    window.open(pwaUrl, '_blank', 'noopener,noreferrer');
  };

  return (
    <div
      id="apk-install-modal-overlay"
      className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 animate-fade-in select-none"
      onClick={onClose}
    >
      <div
        id="apk-install-modal-content"
        className="w-full max-w-lg bg-slate-950 border-2 border-amber-500/40 rounded-3xl p-4 sm:p-6 text-white shadow-[0_0_50px_rgba(245,158,11,0.2)] flex flex-col max-h-[92vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header with App Icon */}
        <div className="flex items-start justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="relative w-12 h-12 rounded-2xl overflow-hidden border-2 border-amber-400 shadow-md bg-gradient-to-br from-amber-500 to-rose-600 p-0.5 shrink-0">
              <img
                src="/icon-192.png"
                alt="Joy Ludo Icon"
                className="w-full h-full object-cover rounded-xl"
                onError={(e) => {
                  (e.target as HTMLElement).style.display = 'none';
                }}
              />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h2 className="text-base sm:text-lg font-black text-amber-300 tracking-wide">
                  {isEn ? 'Joy Ludo Mobile APK' : 'জয় লুডু মোবাইল APK'}
                </h2>
                <span className="text-[10px] font-black px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                  Android APK
                </span>
              </div>
              <p className="text-xs text-slate-400">
                {isEn ? 'Generate & Install on your Android phone' : 'মোবাইল দিয়ে সরাসরি APK তৈরি ও ইনস্টল করার উপায়'}
              </p>
            </div>
          </div>
          <button
            id="close-apk-modal-btn"
            onClick={() => {
              Sound.playClick();
              onClose();
            }}
            className="p-1.5 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="grid grid-cols-3 gap-1.5 bg-slate-900/80 p-1 rounded-2xl my-3 border border-slate-800 text-xs font-bold">
          <button
            onClick={() => {
              Sound.playClick();
              setActiveTab('quick');
            }}
            className={`py-2 px-1 rounded-xl transition-all text-center ${
              activeTab === 'quick'
                ? 'bg-amber-500 text-slate-950 shadow-md font-black'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            {isEn ? '1-Click Install' : '১-ক্লিকে ইনস্টল'}
          </button>
          <button
            onClick={() => {
              Sound.playClick();
              setActiveTab('pwabuilder');
            }}
            className={`py-2 px-1 rounded-xl transition-all text-center ${
              activeTab === 'pwabuilder'
                ? 'bg-amber-500 text-slate-950 shadow-md font-black'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            {isEn ? 'Free APK Builder' : 'ফ্রি APK মেকার'}
          </button>
          <button
            onClick={() => {
              Sound.playClick();
              setActiveTab('checklist');
            }}
            className={`py-2 px-1 rounded-xl transition-all text-center ${
              activeTab === 'checklist'
                ? 'bg-amber-500 text-slate-950 shadow-md font-black'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            {isEn ? 'What You Need' : 'কী কী লাগবে'}
          </button>
        </div>

        {/* TAB 1: 1-Click Install directly onto Android phone */}
        {activeTab === 'quick' && (
          <div className="space-y-3 animate-fade-in">
            <div className="p-3.5 rounded-2xl bg-gradient-to-br from-amber-950/40 via-slate-900 to-slate-900 border border-amber-500/30">
              <div className="flex items-center gap-2 mb-2">
                <Smartphone className="w-5 h-5 text-amber-400" />
                <h3 className="text-sm font-bold text-amber-200">
                  {isEn ? 'Fastest Way: Direct Phone Install' : 'সবচেয়ে সহজ: সরাসরি মোবাইলে অ্যাপ ইনস্টল'}
                </h3>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                {isEn
                  ? 'Joy Ludo is a Progressive Web App (PWA). It installs directly onto your Android phone like an APK without needing Google Play Store or APK files.'
                  : 'জয় লুডু একটি আধুনিক PWA অ্যাপ। এটি কোনো প্লে-স্টোর ছাড়াই সাধারণ APK ফাইলের মতো আপনার মোবাইলের হোমস্ক্রিনে আসল অ্যাপ হিসেবে ইনস্টল হয়ে যায় এবং অফলাইনেও কাজ করে।'}
              </p>

              <button
                id="native-install-app-btn"
                onClick={handleNativeInstall}
                className="w-full mt-3 py-3 px-4 rounded-xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 hover:from-amber-400 hover:to-yellow-300 text-slate-950 font-black text-sm flex items-center justify-center gap-2 shadow-lg active:scale-95 transition-all"
              >
                <Download className="w-4 h-4" />
                <span>
                  {isInstalled
                    ? isEn ? 'Already Installed on this Device' : 'আপনার ডিভাইসে অলরেডি ইনস্টল করা আছে'
                    : isEn ? 'Install App on Phone Now' : 'এখনই মোবাইলে অ্যাপ ইনস্টল করুন'}
                </span>
              </button>
            </div>

            {/* Manual Chrome Browser Instructions */}
            <div className="p-3 rounded-2xl bg-slate-900/60 border border-slate-800 text-xs space-y-2 text-slate-300">
              <div className="font-bold text-slate-200 flex items-center gap-1.5">
                <HelpCircle className="w-4 h-4 text-cyan-400" />
                <span>{isEn ? 'Manual Install in Chrome (2 Steps):' : 'মোবাইলের Chrome ব্রাউজারে ২ সেকেন্ডে ইনস্টল:'}</span>
              </div>
              <ol className="list-decimal list-inside space-y-1 text-slate-400 pl-1">
                <li>
                  {isEn
                    ? 'Tap the 3 dots (⋮) menu at the top right of your Chrome browser.'
                    : 'আপনার মোবাইলের Chrome ব্রাউজারের উপরে ডানে থাকা ৩টি ডট (⋮) মেনুতে চাপ দিন।'}
                </li>
                <li>
                  {isEn
                    ? 'Tap "Install app" or "Add to Home screen".'
                    : '"Install app" (অ্যাপ ইনস্টল করুন) অথবা "Add to Home screen" এ চাপ দিন।'}
                </li>
                <li>
                  {isEn
                    ? 'Done! The Joy Ludo game icon will appear on your phone screen.'
                    : 'ব্যাস! আপনার মোবাইলের হোম স্ক্রিনে গেমের আইকন চলে আসবে এবং আসল অ্যাপের মতো ওপেন হবে।'}
                </li>
              </ol>
            </div>
          </div>
        )}

        {/* TAB 2: Free Cloud APK Builder (PWABuilder by Microsoft) */}
        {activeTab === 'pwabuilder' && (
          <div className="space-y-3 animate-fade-in">
            <div className="p-3.5 rounded-2xl bg-gradient-to-br from-indigo-950/40 via-slate-900 to-slate-900 border border-indigo-500/30">
              <div className="flex items-center gap-2 mb-1.5">
                <Sparkles className="w-5 h-5 text-indigo-400" />
                <h3 className="text-sm font-bold text-indigo-200">
                  {isEn ? 'Generate Real .APK File via Microsoft PWABuilder' : 'মোবাইল দিয়েই আসল .APK ফাইল তৈরির উপায়'}
                </h3>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed mb-3">
                {isEn
                  ? 'Microsoft PWABuilder is a 100% free cloud builder. Open it on your phone, paste your app URL, and it instantly builds a signed Android APK & Play Store AAB package for you!'
                  : 'মাইক্রোসফটের তৈরি PWABuilder সম্পূর্ণ ফ্রি। এটি আপনার অ্যাপের লিংক নিয়ে ক্লাউড থেকে সরাসরি আপনার জন্য ইনস্টলযোগ্য Android .apk ফাইল তৈরি করে দেয়—কম্পিউটার ছাড়াই শুধু মোবাইল দিয়েই করা যায়!'}
              </p>

              {/* URL Copy Card */}
              <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-2">
                <div className="truncate text-xs font-mono text-amber-300">
                  {currentAppUrl}
                </div>
                <button
                  onClick={handleCopyUrl}
                  className="px-2.5 py-1.5 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 text-xs font-bold flex items-center gap-1 shrink-0 transition-colors"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? (isEn ? 'Copied' : 'কপি হয়েছে') : (isEn ? 'Copy URL' : 'লিংক কপি')}</span>
                </button>
              </div>

              {/* Action Button */}
              <button
                onClick={openPWABuilder}
                className="w-full mt-3 py-3 px-4 rounded-xl bg-gradient-to-r from-indigo-500 to-cyan-500 hover:from-indigo-600 hover:to-cyan-600 text-white font-black text-sm flex items-center justify-center gap-2 shadow-lg active:scale-95 transition-all"
              >
                <span>{isEn ? 'Open PWABuilder & Generate APK' : 'PWABuilder এ গিয়ে APK ডাউনলোড করুন'}</span>
                <ExternalLink className="w-4 h-4" />
              </button>
            </div>

            <div className="p-3 rounded-2xl bg-slate-900/60 border border-slate-800 text-xs space-y-1.5 text-slate-400">
              <p className="font-bold text-slate-300">{isEn ? '3 Simple Steps in PWABuilder:' : 'মোবাইলে APK বানানোর ৩টি ধাপ:'}</p>
              <p>১. উপরের <strong>"লিংক কপি"</strong> বাটনে চাপ দিয়ে অ্যাপের লিংকটি কপি করুন।</p>
              <p>২. <strong>"PWABuilder এ যান"</strong> বাটনে ক্লিক করে ওয়েবসাইটটি খুলুন এবং লিংকটি পেস্ট করে Start চাপুন।</p>
              <p>৩. এরপর <strong>"Android"</strong> সিলেক্ট করে <strong>"Package APK"</strong> চাপলে সরাসরি আপনার মোবাইলে .apk ফাইল ডাউনলোড হয়ে যাবে!</p>
            </div>
          </div>
        )}

        {/* TAB 3: Complete Technical Checklist for Mobile APK */}
        {activeTab === 'checklist' && (
          <div className="space-y-3 animate-fade-in text-xs">
            <div className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-2">
              <h3 className="font-bold text-amber-300 flex items-center gap-1.5 text-sm">
                <Layers className="w-4 h-4 text-amber-400" />
                <span>{isEn ? 'Components Needed to Make an APK from Mobile' : 'মোবাইল দিয়ে APK তৈরি করতে যা যা লাগে'}</span>
              </h3>
              <p className="text-slate-400">
                {isEn
                  ? 'We have already configured everything inside this app so it is 100% APK ready:'
                  : 'আমরা এই অ্যাপের ভেতরে প্রয়োজনীয় সবকিছু ইতিমধ্যে তৈরি ও কনফিগার করে দিয়েছি:'}
              </p>
            </div>

            <div className="space-y-2">
              {/* Item 1 */}
              <div className="p-2.5 rounded-xl bg-slate-900/50 border border-emerald-500/30 flex items-start gap-2.5">
                <div className="p-1 rounded-lg bg-emerald-500/20 text-emerald-400 shrink-0 mt-0.5">
                  <Check className="w-4 h-4" />
                </div>
                <div>
                  <div className="font-bold text-emerald-300">১. অ্যাপ আইকন (App Icons - 192px & 512px)</div>
                  <div className="text-slate-400 mt-0.5">
                    রয়্যাল লুডু ও ডাইসের গোল্ডেন আইকন তৈরি করে অ্যাপের <code className="text-amber-300">/icon-192.png</code> ও <code className="text-amber-300">/icon-512.png</code> তে সেট করা হয়েছে।
                  </div>
                </div>
              </div>

              {/* Item 2 */}
              <div className="p-2.5 rounded-xl bg-slate-900/50 border border-emerald-500/30 flex items-start gap-2.5">
                <div className="p-1 rounded-lg bg-emerald-500/20 text-emerald-400 shrink-0 mt-0.5">
                  <Check className="w-4 h-4" />
                </div>
                <div>
                  <div className="font-bold text-emerald-300">২. ওয়েব অ্যাপ ম্যানিফেস্ট (manifest.json)</div>
                  <div className="text-slate-400 mt-0.5">
                    অ্যান্ড্রয়েডের প্যাকেজ কনফিগারেশন, ফুল-স্ক্রিন মোড এবং ব্যাকগ্রাউন্ড রঙ ম্যানিফেস্টে নির্ভুলভাবে সাজানো হয়েছে।
                  </div>
                </div>
              </div>

              {/* Item 3 */}
              <div className="p-2.5 rounded-xl bg-slate-900/50 border border-emerald-500/30 flex items-start gap-2.5">
                <div className="p-1 rounded-lg bg-emerald-500/20 text-emerald-400 shrink-0 mt-0.5">
                  <Check className="w-4 h-4" />
                </div>
                <div>
                  <div className="font-bold text-emerald-300">৩. সার্ভিস ওয়ার্কার (Offline Service Worker)</div>
                  <div className="text-slate-400 mt-0.5">
                    ইন্টারনেট ধীরগতির হলেও গেম দ্রুত লোড হওয়ার জন্য ক্যাশিং সার্ভিস ওয়ার্কার <code className="text-amber-300">/sw.js</code> সক্রিয় করা হয়েছে।
                  </div>
                </div>
              </div>

              {/* Item 4 */}
              <div className="p-2.5 rounded-xl bg-slate-900/50 border border-amber-500/30 flex items-start gap-2.5">
                <div className="p-1 rounded-lg bg-amber-500/20 text-amber-400 shrink-0 mt-0.5">
                  <ShieldCheck className="w-4 h-4" />
                </div>
                <div>
                  <div className="font-bold text-amber-300">৪. প্যাকেজ নাম ও আইডি (Package Name)</div>
                  <div className="text-slate-400 mt-0.5">
                    অ্যান্ড্রয়েড অ্যাপ স্টোরের জন্য আইডি: <code className="text-cyan-300">com.joyludo.game</code>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <div className="flex items-center gap-1.5 text-emerald-400 font-semibold">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>{isEn ? 'APK Ready' : 'APK তৈরির জন্য সম্পূর্ণ প্রস্তুত'}</span>
          </div>
          <button
            onClick={() => {
              Sound.playClick();
              onClose();
            }}
            className="px-4 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold transition-colors"
          >
            {isEn ? 'Close' : 'বন্ধ করুন'}
          </button>
        </div>
      </div>
    </div>
  );
};
