import React from 'react';
import { Dices } from 'lucide-react';
import { DiceStyleId, DiceFaceStyle } from '../types';
import { DICE_STYLES } from '../utils/customizationConstants';

interface DicePieceProps {
  value: number | null;
  styleId?: DiceStyleId;
  faceStyle?: DiceFaceStyle;
  isRolling?: boolean;
  size?: number;
  className?: string;
  onClick?: () => void;
}

export const DicePiece: React.FC<DicePieceProps> = ({
  value,
  styleId = 'classic',
  faceStyle = 'dots',
  isRolling = false,
  size = 56,
  className = '',
  onClick,
}) => {
  const styleDef = DICE_STYLES.find((s) => s.id === styleId) || DICE_STYLES[0];

  const bengaliNumerals: Record<number, string> = {
    1: '১',
    2: '২',
    3: '৩',
    4: '৪',
    5: '৫',
    6: '৬',
  };

  // Render dots for 1-6
  const renderDots = (num: number) => {
    const dotPositions: Record<number, string[]> = {
      1: ['center'],
      2: ['top-left', 'bottom-right'],
      3: ['top-left', 'center', 'bottom-right'],
      4: ['top-left', 'top-right', 'bottom-left', 'bottom-right'],
      5: ['top-left', 'top-right', 'center', 'bottom-left', 'bottom-right'],
      6: ['top-left', 'top-right', 'middle-left', 'middle-right', 'bottom-left', 'bottom-right'],
    };

    const active = dotPositions[num] || ['center'];

    return (
      <div className="relative w-full h-full p-2 grid grid-cols-3 grid-rows-3 gap-0.5">
        {/* Top-left */}
        <div className="flex items-center justify-center">
          {active.includes('top-left') && (
            <span className={`w-2.5 h-2.5 rounded-full ${styleDef.dotColor} shadow-sm`} />
          )}
        </div>
        {/* Top-center */}
        <div className="flex items-center justify-center" />
        {/* Top-right */}
        <div className="flex items-center justify-center">
          {active.includes('top-right') && (
            <span className={`w-2.5 h-2.5 rounded-full ${styleDef.dotColor} shadow-sm`} />
          )}
        </div>
        {/* Middle-left */}
        <div className="flex items-center justify-center">
          {active.includes('middle-left') && (
            <span className={`w-2.5 h-2.5 rounded-full ${styleDef.dotColor} shadow-sm`} />
          )}
        </div>
        {/* Center */}
        <div className="flex items-center justify-center">
          {active.includes('center') && (
            <span
              className={`w-3 h-3 rounded-full ${
                num === 1 || num === 6 ? styleDef.centerDotColor : styleDef.dotColor
              } shadow-sm ${num === 6 ? 'scale-110' : ''}`}
            />
          )}
        </div>
        {/* Middle-right */}
        <div className="flex items-center justify-center">
          {active.includes('middle-right') && (
            <span className={`w-2.5 h-2.5 rounded-full ${styleDef.dotColor} shadow-sm`} />
          )}
        </div>
        {/* Bottom-left */}
        <div className="flex items-center justify-center">
          {active.includes('bottom-left') && (
            <span className={`w-2.5 h-2.5 rounded-full ${styleDef.dotColor} shadow-sm`} />
          )}
        </div>
        {/* Bottom-center */}
        <div className="flex items-center justify-center" />
        {/* Bottom-right */}
        <div className="flex items-center justify-center">
          {active.includes('bottom-right') && (
            <span className={`w-2.5 h-2.5 rounded-full ${styleDef.dotColor} shadow-sm`} />
          )}
        </div>
      </div>
    );
  };

  const renderFaceContent = () => {
    if (isRolling || !value) {
      return (
        <div className="w-full h-full flex items-center justify-center">
          <Dices className="w-7 h-7 text-slate-400 animate-spin opacity-80" />
        </div>
      );
    }

    if (faceStyle === 'bengali_numbers') {
      return (
        <div className="w-full h-full flex items-center justify-center">
          <span
            className={`text-2xl sm:text-3xl font-black font-serif ${styleDef.numberColor} select-none leading-none drop-shadow`}
          >
            {bengaliNumerals[value] || value}
          </span>
        </div>
      );
    }

    if (faceStyle === 'english_numbers') {
      return (
        <div className="w-full h-full flex items-center justify-center">
          <span
            className={`text-2xl sm:text-3xl font-black ${styleDef.numberColor} select-none leading-none tracking-tight drop-shadow`}
          >
            {value}
          </span>
        </div>
      );
    }

    // Default 'dots'
    return renderDots(value);
  };

  const Component = onClick ? 'button' : 'div';

  return (
    <Component
      onClick={onClick}
      style={{ width: `${size}px`, height: `${size}px` }}
      className={`relative rounded-2xl border-4 ${styleDef.borderClass} ${styleDef.bodyGradient} ${styleDef.shadowClass} flex items-center justify-center transition-all select-none overflow-hidden ${
        isRolling ? 'rotate-180 scale-95' : ''
      } ${className}`}
    >
      {/* 3D Chamfer / Highlight Bevel */}
      <div className="absolute inset-0 border-t border-l border-white/50 pointer-events-none rounded-xl" />
      <div className="absolute inset-0 border-b border-r border-black/30 pointer-events-none rounded-xl" />

      {/* Surface Gloss Sheen */}
      <div className="absolute -top-6 -left-6 w-12 h-12 bg-white/25 rounded-full pointer-events-none blur-sm" />

      {/* Main Face Content */}
      {renderFaceContent()}
    </Component>
  );
};
