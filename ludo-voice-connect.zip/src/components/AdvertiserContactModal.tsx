import React, { useState } from 'react';
import {
  X,
  Megaphone,
  PhoneCall,
  Mail,
  MessageSquare,
  Building2,
  Clock,
  CheckCircle2,
  Sparkles,
  TrendingUp,
  Award,
  Users,
  ShieldCheck,
  Send,
  ExternalLink,
  Copy,
  ChevronRight,
  FileText,
  DollarSign,
  Globe,
  Radio,
  Video,
  Flame,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { AdvertiserInquiry } from '../types';
import {
  AD_PLACEMENT_PACKAGES,
  JOY_LUDO_AUDIENCE_STATS,
  OFFICIAL_AD_CONTACT_INFO,
  saveAdvertiserInquiry,
  loadAdvertiserInquiries,
} from '../utils/advertiserService';
import { Sound } from '../utils/soundEffects';

interface AdvertiserContactModalProps {
  isOpen: boolean;
  onClose: () => void;
  isEn?: boolean;
}

export const AdvertiserContactModal: React.FC<AdvertiserContactModalProps> = ({
  isOpen,
  onClose,
  isEn = false,
}) => {
  const [activeTab, setActiveTab] = useState<'contact' | 'packages' | 'proposal' | 'stats'>('contact');

  // Form states
  const [brandName, setBrandName] = useState('');
  const [contactPerson, setContactPerson] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [adType, setAdType] = useState<AdvertiserInquiry['adType']>('board_banner');
  const [budgetRange, setBudgetRange] = useState<AdvertiserInquiry['budgetRange']>('50k_to_200k');
  const [targetAudience, setTargetAudience] = useState(
    isEn ? 'Bangladesh & Global Bengali Diaspora (18-35 yrs)' : 'বাংলাদেশ ও প্রবাসী বাঙালি (১৮-৩৫ বছর)'
  );
  const [message, setMessage] = useState('');
  const [submittedTicket, setSubmittedTicket] = useState<AdvertiserInquiry | null>(null);
  const [copiedField, setCopiedField] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleCopyText = (text: string, fieldName: string) => {
    Sound.playClick();
    navigator.clipboard.writeText(text);
    setCopiedField(fieldName);
    setTimeout(() => setCopiedField(null), 1800);
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!brandName.trim() || !contactPerson.trim() || !phone.trim() || !email.trim()) {
      Sound.playAlert();
      alert(isEn ? 'Please fill out all required fields!' : 'অনুগ্রহ করে সকল প্রয়োজনীয় তথ্য পূরণ করুন!');
      return;
    }

    const inquiry: AdvertiserInquiry = {
      id: 'AD-REQ-' + Math.floor(100000 + Math.random() * 900000),
      brandName: brandName.trim(),
      contactPerson: contactPerson.trim(),
      phone: phone.trim(),
      email: email.trim(),
      adType,
      budgetRange,
      targetAudience: targetAudience.trim(),
      message: message.trim() || (isEn ? 'Interested in advertising on Joy Ludo platform.' : 'জয় লুডু প্ল্যাটফর্মে বিজ্ঞাপন প্রচার করতে আগ্রহী।'),
      submittedAt: Date.now(),
      status: 'received',
    };

    saveAdvertiserInquiry(inquiry);
    setSubmittedTicket(inquiry);
    Sound.playRewardClaim();
    confetti({
      particleCount: 70,
      spread: 80,
      origin: { y: 0.5 },
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-4xl bg-slate-950 text-white rounded-3xl border-2 border-amber-500/60 shadow-2xl flex flex-col h-[94vh] max-h-[850px] overflow-hidden">
        {/* Header Bar */}
        <div className="px-5 py-3.5 bg-gradient-to-r from-amber-600 via-orange-600 to-rose-700 flex items-center justify-between border-b border-amber-400/30 shrink-0 shadow-lg">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-black/30 border border-amber-300/40 flex items-center justify-center text-amber-300 shadow-inner">
              <Megaphone className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-black text-white tracking-wide">
                  {isEn ? '📢 Advertising & Brand Sponsorship Portal' : '📢 বিজ্ঞাপন ও ব্র্যান্ড স্পনসরশিপ পোর্টাল'}
                </h2>
                <span className="px-2 py-0.5 rounded-full bg-yellow-400 text-slate-950 text-[10px] font-black uppercase">
                  Advertise With Us
                </span>
              </div>
              <p className="text-xs text-amber-100 font-medium">
                {isEn
                  ? 'Reach over 1.5M+ active monthly players on Joy Ludo 🇧🇩'
                  : 'জয় লুডুর ১.৫ মিলিয়ন+ সক্রিয় খেলোয়াড়দের মাঝে আপনার ব্র্যান্ড পৌঁছে দিন 🇧🇩'}
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              Sound.playClick();
              onClose();
            }}
            className="w-9 h-9 rounded-2xl bg-black/40 hover:bg-rose-600 text-white flex items-center justify-center transition-all cursor-pointer border border-white/20"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-1.5 px-4 pt-2.5 pb-2 bg-slate-900/95 border-b border-slate-800 shrink-0 overflow-x-auto">
          {[
            { id: 'contact', label: isEn ? '✉️ Official Email Desk' : '✉️ অফিসিয়াল ইমেইল ডেস্ক', icon: Mail },
            { id: 'proposal', label: isEn ? '📝 Submit Ad Proposal' : '📝 বিজ্ঞাপন প্রস্তাবনা জমা দিন', icon: Send },
            { id: 'packages', label: isEn ? '💼 Packages & Rates' : '💼 বিজ্ঞাপন প্যাকেজ ও রেট কার্ড', icon: Award },
            { id: 'stats', label: isEn ? '📊 Audience Reach & Stats' : '📊 অডিয়েন্স রিচ ও পরিসংখ্যান', icon: TrendingUp },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => {
                  Sound.playClick();
                  setActiveTab(tab.id as any);
                }}
                className={`px-3.5 py-2 rounded-2xl text-xs font-black shrink-0 transition-all flex items-center gap-1.5 cursor-pointer ${
                  isActive
                    ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 shadow-md font-black'
                    : 'bg-slate-950 text-slate-400 hover:bg-slate-800 hover:text-slate-200'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Main Content Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950">
          {/* TAB 1: DIRECT EMAIL CONTACT DESK */}
          {activeTab === 'contact' && (
            <div className="space-y-6 max-w-3xl mx-auto animate-fade-in">
              {/* Official Email Desk Banner */}
              <div className="p-6 rounded-3xl bg-gradient-to-br from-amber-950/80 via-slate-900 to-slate-950 border-2 border-amber-500/60 shadow-2xl space-y-4">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-14 h-14 rounded-2xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-400 text-3xl shadow-inner">
                      ✉️
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="text-base font-black text-white">
                          {isEn ? 'Official Advertising Email Desk' : 'অফিসিয়াল বিজ্ঞাপন ইমেইল ডেস্ক'}
                        </h3>
                        <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-black border border-emerald-500/30">
                          {isEn ? 'Direct Email Service' : 'সরাসরি ইমেইল সার্ভিস'}
                        </span>
                      </div>
                      <p className="text-xs text-amber-200/80 mt-0.5">
                        {isEn
                          ? 'The only authorized email channel for ads, sponsorships and media inquiries'
                          : 'বিজ্ঞাপন, স্পনসরশিপ ও মিডিয়া পার্টনারশিপের একমাত্র অনুমোদিত অফিসিয়াল ইমেইল'}
                      </p>
                    </div>
                  </div>
                  <span className="px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 text-xs font-mono font-black border border-amber-500/40">
                    Joysaker5@gmail.com
                  </span>
                </div>

                <div className="p-4 rounded-2xl bg-slate-950/90 border border-amber-500/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                  <div>
                    <span className="text-[11px] text-slate-400 font-bold block uppercase tracking-wider">
                      {isEn ? 'Dedicated Advertising Email:' : 'ডেডিকেটেড বিজ্ঞাপন ইমেইল:'}
                    </span>
                    <span className="text-sm font-black text-amber-300 font-mono select-all">
                      Joysaker5@gmail.com
                    </span>
                  </div>

                  <div className="flex items-center gap-2 w-full sm:w-auto">
                    <a
                      href={`mailto:Joysaker5@gmail.com?subject=${encodeURIComponent('Joy Ludo App - Advertising & Partnership Proposal')}&body=${encodeURIComponent(
                        isEn
                          ? 'Hello Joy Ludo Team,\n\nWe are interested in advertising our brand on Joy Ludo.\n\nBrand Name:\nContact Person:\nEmail:\nEstimated Budget:\nPlacement Type:\n'
                          : 'হ্যালো জয় লুডু টিম,\n\nআমি জয় লুডু প্ল্যাটফর্মে আমাদের ব্র্যান্ডের বিজ্ঞাপন প্রচার করতে আগ্রহী।\n\nব্র্যান্ডের নাম:\nপ্রতিনিধির নাম:\nযোগাযোগের ইমেইল:\nআনুমানিক বাজেট:\nপ্লেসমেন্ট ধরন:\n'
                      )}`}
                      className="flex-1 sm:flex-none py-2.5 px-5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black text-xs text-center flex items-center justify-center gap-1.5 transition-all shadow-md active:scale-95"
                    >
                      <Mail className="w-4 h-4" />
                      <span>{isEn ? 'Send Direct Email' : 'সরাসরি ইমেইল পাঠান'}</span>
                      <ExternalLink className="w-3 h-3 ml-0.5" />
                    </a>
                    <button
                      onClick={() => handleCopyText('Joysaker5@gmail.com', 'email')}
                      className="p-2.5 rounded-xl bg-slate-900 border border-amber-500/40 hover:bg-amber-950/50 text-amber-300 text-xs font-bold transition-all"
                      title={isEn ? 'Copy email' : 'ইমেইল কপি করুন'}
                    >
                      {copiedField === 'email' ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <p className="text-[11px] text-slate-300 leading-relaxed">
                  💡 <strong>{isEn ? 'Notice to Advertisers:' : 'বিজ্ঞাপনদাতাদের জন্য নোটিশ:'}</strong>{' '}
                  {isEn
                    ? 'All advertising proposals, specifications, and rate cards are coordinated solely via Joysaker5@gmail.com. No phone call or chat service applies.'
                    : 'বিজ্ঞাপন সংক্রান্ত যাবতীয় প্রস্তাবনা, ব্যানার সাইজ ও রেট কার্ড শুধুমাত্র Joysaker5@gmail.com ইমেইলে পরিচালনা করা হয়। কোনো প্রকার ফোন কল বা মেসেজ সার্ভিস প্রযোজ্য নয়।'}
                </p>
              </div>

              {/* Office & Service Guarantee Info */}
              <div className="p-5 rounded-3xl bg-slate-900 border border-slate-800 space-y-4 shadow-xl">
                <h3 className="text-xs font-black text-amber-400 uppercase tracking-wider flex items-center gap-2">
                  <Building2 className="w-4 h-4" />
                  {isEn ? 'Head Office & Media Cell' : 'হেড অফিস ও মিডিয়া সেল'}
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                  <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 space-y-1">
                    <span className="text-[10px] text-slate-400 font-bold">{isEn ? '🏢 Address:' : '🏢 ঠিকানা:'}</span>
                    <p className="text-slate-200 leading-relaxed text-[11px]">
                      {isEn ? 'Gulshan-1, Dhaka-1212, Bangladesh' : OFFICIAL_AD_CONTACT_INFO.officeAddress}
                    </p>
                  </div>

                  <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 space-y-1">
                    <span className="text-[10px] text-slate-400 font-bold">{isEn ? '⏰ Office Hours:' : '⏰ অফিস সময়:'}</span>
                    <p className="text-slate-200 text-[11px]">
                      {isEn ? 'Sun - Thu: 9:00 AM - 6:00 PM (BST)' : OFFICIAL_AD_CONTACT_INFO.supportHours}
                    </p>
                  </div>

                  <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 space-y-1">
                    <span className="text-[10px] text-slate-400 font-bold">{isEn ? '⚡ Response SLA:' : '⚡ রেসপন্স গ্যারান্টি:'}</span>
                    <p className="text-emerald-400 font-bold text-[11px]">
                      {isEn ? 'Within 12-24 hours' : OFFICIAL_AD_CONTACT_INFO.responseTime}
                    </p>
                  </div>
                </div>

                <div className="pt-2 text-center">
                  <button
                    onClick={() => {
                      Sound.playClick();
                      setActiveTab('proposal');
                    }}
                    className="py-3 px-6 rounded-2xl bg-gradient-to-r from-amber-500 via-orange-500 to-rose-600 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black text-xs shadow-lg transition-all active:scale-98 cursor-pointer inline-flex items-center gap-2"
                  >
                    <Send className="w-4 h-4" />
                    <span>{isEn ? 'Fill Out Online Ad Proposal ❯' : 'অনলাইনে বিজ্ঞাপন ফর্ম পূরণ করে জমা দিন ❯'}</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: SUBMIT PROPOSAL FORM */}
          {activeTab === 'proposal' && (
            <div className="max-w-2xl mx-auto space-y-4 animate-fade-in">
              {submittedTicket ? (
                <div className="p-6 rounded-3xl bg-slate-900 border-2 border-emerald-500 text-center space-y-4 shadow-xl">
                  <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-400/40 flex items-center justify-center mx-auto">
                    <CheckCircle2 className="w-8 h-8" />
                  </div>
                  <div>
                    <span className="px-3 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-black uppercase">
                      {isEn ? 'Proposal Received Successfully ✓' : 'প্রস্তাবনা সফলভাবে গৃহীত হয়েছে ✓'}
                    </span>
                    <h3 className="text-base font-black text-white mt-2">
                      {isEn ? `Thank you, ${submittedTicket.contactPerson}!` : `ধন্যবাদ ${submittedTicket.contactPerson}!`}
                    </h3>
                  </div>

                  <p className="text-xs text-slate-300 leading-relaxed max-w-md mx-auto">
                    {isEn
                      ? `Your advertising proposal for ${submittedTicket.brandName} has reached our media team. We will reach out to ${submittedTicket.email} within 12 to 24 hours with custom media kits and rates.`
                      : `আপনার ${submittedTicket.brandName} ব্র্যান্ডের বিজ্ঞাপন প্রস্তাবনা আমাদের মিডিয়া সেল টিমে পৌঁছেছে। আমাদের অফিসিয়াল মিডিয়া ডেস্ক থেকে ${submittedTicket.email} ঠিকানায় আগামী ১২ থেকে ২৪ ঘণ্টার মধ্যে সরাসরি ইমেইলে যোগাযোগ ও মিডিয়া কিট পাঠানো হবে।`}
                  </p>

                  <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 font-mono text-xs text-amber-300">
                    {isEn ? 'Tracking Ticket ID: ' : 'ট্র্যাকিং টিকেট আইডি: '}<span className="font-bold">{submittedTicket.id}</span>
                  </div>

                  <div className="flex items-center justify-center gap-3 pt-2">
                    <button
                      onClick={() => {
                        Sound.playClick();
                        setSubmittedTicket(null);
                        setBrandName('');
                        setPhone('');
                        setMessage('');
                      }}
                      className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition-all cursor-pointer"
                    >
                      {isEn ? 'Submit Another Proposal' : 'নতুন প্রস্তাবনা জমা দিন'}
                    </button>
                    <button
                      onClick={() => {
                        Sound.playClick();
                        setActiveTab('contact');
                      }}
                      className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black transition-all cursor-pointer shadow-md"
                    >
                      {isEn ? 'Go to Email Desk ❯' : 'ইমেইল ডেস্কে যান ❯'}
                    </button>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleFormSubmit} className="p-5 rounded-3xl bg-slate-900 border border-slate-800 space-y-4 shadow-xl">
                  <div className="border-b border-slate-800 pb-3">
                    <h3 className="text-sm font-black text-white flex items-center gap-2">
                      <FileText className="w-4 h-4 text-amber-400" />
                      {isEn ? 'Advertiser & Partnership Form' : 'বিজ্ঞাপনদাতা ও পার্টনারশিপ ফর্ম (Business Inquiry)'}
                    </h3>
                    <p className="text-xs text-slate-400 mt-0.5">
                      {isEn
                        ? 'Fill out the form below. Our team will send rate cards and deck from Joysaker5@gmail.com directly to your email.'
                        : 'ফর্মটি পূরণ করে জমা দিন। আমাদের টিম সরাসরি Joysaker5@gmail.com থেকে আপনার ইমেইলে রেট কার্ড ও ডেক পাঠাবে।'}
                    </p>
                  </div>

                  {/* Brand & Representative Name */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs font-bold text-slate-300 block mb-1">
                        {isEn ? 'Company / Brand Name:' : 'কোম্পানি / ব্র্যান্ডের নাম:'} <span className="text-rose-400">*</span>
                      </label>
                      <input
                        type="text"
                        required
                        placeholder={isEn ? 'e.g., Walton, Pran, bKash, Grameenphone' : 'যেমন: Walton, Pran, Bkash, Grameenphone'}
                        value={brandName}
                        onChange={(e) => setBrandName(e.target.value)}
                        className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-amber-400"
                      />
                    </div>
                    <div>
                      <label className="text-xs font-bold text-slate-300 block mb-1">
                        {isEn ? 'Representative Name & Title:' : 'প্রতিনিধির নাম ও পদবি:'} <span className="text-rose-400">*</span>
                      </label>
                      <input
                        type="text"
                        required
                        placeholder={isEn ? 'e.g., John Doe (Marketing Lead)' : 'যেমন: মো: আরিফুল ইসলাম (Marketing Lead)'}
                        value={contactPerson}
                        onChange={(e) => setContactPerson(e.target.value)}
                        className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-amber-400"
                      />
                    </div>
                  </div>

                  {/* Business Email & Optional Organization Details */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs font-bold text-slate-300 block mb-1">
                        {isEn ? 'Business Contact Email:' : 'বিজনেস যোগাযোগের ইমেইল:'} <span className="text-rose-400">*</span>
                      </label>
                      <input
                        type="email"
                        required
                        placeholder={isEn ? 'e.g., marketing@company.com' : 'যেমন: marketing@company.com'}
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-amber-400"
                      />
                    </div>
                    <div>
                      <label className="text-xs font-bold text-slate-300 block mb-1">
                        {isEn ? 'Company Website / Page:' : 'কোম্পানি ওয়েবসাইট / সোশ্যাল পেজ:'}
                      </label>
                      <input
                        type="text"
                        placeholder="https://mybrand.com"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-amber-400"
                      />
                    </div>
                  </div>

                  {/* Ad Placement Type Selector */}
                  <div>
                    <label className="text-xs font-bold text-slate-300 block mb-1.5">
                      {isEn ? 'Ad Placement or Format:' : 'বিজ্ঞাপনের প্লেসমেন্ট বা ধরন:'}
                    </label>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                      {[
                        { id: 'board_banner', label: isEn ? '🎲 Ludo Board Banner' : '🎲 লুডু বোর্ড ব্যানার' },
                        { id: 'video_sponsor', label: isEn ? '🎥 Video Shorts Sponsor' : '🎥 ভিডিও শর্টস স্পনসর' },
                        { id: 'voice_adda_sponsor', label: isEn ? '☕ 10-Player Voice Room' : '☕ ১০ জনের আড্ডা রুম' },
                        { id: 'tournament_partner', label: isEn ? '🏆 Tournament Partner' : '🏆 টুর্নামেন্ট পার্টনার' },
                        { id: 'rewarded_ad', label: isEn ? '💎 Rewarded Ads' : '💎 রিওয়ার্ডেড অ্যাড' },
                        { id: 'custom_partnership', label: isEn ? '🤝 Custom Campaign' : '🤝 কাস্টম ক্যাম্পেইন' },
                      ].map((item) => (
                        <button
                          key={item.id}
                          type="button"
                          onClick={() => {
                            Sound.playButtonTick();
                            setAdType(item.id as any);
                          }}
                          className={`p-2.5 rounded-xl border text-xs font-bold transition-all cursor-pointer text-left ${
                            adType === item.id
                              ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-md font-black'
                              : 'bg-slate-950 text-slate-300 border-slate-800 hover:border-slate-700'
                          }`}
                        >
                          {item.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Estimated Budget Range */}
                  <div>
                    <label className="text-xs font-bold text-slate-300 block mb-1.5">
                      {isEn ? 'Estimated Budget Range:' : 'আনুমানিক বাজেট রেঞ্জ:'}
                    </label>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      {[
                        { id: 'under_50k', label: isEn ? '৳ 25K - 50K' : '৳ ২৫,০০০ - ৫০,০০০' },
                        { id: '50k_to_200k', label: isEn ? '৳ 50K - 200K' : '৳ ৫০,০০০ - ২ লাখ' },
                        { id: '200k_to_500k', label: isEn ? '৳ 200K - 500K' : '৳ ২ লাখ - ৫ লাখ' },
                        { id: '500k_plus', label: isEn ? '৳ 500K+ (Enterprise)' : '৳ ৫ লাখ+ (এন্টারপ্রাইজ)' },
                      ].map((b) => (
                        <button
                          key={b.id}
                          type="button"
                          onClick={() => {
                            Sound.playButtonTick();
                            setBudgetRange(b.id as any);
                          }}
                          className={`p-2 rounded-xl border text-[11px] font-bold text-center transition-all cursor-pointer ${
                            budgetRange === b.id
                              ? 'bg-orange-500 text-slate-950 border-orange-400 shadow-md font-black'
                              : 'bg-slate-950 text-slate-300 border-slate-800 hover:border-slate-700'
                          }`}
                        >
                          {b.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Message Details */}
                  <div>
                    <label className="text-xs font-bold text-slate-300 block mb-1">
                      {isEn ? 'Campaign Goals or Special Instructions:' : 'বিজ্ঞাপনের লক্ষ্য বা কোনো বিশেষ নির্দেশনা:'}
                    </label>
                    <textarea
                      rows={2}
                      placeholder={isEn ? 'Tell us about campaign duration, target offers, or special partnership goals...' : 'আপনার ক্যাম্পেইনের সময়কাল, অফার কিংবা বিশেষ স্পনসরশিপ প্রত্যাশা সম্পর্কে লিখুন...'}
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      className="w-full px-3.5 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-amber-400"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3 rounded-2xl bg-gradient-to-r from-amber-500 via-orange-500 to-rose-600 hover:from-amber-400 hover:to-rose-500 text-slate-950 font-black text-xs shadow-lg active:scale-98 transition-all cursor-pointer flex items-center justify-center gap-2"
                  >
                    <Send className="w-4 h-4" />
                    <span>{isEn ? 'Submit Proposal (Submit Inquiry)' : 'বিজ্ঞাপন প্রস্তাবনা জমা দিন (Submit Inquiry)'}</span>
                  </button>
                </form>
              )}
            </div>
          )}

          {/* TAB 3: PACKAGES & RATE CARD */}
          {activeTab === 'packages' && (
            <div className="space-y-4 max-w-3xl mx-auto animate-fade-in">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-black text-white">
                    {isEn ? 'Official Joy Ludo Advertising Packages' : 'জয় লুডু অফিসিয়াল বিজ্ঞাপন প্যাকেজ'}
                  </h3>
                  <p className="text-xs text-slate-400">
                    {isEn ? 'Select the optimal placement tailored for your brand' : 'আপনার ব্র্যান্ডের চাহিদা অনুযায়ী সঠিক প্লেসমেন্ট বেছে নিন'}
                  </p>
                </div>
                <span className="text-xs font-mono font-bold text-amber-400 bg-amber-400/10 px-2.5 py-1 rounded-xl border border-amber-400/30">
                  {isEn ? 'Affordable & High ROI' : 'অ্যাফোর্ডেবল ও হাই ROI'}
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                {AD_PLACEMENT_PACKAGES.map((pkg) => (
                  <div
                    key={pkg.id}
                    className="p-4 rounded-3xl bg-slate-900 border border-slate-800 hover:border-amber-500/50 transition-all flex flex-col justify-between space-y-3 shadow-lg"
                  >
                    <div className="space-y-2">
                      <div className="flex items-start justify-between">
                        <span className="text-2xl">{pkg.iconEmoji}</span>
                        <span className="px-2.5 py-0.5 rounded-full bg-amber-400/20 text-amber-300 text-[10px] font-black border border-amber-400/40">
                          {pkg.badge}
                        </span>
                      </div>

                      <div>
                        <h4 className="text-sm font-black text-white">{isEn ? pkg.titleEn : pkg.titleBn}</h4>
                        <p className="text-[11px] text-slate-300 mt-1 leading-relaxed">
                          {isEn ? pkg.descriptionEn : pkg.descriptionBn}
                        </p>
                      </div>

                      <div className="p-2.5 rounded-2xl bg-slate-950 border border-slate-800/80 space-y-1 text-xs">
                        <div className="flex items-center justify-between text-slate-300">
                          <span>{isEn ? 'Estimated Reach:' : 'আনুমানিক রিচ:'}</span>
                          <span className="font-bold text-white">{pkg.reachEstimate}</span>
                        </div>
                        <div className="flex items-center justify-between text-slate-300">
                          <span>{isEn ? 'Monthly Impressions:' : 'মাসিক ইম্প্রেশন:'}</span>
                          <span className="font-bold text-emerald-400">{pkg.estimatedImpressions}</span>
                        </div>
                        <div className="flex items-center justify-between pt-1 border-t border-slate-800">
                          <span className="text-slate-400">{isEn ? 'Starting Rate:' : 'শুরুর রেট:'}</span>
                          <span className="font-black font-mono text-amber-300">{pkg.startingPriceBDT}</span>
                        </div>
                      </div>

                      <div className="space-y-1 pt-1">
                        <span className="text-[10px] font-black text-slate-400 uppercase">
                          {isEn ? 'Package Highlights:' : 'প্যাকেজের অন্তর্ভুক্ত:'}
                        </span>
                        {pkg.features.map((feat, idx) => (
                          <div key={idx} className="flex items-center gap-1.5 text-[11px] text-slate-300">
                            <CheckCircle2 className="w-3 h-3 text-emerald-400 shrink-0" />
                            <span className="truncate">{feat}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        Sound.playClick();
                        setAdType(pkg.id as any);
                        setActiveTab('proposal');
                      }}
                      className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-amber-500 hover:text-slate-950 text-slate-200 text-xs font-black transition-all cursor-pointer shadow-sm text-center"
                    >
                      {isEn ? 'Select This Package ❯' : 'এই প্যাকেজটি নির্বাচন করুন ❯'}
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 4: AUDIENCE STATS & MEDIA KIT */}
          {activeTab === 'stats' && (
            <div className="space-y-5 max-w-3xl mx-auto animate-fade-in">
              <div className="p-4 rounded-3xl bg-gradient-to-r from-purple-950/80 via-slate-900 to-indigo-950/80 border-2 border-purple-500/50 shadow-xl flex items-center justify-between">
                <div>
                  <span className="px-2.5 py-0.5 rounded-full bg-purple-500/20 text-purple-300 text-[10px] font-black uppercase">
                    Audience Reach & Media Kit
                  </span>
                  <h3 className="text-base font-black text-white mt-1">
                    {isEn ? 'Joy Ludo Audience & User Demographics' : 'জয় লুডু অডিয়েন্স ও ইউজার ডেমোগ্রাফিক্স'}
                  </h3>
                  <p className="text-xs text-slate-300">
                    {isEn ? 'Young, active, highly engaged Bangladeshi audience.' : 'তরুণ, সক্রিয় ও উচ্চ এনগেজমেন্ট সম্পন্ন বাংলাদেশী অডিয়েন্স।'}
                  </p>
                </div>
                <div className="text-3xl hidden sm:block">📊</div>
              </div>

              {/* Big Metrics Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 text-center space-y-1">
                  <span className="text-[10px] font-bold text-slate-400 uppercase">
                    {isEn ? 'Monthly Active Players' : 'মাসিক সক্রিয় খেলোয়াড়'}
                  </span>
                  <p className="text-xl font-mono font-black text-amber-300">১.৫M+</p>
                  <span className="text-[9px] text-emerald-400 font-bold">1.5M+ Monthly Active</span>
                </div>

                <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 text-center space-y-1">
                  <span className="text-[10px] font-bold text-slate-400 uppercase">
                    {isEn ? 'Daily Matches Played' : 'দৈনিক ম্যাচ খেলা'}
                  </span>
                  <p className="text-xl font-mono font-black text-white">৩,৫০,০০০+</p>
                  <span className="text-[9px] text-slate-400">{isEn ? '350K+ daily games' : 'প্রতিদিন গেমপ্লে'}</span>
                </div>

                <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 text-center space-y-1">
                  <span className="text-[10px] font-bold text-slate-400 uppercase">
                    {isEn ? 'Avg Session Time' : 'গড় সেশন টাইম'}
                  </span>
                  <p className="text-xl font-mono font-black text-emerald-400">২৪.৫ মিনিট</p>
                  <span className="text-[9px] text-emerald-300 font-bold">{isEn ? 'High Retention' : 'হাই রিটেনশন'}</span>
                </div>

                <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 text-center space-y-1">
                  <span className="text-[10px] font-bold text-slate-400 uppercase">
                    {isEn ? 'Target Age Group' : 'টার্গেট বয়স'}
                  </span>
                  <p className="text-xl font-mono font-black text-amber-400">১৮-৩৪ বছর</p>
                  <span className="text-[9px] text-slate-400">{isEn ? '74% Youth Audience' : '৭৪% তরুণ গ্রাহক'}</span>
                </div>
              </div>

              {/* Geographical & Gender Breakdown */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 space-y-3">
                  <h4 className="text-xs font-black text-white flex items-center gap-2">
                    <Globe className="w-4 h-4 text-emerald-400" />
                    {isEn ? 'Geographical Distribution' : 'ভৌগোলিক বিস্তার (Geographical Distribution)'}
                  </h4>
                  <div className="space-y-2 text-xs">
                    <div>
                      <div className="flex justify-between text-slate-300 mb-1">
                        <span>{isEn ? '🇧🇩 Bangladesh (Dhaka, Chittagong, Sylhet...)' : '🇧🇩 বাংলাদেশ (ঢাকা, চট্টগ্রাম, সিলেট, খুলনা...)'}</span>
                        <span className="font-bold text-white">৮৬%</span>
                      </div>
                      <div className="w-full h-2 rounded-full bg-slate-950 overflow-hidden">
                        <div className="h-full bg-emerald-500 rounded-full" style={{ width: '86%' }} />
                      </div>
                    </div>

                    <div>
                      <div className="flex justify-between text-slate-300 mb-1">
                        <span>{isEn ? '🌐 Global Diaspora (KSA, UAE, Qatar, Malaysia)' : '🌐 প্রবাসী বাংলাদেশি (সৌদি, আরব আমিরাত, কাতার, মালয়েশিয়া)'}</span>
                        <span className="font-bold text-white">১৪%</span>
                      </div>
                      <div className="w-full h-2 rounded-full bg-slate-950 overflow-hidden">
                        <div className="h-full bg-blue-500 rounded-full" style={{ width: '14%' }} />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 space-y-3">
                  <h4 className="text-xs font-black text-white flex items-center gap-2">
                    <Users className="w-4 h-4 text-amber-400" />
                    {isEn ? 'Gender & Demographic Profile' : 'লিঙ্গ ও আগ্রহ ডেমোগ্রাফিক্স'}
                  </h4>
                  <div className="space-y-2 text-xs">
                    <div>
                      <div className="flex justify-between text-slate-300 mb-1">
                        <span>{isEn ? '👨 Male Players' : '👨 পুরুষ খেলোয়াড়'}</span>
                        <span className="font-bold text-white">৬৫%</span>
                      </div>
                      <div className="w-full h-2 rounded-full bg-slate-950 overflow-hidden">
                        <div className="h-full bg-indigo-500 rounded-full" style={{ width: '65%' }} />
                      </div>
                    </div>

                    <div>
                      <div className="flex justify-between text-slate-300 mb-1">
                        <span>{isEn ? '👩 Female Players' : '👩 নারী খেলোয়াড়'}</span>
                        <span className="font-bold text-white">৩৫%</span>
                      </div>
                      <div className="w-full h-2 rounded-full bg-slate-950 overflow-hidden">
                        <div className="h-full bg-rose-500 rounded-full" style={{ width: '35%' }} />
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 text-center space-y-2">
                <p className="text-xs text-slate-300">
                  {isEn
                    ? 'For custom campaigns, in-game sponsorships, or tailored rate cards, please contact our media desk directly.'
                    : 'আপনার ব্র্যান্ডের কাস্টম ক্যাম্পেইন বা রেট কার্ড সংক্রান্ত যেকোনো তথ্যের জন্য সরাসরি আমাদের মিডিয়া টিমে যোগাযোগ করুন।'}
                </p>
                <button
                  onClick={() => {
                    Sound.playClick();
                    setActiveTab('contact');
                  }}
                  className="py-2.5 px-5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs cursor-pointer shadow-md inline-flex items-center gap-1.5"
                >
                  <Mail className="w-3.5 h-3.5" />
                  <span>{isEn ? 'Contact Official Email Desk ❯' : 'অফিসিয়াল ইমেইল ডেস্কে যোগাযোগ করুন ❯'}</span>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Footer info bar */}
        <div className="px-5 py-2.5 bg-slate-950 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400 shrink-0">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>{isEn ? 'Official Media Cell & Corporate Advertising Desk' : 'অফিসিয়াল মিডিয়া সেল ও কর্পোরেট বিজ্ঞাপন ডেস্ক'}</span>
          </div>
          <span className="font-mono text-amber-300">{OFFICIAL_AD_CONTACT_INFO.email}</span>
        </div>
      </div>
    </div>
  );
};
