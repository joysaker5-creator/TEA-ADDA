import React from 'react';
import { Users2, ShieldCheck, Trophy, Sparkles } from 'lucide-react';
import { Player, PlayerColor } from '../types';
import { COLOR_CONFIG } from '../utils/ludoConstants';

interface TeamPlayBannerProps {
  players: Player[];
  currentTurnColor: PlayerColor;
  targetTokens?: number;
}

export const TeamPlayBanner: React.FC<TeamPlayBannerProps> = ({
  players,
  currentTurnColor,
  targetTokens = 6,
}) => {
  // Team 1: Red & Yellow
  const team1Players = players.filter((p) => p.color === 'red' || p.color === 'yellow');
  const team1HomeCount = team1Players.reduce(
    (sum, p) => sum + p.tokens.filter((t) => t.isHome).length,
    0
  );

  // Team 2: Green & Blue
  const team2Players = players.filter((p) => p.color === 'green' || p.color === 'blue');
  const team2HomeCount = team2Players.reduce(
    (sum, p) => sum + p.tokens.filter((t) => t.isHome).length,
    0
  );

  const isTeam1Turn = currentTurnColor === 'red' || currentTurnColor === 'yellow';
  const turnCfg = (currentTurnColor && COLOR_CONFIG[currentTurnColor]) || COLOR_CONFIG.red;

  return (
    <div className="w-full max-w-[560px] mx-auto mb-2.5 bg-gradient-to-r from-red-50 via-amber-50 to-blue-50 border-2 border-amber-300 rounded-2xl p-2.5 sm:p-3 shadow-md">
      <div className="flex items-center justify-between gap-2 mb-2">
        <div className="flex items-center gap-1.5">
          <div className="w-6 h-6 rounded-lg bg-indigo-600 text-white flex items-center justify-center shadow-sm">
            <Users2 className="w-3.5 h-3.5" />
          </div>
          <div>
            <span className="text-xs font-black text-slate-900 block leading-tight">
              Team Play Mode (2 vs 2)
            </span>
            <span className="text-[10px] text-amber-800 font-bold flex items-center gap-1 leading-tight">
              <ShieldCheck className="w-3 h-3 text-emerald-600 inline" />
              Teammate tokens safe • Target: {targetTokens} Tokens Home
            </span>
          </div>
        </div>

        <span className="text-[10px] font-black bg-amber-200 text-amber-950 px-2 py-0.5 rounded-full flex items-center gap-1">
          <Trophy className="w-3 h-3 text-amber-700" />
          Joint Target
        </span>
      </div>

      {/* Two Teams Scoreboards */}
      <div className="grid grid-cols-2 gap-2">
        {/* Team 1 Card */}
        <div
          className={`p-2 rounded-xl border-2 transition-all ${
            isTeam1Turn
              ? 'bg-white border-red-400 shadow-sm ring-2 ring-red-400/40'
              : 'bg-white/80 border-slate-200'
          }`}
        >
          <div className="flex items-center justify-between mb-1">
            <div className="flex items-center gap-1.5">
              <div className="flex -space-x-1">
                <div className="w-4 h-4 rounded-full bg-red-500 border border-white" />
                <div className="w-4 h-4 rounded-full bg-yellow-400 border border-white" />
              </div>
              <span className="text-xs font-black text-slate-900">Team 1 (Red & Yellow)</span>
            </div>
            <span className="text-xs font-black text-red-600">
              {team1HomeCount}/{targetTokens}
            </span>
          </div>

          {/* Progress Bar */}
          <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden border border-slate-200">
            <div
              className="h-full bg-gradient-to-r from-red-500 to-yellow-400 rounded-full transition-all duration-500"
              style={{ width: `${Math.min(100, (team1HomeCount / targetTokens) * 100)}%` }}
            />
          </div>
          {isTeam1Turn && (
            <span className="text-[9px] font-extrabold text-red-600 mt-1 block">
              ● Active Turn: {turnCfg.name}
            </span>
          )}
        </div>

        {/* Team 2 Card */}
        <div
          className={`p-2 rounded-xl border-2 transition-all ${
            !isTeam1Turn
              ? 'bg-white border-blue-400 shadow-sm ring-2 ring-blue-400/40'
              : 'bg-white/80 border-slate-200'
          }`}
        >
          <div className="flex items-center justify-between mb-1">
            <div className="flex items-center gap-1.5">
              <div className="flex -space-x-1">
                <div className="w-4 h-4 rounded-full bg-emerald-500 border border-white" />
                <div className="w-4 h-4 rounded-full bg-blue-500 border border-white" />
              </div>
              <span className="text-xs font-black text-slate-900">Team 2 (Green & Blue)</span>
            </div>
            <span className="text-xs font-black text-blue-600">
              {team2HomeCount}/{targetTokens}
            </span>
          </div>

          {/* Progress Bar */}
          <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden border border-slate-200">
            <div
              className="h-full bg-gradient-to-r from-emerald-500 to-blue-500 rounded-full transition-all duration-500"
              style={{ width: `${Math.min(100, (team2HomeCount / targetTokens) * 100)}%` }}
            />
          </div>
          {!isTeam1Turn && (
            <span className="text-[9px] font-extrabold text-blue-600 mt-1 block">
              ● Active Turn: {turnCfg.name}
            </span>
          )}
        </div>
      </div>
    </div>
  );
};
