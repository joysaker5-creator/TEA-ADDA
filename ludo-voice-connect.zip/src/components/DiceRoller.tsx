import React from 'react';
import { Dices, Sparkles, Coins } from 'lucide-react';
import { Player, PlayerColor, DiceStyleId, DiceFaceStyle } from '../types';
import { COLOR_CONFIG } from '../utils/ludoConstants';
import { AvatarDisplay } from './AvatarDisplay';
import { DicePiece } from './DicePiece';

interface DiceRollerProps {
  currentPlayer: Player;
  isMyTurn: boolean;
  diceValue: number | null;
  isRolling: boolean;
  hasRolled: boolean;
  eligibleCount: number;
  consecutiveSixes: number;
  lastActionText: string;
  onRollDice: () => void;
  diceStyle?: DiceStyleId;
  diceFace?: DiceFaceStyle;
}

export const DiceRoller: React.FC<DiceRollerProps> = ({
  currentPlayer,
  isMyTurn,
  diceValue,
  isRolling,
  hasRolled,
  eligibleCount,
  consecutiveSixes,
  lastActionText,
  onRollDice,
  diceStyle = 'classic',
  diceFace = 'dots',
}) => {
  const config = (currentPlayer?.color && COLOR_CONFIG[currentPlayer.color]) || COLOR_CONFIG.red;

  const canClickRoll = isMyTurn && !isRolling && !hasRolled;

  return (
    <div
      id="dice-roller-container"
      className="w-full bg-white border-2 border-amber-200 rounded-3xl p-4 shadow-lg border-b-4 border-amber-300 flex flex-col sm:flex-row items-center justify-between gap-3 transition-all"
    >
      {/* Current Turn Information */}
      <div className="flex items-center gap-3 w-full sm:w-auto">
        <div
          className="relative w-12 h-12 rounded-2xl flex items-center justify-center shadow-md border-2 overflow-visible"
          style={{
            backgroundColor: config.bgHex,
            borderColor: config.borderHex,
          }}
        >
          {currentPlayer.avatar ? (
            <AvatarDisplay avatar={currentPlayer.avatar} size={40} />
          ) : (
            <span className="text-2xl">{config.avatar}</span>
          )}
          {isMyTurn && (
            <span className="absolute -top-1 -right-1 flex h-3.5 w-3.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-80"></span>
              <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-amber-500 border-2 border-white"></span>
            </span>
          )}
        </div>

        <div className="flex flex-col">
          <div className="flex items-center gap-1.5">
            <span className="font-extrabold text-base text-slate-900">{currentPlayer.name}</span>
            <span
              className="text-[10px] font-black px-2 py-0.5 rounded-full text-white"
              style={{ backgroundColor: config.hex }}
            >
              {config.name}
            </span>
            {isMyTurn && (
              <span className="text-[11px] font-black px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-900 border border-amber-300">
                Your Turn
              </span>
            )}
          </div>

          <div className="flex items-center gap-2 mt-0.5">
            <div className="flex items-center gap-1 text-amber-800 text-xs font-black bg-amber-100 px-2 py-0.5 rounded-full">
              <Coins className="w-3.5 h-3.5 fill-amber-500 text-amber-600" />
              <span>{currentPlayer.coins.toLocaleString('en-US')}</span>
            </div>
            {consecutiveSixes > 0 && (
              <span className="text-[11px] text-red-600 font-black flex items-center gap-0.5 bg-red-100 px-2 py-0.5 rounded-full">
                <Sparkles className="w-3 h-3 text-red-500" />
                Six: {consecutiveSixes}x
              </span>
            )}
          </div>
          <span className="text-xs text-slate-600 font-medium line-clamp-1 mt-0.5">
            {lastActionText || (isMyTurn ? 'Roll the dice to make your move' : 'Waiting for opponent...')}
          </span>
        </div>
      </div>

      {/* Center status message */}
      <div className="hidden lg:flex flex-col items-center justify-center text-center px-4 py-2 bg-amber-50 rounded-2xl border border-amber-200 max-w-[210px]">
        {isMyTurn ? (
          !hasRolled ? (
            <span className="text-xs text-emerald-700 font-black animate-pulse">
              🎲 Roll the Dice!
            </span>
          ) : eligibleCount > 0 ? (
            <span className="text-xs text-amber-900 font-bold">
              👉 Tap a token to move ({eligibleCount} possible)
            </span>
          ) : (
            <span className="text-xs text-rose-600 font-semibold">No moves (Next turn)</span>
          )
        ) : (
          <span className="text-xs text-slate-500 font-medium">Opponent is thinking...</span>
        )}
      </div>

      {/* Interactive Dice Face & Action Button */}
      <div className="flex items-center gap-3 self-end sm:self-center">
        {/* Dice Box */}
        <DicePiece
          value={diceValue}
          styleId={diceStyle}
          faceStyle={diceFace}
          isRolling={isRolling}
          size={56}
          onClick={canClickRoll ? onRollDice : undefined}
          className={
            canClickRoll
              ? 'cursor-pointer hover:scale-105 ring-4 ring-amber-400 ring-offset-2 shadow-amber-400/50 animate-pulse active:translate-y-1'
              : 'cursor-default'
          }
        />

        {/* Big Roll Button matching Vibrant Palette */}
        {isMyTurn && !hasRolled && (
          <button
            id="roll-dice-action-btn"
            disabled={!canClickRoll}
            onClick={onRollDice}
            className="px-5 py-3.5 rounded-2xl bg-red-500 hover:bg-red-600 text-white font-black text-sm uppercase tracking-wider shadow-lg border-b-4 border-red-700 active:translate-y-1 active:border-b-0 transition-all flex items-center gap-2"
          >
            <Dices className="w-4 h-4" />
            <span>Roll</span>
          </button>
        )}

        {isMyTurn && hasRolled && eligibleCount > 0 && (
          <div className="px-4 py-2.5 rounded-2xl bg-amber-400 text-amber-950 font-black border-2 border-amber-500 shadow-md text-xs animate-bounce">
            Pick Token
          </div>
        )}
      </div>
    </div>
  );
};
