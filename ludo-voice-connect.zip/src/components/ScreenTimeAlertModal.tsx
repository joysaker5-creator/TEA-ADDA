import React from 'react';
import { Clock, Eye, AlertTriangle, ShieldAlert, Sparkles } from 'lucide-react';
import { Sound } from '../utils/soundEffects';

interface ScreenTimeAlertModalProps {
  isOpen: boolean;
  onClose: () => void;
  usedMinutes: number;
  limitMinutes: number;
  isKidMode: boolean;
}

export const ScreenTimeAlertModal: React.FC<ScreenTimeAlertModalProps> = ({
  isOpen,
  onClose,
  usedMinutes,
  limitMinutes,
  isKidMode,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-md bg-slate-950 text-white rounded-3xl border-2 border-amber-500 shadow-2xl p-6 text-center space-y-4">
        <div className="w-16 h-16 rounded-full bg-amber-500/20 text-amber-400 border border-amber-400/40 flex items-center justify-center mx-auto animate-bounce">
          <Clock className="w-8 h-8" />
        </div>

        <div>
          <span className="px-3 py-0.5 rounded-full bg-amber-500/20 text-amber-300 text-[10px] font-black uppercase tracking-wider">
            ডিজিটাল সুস্থতা রিমাইন্ডার
          </span>
          <h2 className="text-lg font-black text-white mt-1.5">
            {isKidMode ? '🧒 খেলার সময় শেষ হয়েছে!' : '⏰ একটি ছোট্ট বিরতি নিন!'}
          </h2>
        </div>

        <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 text-xs text-slate-300 space-y-1.5">
          <p>
            আপনি আজ নির্ধারিত <strong>{limitMinutes} মিনিট</strong> সময়ের মধ্যে <strong>{usedMinutes} মিনিট</strong> খেলেছেন।
          </p>
          <p className="text-amber-300 font-bold">
            চোখের যত্ন নিন, একটু পানি পান করুন এবং কিছুক্ষণ বিশ্রাম নিন! 💧👀
          </p>
        </div>

        <div className="flex items-center justify-center gap-3 pt-2">
          <button
            onClick={() => {
              Sound.playClick();
              onClose();
            }}
            className="w-full py-2.5 rounded-2xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs transition-all shadow-md active:scale-95 cursor-pointer"
          >
            আমি বুঝেছি, ধন্যবাদ!
          </button>
        </div>
      </div>
    </div>
  );
};
