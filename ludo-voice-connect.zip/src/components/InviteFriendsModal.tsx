import React, { useState, useEffect } from 'react';
import {
  X,
  Copy,
  Check,
  Gift,
  Users,
  Share2,
  Sparkles,
  QrCode,
  Trophy,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  Coins,
  Gem,
  ExternalLink,
  MessageCircle,
  Smartphone,
  Flame,
  Award,
  Zap,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { UserProfile, AvatarConfig, ReferralState, ReferralMilestone, InvitedFriendRecord } from '../types';
import { AvatarDisplay } from './AvatarDisplay';
import {
  loadReferralState,
  saveReferralState,
  buildReferralShareLink,
  buildShareMessage,
  triggerWebShare,
  applyReferralCodeService,
  simulateAddFriendInvite,
  REFERRAL_PER_INVITE_COINS,
  REFERRAL_PER_INVITE_DIAMONDS,
  REFERRAL_WELCOME_COINS,
  REFERRAL_WELCOME_DIAMONDS,
  REFERRAL_MILESTONES,
} from '../utils/referralService';
import { Sound } from '../utils/soundEffects';

interface InviteFriendsModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile;
  userAvatar: AvatarConfig;
  userCoins: number;
  userDiamonds: number;
  onRewardGranted: (coins: number, diamonds: number) => void;
}

export const InviteFriendsModal: React.FC<InviteFriendsModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  userAvatar,
  userCoins,
  userDiamonds,
  onRewardGranted,
}) => {
  const [referralState, setReferralState] = useState<ReferralState>(() => loadReferralState(currentUser));
  const [activeTab, setActiveTab] = useState<'invite' | 'friends' | 'milestones' | 'claim_code'>('invite');
  const [copiedLink, setCopiedLink] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);
  const [showQrCode, setShowQrCode] = useState(false);

  // Claim referral code input
  const [friendCodeInput, setFriendCodeInput] = useState('');
  const [isClaiming, setIsClaiming] = useState(false);
  const [claimFeedback, setClaimFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Reload state whenever opened or user changes
  useEffect(() => {
    if (isOpen) {
      const state = loadReferralState(currentUser);
      setReferralState(state);
      setClaimFeedback(null);
      setCopiedLink(false);
      setCopiedCode(false);
    }
  }, [isOpen, currentUser]);

  if (!isOpen) return null;

  const referralCode = referralState.referralCode;
  const shareLink = buildReferralShareLink(referralCode);
  const shareMessage = buildShareMessage(referralCode, shareLink);

  // Trigger celebration confetti
  const triggerConfetti = () => {
    confetti({
      particleCount: 60,
      spread: 70,
      origin: { y: 0.6 },
    });
  };

  // Copy Referral Link
  const handleCopyLink = () => {
    Sound.playButtonTick();
    navigator.clipboard.writeText(shareLink);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  // Copy Referral Code
  const handleCopyCode = () => {
    Sound.playButtonTick();
    navigator.clipboard.writeText(referralCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2500);
  };

  // WhatsApp Share
  const handleWhatsAppShare = () => {
    Sound.playClick();
    const url = `https://api.whatsapp.com/send?text=${encodeURIComponent(shareMessage)}`;
    window.open(url, '_blank');
  };

  // Facebook Share
  const handleFacebookShare = () => {
    Sound.playClick();
    const url = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareLink)}&quote=${encodeURIComponent(shareMessage)}`;
    window.open(url, '_blank');
  };

  // Telegram Share
  const handleTelegramShare = () => {
    Sound.playClick();
    const url = `https://t.me/share/url?url=${encodeURIComponent(shareLink)}&text=${encodeURIComponent(shareMessage)}`;
    window.open(url, '_blank');
  };

  // Native Share
  const handleNativeShare = async () => {
    Sound.playClick();
    const shared = await triggerWebShare('জয় লুডু - বন্ধুদের আমন্ত্রণ', shareMessage, shareLink);
    if (!shared) {
      handleCopyLink();
    }
  };

  // Apply Friend's Code
  const handleApplyFriendCode = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!friendCodeInput.trim()) return;

    setIsClaiming(true);
    setClaimFeedback(null);

    const result = await applyReferralCodeService(friendCodeInput, currentUser, (coins, diamonds) => {
      onRewardGranted(coins, diamonds);
    });

    setIsClaiming(false);
    if (result.success) {
      Sound.playRewardClaim();
      triggerConfetti();
      setClaimFeedback({ type: 'success', text: result.message });
      setReferralState(loadReferralState(currentUser));
      setFriendCodeInput('');
    } else {
      Sound.playAlert();
      setClaimFeedback({ type: 'error', text: result.message });
    }
  };

  // Simulate Instant Friend Joining (for testing / demo)
  const handleSimulateInvite = () => {
    Sound.playCoinSound();
    triggerConfetti();
    const result = simulateAddFriendInvite(currentUser);
    setReferralState(result.updatedState);
    onRewardGranted(result.coinsEarned, result.diamondsEarned);
  };

  // Claim Milestone Reward
  const handleClaimMilestone = (milestone: ReferralMilestone) => {
    if (referralState.claimedMilestoneIds.includes(milestone.id)) return;
    if (referralState.totalInvitedCount < milestone.targetCount) return;

    Sound.playCrownFanfare();
    triggerConfetti();

    const updatedState: ReferralState = {
      ...referralState,
      claimedMilestoneIds: [...referralState.claimedMilestoneIds, milestone.id],
      totalCoinsEarned: referralState.totalCoinsEarned + milestone.bonusCoins,
      totalDiamondsEarned: referralState.totalDiamondsEarned + milestone.bonusDiamonds,
      lastUpdated: Date.now(),
    };

    setReferralState(updatedState);
    saveReferralState(currentUser.id, updatedState);
    onRewardGranted(milestone.bonusCoins, milestone.bonusDiamonds);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/80 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-4xl max-h-[92vh] bg-slate-950 text-white rounded-3xl border-2 border-amber-500/50 shadow-2xl flex flex-col overflow-hidden">
        {/* Header Bar */}
        <div className="px-4 sm:px-6 py-4 bg-gradient-to-r from-amber-600 via-yellow-600 to-amber-700 flex items-center justify-between shadow-md shrink-0 border-b border-amber-400/40">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-amber-950/40 border border-amber-300/40 flex items-center justify-center text-white shadow-inner">
              <Gift className="w-6 h-6 text-yellow-300 animate-bounce" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-xl font-black text-white tracking-wide">
                  🎁 বন্ধুদের ইনভাইট ও রেফারেল বোনাস
                </h2>
                <span className="px-2.5 py-0.5 rounded-full bg-emerald-500 text-slate-950 font-black text-[10px] uppercase tracking-wider shadow-xs">
                  +৫,০০০ কয়েন
                </span>
              </div>
              <p className="text-xs text-amber-100 font-medium">
                প্রতি সফল রেফারে ৫,০০০ কয়েন 🪙 ও ২০ ডায়মন্ড 💎 এবং বন্ধু পাবে ২,৫০০ কয়েন!
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              Sound.playClick();
              onClose();
            }}
            className="w-9 h-9 rounded-2xl bg-amber-950/50 hover:bg-red-600/80 text-white flex items-center justify-center transition-all cursor-pointer border border-amber-300/30"
            title="বন্ধ করুন"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Stats Summary Bar */}
        <div className="grid grid-cols-3 bg-slate-900/90 border-b border-slate-800 text-center py-2.5 px-3">
          <div className="border-r border-slate-800/80">
            <span className="text-[10px] text-slate-400 font-bold block uppercase">মোট আমন্ত্রিত বন্ধু</span>
            <span className="text-sm sm:text-base font-black text-amber-400 flex items-center justify-center gap-1">
              <Users className="w-3.5 h-3.5" />
              {referralState.totalInvitedCount} জন
            </span>
          </div>
          <div className="border-r border-slate-800/80">
            <span className="text-[10px] text-slate-400 font-bold block uppercase">রেফারেল অর্জিত কয়েন</span>
            <span className="text-sm sm:text-base font-black text-yellow-400 flex items-center justify-center gap-1">
              <span>🪙</span>
              {referralState.totalCoinsEarned.toLocaleString('bn-BD')}
            </span>
          </div>
          <div>
            <span className="text-[10px] text-slate-400 font-bold block uppercase">অর্জিত ডায়মন্ডস</span>
            <span className="text-sm sm:text-base font-black text-cyan-400 flex items-center justify-center gap-1">
              <span>💎</span>
              {referralState.totalDiamondsEarned} টি
            </span>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-1.5 px-4 pt-3 pb-1 bg-slate-950 overflow-x-auto border-b border-slate-800/80">
          {[
            { id: 'invite', label: 'শেয়ার ও ইনভাইট লিঙ্ক', icon: Share2 },
            { id: 'friends', label: `বন্ধুদের তালিকা (${referralState.totalInvitedCount})`, icon: Users },
            { id: 'milestones', label: 'রিওয়ার্ড মাইলস্টোন', icon: Trophy },
            { id: 'claim_code', label: 'কোড ক্লেইম করুন', icon: Sparkles },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => {
                  Sound.playClick();
                  setActiveTab(tab.id as any);
                }}
                className={`px-3.5 py-2 rounded-2xl text-xs font-black shrink-0 transition-all flex items-center gap-1.5 cursor-pointer ${
                  isActive
                    ? 'bg-amber-500 text-slate-950 shadow-md scale-102'
                    : 'bg-slate-900/80 text-slate-400 hover:bg-slate-800/80 hover:text-slate-200'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Tab Contents Area */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6 bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950">
          {/* TAB 1: INVITE & SHARE LINK */}
          {activeTab === 'invite' && (
            <div className="space-y-5 animate-fade-in">
              {/* Unique Referral Code Box */}
              <div className="p-4 sm:p-5 rounded-3xl bg-gradient-to-r from-slate-900 via-amber-950/40 to-slate-900 border-2 border-amber-500/60 shadow-xl flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="text-center sm:text-left">
                  <span className="text-xs font-black text-amber-300 uppercase tracking-widest block mb-1">
                    আপনার ইউনিক রেফারেল কোড
                  </span>
                  <div className="text-2xl sm:text-3xl font-black text-white font-mono tracking-wider flex items-center gap-2 justify-center sm:justify-start">
                    <span className="text-yellow-400">{referralCode}</span>
                  </div>
                  <p className="text-xs text-slate-400 font-medium mt-1">
                    বন্ধুরা সাইন-আপ করার সময় এই কোড দিলে উভয়ই বোনাস কয়েন পাবেন!
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={handleCopyCode}
                    className="px-4 py-2.5 rounded-2xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs shadow-md active:scale-95 transition-all flex items-center gap-1.5 cursor-pointer"
                  >
                    {copiedCode ? <Check className="w-4 h-4 text-emerald-950" /> : <Copy className="w-4 h-4" />}
                    <span>{copiedCode ? 'কোড কপি হয়েছে!' : 'কোড কপি করুন'}</span>
                  </button>

                  <button
                    onClick={() => {
                      Sound.playClick();
                      setShowQrCode(!showQrCode);
                    }}
                    className={`px-3.5 py-2.5 rounded-2xl border text-xs font-black flex items-center gap-1.5 transition-all cursor-pointer ${
                      showQrCode
                        ? 'bg-purple-600 border-purple-400 text-white'
                        : 'bg-slate-800/80 border-slate-700 text-slate-300 hover:bg-slate-700'
                    }`}
                  >
                    <QrCode className="w-4 h-4" />
                    <span>QR কোড</span>
                  </button>
                </div>
              </div>

              {/* QR Code Panel (if toggled) */}
              {showQrCode && (
                <div className="p-4 rounded-3xl bg-slate-900 border border-purple-500/50 shadow-2xl flex flex-col items-center justify-center text-center animate-fade-in">
                  <span className="text-xs font-black text-purple-300 mb-2">
                    📱 বন্ধুদের ক্যামেরা দিয়ে সরাসরি স্ক্যান করতে বলুন
                  </span>
                  {/* Clean Vector SVG QR Code */}
                  <div className="p-3 bg-white rounded-2xl shadow-lg">
                    <svg
                      viewBox="0 0 100 100"
                      className="w-36 h-36 sm:w-44 sm:h-44 text-slate-950 fill-current"
                    >
                      {/* Standard Positioning Markers */}
                      <rect x="5" y="5" width="28" height="28" fill="#000" rx="4" />
                      <rect x="9" y="9" width="20" height="20" fill="#FFF" rx="2" />
                      <rect x="13" y="13" width="12" height="12" fill="#000" rx="2" />

                      <rect x="67" y="5" width="28" height="28" fill="#000" rx="4" />
                      <rect x="71" y="9" width="20" height="20" fill="#FFF" rx="2" />
                      <rect x="75" y="13" width="12" height="12" fill="#000" rx="2" />

                      <rect x="5" y="67" width="28" height="28" fill="#000" rx="4" />
                      <rect x="9" y="71" width="20" height="20" fill="#FFF" rx="2" />
                      <rect x="13" y="75" width="12" height="12" fill="#000" rx="2" />

                      {/* QR Pattern Blocks */}
                      <rect x="38" y="10" width="8" height="8" fill="#000" />
                      <rect x="50" y="10" width="8" height="8" fill="#000" />
                      <rect x="38" y="24" width="8" height="8" fill="#000" />
                      <rect x="50" y="24" width="8" height="8" fill="#000" />

                      <rect x="10" y="38" width="8" height="8" fill="#000" />
                      <rect x="24" y="38" width="8" height="8" fill="#000" />
                      <rect x="38" y="38" width="8" height="8" fill="#000" />
                      <rect x="52" y="38" width="8" height="8" fill="#000" />
                      <rect x="66" y="38" width="8" height="8" fill="#000" />
                      <rect x="80" y="38" width="8" height="8" fill="#000" />

                      <rect x="10" y="52" width="8" height="8" fill="#000" />
                      <rect x="24" y="52" width="8" height="8" fill="#000" />
                      <rect x="38" y="52" width="8" height="8" fill="#000" />
                      <rect x="52" y="52" width="8" height="8" fill="#000" />
                      <rect x="66" y="52" width="8" height="8" fill="#000" />
                      <rect x="80" y="52" width="8" height="8" fill="#000" />

                      <rect x="38" y="66" width="8" height="8" fill="#000" />
                      <rect x="52" y="66" width="8" height="8" fill="#000" />
                      <rect x="66" y="66" width="8" height="8" fill="#000" />
                      <rect x="80" y="66" width="8" height="8" fill="#000" />

                      <rect x="38" y="80" width="8" height="8" fill="#000" />
                      <rect x="52" y="80" width="8" height="8" fill="#000" />
                      <rect x="66" y="80" width="8" height="8" fill="#000" />
                      <rect x="80" y="80" width="8" height="8" fill="#000" />
                    </svg>
                  </div>
                  <span className="text-[11px] font-mono text-slate-300 font-bold mt-2">
                    {shareLink}
                  </span>
                </div>
              )}

              {/* Share Link Direct Copy */}
              <div className="space-y-1.5">
                <label className="text-xs font-black text-slate-300 flex items-center gap-1.5">
                  <Share2 className="w-3.5 h-3.5 text-amber-400" />
                  রেফারেল ইনভাইট লিংক
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    readOnly
                    value={shareLink}
                    className="flex-1 px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-2xl text-xs text-amber-200 font-mono focus:outline-none select-all"
                  />
                  <button
                    onClick={handleCopyLink}
                    className="px-4 py-2.5 rounded-2xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs shadow-md active:scale-95 transition-all flex items-center gap-1.5 cursor-pointer shrink-0"
                  >
                    {copiedLink ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                    <span>{copiedLink ? 'লিঙ্ক কপি হয়েছে!' : 'লিঙ্ক কপি'}</span>
                  </button>
                </div>
              </div>

              {/* Social Channels Share Buttons */}
              <div className="space-y-2">
                <span className="text-xs font-black text-slate-300 block">
                  সরাসরি সোশ্যাল মিডিয়ায় বন্ধুদের শেয়ার করুন:
                </span>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  {/* WhatsApp */}
                  <button
                    onClick={handleWhatsAppShare}
                    className="p-3 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black flex items-center justify-center gap-2 shadow-md transition-all active:scale-95 cursor-pointer"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>WhatsApp</span>
                  </button>

                  {/* Facebook */}
                  <button
                    onClick={handleFacebookShare}
                    className="p-3 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-black flex items-center justify-center gap-2 shadow-md transition-all active:scale-95 cursor-pointer"
                  >
                    <Share2 className="w-4 h-4" />
                    <span>Facebook</span>
                  </button>

                  {/* Telegram */}
                  <button
                    onClick={handleTelegramShare}
                    className="p-3 rounded-2xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-black flex items-center justify-center gap-2 shadow-md transition-all active:scale-95 cursor-pointer"
                  >
                    <Zap className="w-4 h-4" />
                    <span>Telegram</span>
                  </button>

                  {/* More / Web Share */}
                  <button
                    onClick={handleNativeShare}
                    className="p-3 rounded-2xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-black flex items-center justify-center gap-2 shadow-md transition-all active:scale-95 cursor-pointer"
                  >
                    <ExternalLink className="w-4 h-4" />
                    <span>আরও শেয়ার</span>
                  </button>
                </div>
              </div>

              {/* Instant Test Invite Simulator */}
              <div className="p-4 rounded-3xl bg-slate-900/60 border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3">
                <div className="flex items-center gap-3 text-center sm:text-left">
                  <div className="w-9 h-9 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
                    <Sparkles className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-xs font-black text-white block">
                      ইনভাইট বোনাস টেস্ট করুন (Instant Simulation)
                    </span>
                    <span className="text-[11px] text-slate-400">
                      একটি নতুন বন্ধু যোগ হওয়ার বোনাস (+৫,০০০ কয়েন ও ২০ ডায়মন্ড) এখনই পরখ করুন!
                    </span>
                  </div>
                </div>

                <button
                  onClick={handleSimulateInvite}
                  className="px-4 py-2 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 text-xs font-black shadow-md flex items-center gap-1.5 active:scale-95 transition-all cursor-pointer shrink-0"
                >
                  <PlusFriendIcon />
                  <span>টেস্ট ইনভাইট যোগ করুন</span>
                </button>
              </div>
            </div>
          )}

          {/* TAB 2: INVITED FRIENDS LIST */}
          {activeTab === 'friends' && (
            <div className="space-y-4 animate-fade-in">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-black text-amber-400 flex items-center gap-2">
                  <Users className="w-4 h-4" />
                  আপনার আমন্ত্রণে যোগ দেওয়া বন্ধুরা ({referralState.invitedFriends.length} জন)
                </h3>
                <span className="text-xs font-bold text-slate-400">
                  সর্বমোট বোনাস: {referralState.totalCoinsEarned.toLocaleString('bn-BD')} 🪙 | {referralState.totalDiamondsEarned} 💎
                </span>
              </div>

              {referralState.invitedFriends.length === 0 ? (
                <div className="py-12 text-center text-slate-500">
                  <Users className="w-12 h-12 mx-auto mb-2 opacity-40" />
                  <p className="text-xs font-bold">এখনও কোনো বন্ধু যোগ দেয়নি।</p>
                  <p className="text-[11px] mt-1">আপনার ইনভাইট লিংক শেয়ার করে বন্ধুদের আমন্ত্রণ জানান!</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {referralState.invitedFriends.map((friend) => (
                    <div
                      key={friend.id}
                      className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-amber-500/40 transition-all flex items-center justify-between gap-3 shadow-md"
                    >
                      <div className="flex items-center gap-3">
                        {friend.avatarConfig ? (
                          <AvatarDisplay avatar={friend.avatarConfig} size={38} />
                        ) : (
                          <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-black">
                            {friend.name.charAt(0)}
                          </div>
                        )}
                        <div>
                          <div className="flex items-center gap-1.5">
                            <span className="text-xs font-black text-white">{friend.name}</span>
                            <span className="text-xs">{friend.countryFlag || '🇧🇩'}</span>
                          </div>
                          <span className="text-[10px] text-slate-400 font-medium block">
                            যোগ দিয়েছেন: {new Date(friend.joinedAt).toLocaleDateString('bn-BD')}
                          </span>
                        </div>
                      </div>

                      <div className="text-right">
                        <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 text-[10px] font-black block mb-1">
                          +৫,০০০ 🪙
                        </span>
                        <span className="text-[9px] text-cyan-300 font-mono font-bold">
                          +২০ 💎 বোনাস
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 3: MILESTONES & TIER REWARDS */}
          {activeTab === 'milestones' && (
            <div className="space-y-4 animate-fade-in">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-black text-amber-400 flex items-center gap-1.5">
                  <Trophy className="w-4 h-4" />
                  ইনভাইট মাইলস্টোন রিওয়ার্ডস
                </span>
                <span className="text-xs font-bold text-slate-400">
                  বর্তমান অগ্রগতি: {referralState.totalInvitedCount} জন বন্ধু
                </span>
              </div>

              <div className="space-y-3">
                {REFERRAL_MILESTONES.map((mile) => {
                  const isClaimed = referralState.claimedMilestoneIds.includes(mile.id);
                  const isUnlocked = referralState.totalInvitedCount >= mile.targetCount;
                  const progressPct = Math.min(100, Math.round((referralState.totalInvitedCount / mile.targetCount) * 100));

                  return (
                    <div
                      key={mile.id}
                      className={`p-4 rounded-3xl border transition-all ${
                        isClaimed
                          ? 'bg-slate-900/60 border-slate-800 opacity-80'
                          : isUnlocked
                          ? 'bg-gradient-to-r from-amber-950/60 via-slate-900 to-amber-950/60 border-amber-500/80 shadow-lg shadow-amber-500/10'
                          : 'bg-slate-900/90 border-slate-800'
                      }`}
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                        <div className="flex items-center gap-3.5">
                          <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/40 flex items-center justify-center text-2xl shrink-0">
                            {mile.icon}
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <h4 className="text-xs sm:text-sm font-black text-white">
                                {mile.titleBn} ({mile.targetCount} জন বন্ধু)
                              </h4>
                              <span className="px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-300 text-[10px] font-bold">
                                {mile.badgeBn}
                              </span>
                            </div>
                            <p className="text-[11px] text-slate-400 mt-0.5">
                              পুরস্কার: <span className="text-yellow-400 font-bold">{mile.bonusCoins.toLocaleString('bn-BD')} 🪙 কয়েন</span> + <span className="text-cyan-400 font-bold">{mile.bonusDiamonds} 💎 ডায়মন্ড</span> • {mile.exclusivePerkBn}
                            </p>
                          </div>
                        </div>

                        <div>
                          {isClaimed ? (
                            <span className="px-4 py-2 rounded-2xl bg-slate-800 text-emerald-400 text-xs font-black flex items-center gap-1.5">
                              <CheckCircle2 className="w-4 h-4" />
                              সংগৃহীত ✓
                            </span>
                          ) : isUnlocked ? (
                            <button
                              onClick={() => handleClaimMilestone(mile)}
                              className="px-5 py-2.5 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-xs shadow-md active:scale-95 transition-all flex items-center gap-1.5 cursor-pointer animate-pulse"
                            >
                              <Gift className="w-4 h-4" />
                              <span>ক্লেইম করুন 🎁</span>
                            </button>
                          ) : (
                            <span className="text-[11px] text-slate-500 font-bold">
                              আরও {mile.targetCount - referralState.totalInvitedCount} জন বাকি
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Progress Bar */}
                      <div className="mt-3 w-full bg-slate-800 rounded-full h-2 overflow-hidden">
                        <div
                          className={`h-full transition-all duration-500 ${
                            isClaimed ? 'bg-emerald-500' : 'bg-gradient-to-r from-amber-500 to-yellow-400'
                          }`}
                          style={{ width: `${progressPct}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 4: CLAIM FRIEND'S REFERRAL CODE */}
          {activeTab === 'claim_code' && (
            <div className="space-y-5 max-w-xl mx-auto animate-fade-in">
              <div className="p-5 rounded-3xl bg-slate-900 border border-slate-800 shadow-xl text-center">
                <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-yellow-300 flex items-center justify-center mx-auto mb-3">
                  <Sparkles className="w-6 h-6 animate-pulse" />
                </div>
                <h3 className="text-base font-black text-white">বন্ধুর রেফারেল কোড যুক্ত করুন</h3>
                <p className="text-xs text-slate-400 font-medium mt-1 leading-relaxed">
                  আপনার কোনো বন্ধুর রেফারেল কোড থাকলে এখানে দিন। কোড যুক্ত করলেই সাথে সাথে পাবেন{' '}
                  <span className="text-yellow-400 font-bold">২,৫০০ ফ্রি কয়েন 🪙</span> এবং{' '}
                  <span className="text-cyan-400 font-bold">১০টি ডায়মন্ড 💎</span>!
                </p>

                {referralState.hasClaimedWelcomeBonus ? (
                  <div className="mt-5 p-4 rounded-2xl bg-emerald-950/40 border border-emerald-500/40 text-emerald-300 text-xs font-black flex items-center justify-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                    <span>আপনি ইতিমধ্যে রেফারেল বোনাস গ্রহণ করেছেন! (কোড: {referralState.referredByCode || 'LUDO-INVITE'})</span>
                  </div>
                ) : (
                  <form onSubmit={handleApplyFriendCode} className="mt-5 space-y-3">
                    <div className="relative">
                      <input
                        type="text"
                        placeholder="যেমন: LUDO-ARIF77"
                        value={friendCodeInput}
                        onChange={(e) => setFriendCodeInput(e.target.value.toUpperCase())}
                        disabled={isClaiming}
                        className="w-full px-4 py-3 bg-slate-950 border border-slate-700 focus:border-amber-400 rounded-2xl text-center text-sm font-mono font-black text-amber-300 placeholder:text-slate-600 focus:outline-none uppercase tracking-wider"
                      />
                    </div>

                    {claimFeedback && (
                      <div
                        className={`p-3 rounded-2xl text-xs font-bold ${
                          claimFeedback.type === 'success'
                            ? 'bg-emerald-950/60 border border-emerald-500 text-emerald-300'
                            : 'bg-rose-950/60 border border-rose-500 text-rose-300'
                        }`}
                      >
                        {claimFeedback.text}
                      </div>
                    )}

                    <button
                      type="submit"
                      disabled={isClaiming || !friendCodeInput.trim()}
                      className="w-full py-3 rounded-2xl bg-gradient-to-r from-amber-500 via-orange-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-sm shadow-md active:scale-98 transition-all disabled:opacity-50 cursor-pointer flex items-center justify-center gap-2"
                    >
                      <Gift className="w-4 h-4" />
                      <span>{isClaiming ? 'যাচাই করা হচ্ছে...' : '২,৫০০ কয়েন ও ১০ ডায়মন্ড ক্লেইম করুন'}</span>
                    </button>
                  </form>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const PlusFriendIcon = () => (
  <svg
    className="w-4 h-4"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2.5"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
    <circle cx="9" cy="7" r="4" />
    <line x1="19" y1="8" x2="19" y2="14" />
    <line x1="22" y1="11" x2="16" y2="11" />
  </svg>
);
