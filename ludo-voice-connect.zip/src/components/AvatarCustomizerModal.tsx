import React, { useState, useRef } from 'react';
import {
  Sparkles,
  Dices,
  Check,
  X,
  Palette,
  Shirt,
  Smile,
  User,
  Camera,
  Upload,
  Image as ImageIcon,
  ZoomIn,
  Trash2,
  Sliders,
  CheckCircle2,
  AlertCircle,
  Layers,
} from 'lucide-react';
import { AvatarConfig } from '../types';
import { AvatarDisplay } from './AvatarDisplay';
import { Sound } from '../utils/soundEffects';

interface AvatarCustomizerModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentAvatar: AvatarConfig;
  onSaveAvatar: (newAvatar: AvatarConfig) => void;
}

const SKIN_TONES = [
  { id: '#fcd34d', label: 'উজ্জ্বল ফর্সা' },
  { id: '#fed7aa', label: 'ফর্সা' },
  { id: '#fbb6ce', label: 'গোলাপি আভা' },
  { id: '#f59e0b', label: 'শ্যামলা' },
  { id: '#d97706', label: 'উজ্জ্বল শ্যামলা' },
  { id: '#78350f', label: 'গাঢ় শ্যামলা' },
];

const HAIR_STYLES: { id: AvatarConfig['hairStyle']; label: string }[] = [
  { id: 'short', label: 'স্মার্ট শর্ট' },
  { id: 'curly', label: 'কোঁকড়ানো' },
  { id: 'wavy', label: 'স্টাইলিশ ওয়েভ' },
  { id: 'crown', label: 'রাজকীয় মুকুট' },
  { id: 'cap', label: 'স্পোর্টস ক্যাপ' },
  { id: 'turban', label: 'পাগড়ি' },
  { id: 'hijab', label: 'হিজাব' },
  { id: 'ponytail', label: 'পনিটেইল' },
];

const HAIR_COLORS = [
  { id: '#1f2937', label: 'কালো' },
  { id: '#78350f', label: 'গাঢ় বাদামী' },
  { id: '#b45309', label: 'সোনালী বাদামী' },
  { id: '#dc2626', label: 'বারগ্যান্ডি রেড' },
  { id: '#4f46e5', label: 'ইন্ডিগো ব্লু' },
  { id: '#9333ea', label: 'রয়্যাল পার্পল' },
];

const EYE_STYLES: { id: AvatarConfig['eyes']; label: string }[] = [
  { id: 'happy', label: 'হাস্যোজ্জ্বল' },
  { id: 'normal', label: 'স্বাভাবিক' },
  { id: 'wink', label: 'উইঙ্ক (ইশারা)' },
  { id: 'cool', label: 'কুল লুক' },
  { id: 'sparkle', label: 'ঝলমলে চোখ' },
];

const MOUTH_STYLES: { id: AvatarConfig['mouth']; label: string }[] = [
  { id: 'smile', label: 'মিষ্টি হাসি' },
  { id: 'laugh', label: 'অট্টহাসি' },
  { id: 'smirk', label: 'মৃদু হাসি' },
  { id: 'open', label: 'উত্তেজিত' },
];

const CLOTHING_STYLES: { id: AvatarConfig['clothing']; label: string }[] = [
  { id: 'punjabi', label: 'ঐতিহ্যবাহী পাঞ্জাবি' },
  { id: 'hoodie', label: 'আধুনিক হুডি' },
  { id: 'tshirt', label: 'ক্যাজুয়াল টি-শার্ট' },
  { id: 'suit', label: 'ফর্মাল স্যুট ও টাই' },
  { id: 'jersey', label: 'লুডু স্টার জার্সি' },
  { id: 'royal_robe', label: 'লুডু রাজকীয় পোশাক' },
];

const CLOTHING_COLORS = [
  { id: '#dc2626', label: 'লাল' },
  { id: '#16a34a', label: 'সবুজ' },
  { id: '#2563eb', label: 'নীল' },
  { id: '#d97706', label: 'হলুদ' },
  { id: '#9333ea', label: 'বেগুনী' },
  { id: '#0f172a', label: 'কালো' },
  { id: '#0891b2', label: 'আসমানী' },
  { id: '#e11d48', label: 'গোলাপি' },
];

const ACCESSORIES: { id: AvatarConfig['accessory']; label: string }[] = [
  { id: 'none', label: 'কোনটি না' },
  { id: 'glasses', label: 'স্টাইলিশ চশমা' },
  { id: 'sunglasses', label: 'কালো সানগ্লাস' },
  { id: 'headphone', label: 'গেমিং হেডফোন' },
  { id: 'mustache', label: 'অভিজাত গোঁফ' },
  { id: 'golden_chain', label: 'স্বর্ণের চেইন' },
];

const BG_GRADIENTS = [
  { id: 'from-amber-400 to-red-500', label: 'রয়্যাল অ্যাম্বার' },
  { id: 'from-blue-500 to-indigo-600', label: 'ওশান ব্লু' },
  { id: 'from-emerald-400 to-teal-600', label: 'এমেরাল্ড গ্রিন' },
  { id: 'from-purple-500 to-pink-500', label: 'ম্যাজেন্টা নিয়ন' },
  { id: 'from-rose-500 to-orange-500', label: 'সানসেট ফায়ার' },
];

const PHOTO_FILTERS: { id: NonNullable<AvatarConfig['photoFilter']>; label: string }[] = [
  { id: 'none', label: 'স্বাভাবিক' },
  { id: 'vivid', label: 'উজ্জ্বল (Vivid)' },
  { id: 'warm', label: 'উষ্ণ রয়্যাল (Warm)' },
  { id: 'cool', label: 'কুল ব্লু (Cool)' },
  { id: 'golden', label: 'স্বর্ণালী (Golden)' },
  { id: 'bw', label: 'ক্লাসিক সাদাকালো' },
];

// High quality curated presets from gallery
const GALLERY_PRESETS = [
  {
    id: 'ludo_king_1',
    name: 'লুডু কিং মাস্টার',
    url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80',
    category: 'প্রো প্লেয়ার',
  },
  {
    id: 'ludo_star_2',
    name: 'দেশি লুডু স্টার',
    url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&auto=format&fit=crop&q=80',
    category: 'রয়্যাল প্লেয়ার',
  },
  {
    id: 'queen_ludo_3',
    name: 'লুডু কুইন গেমার',
    url: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=300&auto=format&fit=crop&q=80',
    category: 'চ্যাম্পিয়ন',
  },
  {
    id: 'stylish_boy_4',
    name: 'স্মার্ট লুডু বয়',
    url: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=300&auto=format&fit=crop&q=80',
    category: 'মাস্টার',
  },
  {
    id: 'gamer_girl_5',
    name: 'সাইবার গেমার গার্ল',
    url: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=300&auto=format&fit=crop&q=80',
    category: 'সাইবার স্টার',
  },
  {
    id: 'champion_boy_6',
    name: 'বিজয়ী চ্যাম্পিয়ন',
    url: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=300&auto=format&fit=crop&q=80',
    category: 'গোল্ডেন প্লেয়ার',
  },
  {
    id: 'royal_master_7',
    name: 'রাজকীয় নবাব',
    url: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=300&auto=format&fit=crop&q=80',
    category: 'নবাবী স্টাইল',
  },
  {
    id: 'desi_queen_8',
    name: 'সোনার মেয়ে',
    url: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=300&auto=format&fit=crop&q=80',
    category: 'লুডু সম্রাজ্ঞী',
  },
];

export const AvatarCustomizerModal: React.FC<AvatarCustomizerModalProps> = ({
  isOpen,
  onClose,
  currentAvatar,
  onSaveAvatar,
}) => {
  const [avatar, setAvatar] = useState<AvatarConfig>(currentAvatar);
  const [activeTab, setActiveTab] = useState<'gallery' | 'face' | 'hair' | 'clothes' | 'accessories'>(
    currentAvatar.avatarType === 'photo' || !!currentAvatar.photoUrl ? 'gallery' : 'gallery'
  );
  const [testSpeaking, setTestSpeaking] = useState<boolean>(false);
  const [isProcessingImage, setIsProcessingImage] = useState<boolean>(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [isDragOver, setIsDragOver] = useState<boolean>(false);

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  if (!isOpen) return null;

  const isPhotoActive = avatar.avatarType === 'photo' || (!!avatar.photoUrl && avatar.avatarType !== 'vector');

  // Process file upload from gallery / device with image resizing
  const handleProcessImageFile = (file: File) => {
    if (!file.type.startsWith('image/')) {
      setUploadError('অনুগ্রহ করে শুধুমাত্র একটি ছবি ফাইল (JPG, PNG, WebP) নির্বাচন করুন।');
      return;
    }

    setUploadError(null);
    setIsProcessingImage(true);

    const reader = new FileReader();
    reader.onload = (e) => {
      const rawDataUrl = e.target?.result as string;
      const img = new Image();
      img.onload = () => {
        // Downscale image to max 512x512 with canvas to keep size lean for storage & speed
        const maxDim = 512;
        let width = img.width;
        let height = img.height;

        if (width > maxDim || height > maxDim) {
          if (width > height) {
            height = Math.round((height * maxDim) / width);
            width = maxDim;
          } else {
            width = Math.round((width * maxDim) / height);
            height = maxDim;
          }
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          const optimizedDataUrl = canvas.toDataURL('image/jpeg', 0.88);
          setAvatar((prev) => ({
            ...prev,
            avatarType: 'photo',
            photoUrl: optimizedDataUrl,
            photoScale: prev.photoScale || 1,
            photoFilter: prev.photoFilter || 'none',
          }));
        } else {
          setAvatar((prev) => ({
            ...prev,
            avatarType: 'photo',
            photoUrl: rawDataUrl,
            photoScale: prev.photoScale || 1,
            photoFilter: prev.photoFilter || 'none',
          }));
        }
        Sound.playCoinSound();
        setIsProcessingImage(false);
      };
      img.onerror = () => {
        setUploadError('ছবি লোড করতে সমস্যা হয়েছে। অন্য ছবি চেষ্টা করুন।');
        setIsProcessingImage(false);
      };
      img.src = rawDataUrl;
    };
    reader.onerror = () => {
      setUploadError('ফাইল পড়তে ব্যর্থ হয়েছে।');
      setIsProcessingImage(false);
    };
    reader.readAsDataURL(file);
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleProcessImageFile(file);
    }
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragOver(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      handleProcessImageFile(file);
    }
  };

  const handleSelectPreset = (url: string) => {
    Sound.playClick();
    setAvatar((prev) => ({
      ...prev,
      avatarType: 'photo',
      photoUrl: url,
      photoScale: 1,
      photoFilter: prev.photoFilter || 'none',
    }));
  };

  const handleRemovePhoto = () => {
    Sound.playClick();
    setAvatar((prev) => ({
      ...prev,
      avatarType: 'vector',
      photoUrl: undefined,
    }));
  };

  const handleSwitchToVector = () => {
    Sound.playClick();
    setAvatar((prev) => ({
      ...prev,
      avatarType: 'vector',
    }));
  };

  const handleSwitchToPhoto = () => {
    Sound.playClick();
    if (!avatar.photoUrl) {
      // If no photo yet, trigger file input directly
      fileInputRef.current?.click();
    } else {
      setAvatar((prev) => ({
        ...prev,
        avatarType: 'photo',
      }));
    }
  };

  const handleRandomize = () => {
    Sound.playDiceRoll();
    const randomSkin = SKIN_TONES[Math.floor(Math.random() * SKIN_TONES.length)].id;
    const randomHair = HAIR_STYLES[Math.floor(Math.random() * HAIR_STYLES.length)].id;
    const randomHairColor = HAIR_COLORS[Math.floor(Math.random() * HAIR_COLORS.length)].id;
    const randomEyes = EYE_STYLES[Math.floor(Math.random() * EYE_STYLES.length)].id;
    const randomMouth = MOUTH_STYLES[Math.floor(Math.random() * MOUTH_STYLES.length)].id;
    const randomCloth = CLOTHING_STYLES[Math.floor(Math.random() * CLOTHING_STYLES.length)].id;
    const randomClothColor = CLOTHING_COLORS[Math.floor(Math.random() * CLOTHING_COLORS.length)].id;
    const randomAccessory = ACCESSORIES[Math.floor(Math.random() * ACCESSORIES.length)].id;
    const randomBg = BG_GRADIENTS[Math.floor(Math.random() * BG_GRADIENTS.length)].id;

    setAvatar((prev) => ({
      ...prev,
      avatarType: 'vector',
      skinColor: randomSkin,
      hairStyle: randomHair,
      hairColor: randomHairColor,
      eyes: randomEyes,
      mouth: randomMouth,
      clothing: randomCloth,
      clothingColor: randomClothColor,
      accessory: randomAccessory,
      bgGradient: randomBg,
    }));
  };

  const handleSave = () => {
    Sound.playWin();
    onSaveAvatar(avatar);
    onClose();
  };

  return (
    <div
      id="avatar-customizer-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-sm animate-fade-in"
    >
      <div className="relative w-full max-w-xl bg-amber-50 rounded-3xl shadow-2xl border-4 border-amber-200 overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-5 sm:px-6 py-3.5 bg-white border-b-4 border-amber-200">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-tr from-amber-500 to-rose-500 rounded-2xl flex items-center justify-center text-white text-xl shadow-md border-b-2 border-amber-700">
              <Camera className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-black text-amber-950 tracking-tight flex items-center gap-2">
                <span>প্রোফাইল ফটো ও অবতার স্টুডিও</span>
              </h2>
              <p className="text-xs text-amber-700 font-medium">
                গ্যালারি থেকে আপনার আসল ছবি আপলোড করুন অথবা কার্টুন অবতার সাজান
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          {/* Avatar Preview Card with Interactive Camera Button */}
          <div className="bg-white rounded-3xl p-4 shadow-md border-2 border-amber-200 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              {/* Interactive Avatar Frame with Tap-to-Upload Camera Button */}
              <div className="relative group">
                <AvatarDisplay
                  avatar={avatar}
                  size={96}
                  isSpeaking={testSpeaking}
                  showBadge={true}
                  badgeText="আপনি"
                />

                {/* Floating Camera Button on Avatar */}
                <button
                  type="button"
                  id="avatar-quick-upload-camera-btn"
                  onClick={() => fileInputRef.current?.click()}
                  title="গ্যালারি থেকে ফটো বাছাই করুন"
                  className="absolute bottom-0 right-0 w-8 h-8 rounded-full bg-amber-500 hover:bg-amber-600 text-white border-2 border-white shadow-lg flex items-center justify-center transition-all group-hover:scale-110 active:scale-95 cursor-pointer"
                >
                  <Camera className="w-4 h-4" />
                </button>
              </div>

              <div className="flex flex-col">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-black text-amber-950">লাইভ প্রিভিউ</span>
                  {isPhotoActive ? (
                    <span className="bg-purple-100 text-purple-900 border border-purple-300 text-[10px] font-black px-2 py-0.5 rounded-full flex items-center gap-1">
                      <ImageIcon className="w-3 h-3" />
                      গ্যালারি ফটো
                    </span>
                  ) : (
                    <span className="bg-amber-100 text-amber-900 border border-amber-300 text-[10px] font-black px-2 py-0.5 rounded-full flex items-center gap-1">
                      <Palette className="w-3 h-3" />
                      কার্টুন অবতার
                    </span>
                  )}
                </div>

                <span className="text-xs text-slate-500 mt-0.5">
                  {isPhotoActive
                    ? 'আপনার গ্যালারি ছবি সক্রিয় রয়েছে'
                    : avatar.clothing === 'punjabi'
                    ? 'পাঞ্জাবি পরিহিত কার্টুন'
                    : avatar.clothing === 'royal_robe'
                    ? 'রাজকীয় পোশাকে'
                    : avatar.clothing === 'jersey'
                    ? 'জার্সি পরিহিত'
                    : 'স্টাইলিশ লুকে'}
                </span>

                <div className="flex items-center gap-2 mt-2">
                  <button
                    type="button"
                    onClick={() => setTestSpeaking(!testSpeaking)}
                    className={`px-2.5 py-1 rounded-xl text-xs font-bold border flex items-center gap-1.5 transition-all cursor-pointer ${
                      testSpeaking
                        ? 'bg-emerald-500 text-white border-emerald-600 shadow-sm'
                        : 'bg-slate-100 text-slate-700 border-slate-300 hover:bg-slate-200'
                    }`}
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>{testSpeaking ? 'কথা বলছেন' : 'ভয়েস টেস্ট'}</span>
                  </button>

                  {/* Mode switcher button */}
                  {isPhotoActive ? (
                    <button
                      type="button"
                      onClick={handleSwitchToVector}
                      className="px-2.5 py-1 rounded-xl text-xs font-bold bg-amber-100 text-amber-900 border border-amber-300 hover:bg-amber-200 transition-all cursor-pointer"
                    >
                      কার্টুনে ফিরুন
                    </button>
                  ) : avatar.photoUrl ? (
                    <button
                      type="button"
                      onClick={handleSwitchToPhoto}
                      className="px-2.5 py-1 rounded-xl text-xs font-bold bg-purple-100 text-purple-900 border border-purple-300 hover:bg-purple-200 transition-all cursor-pointer"
                    >
                      ছবিতে ফিরুন
                    </button>
                  ) : null}
                </div>
              </div>
            </div>

            {/* Quick Randomize or File Select */}
            <div className="flex flex-col gap-1.5 w-full sm:w-auto">
              <button
                type="button"
                id="gallery-pick-photo-action-btn"
                onClick={() => fileInputRef.current?.click()}
                className="px-4 py-2 rounded-2xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-black text-xs flex items-center justify-center gap-2 transition-all active:scale-95 shadow-sm cursor-pointer"
              >
                <Upload className="w-4 h-4 text-yellow-300" />
                <span>গ্যালারি থেকে ফটো দিন</span>
              </button>

              <button
                type="button"
                onClick={handleRandomize}
                className="px-4 py-1.5 rounded-2xl bg-amber-100 hover:bg-amber-200 text-amber-900 border border-amber-300 font-bold text-xs flex items-center justify-center gap-1.5 transition-all active:scale-95 cursor-pointer"
              >
                <Dices className="w-3.5 h-3.5 text-amber-700" />
                <span>এলোমেলো কার্টুন</span>
              </button>
            </div>
          </div>

          {/* Hidden File Input for Gallery Photo Selection */}
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileInputChange}
            accept="image/png,image/jpeg,image/jpg,image/webp,image/gif"
            className="hidden"
          />

          {/* Customization Tabs */}
          <div className="flex items-center gap-1 bg-amber-100/70 p-1.5 rounded-2xl border border-amber-200 overflow-x-auto">
            <button
              id="tab-gallery-photo"
              onClick={() => setActiveTab('gallery')}
              className={`flex-1 min-w-[100px] py-2 px-2 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                activeTab === 'gallery'
                  ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-md'
                  : 'text-purple-900 hover:bg-white/50'
              }`}
            >
              <Camera className="w-4 h-4" />
              <span>গ্যালারি ফটো</span>
              <span className="bg-amber-400 text-slate-950 text-[9px] font-black px-1.5 py-0.2 rounded-full">
                HOT
              </span>
            </button>
            <button
              onClick={() => setActiveTab('face')}
              className={`flex-1 min-w-[80px] py-2 px-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                activeTab === 'face'
                  ? 'bg-white text-amber-950 shadow-sm border border-amber-200'
                  : 'text-amber-800 hover:bg-white/50'
              }`}
            >
              <Smile className="w-4 h-4" />
              <span>চেহারা</span>
            </button>
            <button
              onClick={() => setActiveTab('hair')}
              className={`flex-1 min-w-[80px] py-2 px-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                activeTab === 'hair'
                  ? 'bg-white text-amber-950 shadow-sm border border-amber-200'
                  : 'text-amber-800 hover:bg-white/50'
              }`}
            >
              <User className="w-4 h-4" />
              <span>চুল</span>
            </button>
            <button
              onClick={() => setActiveTab('clothes')}
              className={`flex-1 min-w-[80px] py-2 px-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                activeTab === 'clothes'
                  ? 'bg-white text-amber-950 shadow-sm border border-amber-200'
                  : 'text-amber-800 hover:bg-white/50'
              }`}
            >
              <Shirt className="w-4 h-4" />
              <span>পোশাক</span>
            </button>
            <button
              onClick={() => setActiveTab('accessories')}
              className={`flex-1 min-w-[90px] py-2 px-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                activeTab === 'accessories'
                  ? 'bg-white text-amber-950 shadow-sm border border-amber-200'
                  : 'text-amber-800 hover:bg-white/50'
              }`}
            >
              <Palette className="w-4 h-4" />
              <span>অ্যাক্সেসরিজ</span>
            </button>
          </div>

          {/* TAB 0: GALLERY PHOTO UPLOAD & ADJUSTMENTS */}
          {activeTab === 'gallery' && (
            <div className="space-y-4 bg-white p-4 sm:p-5 rounded-3xl border-2 border-purple-200 shadow-sm">
              {/* Drag & Drop Upload Zone */}
              <div
                onDragOver={(e) => {
                  e.preventDefault();
                  setIsDragOver(true);
                }}
                onDragLeave={() => setIsDragOver(false)}
                onDrop={handleDrop}
                onClick={() => fileInputRef.current?.click()}
                className={`relative border-2 border-dashed rounded-3xl p-6 text-center transition-all cursor-pointer ${
                  isDragOver
                    ? 'border-purple-600 bg-purple-50 scale-102'
                    : 'border-purple-300 hover:border-purple-500 bg-gradient-to-b from-purple-50/50 to-indigo-50/30'
                }`}
              >
                <div className="flex flex-col items-center justify-center gap-2">
                  <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-purple-600 to-indigo-600 flex items-center justify-center text-white shadow-md">
                    <Upload className="w-7 h-7 text-yellow-300 animate-bounce" />
                  </div>
                  <div>
                    <h4 className="text-sm font-black text-purple-950">
                      গ্যালারি থেকে ফটো আপলোড করুন
                    </h4>
                    <p className="text-xs text-slate-500 mt-0.5">
                      ছবি এখানে ড্র্যাগ করুন অথবা ক্লিক করে ফাইল বেছে নিন (JPG, PNG, WebP)
                    </p>
                  </div>
                  <span className="inline-block mt-1 px-4 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs shadow-sm">
                    গ্যালারি ওপেন করুন 📂
                  </span>
                </div>

                {isProcessingImage && (
                  <div className="absolute inset-0 bg-white/90 backdrop-blur-xs rounded-3xl flex items-center justify-center">
                    <div className="flex items-center gap-2 text-purple-900 font-black text-xs animate-pulse">
                      <Sparkles className="w-4 h-4 text-purple-600 animate-spin" />
                      <span>ছবি প্রসেস হচ্ছে...</span>
                    </div>
                  </div>
                )}
              </div>

              {uploadError && (
                <div className="p-3 rounded-2xl bg-red-50 border border-red-200 flex items-center gap-2 text-xs text-red-700 font-bold">
                  <AlertCircle className="w-4 h-4 text-red-500 shrink-0" />
                  <span>{uploadError}</span>
                </div>
              )}

              {/* Photo Controls if photo is active */}
              {avatar.photoUrl && (
                <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-slate-800 flex items-center gap-1.5">
                      <Sliders className="w-4 h-4 text-purple-600" />
                      ফটো জুম ও অ্যাডজাস্টমেন্ট
                    </span>
                    <button
                      type="button"
                      onClick={handleRemovePhoto}
                      className="text-xs font-bold text-red-600 hover:text-red-700 flex items-center gap-1 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      ছবি ডিলিট করুন
                    </button>
                  </div>

                  {/* Zoom Slider */}
                  <div className="flex items-center gap-3">
                    <ZoomIn className="w-4 h-4 text-slate-500" />
                    <span className="text-xs font-bold text-slate-600 min-w-[40px]">জুম:</span>
                    <input
                      type="range"
                      min="0.8"
                      max="1.8"
                      step="0.05"
                      value={avatar.photoScale || 1}
                      onChange={(e) =>
                        setAvatar((prev) => ({
                          ...prev,
                          photoScale: parseFloat(e.target.value),
                        }))
                      }
                      className="flex-1 accent-purple-600 cursor-pointer"
                    />
                    <span className="text-xs font-bold text-purple-900 min-w-[42px] text-right">
                      {Math.round((avatar.photoScale || 1) * 100)}%
                    </span>
                  </div>

                  {/* Photo Filter selector */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1.5">
                      কালার ইফেক্ট ফিল্টার:
                    </label>
                    <div className="grid grid-cols-3 sm:grid-cols-6 gap-1.5">
                      {PHOTO_FILTERS.map((f) => (
                        <button
                          key={f.id}
                          type="button"
                          onClick={() =>
                            setAvatar((prev) => ({
                              ...prev,
                              photoFilter: f.id,
                            }))
                          }
                          className={`px-2 py-1.5 rounded-xl text-[11px] font-bold border transition-all text-center cursor-pointer ${
                            (avatar.photoFilter || 'none') === f.id
                              ? 'bg-purple-600 text-white border-purple-700 shadow-sm'
                              : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                          }`}
                        >
                          {f.label}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* Background Frame Gradient */}
              <div>
                <label className="block text-xs font-black text-amber-950 mb-2">
                  ফ্রেম বর্ডার রিং ব্যাকগ্রাউন্ড:
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                  {BG_GRADIENTS.map((bg) => (
                    <button
                      key={bg.id}
                      onClick={() => setAvatar({ ...avatar, bgGradient: bg.id })}
                      className={`p-2 rounded-2xl border-2 flex items-center gap-2 transition-all cursor-pointer ${
                        avatar.bgGradient === bg.id
                          ? 'border-purple-600 bg-purple-50 shadow-sm'
                          : 'border-slate-200 hover:border-amber-300'
                      }`}
                    >
                      <span className={`w-5 h-5 rounded-full bg-gradient-to-tr ${bg.id} shrink-0`} />
                      <span className="text-[11px] font-bold text-slate-700 truncate">{bg.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Popular Curated Gallery Avatars Presets */}
              <div className="pt-2 border-t border-slate-200">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-black text-slate-800 flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-amber-500" />
                    রেডিমেড গ্যালারি প্রোফাইল সম্ভার (এক-ক্লিকে সিলেক্ট করুন)
                  </span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  {GALLERY_PRESETS.map((item) => {
                    const isSelected = avatar.photoUrl === item.url && isPhotoActive;
                    return (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => handleSelectPreset(item.url)}
                        className={`flex items-center gap-2 p-2 rounded-2xl border-2 transition-all text-left cursor-pointer group ${
                          isSelected
                            ? 'border-purple-600 bg-purple-50 shadow-md ring-2 ring-purple-300'
                            : 'border-slate-200 hover:border-purple-300 bg-white'
                        }`}
                      >
                        <div className="relative w-10 h-10 rounded-full overflow-hidden shrink-0 border border-slate-300 group-hover:scale-105 transition-transform">
                          <img
                            src={item.url}
                            alt={item.name}
                            referrerPolicy="no-referrer"
                            className="w-full h-full object-cover"
                          />
                          {isSelected && (
                            <div className="absolute inset-0 bg-purple-600/50 flex items-center justify-center text-white">
                              <CheckCircle2 className="w-4 h-4" />
                            </div>
                          )}
                        </div>
                        <div className="flex flex-col min-w-0">
                          <span className="text-xs font-black text-slate-900 truncate">
                            {item.name}
                          </span>
                          <span className="text-[10px] text-slate-500 font-bold">
                            {item.category}
                          </span>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* TAB 1: FACE & SKIN */}
          {activeTab === 'face' && (
            <div className="space-y-4 bg-white p-4 rounded-3xl border-2 border-amber-200 shadow-sm">
              {/* Skin Tone */}
              <div>
                <label className="block text-xs font-black text-amber-950 mb-2">
                  গায়ের রঙ (Skin Tone):
                </label>
                <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
                  {SKIN_TONES.map((tone) => (
                    <button
                      key={tone.id}
                      onClick={() => setAvatar({ ...avatar, skinColor: tone.id, avatarType: 'vector' })}
                      className={`flex flex-col items-center gap-1 p-2 rounded-2xl border-2 transition-all cursor-pointer ${
                        avatar.skinColor === tone.id && !isPhotoActive
                          ? 'border-amber-600 bg-amber-50 shadow-sm scale-105'
                          : 'border-slate-200 hover:border-amber-300'
                      }`}
                    >
                      <span
                        className="w-7 h-7 rounded-full shadow-inner border border-black/10"
                        style={{ backgroundColor: tone.id }}
                      />
                      <span className="text-[10px] font-bold text-slate-700">{tone.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Eyes Expression */}
              <div>
                <label className="block text-xs font-black text-amber-950 mb-2">
                  চোখের ভাব (Eye Expression):
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {EYE_STYLES.map((eye) => (
                    <button
                      key={eye.id}
                      onClick={() => setAvatar({ ...avatar, eyes: eye.id, avatarType: 'vector' })}
                      className={`px-3 py-2 rounded-xl text-xs font-bold border text-left transition-all cursor-pointer ${
                        avatar.eyes === eye.id && !isPhotoActive
                          ? 'bg-amber-100 border-amber-500 text-amber-950 shadow-sm'
                          : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      {eye.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Mouth Style */}
              <div>
                <label className="block text-xs font-black text-amber-950 mb-2">
                  মুখের অভিব্যক্তি (Mouth Expression):
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {MOUTH_STYLES.map((m) => (
                    <button
                      key={m.id}
                      onClick={() => setAvatar({ ...avatar, mouth: m.id, avatarType: 'vector' })}
                      className={`px-3 py-2 rounded-xl text-xs font-bold border text-center transition-all cursor-pointer ${
                        avatar.mouth === m.id && !isPhotoActive
                          ? 'bg-amber-100 border-amber-500 text-amber-950 shadow-sm'
                          : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      {m.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: HAIR & HEADWEAR */}
          {activeTab === 'hair' && (
            <div className="space-y-4 bg-white p-4 rounded-3xl border-2 border-amber-200 shadow-sm">
              {/* Hair Style */}
              <div>
                <label className="block text-xs font-black text-amber-950 mb-2">
                  চুলের স্টাইল ও হেডওয়্যার:
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {HAIR_STYLES.map((h) => (
                    <button
                      key={h.id}
                      onClick={() => setAvatar({ ...avatar, hairStyle: h.id, avatarType: 'vector' })}
                      className={`px-3 py-2.5 rounded-xl text-xs font-bold border text-left transition-all cursor-pointer ${
                        avatar.hairStyle === h.id && !isPhotoActive
                          ? 'bg-amber-100 border-amber-500 text-amber-950 shadow-sm scale-105'
                          : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      {h.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Hair Color */}
              <div>
                <label className="block text-xs font-black text-amber-950 mb-2">
                  চুলের রঙ (Hair Color):
                </label>
                <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
                  {HAIR_COLORS.map((c) => (
                    <button
                      key={c.id}
                      onClick={() => setAvatar({ ...avatar, hairColor: c.id, avatarType: 'vector' })}
                      className={`flex flex-col items-center gap-1 p-2 rounded-2xl border-2 transition-all cursor-pointer ${
                        avatar.hairColor === c.id && !isPhotoActive
                          ? 'border-amber-600 bg-amber-50 shadow-sm'
                          : 'border-slate-200 hover:border-amber-300'
                      }`}
                    >
                      <span
                        className="w-7 h-7 rounded-full shadow-inner border border-black/10"
                        style={{ backgroundColor: c.id }}
                      />
                      <span className="text-[10px] font-bold text-slate-700">{c.label}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: CLOTHES */}
          {activeTab === 'clothes' && (
            <div className="space-y-4 bg-white p-4 rounded-3xl border-2 border-amber-200 shadow-sm">
              {/* Clothing Style */}
              <div>
                <label className="block text-xs font-black text-amber-950 mb-2">
                  পোশাকের ধরন (Clothing Style):
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {CLOTHING_STYLES.map((cloth) => (
                    <button
                      key={cloth.id}
                      onClick={() => setAvatar({ ...avatar, clothing: cloth.id, avatarType: 'vector' })}
                      className={`px-3 py-2.5 rounded-xl text-xs font-bold border text-left transition-all cursor-pointer ${
                        avatar.clothing === cloth.id && !isPhotoActive
                          ? 'bg-amber-100 border-amber-500 text-amber-950 shadow-sm scale-105'
                          : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      {cloth.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Clothing Color */}
              <div>
                <label className="block text-xs font-black text-amber-950 mb-2">
                  পোশাকের রঙ:
                </label>
                <div className="grid grid-cols-4 sm:grid-cols-8 gap-2">
                  {CLOTHING_COLORS.map((cc) => (
                    <button
                      key={cc.id}
                      onClick={() => setAvatar({ ...avatar, clothingColor: cc.id, avatarType: 'vector' })}
                      className={`flex flex-col items-center gap-1 p-2 rounded-2xl border-2 transition-all cursor-pointer ${
                        avatar.clothingColor === cc.id && !isPhotoActive
                          ? 'border-amber-600 bg-amber-50 shadow-sm'
                          : 'border-slate-200 hover:border-amber-300'
                      }`}
                    >
                      <span
                        className="w-6 h-6 rounded-full shadow-inner border border-black/10"
                        style={{ backgroundColor: cc.id }}
                      />
                      <span className="text-[10px] font-bold text-slate-700">{cc.label}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: ACCESSORIES & FRAME */}
          {activeTab === 'accessories' && (
            <div className="space-y-4 bg-white p-4 rounded-3xl border-2 border-amber-200 shadow-sm">
              {/* Accessories */}
              <div>
                <label className="block text-xs font-black text-amber-950 mb-2">
                  স্টাইলিশ অ্যাক্সেসরিজ (Accessories):
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {ACCESSORIES.map((acc) => (
                    <button
                      key={acc.id}
                      onClick={() => setAvatar({ ...avatar, accessory: acc.id, avatarType: 'vector' })}
                      className={`px-3 py-2.5 rounded-xl text-xs font-bold border text-left transition-all cursor-pointer ${
                        avatar.accessory === acc.id && !isPhotoActive
                          ? 'bg-amber-100 border-amber-500 text-amber-950 shadow-sm scale-105'
                          : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      {acc.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Background Frame Gradient */}
              <div>
                <label className="block text-xs font-black text-amber-950 mb-2">
                  অবতার ফ্রেম ব্যাকগ্রাউন্ড:
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {BG_GRADIENTS.map((bg) => (
                    <button
                      key={bg.id}
                      onClick={() => setAvatar({ ...avatar, bgGradient: bg.id })}
                      className={`p-2 rounded-2xl border-2 flex items-center gap-2 transition-all cursor-pointer ${
                        avatar.bgGradient === bg.id
                          ? 'border-amber-600 bg-amber-50 shadow-sm'
                          : 'border-slate-200 hover:border-amber-300'
                      }`}
                    >
                      <span className={`w-5 h-5 rounded-full bg-gradient-to-tr ${bg.id}`} />
                      <span className="text-[11px] font-bold text-slate-700">{bg.label}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="px-5 sm:px-6 py-3.5 bg-white border-t-4 border-amber-200 flex items-center justify-between">
          <button
            onClick={onClose}
            className="px-4 sm:px-5 py-2.5 rounded-2xl border-2 border-slate-300 text-slate-700 font-bold text-xs sm:text-sm hover:bg-slate-100 transition-colors cursor-pointer"
          >
            বাতিল
          </button>
          <button
            id="save-avatar-btn"
            onClick={handleSave}
            className="px-5 sm:px-6 py-2.5 rounded-2xl bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 text-white font-black text-xs sm:text-sm shadow-md border-b-4 border-emerald-800 flex items-center gap-2 active:scale-95 transition-all cursor-pointer"
          >
            <Check className="w-4 h-4" />
            <span>প্রোফাইল ফটো ও অবতার সংরক্ষণ করুন</span>
          </button>
        </div>
      </div>
    </div>
  );
};
