import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  User,
  Mail,
  Phone,
  Lock,
  Eye,
  EyeOff,
  ShieldCheck,
  Smartphone,
  KeyRound,
  ArrowRight,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  LogOut,
  Coins,
  Gem,
  Award,
  RefreshCw,
  Copy,
  Check,
  Shield,
  Layers,
  Globe,
  UserPlus,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { UserProfile, AuthModalView, AuthProvider } from '../types';
import {
  loadUserProfile,
  detectBdOperator,
  evaluatePasswordStrength,
  sendOtpService,
  verifyOtpService,
  registerWithEmailPassword,
  loginWithEmailPassword,
  loginWithGoogleService,
  loginWithFacebookService,
  loginWithWhatsAppService,
  resetPasswordWithOtpService,
  changeUserPasswordService,
  logoutUserService,
  getActiveOtp,
  ActiveOtpSession,
} from '../utils/authService';
import { Sound } from '../utils/soundEffects';
import { CountryPicker } from './CountryPicker';
import { CountryInfo, COUNTRIES_195, detectCountryFromPhoneInput, formatInternationalPhone } from '../utils/countryData';
import { detectReferralCodeFromUrl, applyReferralCodeService } from '../utils/referralService';
import { saveUserAgeConfig, buildDefaultAgeConfig, loadUserAgeConfig } from '../utils/ageLimitService';
import { Gift, Clock } from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile;
  onUserUpdated: (user: UserProfile, isNewRegistration?: boolean) => void;
  initialView?: AuthModalView;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onUserUpdated,
  initialView = 'login',
}) => {
  const [view, setView] = useState<AuthModalView>(initialView);

  // Country Selection for 195 Countries
  const [selectedCountry, setSelectedCountry] = useState<CountryInfo>(COUNTRIES_195[0]);

  // Form states
  const [name, setName] = useState('');
  const [emailOrPhone, setEmailOrPhone] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [oldPassword, setOldPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [showOldPassword, setShowOldPassword] = useState(false);
  const [referralCodeInput, setReferralCodeInput] = useState(() => detectReferralCodeFromUrl() || '');
  const [regAgeCategory, setRegAgeCategory] = useState<'adult_18_plus' | 'teen_13_17' | 'under_13'>('adult_18_plus');

  // Phone OTP specific
  const [phoneNumber, setPhoneNumber] = useState('');
  const [otpDigits, setOtpDigits] = useState<string[]>(['', '', '', '', '', '']);
  const [otpCountdown, setOtpCountdown] = useState<number>(0);
  const [activeOtpInfo, setActiveOtpInfo] = useState<ActiveOtpSession | null>(null);
  const [copiedOtp, setCopiedOtp] = useState(false);

  // Social Verified Access States
  const [fbAccessName, setFbAccessName] = useState(currentUser.name !== 'গেস্ট খেলোয়াড়' ? currentUser.name : 'Joy Sarker');
  const [fbAccessEmail, setFbAccessEmail] = useState(currentUser.email || 'joy.saker.fb@facebook.com');
  const [fbAccessAgree, setFbAccessAgree] = useState(true);

  // Google Accounts (Matching User Device & Video)
  const [googleAccounts, setGoogleAccounts] = useState([
    {
      name: 'Joy Sarker',
      email: 'joysaker5@gmail.com',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=JoySarker5',
      color: 'bg-purple-700',
      initial: 'J',
    },
    {
      name: 'Joy Sarker',
      email: 'joysaker777@gmail.com',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=JoySarker777',
      color: 'bg-emerald-700',
      initial: 'J',
    },
    {
      name: 'Joy Sarker',
      email: 'joy495894@gmail.com',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=JoySarker495',
      color: 'bg-indigo-700',
      initial: 'J',
    },
  ]);
  const [showAddGoogleAccount, setShowAddGoogleAccount] = useState(false);
  const [newGoogleName, setNewGoogleName] = useState('');
  const [newGoogleEmail, setNewGoogleEmail] = useState('');

  const [googleAccessName, setGoogleAccessName] = useState(currentUser.name !== 'গেস্ট খেলোয়াড়' ? currentUser.name : 'Joy Sarker');
  const [googleAccessEmail, setGoogleAccessEmail] = useState(currentUser.email || 'joysaker5@gmail.com');
  const [googleAccessAgree, setGoogleAccessAgree] = useState(true);

  // WhatsApp Access State
  const [whatsAppPhone, setWhatsAppPhone] = useState('+8801712345678');
  const [whatsAppName, setWhatsAppName] = useState('Joy Sarker');

  // Video UI Simulation: "Logging in..." loader overlay & "Login Successful" toast
  const [isLoggingInOverlay, setIsLoggingInOverlay] = useState(false);
  const [loginSuccessToast, setLoginSuccessToast] = useState<string | null>(null);

  // Login View mode: 'quick_social' (Facebook, Google, WhatsApp prominent) or 'form' (password & inputs)
  const [loginMode, setLoginMode] = useState<'quick_social' | 'form'>('quick_social');

  // Status & Feedback
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Refs for 6-box OTP input
  const otpInputRefs = useRef<(HTMLInputElement | null)[]>([]);

  // Sync initial view when opened
  useEffect(() => {
    if (isOpen) {
      if (currentUser.provider !== 'guest' && initialView === 'login') {
        setView('profile');
      } else {
        setView(initialView);
      }
      setErrorMessage(null);
      setSuccessMessage(null);
    }
  }, [isOpen, initialView, currentUser.provider]);

  // Countdown timer for OTP
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (otpCountdown > 0) {
      timer = setInterval(() => {
        setOtpCountdown((prev) => prev - 1);
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [otpCountdown]);

  // Check active OTP in session
  useEffect(() => {
    if (view === 'phone_otp' || view === 'reset_password') {
      const active = getActiveOtp();
      setActiveOtpInfo(active);
    }
  }, [view, otpCountdown]);

  if (!isOpen) return null;

  const passwordStrength = evaluatePasswordStrength(password);
  const detectedOperator = detectBdOperator(phoneNumber || emailOrPhone);

  const triggerCelebration = () => {
    try {
      confetti({
        particleCount: 70,
        spread: 60,
        origin: { y: 0.6 },
      });
    } catch {}
  };

  // 1. Handle Email/Phone + Password Login with Mandatory OTP enforcement
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!emailOrPhone.trim() || !password) {
      setErrorMessage('ইমেইল/ফোন নাম্বার এবং পাসওয়ার্ড দিন।');
      Sound.playAlert();
      return;
    }

    setIsLoading(true);
    setErrorMessage(null);
    setSuccessMessage(null);

    try {
      // If user typed a numeric phone without dial code, combine with selected country
      let loginIdentifier = emailOrPhone.trim();
      const isEmail = loginIdentifier.includes('@');
      if (!isEmail && !loginIdentifier.startsWith('+') && selectedCountry.code !== 'BD') {
        loginIdentifier = `${selectedCountry.dialCode} ${loginIdentifier.replace(/[\s-+]/g, '')}`;
      }

      // First check credential validity
      const res = await loginWithEmailPassword(loginIdentifier, password);
      if (res.success) {
        // Enforce mandatory OTP verification step for account security
        setPhoneNumber(loginIdentifier);
        const otpRes = await sendOtpService(loginIdentifier, 'login', res.user?.name, password);
        if (otpRes.success) {
          Sound.playOtpBeep();
          setOtpCountdown(60);
          setActiveOtpInfo(getActiveOtp());
          setSuccessMessage(`নিরাপত্তার জন্য ওটিপি (OTP) কোড দেওয়া বাধ্যতামূলক। ৬ ডিজিটের কোড পাঠানো হয়েছে! (${otpRes.otp})`);
          setView('phone_otp');
        } else {
          // If already verified or fallback
          Sound.playAuthSuccess();
          triggerCelebration();
          setSuccessMessage('লগইন সফল হয়েছে!');
          if (res.user) onUserUpdated(res.user, false);
          setTimeout(() => {
            onClose();
          }, 1200);
        }
      } else {
        setErrorMessage(res.message);
        Sound.playAlert();
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'লগইন করতে সমস্যা হয়েছে!');
      Sound.playAlert();
    } finally {
      setIsLoading(false);
    }
  };

  // 2. Handle Registration - strictly enforces mandatory OTP / Email verification
  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setErrorMessage('আপনার নাম লিখুন।');
      Sound.playAlert();
      return;
    }
    if (!emailOrPhone.trim()) {
      setErrorMessage('ইমেইল অথবা মোবাইল নাম্বার দিন।');
      Sound.playAlert();
      return;
    }
    if (password.length < 6) {
      setErrorMessage('পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।');
      Sound.playAlert();
      return;
    }
    if (password !== confirmPassword) {
      setErrorMessage('দুইটি পাসওয়ার্ড মিলছে না! পুনরায় চেক করুন।');
      Sound.playAlert();
      return;
    }

    setIsLoading(true);
    setErrorMessage(null);
    setSuccessMessage(null);

    try {
      const rawInput = emailOrPhone.trim();
      const isEmail = rawInput.includes('@');
      let phone: string | undefined = undefined;
      let email = isEmail ? rawInput : '';

      if (!isEmail) {
        // International formatted phone
        if (rawInput.startsWith('+')) {
          phone = rawInput;
        } else {
          phone = `${selectedCountry.dialCode} ${rawInput.replace(/[\s-+]/g, '')}`;
        }
        email = `${phone.replace(/[\s-+]/g, '')}@ludolive.app`;
      }

      const target = isEmail ? email : (phone || rawInput);
      setPhoneNumber(target);

      // Trigger mandatory OTP verification before creating the ID!
      const otpRes = await sendOtpService(
        target,
        'register',
        name.trim(),
        password,
        regAgeCategory,
        referralCodeInput.trim(),
        phone,
        email
      );

      if (otpRes.success) {
        Sound.playOtpBeep();
        setOtpCountdown(60);
        setActiveOtpInfo(getActiveOtp());
        setSuccessMessage(`নিবন্ধন যাচাই করতে ${target} এ ৬ ডিজিটের ওটিপি ভেরিফিকেশন কোড পাঠানো হয়েছে! (${otpRes.otp})`);
        setView('phone_otp');
      } else {
        setErrorMessage(otpRes.message || 'ভেরিফিকেশন কোড পাঠানো যায়নি।');
        Sound.playAlert();
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'নিবন্ধন প্রক্রিয়া শুরু করতে সমস্যা হয়েছে!');
      Sound.playAlert();
    } finally {
      setIsLoading(false);
    }
  };

  // 3. Handle Send OTP (for Phone login or Registration across 195 countries)
  const handleSendPhoneOtp = async (purpose: 'login' | 'register' | 'forgot_password' = 'login') => {
    const rawTarget = (phoneNumber || emailOrPhone).trim();
    if (!rawTarget) {
      setErrorMessage('মোবাইল নাম্বার দিন।');
      Sound.playAlert();
      return;
    }

    // Format with international dial code if not already included
    let target = rawTarget;
    if (!target.includes('@') && !target.startsWith('+')) {
      target = `${selectedCountry.dialCode} ${target.replace(/[\s-+]/g, '')}`;
    }

    setIsLoading(true);
    setErrorMessage(null);

    try {
      const res = await sendOtpService(target, purpose, name, password, regAgeCategory, referralCodeInput.trim());
      if (res.success) {
        Sound.playOtpBeep();
        setOtpCountdown(60);
        setActiveOtpInfo(getActiveOtp());
        setSuccessMessage(`৬ ডিজিটের ওটিপি কোড পাঠানো হয়েছে! (${res.otp})`);
        setView(purpose === 'forgot_password' ? 'reset_password' : 'phone_otp');
      } else {
        setErrorMessage(res.message);
        Sound.playAlert();
      }
    } catch (err: any) {
      setErrorMessage('ওটিপি পাঠাতে ব্যর্থ হয়েছে।');
      Sound.playAlert();
    } finally {
      setIsLoading(false);
    }
  };

  // 4. Handle Verify OTP
  const handleVerifyOtp = async () => {
    const enteredOtp = otpDigits.join('');
    if (enteredOtp.length !== 6) {
      setErrorMessage('অনুগ্রহ করে সম্পূর্ণ ৬ ডিজিটের কোডটি দিন।');
      Sound.playAlert();
      return;
    }

    const target = (phoneNumber || emailOrPhone).trim();
    setIsLoading(true);
    setErrorMessage(null);
    setSuccessMessage(null);

    try {
      const res = await verifyOtpService(target, enteredOtp);
      if (res.success && res.user) {
        // Save initial age limit config
        const ageNum = regAgeCategory === 'under_13' ? 10 : regAgeCategory === 'teen_13_17' ? 15 : 20;
        saveUserAgeConfig(res.user.id, buildDefaultAgeConfig(ageNum));

        // If referral code was entered, apply it!
        if (referralCodeInput.trim()) {
          try {
            await applyReferralCodeService(referralCodeInput, res.user, () => {});
          } catch (e) {
            console.error('Error applying referral during registration:', e);
          }
        }

        Sound.playAuthSuccess();
        triggerCelebration();
        setSuccessMessage(res.message);
        onUserUpdated(res.user, !!res.isNewRegistration);
        setTimeout(() => {
          onClose();
        }, 1200);
      } else {
        setErrorMessage(res.message);
        Sound.playAlert();
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'ভেরিফিকেশন সম্পন্ন হয়নি!');
      Sound.playAlert();
    } finally {
      setIsLoading(false);
    }
  };

  // 5. Direct Account Selection & Login for Google (Matching Video Flow)
  const selectGoogleAccountAndLogin = async (acc: {
    name: string;
    email: string;
    avatar?: string;
  }) => {
    Sound.playClick();
    setErrorMessage(null);
    setIsLoggingInOverlay(true);
    try {
      const res = await loginWithGoogleService(acc.name, acc.email, acc.avatar);
      if (res.success && res.user) {
        setTimeout(() => {
          setIsLoggingInOverlay(false);
          setLoginSuccessToast('Login Successful');
          Sound.playAuthSuccess();
          triggerCelebration();
          onUserUpdated(res.user, false);
          setTimeout(() => {
            setLoginSuccessToast(null);
            onClose();
          }, 1200);
        }, 800);
      } else {
        setIsLoggingInOverlay(false);
        setErrorMessage(res.message || 'গুগল লগইন সম্পন্ন করা যায়নি।');
        Sound.playAlert();
      }
    } catch (err: any) {
      setIsLoggingInOverlay(false);
      setErrorMessage(err.message || 'গুগল লগইন করতে সমস্যা হয়েছে!');
      Sound.playAlert();
    }
  };

  // Add custom Google Account and log in immediately
  const handleAddNewGoogleAccount = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGoogleEmail.trim()) {
      setErrorMessage('জিমেইল এড্রেস প্রদান করুন');
      Sound.playAlert();
      return;
    }
    const finalEmail = newGoogleEmail.includes('@') ? newGoogleEmail.trim() : `${newGoogleEmail.trim()}@gmail.com`;
    const finalName = newGoogleName.trim() || 'Joy Sarker';
    const newAcc = {
      name: finalName,
      email: finalEmail,
      avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${finalName}`,
      color: 'bg-blue-700',
      initial: finalName.charAt(0).toUpperCase(),
    };
    setGoogleAccounts((prev) => [newAcc, ...prev]);
    setShowAddGoogleAccount(false);
    selectGoogleAccountAndLogin(newAcc);
  };

  // Open Google Verified Access View (Modal Sheet)
  const handleGoogleLogin = () => {
    Sound.playClick();
    setErrorMessage(null);
    setSuccessMessage(null);
    setView('google_access');
  };

  // Confirm Google Verified Access Form
  const handleGoogleVerifiedLogin = async () => {
    if (!googleAccessAgree) {
      setErrorMessage('গুগল অ্যাকাউন্ট ভেরিফিকেশন সম্মতি দিন।');
      Sound.playAlert();
      return;
    }
    await selectGoogleAccountAndLogin({
      name: googleAccessName.trim() || 'Joy Sarker',
      email: googleAccessEmail.trim() || 'joysaker5@gmail.com',
      avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${googleAccessName.trim() || 'JoySarker'}`,
    });
  };

  // 6. Open Facebook Verified Access View
  const handleFacebookLogin = () => {
    Sound.playClick();
    setErrorMessage(null);
    setSuccessMessage(null);
    setView('facebook_access');
  };

  // Confirm Facebook Login (Matching Video Flow)
  const handleFacebookVerifiedLogin = async (customName?: string, customEmail?: string) => {
    Sound.playClick();
    setIsLoggingInOverlay(true);
    setErrorMessage(null);
    try {
      const finalName = customName || fbAccessName.trim() || 'Joy Sarker';
      const finalEmail = customEmail || fbAccessEmail.trim() || 'joysaker5@gmail.com';
      const res = await loginWithFacebookService(finalName, finalEmail);
      if (res.success && res.user) {
        setTimeout(() => {
          setIsLoggingInOverlay(false);
          setLoginSuccessToast('Login Successful');
          Sound.playAuthSuccess();
          triggerCelebration();
          onUserUpdated(res.user, false);
          setTimeout(() => {
            setLoginSuccessToast(null);
            onClose();
          }, 1200);
        }, 800);
      } else {
        setIsLoggingInOverlay(false);
        setErrorMessage(res.message || 'ফেসবুক লগইন সম্পন্ন হয়নি।');
        Sound.playAlert();
      }
    } catch (err: any) {
      setIsLoggingInOverlay(false);
      setErrorMessage('ফেসবুক ভেরিফাইড এক্সেস ব্যর্থ হয়েছে!');
      Sound.playAlert();
    }
  };

  // 7. Open WhatsApp Verified Access View
  const handleWhatsAppLogin = () => {
    Sound.playClick();
    setErrorMessage(null);
    setSuccessMessage(null);
    setView('whatsapp_access');
  };

  // Confirm WhatsApp Login (Matching Video Flow)
  const handleWhatsAppVerifiedLogin = async (customPhone?: string, customName?: string) => {
    Sound.playClick();
    setIsLoggingInOverlay(true);
    setErrorMessage(null);
    try {
      const finalPhone = customPhone || whatsAppPhone.trim() || '+8801712345678';
      const finalName = customName || whatsAppName.trim() || 'Joy Sarker';
      const res = await loginWithWhatsAppService(finalPhone, finalName);
      if (res.success && res.user) {
        setTimeout(() => {
          setIsLoggingInOverlay(false);
          setLoginSuccessToast('Login Successful');
          Sound.playAuthSuccess();
          triggerCelebration();
          onUserUpdated(res.user, false);
          setTimeout(() => {
            setLoginSuccessToast(null);
            onClose();
          }, 1200);
        }, 800);
      } else {
        setIsLoggingInOverlay(false);
        setErrorMessage(res.message || 'হোয়াটসঅ্যাপ লগইন সম্পন্ন হয়নি।');
        Sound.playAlert();
      }
    } catch (err: any) {
      setIsLoggingInOverlay(false);
      setErrorMessage('হোয়াটসঅ্যাপ ভেরিফাইড এক্সেস ব্যর্থ হয়েছে!');
      Sound.playAlert();
    }
  };

  // 7. Handle Forgot Password Reset OTP Request
  const handleRequestPasswordReset = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!emailOrPhone.trim()) {
      setErrorMessage('আপনার রেজিস্টার্ড ইমেইল বা ফোন নাম্বার দিন।');
      Sound.playAlert();
      return;
    }
    await handleSendPhoneOtp('forgot_password');
  };

  // 8. Handle Submit New Password after OTP
  const handleResetPasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const enteredOtp = otpDigits.join('');
    if (enteredOtp.length !== 6) {
      setErrorMessage('৬ ডিজিটের রিসেট ওটিপি কোড দিন।');
      Sound.playAlert();
      return;
    }
    if (password.length < 6) {
      setErrorMessage('নতুন পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।');
      Sound.playAlert();
      return;
    }
    if (password !== confirmPassword) {
      setErrorMessage('দুইটি পাসওয়ার্ড মিলছে না!');
      Sound.playAlert();
      return;
    }

    setIsLoading(true);
    setErrorMessage(null);

    try {
      const target = (emailOrPhone || phoneNumber).trim();
      const res = await resetPasswordWithOtpService(target, enteredOtp, password);
      if (res.success && res.user) {
        Sound.playAuthSuccess();
        triggerCelebration();
        setSuccessMessage(res.message);
        onUserUpdated(res.user, false);
        setTimeout(() => {
          onClose();
        }, 1200);
      } else {
        setErrorMessage(res.message);
        Sound.playAlert();
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'পাসওয়ার্ড রিসেট করা যায়নি!');
      Sound.playAlert();
    } finally {
      setIsLoading(false);
    }
  };

  // 9. Handle Change Password for Logged In User
  const handleChangePassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPasswordValid()) return;

    const res = changeUserPasswordService(currentUser.id, oldPassword, password);
    if (res.success) {
      Sound.playAuthSuccess();
      setSuccessMessage(res.message);
      const updated = loadUserProfile();
      onUserUpdated(updated, false);
      setTimeout(() => {
        setView('profile');
        setSuccessMessage(null);
        setPassword('');
        setConfirmPassword('');
        setOldPassword('');
      }, 1400);
    } else {
      setErrorMessage(res.message);
      Sound.playAlert();
    }
  };

  const newPasswordValid = () => {
    if (currentUser.hasPassword && !oldPassword) {
      setErrorMessage('বর্তমান পাসওয়ার্ড দিন।');
      Sound.playAlert();
      return false;
    }
    if (password.length < 6) {
      setErrorMessage('নতুন পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।');
      Sound.playAlert();
      return false;
    }
    if (password !== confirmPassword) {
      setErrorMessage('নতুন পাসওয়ার্ড ও কনফার্ম পাসওয়ার্ড মিলছে না!');
      Sound.playAlert();
      return false;
    }
    return true;
  };

  // 10. Handle Logout
  const handleLogout = () => {
    Sound.playClick();
    const guestUser = logoutUserService();
    onUserUpdated(guestUser, false);
    setSuccessMessage('সফলভাবে লগআউট করা হয়েছে।');
    setTimeout(() => {
      onClose();
    }, 800);
  };

  // OTP digit box handler
  const handleOtpBoxChange = (index: number, value: string) => {
    if (!/^\d*$/.test(value)) return;
    const newDigits = [...otpDigits];
    newDigits[index] = value.slice(-1);
    setOtpDigits(newDigits);

    if (value && index < 5) {
      otpInputRefs.current[index + 1]?.focus();
    }
  };

  const handleOtpKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace' && !otpDigits[index] && index > 0) {
      otpInputRefs.current[index - 1]?.focus();
    }
  };

  const handlePasteOtp = (e: React.ClipboardEvent) => {
    e.preventDefault();
    const pasted = e.clipboardData.getData('text').replace(/\D/g, '').slice(0, 6);
    if (pasted.length > 0) {
      const newDigits = ['', '', '', '', '', ''];
      for (let i = 0; i < pasted.length; i++) {
        newDigits[i] = pasted[i];
      }
      setOtpDigits(newDigits);
      otpInputRefs.current[Math.min(pasted.length, 5)]?.focus();
    }
  };

  const fillAutoOtp = () => {
    if (activeOtpInfo?.otp) {
      const code = activeOtpInfo.otp;
      setOtpDigits(code.split('').slice(0, 6));
      Sound.playOtpBeep();
    }
  };

  return (
    <div
      id="auth-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-md animate-fade-in"
    >
      <div
        id="auth-modal-card"
        className="relative w-full max-w-md bg-gradient-to-b from-amber-50 to-orange-50 border-2 border-amber-400/80 rounded-3xl shadow-2xl overflow-hidden text-amber-950 flex flex-col max-h-[92vh]"
      >
        {/* Realistic "Logging in..." Loader Overlay matching the video */}
        {isLoggingInOverlay && (
          <div className="absolute inset-0 z-[100] bg-black/65 backdrop-blur-sm flex items-center justify-center animate-fade-in">
            <div className="px-6 py-4 rounded-2xl bg-slate-900/95 border border-slate-700 shadow-2xl flex items-center gap-3.5 text-white">
              <div className="w-6 h-6 border-3 border-cyan-400 border-t-transparent rounded-full animate-spin"></div>
              <span className="text-sm font-bold tracking-wide">Logging in...</span>
            </div>
          </div>
        )}

        {/* Realistic "Login Successful" Toast matching the video */}
        {loginSuccessToast && (
          <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-[110] animate-bounce pointer-events-none">
            <div className="px-5 py-2.5 rounded-full bg-slate-900/95 border border-slate-700 shadow-2xl flex items-center gap-2 text-white text-xs font-black tracking-wide">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{loginSuccessToast}</span>
            </div>
          </div>
        )}

        {/* Modal Header */}
        <div className="relative px-5 py-4 bg-gradient-to-r from-amber-600 via-amber-700 to-orange-600 text-white flex items-center justify-between shadow-md shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-white/20 backdrop-blur-sm border border-white/30 flex items-center justify-center shadow-inner text-amber-100">
              {view === 'profile' ? (
                <User className="w-6 h-6" />
              ) : view === 'phone_otp' ? (
                <Smartphone className="w-6 h-6" />
              ) : view === 'forgot_password' || view === 'reset_password' || view === 'change_password' ? (
                <KeyRound className="w-6 h-6" />
              ) : (
                <ShieldCheck className="w-6 h-6" />
              )}
            </div>
            <div>
              <h2 className="text-lg font-black tracking-tight text-white flex items-center gap-1.5">
                {view === 'login' && 'লুডু লাইভ লগইন'}
                {view === 'register' && 'নতুন অ্যাকাউন্ট তৈরি করুন'}
                {view === 'phone_otp' && 'ভেরিফিকেশন OTP যাচাই'}
                {view === 'facebook_access' && 'ফেসবুক ভেরিফাইড এক্সেস'}
                {view === 'google_access' && 'গুগল ভেরিফাইড এক্সেস'}
                {view === 'whatsapp_access' && 'হোয়াটসঅ্যাপ এক্সেস'}
                {view === 'forgot_password' && 'পাসওয়ার্ড রিসেট'}
                {view === 'reset_password' && 'নতুন পাসওয়ার্ড সেট করুন'}
                {view === 'change_password' && 'পাসওয়ার্ড পরিবর্তন'}
                {view === 'profile' && 'আমার অ্যাকাউন্ট প্রোফাইল'}
              </h2>
              <p className="text-[11px] text-amber-100/90 font-medium">
                {view === 'login' && 'আপনার প্রোফাইল, কয়েন ও ডাটা সুরক্ষিত রাখুন'}
                {view === 'register' && 'নিবন্ধন যাচাই করলেই পাবেন +৫০০ কয়েন ও +২০ ডায়মন্ড'}
                {view === 'phone_otp' && 'ইমেইল বা মোবাইল কোড দিয়ে আইডি সক্রিয় করুন'}
                {view === 'facebook_access' && 'ফেসবুক আইডি ভেরিফাই করে ফুল এক্সেস পান'}
                {view === 'google_access' && 'গুগল ইমেইল ভেরিফাই করে ফুল এক্সেস পান'}
                {view === 'whatsapp_access' && 'হোয়াটসঅ্যাপ নাম্বার দিয়ে দ্রুত এক্সেস পান'}
                {view === 'forgot_password' && 'ওটিপি কোড দিয়ে নতুন পাসওয়ার্ড তৈরি করুন'}
                {view === 'reset_password' && 'সুরক্ষিত নতুন পাসওয়ার্ড নির্বাচন করুন'}
                {view === 'change_password' && 'অ্যাকাউন্টের নিরাপত্তা নিশ্চিত করুন'}
                {view === 'profile' && 'লুডু রয়্যাল ভিআইপি প্লেয়ার হাব'}
              </p>
            </div>
          </div>

          <button
            id="auth-modal-close-btn"
            onClick={() => {
              Sound.playClick();
              onClose();
            }}
            className="w-8 h-8 rounded-full bg-black/20 hover:bg-black/40 text-white flex items-center justify-center transition-all border border-white/20"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Global 195 Countries VPN-Free Reassurance Banner */}
        <div className="px-4 py-2 bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-700 text-white flex items-center justify-between text-xs font-bold shadow-inner shrink-0 border-b border-emerald-500/40">
          <div className="flex items-center gap-2 truncate">
            <span className="text-sm">🌐</span>
            <span className="truncate">১৯৫টি দেশে VPN ছাড়া সরাসরি একাউন্ট তৈরি ও ভয়েস কল সক্রিয়</span>
          </div>
          <span className="px-2 py-0.5 rounded-full bg-white/20 text-[10px] uppercase tracking-wider shrink-0 font-black border border-white/30">
            VPN মুক্ত ✓
          </span>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-4">
          {/* Status Banners */}
          {errorMessage && (
            <div className="p-3 rounded-2xl bg-red-50 border border-red-200 text-red-700 text-xs font-semibold flex items-center gap-2 animate-shake">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-500" />
              <span>{errorMessage}</span>
            </div>
          )}

          {successMessage && (
            <div className="p-3 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold flex items-center gap-2 animate-fade-in">
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
              <span>{successMessage}</span>
            </div>
          )}

          {/* VIEW: LOGIN */}
          {view === 'login' && (
            <div className="space-y-4 animate-fade-in">
              {loginMode === 'quick_social' ? (
                <div className="space-y-4 animate-fade-in">
                  {/* Hero Brand Title matching Video */}
                  <div className="text-center space-y-1.5 py-1">
                    <div className="w-14 h-14 mx-auto rounded-3xl bg-gradient-to-tr from-amber-500 via-orange-500 to-red-500 flex items-center justify-center shadow-lg border-2 border-white/50 text-white text-2xl">
                      🎲
                    </div>
                    <div>
                      <h3 className="text-lg font-black text-amber-950 tracking-tight flex items-center justify-center gap-1.5">
                        <span>লুডু লাইভ</span>
                        <span className="text-xs px-2 py-0.5 rounded-full bg-red-500 text-white font-black uppercase tracking-wider">
                          LIVE
                        </span>
                      </h3>
                      <p className="text-xs font-semibold text-amber-800/90">
                        লাইভ লুডু ম্যাচ ও ভিডিও চ্যাট • ভেরিফাইড সোশ্যাল এক্সেস
                      </p>
                    </div>
                  </div>

                  {/* 3 Prominent Full-Width Social Buttons (Facebook, Google, WhatsApp) matching Video */}
                  <div className="space-y-2.5 pt-1">
                    {/* 1. Log in with Facebook */}
                    <button
                      type="button"
                      id="video-facebook-login-btn"
                      onClick={() => {
                        Sound.playClick();
                        handleFacebookLogin();
                      }}
                      disabled={isLoading}
                      className="w-full py-3 px-4 rounded-2xl bg-[#1877F2] hover:bg-[#166fe5] active:scale-[0.98] text-white font-black text-sm shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-3 cursor-pointer disabled:opacity-50"
                    >
                      <svg className="w-5 h-5 fill-current shrink-0" viewBox="0 0 24 24">
                        <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                      </svg>
                      <span>Log in with Facebook</span>
                    </button>

                    {/* 2. Log in with Google */}
                    <button
                      type="button"
                      id="video-google-login-btn"
                      onClick={() => {
                        Sound.playClick();
                        handleGoogleLogin();
                      }}
                      disabled={isLoading}
                      className="w-full py-3 px-4 rounded-2xl bg-white hover:bg-slate-50 active:scale-[0.98] text-slate-800 font-black text-sm border-2 border-slate-300/90 shadow-sm hover:shadow transition-all flex items-center justify-center gap-3 cursor-pointer disabled:opacity-50"
                    >
                      <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24">
                        <path
                          fill="#4285F4"
                          d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17Z"
                        />
                        <path
                          fill="#34A853"
                          d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.33 24 12 24Z"
                        />
                        <path
                          fill="#FBBC05"
                          d="M5.28 14.27A7.16 7.16 0 0 1 4.9 12c0-.79.14-1.57.38-2.27V6.58H1.25A11.96 11.96 0 0 0 0 12c0 1.92.45 3.74 1.25 5.42l4.03-3.15Z"
                        />
                        <path
                          fill="#EA4335"
                          d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.33 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98Z"
                        />
                      </svg>
                      <span>Log in with Google</span>
                    </button>

                    {/* 3. Log in with WhatsApp */}
                    <button
                      type="button"
                      id="video-whatsapp-login-btn"
                      onClick={() => {
                        Sound.playClick();
                        handleWhatsAppLogin();
                      }}
                      disabled={isLoading}
                      className="w-full py-3 px-4 rounded-2xl bg-[#25D366] hover:bg-[#22bf5b] active:scale-[0.98] text-white font-black text-sm shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-3 cursor-pointer disabled:opacity-50"
                    >
                      <svg className="w-5 h-5 fill-current shrink-0" viewBox="0 0 24 24">
                        <path d="M17.472 14.382c-.301-.15-1.782-.879-2.058-.98-.276-.1-.477-.15-.678.15s-.778.98-.954 1.181c-.176.2-.351.226-.652.075s-1.272-.469-2.423-1.496c-.896-.799-1.5-1.786-1.676-2.087s-.019-.464.132-.614c.135-.135.301-.351.452-.527s.201-.301.301-.502c.101-.2.05-.376-.025-.527s-.678-1.631-.929-2.233c-.245-.587-.494-.507-.678-.517l-.578-.01c-.2 0-.527.075-.803.376s-1.054 1.03-1.054 2.511c0 1.481 1.079 2.91 1.229 3.111.15.201 2.124 3.243 5.145 4.549.719.311 1.28.497 1.718.636.722.23 1.379.197 1.9.119.58-.088 1.782-.728 2.033-1.431.251-.703.251-1.305.176-1.431-.076-.126-.277-.201-.578-.351zM12.04 21.785h-.002a9.78 9.78 0 0 1-4.992-1.365l-.358-.213-3.712.974.991-3.619-.233-.371A9.78 9.78 0 0 1 2.25 12.04c0-5.395 4.39-9.785 9.79-9.785a9.75 9.75 0 0 1 6.924 2.869 9.75 9.75 0 0 1 2.868 6.921c0 5.396-4.39 9.786-9.792 9.786zm0-17.785a7.99 7.99 0 0 0-8 8c0 1.572.457 3.09 1.321 4.402l.205.312-.587 2.146 2.196-.576.303.18a7.98 7.98 0 0 0 4.562 1.336c4.411 0 8-3.589 8-8s-3.589-8-8-8z" />
                      </svg>
                      <span>Log in with WhatsApp</span>
                    </button>
                  </div>

                  {/* "or" Divider */}
                  <div className="relative flex py-1 items-center">
                    <div className="flex-grow border-t border-amber-300/70"></div>
                    <span className="flex-shrink mx-3 text-xs text-amber-800 font-semibold lowercase">
                      or
                    </span>
                    <div className="flex-grow border-t border-amber-300/70"></div>
                  </div>

                  {/* 3 Circular Icon Buttons matching Video */}
                  <div className="flex items-center justify-center gap-4 py-0.5">
                    {/* Phone OTP Login */}
                    <button
                      type="button"
                      id="social-circle-phone-btn"
                      onClick={() => {
                        Sound.playClick();
                        setView('phone_otp');
                      }}
                      title="মোবাইল কোড দিয়ে লগইন"
                      className="w-12 h-12 rounded-full bg-white hover:bg-amber-100/60 border-2 border-amber-300 flex items-center justify-center text-amber-900 shadow-sm hover:shadow transition-all active:scale-95 cursor-pointer"
                    >
                      <Phone className="w-5 h-5 text-amber-700" />
                    </button>

                    {/* Twitter / X Icon */}
                    <button
                      type="button"
                      id="social-circle-twitter-btn"
                      onClick={() => {
                        Sound.playClick();
                        handleGoogleLogin();
                      }}
                      title="Twitter / X লগইন"
                      className="w-12 h-12 rounded-full bg-white hover:bg-slate-100 border-2 border-slate-300 flex items-center justify-center text-slate-900 shadow-sm hover:shadow transition-all active:scale-95 cursor-pointer"
                    >
                      <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                        <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
                      </svg>
                    </button>

                    {/* Guest Profile Play */}
                    <button
                      type="button"
                      id="social-circle-guest-btn"
                      onClick={() => {
                        Sound.playClick();
                        onClose();
                      }}
                      title="গেস্ট হিসেবে খেলা চালিয়ে যান"
                      className="w-12 h-12 rounded-full bg-white hover:bg-emerald-100/60 border-2 border-emerald-300 flex items-center justify-center text-emerald-800 shadow-sm hover:shadow transition-all active:scale-95 cursor-pointer"
                    >
                      <User className="w-5 h-5 text-emerald-700" />
                    </button>
                  </div>

                  {/* Toggle to Standard Credentials Form */}
                  <div className="pt-2 text-center">
                    <button
                      type="button"
                      onClick={() => {
                        Sound.playClick();
                        setLoginMode('form');
                      }}
                      className="text-xs font-bold text-amber-800 hover:text-amber-950 underline flex items-center justify-center gap-1 mx-auto cursor-pointer"
                    >
                      <span>মোবাইল/ইমেইল ও পাসওয়ার্ড দিয়ে প্রবেশ করুন</span>
                      <span className="text-amber-600">▾</span>
                    </button>
                  </div>

                  {/* Bottom Video Disclaimer */}
                  <p className="text-[10px] leading-relaxed text-center text-amber-900/70 font-medium px-4 pt-1">
                    By logging in, you confirm you're over 18 years old and agree to our{' '}
                    <span className="underline font-bold cursor-pointer text-amber-950">Terms</span> &{' '}
                    <span className="underline font-bold cursor-pointer text-amber-950">Privacy Policy</span>.
                  </p>
                </div>
              ) : (
                /* Standard Credentials Form with Toggle Back */
                <div className="space-y-3.5 animate-fade-in">
                  <div className="flex items-center justify-between">
                    <button
                      type="button"
                      onClick={() => {
                        Sound.playClick();
                        setLoginMode('quick_social');
                      }}
                      className="text-xs font-black text-amber-800 hover:text-amber-950 underline flex items-center gap-1 cursor-pointer"
                    >
                      <span>← দ্রুত সোশ্যাল এক্সেসে ফিরুন</span>
                    </button>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-200/80 text-amber-900">
                      পাসওয়ার্ড লগইন
                    </span>
                  </div>

                  {/* Login Form */}
                  <form onSubmit={handleLogin} className="space-y-3">
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="text-xs font-bold text-amber-900">
                          ইমেইল অথবা মোবাইল নাম্বার:
                        </label>
                        {detectedOperator && (
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${detectedOperator.color}`}>
                            {detectedOperator.name}
                          </span>
                        )}
                      </div>
                      <div className="flex gap-1.5 items-center">
                        <CountryPicker
                          selectedCountry={selectedCountry}
                          onSelectCountry={(c) => {
                            setSelectedCountry(c);
                            Sound.playClick();
                          }}
                          disabled={isLoading}
                        />
                        <div className="relative flex-grow">
                          <Mail className="w-4 h-4 text-amber-600 absolute left-3.5 top-1/2 -translate-y-1/2" />
                          <input
                            id="login-email-input"
                            type="text"
                            placeholder="017... অথবা ইমেইল"
                            value={emailOrPhone}
                            onChange={(e) => {
                              const val = e.target.value;
                              setEmailOrPhone(val);
                              // Auto detect country if typed international format
                              const detected = detectCountryFromPhoneInput(val);
                              if (detected) setSelectedCountry(detected.country);
                            }}
                            className="w-full pl-10 pr-3 py-2.5 bg-white border-2 border-amber-200 focus:border-amber-500 rounded-2xl text-xs font-semibold focus:outline-none transition-all placeholder:text-amber-900/40"
                          />
                        </div>
                      </div>
                    </div>

                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="text-xs font-bold text-amber-900">পাসওয়ার্ড:</label>
                        <button
                          type="button"
                          id="login-forgot-pass-link"
                          onClick={() => {
                            Sound.playClick();
                            setView('forgot_password');
                          }}
                          className="text-[11px] font-bold text-amber-700 hover:text-amber-900 underline"
                        >
                          পাসওয়ার্ড ভুলে গেছেন?
                        </button>
                      </div>
                      <div className="relative">
                        <Lock className="w-4 h-4 text-amber-600 absolute left-3.5 top-1/2 -translate-y-1/2" />
                        <input
                          id="login-password-input"
                          type={showPassword ? 'text' : 'password'}
                          placeholder="আপনার পাসওয়ার্ড দিন"
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          className="w-full pl-10 pr-10 py-2.5 bg-white border-2 border-amber-200 focus:border-amber-500 rounded-2xl text-xs font-semibold focus:outline-none transition-all placeholder:text-amber-900/40"
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-amber-600 hover:text-amber-900 p-1"
                        >
                          {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>
                    </div>

                    {/* Submit Login */}
                    <button
                      type="submit"
                      id="login-submit-btn"
                      disabled={isLoading}
                      className="w-full py-3 px-4 rounded-2xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white font-black text-sm shadow-md hover:shadow-lg active:scale-98 transition-all flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer"
                    >
                      {isLoading ? (
                        <RefreshCw className="w-4 h-4 animate-spin" />
                      ) : (
                        <>
                          <span>লগইন করুন</span>
                          <ArrowRight className="w-4 h-4" />
                        </>
                      )}
                    </button>
                  </form>

                  {/* Alternative Actions */}
                  <div className="pt-2 grid grid-cols-2 gap-2 text-center">
                    <button
                      type="button"
                      id="login-switch-otp-btn"
                      onClick={() => {
                        Sound.playClick();
                        setView('phone_otp');
                      }}
                      className="p-2.5 rounded-2xl bg-amber-100/70 hover:bg-amber-200/80 border border-amber-300 text-amber-900 text-xs font-bold flex items-center justify-center gap-1.5 transition-all"
                    >
                      <Smartphone className="w-3.5 h-3.5 text-amber-700" />
                      <span>মোবাইল OTP লগইন</span>
                    </button>

                    <button
                      type="button"
                      id="login-switch-register-btn"
                      onClick={() => {
                        Sound.playClick();
                        setView('register');
                      }}
                      className="p-2.5 rounded-2xl bg-emerald-100/80 hover:bg-emerald-200 border border-emerald-300 text-emerald-900 text-xs font-black flex items-center justify-center gap-1.5 transition-all"
                    >
                      <Sparkles className="w-3.5 h-3.5 text-emerald-700" />
                      <span>নতুন অ্যাকাউন্ট তৈরি</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* VIEW: REGISTER */}
          {view === 'register' && (
            <div className="space-y-3.5 animate-fade-in">
              <div className="p-2.5 rounded-2xl bg-gradient-to-r from-amber-500/15 via-orange-500/15 to-emerald-500/15 border border-amber-300 flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-amber-500 text-white flex items-center justify-center shrink-0 shadow-sm">
                  <Sparkles className="w-4 h-4" />
                </div>
                <div className="text-left">
                  <div className="text-xs font-black text-amber-950 flex items-center gap-1">
                    বোনাস স্বাগতম অফার!
                    <span className="px-1.5 py-0.2 text-[9px] bg-amber-600 text-white rounded-full font-bold">
                      ফ্রি
                    </span>
                  </div>
                  <div className="text-[11px] font-semibold text-amber-800">
                    একাউন্ট খুললেই পাবেন <span className="font-bold">+৫০০ কয়েন</span> এবং{' '}
                    <span className="font-bold">+২০ ডায়মন্ড</span>!
                  </div>
                </div>
              </div>

              <form onSubmit={handleRegister} className="space-y-2.5">
                <div>
                  <label className="text-xs font-bold text-amber-900 block mb-1">
                    আপনার পূর্ণ নাম:
                  </label>
                  <div className="relative">
                    <User className="w-4 h-4 text-amber-600 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      id="reg-name-input"
                      type="text"
                      placeholder="উদা: সাকিব আল হাসান"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full pl-10 pr-3 py-2 bg-white border-2 border-amber-200 focus:border-amber-500 rounded-2xl text-xs font-semibold focus:outline-none transition-all placeholder:text-amber-900/40"
                    />
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-bold text-amber-900">
                      ইমেইল অথবা মোবাইল নাম্বার:
                    </label>
                    {detectedOperator && (
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${detectedOperator.color}`}
                      >
                        {detectedOperator.name}
                      </span>
                    )}
                  </div>
                  <div className="flex gap-1.5 items-center">
                    <CountryPicker
                      selectedCountry={selectedCountry}
                      onSelectCountry={(c) => {
                        setSelectedCountry(c);
                        Sound.playClick();
                      }}
                      disabled={isLoading}
                    />
                    <div className="relative flex-grow">
                      <Mail className="w-4 h-4 text-amber-600 absolute left-3.5 top-1/2 -translate-y-1/2" />
                      <input
                        id="reg-email-phone-input"
                        type="text"
                        placeholder="017... অথবা yourname@gmail.com"
                        value={emailOrPhone}
                        onChange={(e) => {
                          const val = e.target.value;
                          setEmailOrPhone(val);
                          const detected = detectCountryFromPhoneInput(val);
                          if (detected) setSelectedCountry(detected.country);
                        }}
                        className="w-full pl-10 pr-3 py-2 bg-white border-2 border-amber-200 focus:border-amber-500 rounded-2xl text-xs font-semibold focus:outline-none transition-all placeholder:text-amber-900/40"
                      />
                    </div>
                  </div>
                </div>

                <div>
                  <label className="text-xs font-bold text-amber-900 block mb-1">
                    পাসওয়ার্ড তৈরি করুন:
                  </label>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-amber-600 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      id="reg-password-input"
                      type={showPassword ? 'text' : 'password'}
                      placeholder="কমপক্ষে ৬ অক্ষরের শক্তিশালী পাসওয়ার্ড"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full pl-10 pr-10 py-2 bg-white border-2 border-amber-200 focus:border-amber-500 rounded-2xl text-xs font-semibold focus:outline-none transition-all placeholder:text-amber-900/40"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-amber-600 hover:text-amber-900 p-1"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>

                  {/* Password Strength Meter */}
                  {password && (
                    <div className="mt-1.5 p-2 rounded-xl bg-amber-100/50 border border-amber-200/80 space-y-1">
                      <div className="flex items-center justify-between text-[11px]">
                        <span className="font-bold text-amber-950">পাসওয়ার্ডের মাত্রা:</span>
                        <span
                          className={`font-black ${
                            passwordStrength.score >= 3 ? 'text-emerald-700' : 'text-amber-700'
                          }`}
                        >
                          {passwordStrength.labelBn}
                        </span>
                      </div>
                      <div className="w-full h-1.5 bg-amber-200 rounded-full overflow-hidden flex gap-1">
                        <div
                          className={`h-full transition-all duration-300 rounded-full ${
                            passwordStrength.score >= 1 ? passwordStrength.color : 'bg-transparent'
                          }`}
                          style={{ width: '25%' }}
                        />
                        <div
                          className={`h-full transition-all duration-300 rounded-full ${
                            passwordStrength.score >= 2 ? passwordStrength.color : 'bg-transparent'
                          }`}
                          style={{ width: '25%' }}
                        />
                        <div
                          className={`h-full transition-all duration-300 rounded-full ${
                            passwordStrength.score >= 3 ? passwordStrength.color : 'bg-transparent'
                          }`}
                          style={{ width: '25%' }}
                        />
                        <div
                          className={`h-full transition-all duration-300 rounded-full ${
                            passwordStrength.score >= 4 ? passwordStrength.color : 'bg-transparent'
                          }`}
                          style={{ width: '25%' }}
                        />
                      </div>
                      <div className="flex items-center gap-2 text-[10px] text-amber-800 pt-0.5">
                        <span
                          className={
                            passwordStrength.hasMinLength ? 'text-emerald-700 font-bold' : 'opacity-60'
                          }
                        >
                          ✓ ৬+ অক্ষর
                        </span>
                        <span
                          className={
                            passwordStrength.hasNumber ? 'text-emerald-700 font-bold' : 'opacity-60'
                          }
                        >
                          ✓ সংখ্যা
                        </span>
                        <span
                          className={
                            passwordStrength.hasLetter ? 'text-emerald-700 font-bold' : 'opacity-60'
                          }
                        >
                          ✓ বর্ণমালা
                        </span>
                      </div>
                    </div>
                  )}
                </div>

                <div>
                  <label className="text-xs font-bold text-amber-900 block mb-1">
                    পাসওয়ার্ড নিশ্চিত করুন:
                  </label>
                  <div className="relative">
                    <ShieldCheck className="w-4 h-4 text-amber-600 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      id="reg-confirm-password-input"
                      type={showConfirmPassword ? 'text' : 'password'}
                      placeholder="পুনরায় একই পাসওয়ার্ড লিখুন"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      className="w-full pl-10 pr-10 py-2 bg-white border-2 border-amber-200 focus:border-amber-500 rounded-2xl text-xs font-semibold focus:outline-none transition-all placeholder:text-amber-900/40"
                    />
                    <button
                      type="button"
                      onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-amber-600 hover:text-amber-900 p-1"
                    >
                      {showConfirmPassword ? (
                        <EyeOff className="w-4 h-4" />
                      ) : (
                        <Eye className="w-4 h-4" />
                      )}
                    </button>
                  </div>
                </div>

                {/* Age Limit & Category Selection */}
                <div>
                  <label className="text-xs font-bold text-amber-900 block mb-1">
                    বয়স সীমা নির্বাচন করুন (নিরাপত্তা ও পলিসি):
                  </label>
                  <div className="grid grid-cols-3 gap-1.5">
                    <button
                      type="button"
                      onClick={() => setRegAgeCategory('adult_18_plus')}
                      className={`py-2 px-1.5 rounded-xl border text-[11px] font-bold text-center transition-all cursor-pointer ${
                        regAgeCategory === 'adult_18_plus'
                          ? 'bg-amber-600 text-white border-amber-700 shadow-sm'
                          : 'bg-white text-amber-950 border-amber-200 hover:bg-amber-50'
                      }`}
                    >
                      👑 ১৮+ বছর
                    </button>
                    <button
                      type="button"
                      onClick={() => setRegAgeCategory('teen_13_17')}
                      className={`py-2 px-1.5 rounded-xl border text-[11px] font-bold text-center transition-all cursor-pointer ${
                        regAgeCategory === 'teen_13_17'
                          ? 'bg-amber-600 text-white border-amber-700 shadow-sm'
                          : 'bg-white text-amber-950 border-amber-200 hover:bg-amber-50'
                      }`}
                    >
                      🛡️ ১৩-১৭ বছর
                    </button>
                    <button
                      type="button"
                      onClick={() => setRegAgeCategory('under_13')}
                      className={`py-2 px-1.5 rounded-xl border text-[11px] font-bold text-center transition-all cursor-pointer ${
                        regAgeCategory === 'under_13'
                          ? 'bg-amber-600 text-white border-amber-700 shadow-sm'
                          : 'bg-white text-amber-950 border-amber-200 hover:bg-amber-50'
                      }`}
                    >
                      🧒 ১৩ এর নিচে
                    </button>
                  </div>
                </div>

                {/* Optional Referral Code Input */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-bold text-amber-900 flex items-center gap-1">
                      <Gift className="w-3.5 h-3.5 text-amber-600" />
                      রেফারেল কোড (ঐচ্ছিক):
                    </label>
                    <span className="text-[10px] text-emerald-700 font-bold bg-emerald-100 px-2 py-0.5 rounded-full">
                      +২,৫০০ কয়েন বোনাস 🪙
                    </span>
                  </div>
                  <div className="relative">
                    <input
                      id="reg-referral-code-input"
                      type="text"
                      placeholder="উদা: LUDO-ARIF77 (যদি থাকে)"
                      value={referralCodeInput}
                      onChange={(e) => setReferralCodeInput(e.target.value.toUpperCase())}
                      className="w-full px-3 py-2 bg-amber-50/50 border-2 border-dashed border-amber-300 focus:border-amber-500 rounded-2xl text-xs font-mono font-bold text-amber-950 focus:outline-none uppercase placeholder:text-amber-900/40"
                    />
                  </div>
                </div>

                {/* Submit Register */}
                <button
                  type="submit"
                  id="reg-submit-btn"
                  disabled={isLoading}
                  className="w-full mt-2 py-3 px-4 rounded-2xl bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-700 hover:from-emerald-700 hover:to-teal-700 text-white font-black text-sm shadow-md hover:shadow-lg active:scale-98 transition-all flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer"
                >
                  {isLoading ? (
                    <RefreshCw className="w-4 h-4 animate-spin" />
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4" />
                      <span>অ্যাকাউন্ট তৈরি করুন (+৫০০ ফ্রি কয়েন)</span>
                    </>
                  )}
                </button>
              </form>

              <div className="text-center pt-1">
                <button
                  type="button"
                  onClick={() => {
                    Sound.playClick();
                    setView('login');
                  }}
                  className="text-xs font-bold text-amber-800 hover:text-amber-950 underline"
                >
                  ইতিমধ্যে অ্যাকাউন্ট আছে? লগইন করুন
                </button>
              </div>
            </div>
          )}

          {/* VIEW: PHONE OTP */}
          {view === 'phone_otp' && (
            <div className="space-y-4 animate-fade-in">
              <div className="text-center space-y-1">
                <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-400 mx-auto flex items-center justify-center text-amber-800">
                  <Smartphone className="w-6 h-6" />
                </div>
                <h3 className="text-sm font-black text-amber-950">
                  মোবাইল নাম্বারে ওটিপি পাঠান
                </h3>
                <p className="text-xs text-amber-800">
                  আপনার সচল মোবাইল নাম্বারে ৬ ডিজিটের ওটিপি পাঠানো হবে
                </p>
              </div>

              {/* Phone Input */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-amber-900">মোবাইল নাম্বার:</label>
                  {detectedOperator && (
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${detectedOperator.color}`}
                    >
                      {detectedOperator.name}
                    </span>
                  )}
                </div>
                <div className="flex gap-1.5 items-center">
                  <CountryPicker
                    selectedCountry={selectedCountry}
                    onSelectCountry={(c) => {
                      setSelectedCountry(c);
                      Sound.playClick();
                    }}
                    disabled={isLoading}
                  />
                  <div className="relative flex-grow">
                    <Phone className="w-4 h-4 text-amber-600 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      id="otp-phone-input"
                      type="tel"
                      placeholder="017... অথবা মোবাইল নাম্বার"
                      value={phoneNumber}
                      onChange={(e) => {
                        const val = e.target.value;
                        setPhoneNumber(val);
                        const detected = detectCountryFromPhoneInput(val);
                        if (detected) setSelectedCountry(detected.country);
                      }}
                      className="w-full pl-10 pr-3 py-2.5 bg-white border-2 border-amber-200 focus:border-amber-500 rounded-2xl text-xs font-semibold focus:outline-none transition-all placeholder:text-amber-900/40"
                    />
                  </div>
                  <button
                    type="button"
                    id="otp-send-code-btn"
                    onClick={() => handleSendPhoneOtp('login')}
                    disabled={isLoading || otpCountdown > 0 || !phoneNumber.trim()}
                    className="px-3.5 sm:px-4 py-2.5 rounded-2xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-black shrink-0 transition-all active:scale-95 disabled:opacity-50 cursor-pointer shadow-sm"
                  >
                    {otpCountdown > 0 ? `${otpCountdown}s অপেক্ষা` : 'কোড পাঠান'}
                  </button>
                </div>
              </div>

              {/* Active OTP Simulation Banner */}
              {activeOtpInfo && (
                <div className="p-3 rounded-2xl bg-amber-100/90 border-2 border-dashed border-amber-400 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <Smartphone className="w-4 h-4 text-amber-700 shrink-0" />
                    <div className="text-left">
                      <div className="text-[11px] font-bold text-amber-950">
                        মোবাইল এসএমএস সিমুলেশন কোড:
                      </div>
                      <div className="text-sm font-black tracking-widest text-amber-900">
                        {activeOtpInfo.otp}
                      </div>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={fillAutoOtp}
                    className="px-3 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-[11px] font-bold shadow transition-all active:scale-95"
                  >
                    অটো ফিল
                  </button>
                </div>
              )}

              {/* 6 Digit Input Boxes */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-amber-900 block text-center">
                  ৬ ডিজিটের ওটিপি কোড লিখুন:
                </label>
                <div className="flex justify-center gap-2" onPaste={handlePasteOtp}>
                  {otpDigits.map((digit, index) => (
                    <input
                      key={index}
                      ref={(el) => (otpInputRefs.current[index] = el)}
                      type="text"
                      inputMode="numeric"
                      maxLength={1}
                      value={digit}
                      onChange={(e) => handleOtpBoxChange(index, e.target.value)}
                      onKeyDown={(e) => handleOtpKeyDown(index, e)}
                      className="w-10 h-12 text-center text-lg font-black bg-white border-2 border-amber-300 focus:border-amber-600 focus:bg-amber-50/50 rounded-xl focus:outline-none shadow-inner transition-all text-amber-950"
                    />
                  ))}
                </div>
              </div>

              {/* Verify Button */}
              <button
                type="button"
                id="otp-verify-submit-btn"
                onClick={handleVerifyOtp}
                disabled={isLoading || otpDigits.join('').length !== 6}
                className="w-full py-3 px-4 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-black text-sm shadow-md hover:shadow-lg active:scale-98 transition-all flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer"
              >
                {isLoading ? (
                  <RefreshCw className="w-4 h-4 animate-spin" />
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    <span>ওটিপি যাচাই করে প্রবেশ করুন</span>
                  </>
                )}
              </button>

              <div className="flex justify-between items-center text-xs pt-1">
                <button
                  type="button"
                  onClick={() => {
                    Sound.playClick();
                    setView('login');
                  }}
                  className="font-bold text-amber-800 hover:text-amber-950 underline"
                >
                  ← পাসওয়ার্ড দিয়ে লগইন
                </button>
                <button
                  type="button"
                  onClick={() => {
                    Sound.playClick();
                    setView('register');
                  }}
                  className="font-bold text-emerald-800 hover:text-emerald-950 underline"
                >
                  নতুন একাউন্ট?
                </button>
              </div>
            </div>
          )}

          {/* VIEW: FACEBOOK VERIFIED ACCESS (Video SSO Style) */}
          {view === 'facebook_access' && (
            <div className="space-y-4 animate-fade-in">
              <div className="text-center space-y-1.5 pt-1">
                <div className="w-12 h-12 rounded-2xl bg-[#1877F2] mx-auto flex items-center justify-center text-white shadow-md">
                  <svg className="w-7 h-7 fill-current" viewBox="0 0 24 24">
                    <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                  </svg>
                </div>
                <div>
                  <h3 className="text-base font-black text-slate-900 tracking-tight">
                    Log in with Facebook
                  </h3>
                  <p className="text-xs text-slate-600 flex items-center justify-center gap-1.5 mt-0.5">
                    <span>to continue to</span>
                    <span className="font-bold text-amber-800 flex items-center gap-1">
                      🎲 Ludo Live
                    </span>
                  </p>
                </div>
              </div>

              {/* Profile Card Preview */}
              <div className="p-4 rounded-2xl bg-white border-2 border-blue-200 shadow-sm space-y-3">
                <div className="flex items-center gap-3">
                  <div className="w-13 h-13 rounded-2xl bg-[#1877F2]/10 border-2 border-[#1877F2] overflow-hidden flex items-center justify-center shrink-0">
                    <img
                      src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${fbAccessName || 'Joy'}`}
                      alt="Facebook Avatar"
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <div className="flex-grow min-w-0">
                    <div className="flex items-center gap-1.5">
                      <span className="text-sm font-black text-slate-900 truncate">
                        {fbAccessName || 'Joy Sarker'}
                      </span>
                      <span className="px-1.5 py-0.5 rounded-md bg-[#1877F2] text-white text-[9px] font-black">
                        FB Verified ✓
                      </span>
                    </div>
                    <div className="text-xs text-slate-600 font-medium truncate">
                      {fbAccessEmail || 'joysaker5@gmail.com'}
                    </div>
                  </div>
                </div>

                {/* Edit Toggle / Form fields */}
                <div className="space-y-2 pt-2 border-t border-slate-200">
                  <div>
                    <label className="text-[11px] font-bold text-slate-700 block mb-1">
                      ফেসবুক ডিসপ্লে নাম:
                    </label>
                    <input
                      type="text"
                      value={fbAccessName}
                      onChange={(e) => setFbAccessName(e.target.value)}
                      placeholder="আপনার ফেসবুক নাম"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold text-slate-900 focus:outline-none focus:border-blue-600"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-bold text-slate-700 block mb-1">
                      ভেরিফাইড ইমেইল ঠিকানা:
                    </label>
                    <input
                      type="email"
                      value={fbAccessEmail}
                      onChange={(e) => setFbAccessEmail(e.target.value)}
                      placeholder="আপনার ইমেইল"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold text-slate-900 focus:outline-none focus:border-blue-600"
                    />
                  </div>
                </div>
              </div>

              {/* Action Button */}
              <button
                type="button"
                id="fb-verify-confirm-btn"
                onClick={handleFacebookVerifiedLogin}
                disabled={isLoading}
                className="w-full py-3 px-4 rounded-2xl bg-[#1877F2] hover:bg-[#166fe5] text-white font-black text-sm shadow-md hover:shadow-lg active:scale-98 transition-all flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer"
              >
                {isLoading ? (
                  <RefreshCw className="w-4 h-4 animate-spin" />
                ) : (
                  <>
                    <span>Continue as {fbAccessName.split(' ')[0] || 'Joy'}</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>

              <div className="text-center pt-1">
                <button
                  type="button"
                  onClick={() => {
                    Sound.playClick();
                    setView('login');
                  }}
                  className="text-xs font-bold text-slate-600 hover:text-slate-900 underline"
                >
                  Cancel and return to login
                </button>
              </div>
            </div>
          )}

          {/* VIEW: GOOGLE / GMAIL VERIFIED ACCESS (Video "Choose an account" Style) */}
          {view === 'google_access' && (
            <div className="space-y-3.5 animate-fade-in">
              {/* Google Header */}
              <div className="text-center space-y-1 pt-1">
                <div className="w-10 h-10 mx-auto flex items-center justify-center">
                  <svg className="w-8 h-8" viewBox="0 0 24 24">
                    <path
                      fill="#4285F4"
                      d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17Z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.33 24 12 24Z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.28 14.27A7.16 7.16 0 0 1 4.9 12c0-.79.14-1.57.38-2.27V6.58H1.25A11.96 11.96 0 0 0 0 12c0 1.92.45 3.74 1.25 5.42l4.03-3.15Z"
                    />
                    <path
                      fill="#EA4335"
                      d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.33 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98Z"
                    />
                  </svg>
                </div>
                <h3 className="text-base font-black text-slate-900 tracking-tight">
                  Choose an account
                </h3>
                <p className="text-xs text-slate-600 flex items-center justify-center gap-1.5">
                  <span>to continue to</span>
                  <span className="font-bold text-amber-800 flex items-center gap-1">
                    🎲 Ludo Live
                  </span>
                </p>
              </div>

              {/* Account Picker List matching Video */}
              <div className="bg-white rounded-2xl border-2 border-slate-200 divide-y divide-slate-200 overflow-hidden shadow-sm">
                {googleAccounts.map((account) => {
                  const initial = (account.name || 'J').charAt(0).toUpperCase();
                  return (
                    <button
                      key={account.email}
                      type="button"
                      onClick={() => selectGoogleAccountAndLogin(account)}
                      className="w-full px-4 py-3 flex items-center gap-3 hover:bg-slate-50 transition-colors text-left cursor-pointer group"
                    >
                      <div className="w-10 h-10 rounded-full bg-emerald-600 text-white font-black text-base flex items-center justify-center shrink-0 shadow-sm group-hover:scale-105 transition-transform">
                        {initial}
                      </div>
                      <div className="flex-grow min-w-0">
                        <div className="text-xs font-black text-slate-900 truncate">
                          {account.name}
                        </div>
                        <div className="text-[11px] text-slate-600 truncate font-medium">
                          {account.email}
                        </div>
                      </div>
                      <span className="text-xs text-slate-400 group-hover:text-slate-700 font-bold">
                        →
                      </span>
                    </button>
                  );
                })}

                {/* Use another account row */}
                {!showAddGoogleAccount ? (
                  <button
                    type="button"
                    onClick={() => setShowAddGoogleAccount(true)}
                    className="w-full px-4 py-3 flex items-center gap-3 hover:bg-slate-50 transition-colors text-left cursor-pointer text-slate-800"
                  >
                    <div className="w-10 h-10 rounded-full border-2 border-slate-300 flex items-center justify-center text-slate-600 shrink-0">
                      <UserPlus className="w-5 h-5" />
                    </div>
                    <span className="text-xs font-bold text-slate-800">
                      Use another account
                    </span>
                  </button>
                ) : (
                  <div className="p-3 bg-slate-50 space-y-2 animate-fade-in">
                    <div className="text-[11px] font-black text-slate-800">
                      Add Custom Google Account:
                    </div>
                    <input
                      type="text"
                      placeholder="আপনার নাম (যেমন: Joy Sarker)"
                      value={newGoogleName}
                      onChange={(e) => setNewGoogleName(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-bold text-slate-900 focus:outline-none focus:border-blue-500"
                    />
                    <input
                      type="email"
                      placeholder="ইমেইল (যেমন: joysaker5@gmail.com)"
                      value={newGoogleEmail}
                      onChange={(e) => setNewGoogleEmail(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-bold text-slate-900 focus:outline-none focus:border-blue-500"
                    />
                    <div className="flex gap-2 pt-1">
                      <button
                        type="button"
                        onClick={handleAddNewGoogleAccount}
                        className="flex-1 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow cursor-pointer"
                      >
                        Add & Sign In
                      </button>
                      <button
                        type="button"
                        onClick={() => setShowAddGoogleAccount(false)}
                        className="px-3 py-2 rounded-xl bg-slate-200 text-slate-700 font-bold text-xs cursor-pointer"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                )}
              </div>

              {/* Bottom Video Note */}
              <p className="text-[10px] leading-relaxed text-slate-600 text-center px-3 pt-1">
                To continue, Google will share your name, email address and profile picture with Ludo Live. Before using this app, review its{' '}
                <span className="underline font-semibold cursor-pointer text-blue-700">privacy policy</span> and{' '}
                <span className="underline font-semibold cursor-pointer text-blue-700">terms of service</span>.
              </p>

              <div className="text-center pt-1">
                <button
                  type="button"
                  onClick={() => {
                    Sound.playClick();
                    setView('login');
                  }}
                  className="text-xs font-bold text-slate-600 hover:text-slate-900 underline cursor-pointer"
                >
                  ← লগইন অপশনে ফিরে যান
                </button>
              </div>
            </div>
          )}

          {/* VIEW: WHATSAPP ACCESS (Video Style) */}
          {view === 'whatsapp_access' && (
            <div className="space-y-4 animate-fade-in">
              <div className="text-center space-y-1.5 pt-1">
                <div className="w-12 h-12 rounded-2xl bg-[#25D366] mx-auto flex items-center justify-center text-white shadow-md">
                  <svg className="w-7 h-7 fill-current" viewBox="0 0 24 24">
                    <path d="M17.472 14.382c-.301-.15-1.782-.879-2.058-.98-.276-.1-.477-.15-.678.15s-.778.98-.954 1.181c-.176.2-.351.226-.652.075s-1.272-.469-2.423-1.496c-.896-.799-1.5-1.786-1.676-2.087s-.019-.464.132-.614c.135-.135.301-.351.452-.527s.201-.301.301-.502c.101-.2.05-.376-.025-.527s-.678-1.631-.929-2.233c-.245-.587-.494-.507-.678-.517l-.578-.01c-.2 0-.527.075-.803.376s-1.054 1.03-1.054 2.511c0 1.481 1.079 2.91 1.229 3.111.15.201 2.124 3.243 5.145 4.549.719.311 1.28.497 1.718.636.722.23 1.379.197 1.9.119.58-.088 1.782-.728 2.033-1.431.251-.703.251-1.305.176-1.431-.076-.126-.277-.201-.578-.351zM12.04 21.785h-.002a9.78 9.78 0 0 1-4.992-1.365l-.358-.213-3.712.974.991-3.619-.233-.371A9.78 9.78 0 0 1 2.25 12.04c0-5.395 4.39-9.785 9.79-9.785a9.75 9.75 0 0 1 6.924 2.869 9.75 9.75 0 0 1 2.868 6.921c0 5.396-4.39 9.786-9.792 9.786zm0-17.785a7.99 7.99 0 0 0-8 8c0 1.572.457 3.09 1.321 4.402l.205.312-.587 2.146 2.196-.576.303.18a7.98 7.98 0 0 0 4.562 1.336c4.411 0 8-3.589 8-8s-3.589-8-8-8z" />
                  </svg>
                </div>
                <div>
                  <h3 className="text-base font-black text-slate-900 tracking-tight">
                    Log in with WhatsApp
                  </h3>
                  <p className="text-xs text-slate-600 flex items-center justify-center gap-1.5 mt-0.5">
                    <span>to continue to</span>
                    <span className="font-bold text-amber-800 flex items-center gap-1">
                      🎲 Ludo Live
                    </span>
                  </p>
                </div>
              </div>

              {/* Phone details card */}
              <div className="p-4 rounded-2xl bg-white border-2 border-emerald-200 shadow-sm space-y-3">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-emerald-100 border-2 border-emerald-400 overflow-hidden flex items-center justify-center shrink-0">
                    <img
                      src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${whatsAppPhone || 'WhatsAppPlayer'}`}
                      alt="WhatsApp Avatar"
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <div className="flex-grow min-w-0">
                    <div className="flex items-center gap-1.5">
                      <span className="text-sm font-black text-slate-900 truncate">
                        {whatsAppPhone || '+880 1712-345678'}
                      </span>
                      <span className="px-1.5 py-0.5 rounded-md bg-[#25D366] text-white text-[9px] font-black">
                        WhatsApp Verified ✓
                      </span>
                    </div>
                    <div className="text-xs text-emerald-700 font-semibold">
                      তাত্ক্ষণিক ওটিপি ভেরিফিকেশন সক্রিয়
                    </div>
                  </div>
                </div>

                <div className="space-y-2 pt-2 border-t border-emerald-100">
                  <div>
                    <label className="text-[11px] font-bold text-slate-700 block mb-1">
                      হোয়াটসঅ্যাপ মোবাইল নাম্বার:
                    </label>
                    <input
                      type="text"
                      value={whatsAppPhone}
                      onChange={(e) => setWhatsAppPhone(e.target.value)}
                      placeholder="+880 1712-345678"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold text-slate-900 focus:outline-none focus:border-emerald-600"
                    />
                  </div>
                </div>
              </div>

              {/* Continue with WhatsApp button */}
              <button
                type="button"
                id="whatsapp-verify-confirm-btn"
                onClick={handleWhatsAppVerifiedLogin}
                disabled={isLoading}
                className="w-full py-3 px-4 rounded-2xl bg-[#25D366] hover:bg-[#22bf5b] text-white font-black text-sm shadow-md hover:shadow-lg active:scale-98 transition-all flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer"
              >
                {isLoading ? (
                  <RefreshCw className="w-4 h-4 animate-spin" />
                ) : (
                  <>
                    <span>Continue with WhatsApp</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>

              <div className="text-center pt-1">
                <button
                  type="button"
                  onClick={() => {
                    Sound.playClick();
                    setView('login');
                  }}
                  className="text-xs font-bold text-slate-600 hover:text-slate-900 underline cursor-pointer"
                >
                  Cancel and return to login
                </button>
              </div>
            </div>
          )}

          {/* VIEW: FORGOT PASSWORD */}
          {view === 'forgot_password' && (
            <div className="space-y-4 animate-fade-in">
              <div className="text-center space-y-1">
                <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-400 mx-auto flex items-center justify-center text-amber-800">
                  <KeyRound className="w-6 h-6" />
                </div>
                <h3 className="text-sm font-black text-amber-950">পাসওয়ার্ড ভুলে গেছেন?</h3>
                <p className="text-xs text-amber-800">
                  আপনার নিবন্ধিত ইমেইল বা ফোন নাম্বারে একটি ভেরিফিকেশন ওটিপি পাঠানো হবে
                </p>
              </div>

              <form onSubmit={handleRequestPasswordReset} className="space-y-3">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-bold text-amber-900">
                      নিবন্ধিত ইমেইল বা মোবাইল নাম্বার:
                    </label>
                    {detectedOperator && (
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${detectedOperator.color}`}>
                        {detectedOperator.name}
                      </span>
                    )}
                  </div>
                  <div className="flex gap-1.5 items-center">
                    <CountryPicker
                      selectedCountry={selectedCountry}
                      onSelectCountry={(c) => {
                        setSelectedCountry(c);
                        Sound.playClick();
                      }}
                      disabled={isLoading}
                    />
                    <div className="relative flex-grow">
                      <Mail className="w-4 h-4 text-amber-600 absolute left-3.5 top-1/2 -translate-y-1/2" />
                      <input
                        id="forgot-email-input"
                        type="text"
                        placeholder="017... অথবা yourname@gmail.com"
                        value={emailOrPhone}
                        onChange={(e) => {
                          const val = e.target.value;
                          setEmailOrPhone(val);
                          const detected = detectCountryFromPhoneInput(val);
                          if (detected) setSelectedCountry(detected.country);
                        }}
                        className="w-full pl-10 pr-3 py-2.5 bg-white border-2 border-amber-200 focus:border-amber-500 rounded-2xl text-xs font-semibold focus:outline-none transition-all placeholder:text-amber-900/40"
                      />
                    </div>
                  </div>
                </div>

                <button
                  type="submit"
                  id="forgot-submit-btn"
                  disabled={isLoading || !emailOrPhone.trim()}
                  className="w-full py-3 px-4 rounded-2xl bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 text-white font-black text-sm shadow-md hover:shadow-lg active:scale-98 transition-all flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer"
                >
                  {isLoading ? (
                    <RefreshCw className="w-4 h-4 animate-spin" />
                  ) : (
                    <>
                      <span>রিসেট ওটিপি কোড পাঠান</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </form>

              <div className="text-center pt-1">
                <button
                  type="button"
                  onClick={() => {
                    Sound.playClick();
                    setView('login');
                  }}
                  className="text-xs font-bold text-amber-800 hover:text-amber-950 underline"
                >
                  লগইন পাতায় ফিরে যান
                </button>
              </div>
            </div>
          )}

          {/* VIEW: RESET PASSWORD */}
          {view === 'reset_password' && (
            <div className="space-y-3.5 animate-fade-in">
              <div className="text-center space-y-1">
                <h3 className="text-sm font-black text-amber-950">নতুন পাসওয়ার্ড সেট করুন</h3>
                <p className="text-xs text-amber-800">
                  {emailOrPhone || phoneNumber} এ পাঠানো ওটিপি দিন এবং নতুন পাসওয়ার্ড তৈরি করুন
                </p>
              </div>

              {/* Simulation Banner */}
              {activeOtpInfo && (
                <div className="p-3 rounded-2xl bg-amber-100/90 border-2 border-dashed border-amber-400 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <Smartphone className="w-4 h-4 text-amber-700 shrink-0" />
                    <div className="text-left">
                      <div className="text-[11px] font-bold text-amber-950">রিসেট ওটিপি কোড:</div>
                      <div className="text-sm font-black tracking-widest text-amber-900">
                        {activeOtpInfo.otp}
                      </div>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={fillAutoOtp}
                    className="px-3 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-[11px] font-bold shadow transition-all active:scale-95"
                  >
                    অটো ফিল
                  </button>
                </div>
              )}

              {/* 6 Digit Input Boxes */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-amber-900 block text-center">
                  ৬ ডিজিটের ভেরিফিকেশন ওটিপি:
                </label>
                <div className="flex justify-center gap-2" onPaste={handlePasteOtp}>
                  {otpDigits.map((digit, index) => (
                    <input
                      key={index}
                      ref={(el) => (otpInputRefs.current[index] = el)}
                      type="text"
                      inputMode="numeric"
                      maxLength={1}
                      value={digit}
                      onChange={(e) => handleOtpBoxChange(index, e.target.value)}
                      onKeyDown={(e) => handleOtpKeyDown(index, e)}
                      className="w-10 h-12 text-center text-lg font-black bg-white border-2 border-amber-300 focus:border-amber-600 rounded-xl focus:outline-none shadow-inner text-amber-950"
                    />
                  ))}
                </div>
              </div>

              <form onSubmit={handleResetPasswordSubmit} className="space-y-2.5">
                <div>
                  <label className="text-xs font-bold text-amber-900 block mb-1">
                    নতুন পাসওয়ার্ড:
                  </label>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-amber-600 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      id="reset-new-password-input"
                      type={showPassword ? 'text' : 'password'}
                      placeholder="কমপক্ষে ৬ অক্ষরের নতুন পাসওয়ার্ড"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full pl-10 pr-10 py-2 bg-white border-2 border-amber-200 focus:border-amber-500 rounded-2xl text-xs font-semibold focus:outline-none transition-all placeholder:text-amber-900/40"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-amber-600 hover:text-amber-900 p-1"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <div>
                  <label className="text-xs font-bold text-amber-900 block mb-1">
                    নতুন পাসওয়ার্ড নিশ্চিত করুন:
                  </label>
                  <div className="relative">
                    <ShieldCheck className="w-4 h-4 text-amber-600 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      id="reset-confirm-password-input"
                      type={showConfirmPassword ? 'text' : 'password'}
                      placeholder="পুনরায় একই নতুন পাসওয়ার্ড দিন"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      className="w-full pl-10 pr-10 py-2 bg-white border-2 border-amber-200 focus:border-amber-500 rounded-2xl text-xs font-semibold focus:outline-none transition-all placeholder:text-amber-900/40"
                    />
                    <button
                      type="button"
                      onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-amber-600 hover:text-amber-900 p-1"
                    >
                      {showConfirmPassword ? (
                        <EyeOff className="w-4 h-4" />
                      ) : (
                        <Eye className="w-4 h-4" />
                      )}
                    </button>
                  </div>
                </div>

                <button
                  type="submit"
                  id="reset-submit-btn"
                  disabled={isLoading}
                  className="w-full py-3 px-4 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-black text-sm shadow-md hover:shadow-lg active:scale-98 transition-all flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer"
                >
                  {isLoading ? (
                    <RefreshCw className="w-4 h-4 animate-spin" />
                  ) : (
                    <>
                      <CheckCircle2 className="w-4 h-4" />
                      <span>পাসওয়ার্ড পরিবর্তন ও সংরক্ষণ</span>
                    </>
                  )}
                </button>
              </form>
            </div>
          )}

          {/* VIEW: CHANGE PASSWORD (For Logged In User) */}
          {view === 'change_password' && (
            <div className="space-y-3.5 animate-fade-in">
              <form onSubmit={handleChangePassword} className="space-y-3">
                {currentUser.hasPassword && (
                  <div>
                    <label className="text-xs font-bold text-amber-900 block mb-1">
                      বর্তমান পাসওয়ার্ড:
                    </label>
                    <div className="relative">
                      <Lock className="w-4 h-4 text-amber-600 absolute left-3.5 top-1/2 -translate-y-1/2" />
                      <input
                        id="change-old-password-input"
                        type={showOldPassword ? 'text' : 'password'}
                        placeholder="আপনার বর্তমান পাসওয়ার্ড দিন"
                        value={oldPassword}
                        onChange={(e) => setOldPassword(e.target.value)}
                        className="w-full pl-10 pr-10 py-2.5 bg-white border-2 border-amber-200 focus:border-amber-500 rounded-2xl text-xs font-semibold focus:outline-none transition-all placeholder:text-amber-900/40"
                      />
                      <button
                        type="button"
                        onClick={() => setShowOldPassword(!showOldPassword)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-amber-600 hover:text-amber-900 p-1"
                      >
                        {showOldPassword ? (
                          <EyeOff className="w-4 h-4" />
                        ) : (
                          <Eye className="w-4 h-4" />
                        )}
                      </button>
                    </div>
                  </div>
                )}

                <div>
                  <label className="text-xs font-bold text-amber-900 block mb-1">
                    নতুন পাসওয়ার্ড:
                  </label>
                  <div className="relative">
                    <KeyRound className="w-4 h-4 text-amber-600 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      id="change-new-password-input"
                      type={showPassword ? 'text' : 'password'}
                      placeholder="কমপক্ষে ৬ অক্ষরের নতুন পাসওয়ার্ড"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full pl-10 pr-10 py-2.5 bg-white border-2 border-amber-200 focus:border-amber-500 rounded-2xl text-xs font-semibold focus:outline-none transition-all placeholder:text-amber-900/40"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-amber-600 hover:text-amber-900 p-1"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <div>
                  <label className="text-xs font-bold text-amber-900 block mb-1">
                    নতুন পাসওয়ার্ড নিশ্চিত করুন:
                  </label>
                  <div className="relative">
                    <ShieldCheck className="w-4 h-4 text-amber-600 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      id="change-confirm-password-input"
                      type={showConfirmPassword ? 'text' : 'password'}
                      placeholder="পুনরায় নতুন পাসওয়ার্ড লিখুন"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      className="w-full pl-10 pr-10 py-2.5 bg-white border-2 border-amber-200 focus:border-amber-500 rounded-2xl text-xs font-semibold focus:outline-none transition-all placeholder:text-amber-900/40"
                    />
                    <button
                      type="button"
                      onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-amber-600 hover:text-amber-900 p-1"
                    >
                      {showConfirmPassword ? (
                        <EyeOff className="w-4 h-4" />
                      ) : (
                        <Eye className="w-4 h-4" />
                      )}
                    </button>
                  </div>
                </div>

                <div className="flex gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => {
                      Sound.playClick();
                      setView('profile');
                    }}
                    className="w-1/2 py-2.5 rounded-2xl bg-amber-200/80 hover:bg-amber-300 text-amber-950 font-bold text-xs transition-all"
                  >
                    বাতিল
                  </button>
                  <button
                    type="submit"
                    id="change-save-btn"
                    className="w-1/2 py-2.5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs shadow-md transition-all cursor-pointer"
                  >
                    পাসওয়ার্ড সেভ করুন
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* VIEW: PROFILE & ACCOUNT SETTINGS */}
          {view === 'profile' && (
            <div className="space-y-4 animate-fade-in">
              {/* Profile Card */}
              <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-500/10 via-orange-500/10 to-amber-600/10 border-2 border-amber-300 flex items-center gap-3.5">
                <div className="relative">
                  <div className="w-14 h-14 rounded-2xl bg-amber-500 text-white border-2 border-white shadow-md flex items-center justify-center font-black text-xl overflow-hidden">
                    {currentUser.avatarUrl ? (
                      <img
                        src={currentUser.avatarUrl}
                        alt="Avatar"
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      currentUser.name.charAt(0)
                    )}
                  </div>
                  {currentUser.isVerified && (
                    <div className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-blue-500 text-white flex items-center justify-center shadow">
                      <Check className="w-3 h-3 stroke-[3]" />
                    </div>
                  )}
                </div>

                <div className="flex-grow min-w-0">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <h3 className="text-base font-black text-amber-950 truncate">
                      {currentUser.name}
                    </h3>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-amber-600 text-white">
                      {currentUser.provider === 'google'
                        ? 'Google'
                        : currentUser.provider === 'facebook'
                        ? 'Facebook'
                        : currentUser.provider === 'phone'
                        ? 'Mobile OTP'
                        : currentUser.provider === 'email'
                        ? 'Email'
                        : 'গেস্ট'}
                    </span>
                  </div>
                  <div className="text-xs font-semibold text-amber-800 truncate">
                    {currentUser.email || currentUser.phone || `আইডি: ${currentUser.id}`}
                  </div>
                  <div className="text-[11px] font-medium text-amber-700/80">
                    অ্যাকাউন্ট স্ট্যাটাস:{' '}
                    <span className="text-emerald-700 font-bold">
                      {currentUser.provider === 'guest' ? 'গেস্ট মোড' : 'ভেরিফাইড প্লেয়ার ✓'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Linked Providers */}
              <div className="space-y-2">
                <span className="text-xs font-bold text-amber-900 block">
                  সংযুক্ত অ্যাকাউন্ট ও সোশ্যাল লিংক:
                </span>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={handleGoogleLogin}
                    className={`p-2.5 rounded-2xl border-2 flex items-center justify-between text-xs font-bold transition-all ${
                      currentUser.linkedProviders.includes('google')
                        ? 'bg-blue-50 border-blue-300 text-blue-900'
                        : 'bg-white border-amber-200 text-amber-900 hover:bg-amber-50'
                    }`}
                  >
                    <div className="flex items-center gap-1.5">
                      <svg className="w-3.5 h-3.5" viewBox="0 0 24 24">
                        <path
                          fill="#4285F4"
                          d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17Z"
                        />
                        <path
                          fill="#34A853"
                          d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.33 24 12 24Z"
                        />
                        <path
                          fill="#FBBC05"
                          d="M5.28 14.27A7.16 7.16 0 0 1 4.9 12c0-.79.14-1.57.38-2.27V6.58H1.25A11.96 11.96 0 0 0 0 12c0 1.92.45 3.74 1.25 5.42l4.03-3.15Z"
                        />
                        <path
                          fill="#EA4335"
                          d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.33 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98Z"
                        />
                      </svg>
                      <span>গুগল</span>
                    </div>
                    {currentUser.linkedProviders.includes('google') ? (
                      <span className="text-[10px] text-emerald-600 font-black">লিঙ্কড ✓</span>
                    ) : (
                      <span className="text-[10px] text-amber-700 font-bold">+ যুক্ত করুন</span>
                    )}
                  </button>

                  <button
                    onClick={handleFacebookLogin}
                    className={`p-2.5 rounded-2xl border-2 flex items-center justify-between text-xs font-bold transition-all ${
                      currentUser.linkedProviders.includes('facebook')
                        ? 'bg-blue-50 border-blue-400 text-blue-900'
                        : 'bg-white border-amber-200 text-amber-900 hover:bg-amber-50'
                    }`}
                  >
                    <div className="flex items-center gap-1.5">
                      <svg className="w-3.5 h-3.5 fill-[#1877F2]" viewBox="0 0 24 24">
                        <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                      </svg>
                      <span>ফেসবুক</span>
                    </div>
                    {currentUser.linkedProviders.includes('facebook') ? (
                      <span className="text-[10px] text-emerald-600 font-black">লিঙ্কড ✓</span>
                    ) : (
                      <span className="text-[10px] text-amber-700 font-bold">+ যুক্ত করুন</span>
                    )}
                  </button>
                </div>
              </div>

              {/* Age Verification & Safety Status */}
              <div className="p-3 rounded-2xl bg-amber-50/80 border border-amber-200 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-emerald-100 border border-emerald-300 flex items-center justify-center text-emerald-700 shrink-0">
                    <ShieldCheck className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-black text-amber-950 flex items-center gap-1.5">
                      <span>বয়স সুরক্ষা স্ট্যাটাস:</span>
                      <span className="text-emerald-700 font-bold">
                        {loadUserAgeConfig(currentUser).ageCategory === 'under_13'
                          ? '🧒 কিডস মোড'
                          : loadUserAgeConfig(currentUser).ageCategory === 'teen_13_17'
                          ? '🛡️ টিন মোড'
                          : '👑 ১৮+ আনরেস্ট্রিক্টেড'}
                      </span>
                    </div>
                    <div className="text-[10px] text-amber-800">
                      {loadUserAgeConfig(currentUser).childSafeMode
                        ? 'চাইল্ড সেফটি ও চ্যাট ফিল্টার সক্রিয়'
                        : 'সকল লাইভ আড্ডা রুম ও ভয়েস স্টেজ সক্রিয়'}
                    </div>
                  </div>
                </div>
                <span className="px-2 py-0.5 rounded-full bg-emerald-200 text-emerald-900 text-[10px] font-black">
                  ভেরিফাইড ✓
                </span>
              </div>

              {/* Action Buttons */}
              <div className="space-y-2 pt-2">
                <button
                  type="button"
                  id="profile-change-pass-btn"
                  onClick={() => {
                    Sound.playClick();
                    setPassword('');
                    setConfirmPassword('');
                    setOldPassword('');
                    setView('change_password');
                  }}
                  className="w-full py-2.5 px-3.5 rounded-2xl bg-amber-100/90 hover:bg-amber-200/90 border border-amber-300 text-amber-950 font-bold text-xs flex items-center justify-between transition-all"
                >
                  <div className="flex items-center gap-2">
                    <KeyRound className="w-4 h-4 text-amber-700" />
                    <span>পাসওয়ার্ড পরিবর্তন করুন</span>
                  </div>
                  <ArrowRight className="w-4 h-4 text-amber-700" />
                </button>

                {currentUser.provider === 'guest' ? (
                  <button
                    type="button"
                    id="profile-upgrade-btn"
                    onClick={() => {
                      Sound.playClick();
                      setView('register');
                    }}
                    className="w-full py-3 px-4 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-black text-xs shadow-md flex items-center justify-center gap-2 transition-all cursor-pointer"
                  >
                    <Sparkles className="w-4 h-4" />
                    <span>স্থায়ী একাউন্ট তৈরি করুন (+৫০০ কয়েন ফ্রি)</span>
                  </button>
                ) : (
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      id="profile-switch-account-btn"
                      onClick={() => {
                        Sound.playClick();
                        setView('login');
                      }}
                      className="py-2.5 px-3 rounded-2xl bg-white hover:bg-amber-50 border-2 border-amber-300 text-amber-900 font-bold text-xs flex items-center justify-center gap-1.5 transition-all"
                    >
                      <User className="w-3.5 h-3.5 text-amber-700" />
                      <span>অন্য একাউন্ট লগইন</span>
                    </button>

                    <button
                      type="button"
                      id="profile-logout-btn"
                      onClick={handleLogout}
                      className="py-2.5 px-3 rounded-2xl bg-red-50 hover:bg-red-100 border-2 border-red-200 text-red-700 font-bold text-xs flex items-center justify-center gap-1.5 transition-all"
                    >
                      <LogOut className="w-3.5 h-3.5 text-red-600" />
                      <span>লগআউট করুন</span>
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
