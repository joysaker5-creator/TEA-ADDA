import React, { useState } from 'react';
import {
  Trophy,
  Target,
  Flame,
  Coins,
  TrendingUp,
  Swords,
  Crown,
  Percent,
  Award,
  Zap,
  RotateCcw,
  CheckCircle2,
  Dice5,
  Users,
  Bot,
  Globe,
  Users2,
  Calendar,
  Star,
  Medal,
  Share2,
  Check,
  Sparkles,
  ChevronRight,
  Shield,
} from 'lucide-react';
import { PlayerStats, GameMode, MatchHistoryItem } from '../types';
import { getPlayerRankInfo, calculateAchievements, formatBanglaDate } from '../utils/statsConstants';

interface GameStatsProps {
  stats: PlayerStats;
  onResetStats?: () => void;
  onClaimAchievementReward?: (coins: number) => void;
  userCoins?: number;
}

export const GameStats: React.FC<GameStatsProps> = ({
  stats,
  onResetStats,
  onClaimAchievementReward,
  userCoins,
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'modes' | 'history' | 'achievements'>(
    'overview'
  );
  const [showResetConfirm, setShowResetConfirm] = useState<boolean>(false);
  const [copiedNotification, setCopiedNotification] = useState<boolean>(false);

  // Derived calculations
  const totalGames = Math.max(0, stats.totalGamesPlayed);
  const totalWins = Math.max(0, stats.totalWins);
  const totalLosses = Math.max(0, totalGames - totalWins);
  const winPercentage = totalGames > 0 ? Math.round((totalWins / totalGames) * 100) : 0;

  const rankInfo = getPlayerRankInfo(stats);
  const achievements = calculateAchievements(stats);
  const unlockedCount = achievements.filter((a) => a.isUnlocked).length;

  // Copy shareable summary
  const handleShareStats = () => {
    const text = `🏆 আমার লুডু রয়্যাল লাইভ পরিসংখ্যান:\n🎮 মোট ম্যাচ: ${totalGames.toLocaleString(
      'bn-BD'
    )} টি\n🥇 মোট জয়: ${totalWins.toLocaleString('bn-BD')} টি (${winPercentage.toLocaleString(
      'bn-BD'
    )}% জয়)\n💰 মোট অর্জিত কয়েন: ${stats.totalCoinsEarned.toLocaleString(
      'bn-BD'
    )}\n🔥 সর্বোচ্চ উইন স্ট্রিক: ${stats.highestWinStreak.toLocaleString(
      'bn-BD'
    )}\n🌟 খেলোয়াড় পদবী: ${rankInfo.titleBn} (লেভেল ${rankInfo.level.toLocaleString('bn-BD')})`;

    if (navigator.clipboard) {
      navigator.clipboard.writeText(text);
      setCopiedNotification(true);
      setTimeout(() => setCopiedNotification(false), 3000);
    }
  };

  const modeConfigMap: Record<
    GameMode,
    { titleBn: string; icon: React.ReactNode; colorClass: string; bgClass: string }
  > = {
    'vs-bot': {
      titleBn: 'রোবট বনাম (Vs Bot)',
      icon: <Bot className="w-4 h-4 text-red-500" />,
      colorClass: 'text-red-600',
      bgClass: 'bg-red-50 border-red-200',
    },
    'pass-and-play': {
      titleBn: '৪ জন বন্ধু (Pass & Play)',
      icon: <Users className="w-4 h-4 text-amber-600" />,
      colorClass: 'text-amber-600',
      bgClass: 'bg-amber-50 border-amber-200',
    },
    'team-2v2': {
      titleBn: 'টিম প্লে ২v২ (Team 2v2)',
      icon: <Users2 className="w-4 h-4 text-indigo-600" />,
      colorClass: 'text-indigo-600',
      bgClass: 'bg-indigo-50 border-indigo-200',
    },
    'tournament': {
      titleBn: 'নকআউট টুর্নামেন্ট (Tournament)',
      icon: <Trophy className="w-4 h-4 text-rose-600" />,
      colorClass: 'text-rose-600',
      bgClass: 'bg-rose-50 border-rose-200',
    },
    'quick-match': {
      titleBn: 'কুইক ম্যাচ (Quick 2-Token)',
      icon: <Zap className="w-4 h-4 text-amber-500" />,
      colorClass: 'text-amber-600',
      bgClass: 'bg-amber-50 border-amber-200',
    },
    'online-room': {
      titleBn: 'অনলাইন লাইভ রুম (Online Live)',
      icon: <Globe className="w-4 h-4 text-emerald-600" />,
      colorClass: 'text-emerald-600',
      bgClass: 'bg-emerald-50 border-emerald-200',
    },
  };

  return (
    <div className="flex flex-col h-full text-slate-900">
      {/* Player Level & XP Banner */}
      <div className="bg-gradient-to-r from-amber-600 via-amber-700 to-amber-900 rounded-3xl p-4 sm:p-5 text-white shadow-md border-2 border-amber-500/40 relative overflow-hidden mb-4">
        {/* Glow ambient */}
        <div className="absolute top-0 right-0 -mr-8 -mt-8 w-40 h-40 bg-yellow-400/20 rounded-full blur-2xl pointer-events-none" />

        <div className="flex flex-wrap items-center justify-between gap-3 relative z-10">
          <div className="flex items-center gap-3">
            <div className="w-14 h-14 rounded-2xl bg-amber-400/20 border-2 border-amber-300 flex flex-col items-center justify-center shadow-inner">
              <span className="text-[10px] font-black uppercase text-amber-200 tracking-wider">
                লেভেল
              </span>
              <span className="text-xl font-black text-white leading-none">
                {rankInfo.level.toLocaleString('bn-BD')}
              </span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg sm:text-xl font-black text-white">{rankInfo.titleBn}</h3>
                <span className="bg-amber-400 text-amber-950 text-[10px] font-black px-2 py-0.5 rounded-full shadow-xs">
                  র‍্যাংকড প্রোফাইল
                </span>
              </div>
              <p className="text-xs text-amber-100/90 font-medium mt-0.5">
                মোট অর্জিত অভিজ্ঞতা: {stats.totalCoinsEarned.toLocaleString('bn-BD')} কয়েন ও{' '}
                {stats.totalWins.toLocaleString('bn-BD')} বিজয়
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleShareStats}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/15 hover:bg-white/25 border border-white/30 text-white text-xs font-black shadow-xs transition-all active:scale-95 cursor-pointer"
              title="স্ট্যাটস কপি ও শেয়ার করুন"
            >
              {copiedNotification ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-300" />
                  <span>কপি হয়েছে!</span>
                </>
              ) : (
                <>
                  <Share2 className="w-3.5 h-3.5 text-amber-200" />
                  <span>শেয়ার স্ট্যাটস</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Level Progress Bar */}
        <div className="mt-3.5 pt-3 border-t border-amber-500/30">
          <div className="flex justify-between text-[11px] font-extrabold text-amber-200 mb-1">
            <span>পরবর্তী লেভেল প্রগ্রেস</span>
            <span>
              {rankInfo.xpCurrent.toLocaleString('bn-BD')} /{' '}
              {rankInfo.xpRequired.toLocaleString('bn-BD')} XP ({rankInfo.progressPercent}%)
            </span>
          </div>
          <div className="w-full h-2.5 bg-black/30 rounded-full overflow-hidden p-0.5 border border-amber-400/30">
            <div
              className="h-full bg-gradient-to-r from-yellow-300 to-amber-400 rounded-full transition-all duration-500 shadow-sm"
              style={{ width: `${rankInfo.progressPercent}%` }}
            />
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex items-center gap-1.5 p-1 bg-amber-100/80 rounded-2xl border border-amber-200 mb-4 overflow-x-auto">
        <button
          onClick={() => setActiveTab('overview')}
          className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-black transition-all shrink-0 cursor-pointer ${
            activeTab === 'overview'
              ? 'bg-amber-500 text-white shadow-sm border-b-2 border-amber-700'
              : 'text-amber-900 hover:bg-amber-200/60'
          }`}
        >
          <TrendingUp className="w-3.5 h-3.5" />
          <span>সামগ্রিক পরিসংখ্যান</span>
        </button>

        <button
          onClick={() => setActiveTab('modes')}
          className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-black transition-all shrink-0 cursor-pointer ${
            activeTab === 'modes'
              ? 'bg-amber-500 text-white shadow-sm border-b-2 border-amber-700'
              : 'text-amber-900 hover:bg-amber-200/60'
          }`}
        >
          <Target className="w-3.5 h-3.5" />
          <span>মোড ভিত্তিক ফলাফল</span>
        </button>

        <button
          onClick={() => setActiveTab('history')}
          className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-black transition-all shrink-0 cursor-pointer ${
            activeTab === 'history'
              ? 'bg-amber-500 text-white shadow-sm border-b-2 border-amber-700'
              : 'text-amber-900 hover:bg-amber-200/60'
          }`}
        >
          <Calendar className="w-3.5 h-3.5" />
          <span>ম্যাচ হিস্ট্রি ({stats.history?.length || 0})</span>
        </button>

        <button
          onClick={() => setActiveTab('achievements')}
          className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-black transition-all shrink-0 cursor-pointer ${
            activeTab === 'achievements'
              ? 'bg-amber-500 text-white shadow-sm border-b-2 border-amber-700'
              : 'text-amber-900 hover:bg-amber-200/60'
          }`}
        >
          <Award className="w-3.5 h-3.5" />
          <span>অর্জনসমূহ ({unlockedCount}/{achievements.length})</span>
        </button>
      </div>

      {/* Tab Content 1: Overview */}
      {activeTab === 'overview' && (
        <div className="space-y-4">
          {/* Primary Top 4 Core Metrics Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            {/* Total Games */}
            <div className="bg-white p-3.5 rounded-2xl border-2 border-slate-200 shadow-xs flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-black text-slate-500">মোট ম্যাচ</span>
                <div className="p-1.5 rounded-xl bg-blue-50 text-blue-600 border border-blue-200">
                  <Dice5 className="w-4 h-4" />
                </div>
              </div>
              <div className="mt-2">
                <span className="text-2xl font-black text-slate-900 leading-none">
                  {totalGames.toLocaleString('bn-BD')}
                </span>
                <span className="text-[10px] block font-bold text-slate-400 mt-0.5">ম্যাচ সম্পন্ন</span>
              </div>
            </div>

            {/* Total Wins */}
            <div className="bg-white p-3.5 rounded-2xl border-2 border-emerald-200 shadow-xs flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-black text-emerald-700">মোট জয়</span>
                <div className="p-1.5 rounded-xl bg-emerald-50 text-emerald-600 border border-emerald-200">
                  <Trophy className="w-4 h-4" />
                </div>
              </div>
              <div className="mt-2">
                <span className="text-2xl font-black text-emerald-600 leading-none">
                  {totalWins.toLocaleString('bn-BD')}
                </span>
                <span className="text-[10px] block font-bold text-emerald-700 mt-0.5">
                  পরাজয়: {totalLosses.toLocaleString('bn-BD')}
                </span>
              </div>
            </div>

            {/* Win Percentage */}
            <div className="bg-white p-3.5 rounded-2xl border-2 border-amber-200 shadow-xs flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-black text-amber-800">জয়ের হার</span>
                <div className="p-1.5 rounded-xl bg-amber-50 text-amber-600 border border-amber-200">
                  <Percent className="w-4 h-4" />
                </div>
              </div>
              <div className="mt-2">
                <div className="flex items-baseline gap-1">
                  <span className="text-2xl font-black text-amber-950 leading-none">
                    {winPercentage.toLocaleString('bn-BD')}%
                  </span>
                </div>
                <div className="w-full bg-slate-100 h-1.5 rounded-full mt-1.5 overflow-hidden">
                  <div
                    className="h-full bg-amber-500 rounded-full"
                    style={{ width: `${winPercentage}%` }}
                  />
                </div>
              </div>
            </div>

            {/* Total Coins Earned */}
            <div className="bg-white p-3.5 rounded-2xl border-2 border-yellow-200 shadow-xs flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-black text-amber-900">মোট অর্জিত কয়েন</span>
                <div className="p-1.5 rounded-xl bg-yellow-50 text-amber-600 border border-yellow-200">
                  <Coins className="w-4 h-4 fill-yellow-400" />
                </div>
              </div>
              <div className="mt-2">
                <span className="text-2xl font-black text-amber-950 leading-none">
                  {stats.totalCoinsEarned.toLocaleString('bn-BD')}
                </span>
                <span className="text-[10px] block font-bold text-amber-700 mt-0.5">লাইফটাইম ইনকাম</span>
              </div>
            </div>
          </div>

          {/* Secondary Stats Grid */}
          <div className="bg-white rounded-3xl p-4 border-2 border-amber-100 shadow-xs space-y-3">
            <h4 className="text-xs font-black text-amber-950 flex items-center gap-1.5 uppercase tracking-wider">
              <Sparkles className="w-3.5 h-3.5 text-amber-600" />
              <span>মাইলস্টোন ও গেমপ্লে হাইলাইটস</span>
            </h4>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
              {/* Win Streak */}
              <div className="p-3 rounded-2xl bg-amber-50/70 border border-amber-200 flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-amber-500 text-white flex items-center justify-center shrink-0 shadow-xs">
                  <Flame className="w-5 h-5 text-yellow-200 fill-amber-300" />
                </div>
                <div>
                  <span className="text-[10px] font-extrabold text-amber-800 block">বর্তমান স্ট্রিক</span>
                  <span className="text-base font-black text-amber-950">
                    {stats.currentWinStreak.toLocaleString('bn-BD')} ম্যাচ
                  </span>
                  <span className="text-[9px] block text-amber-700 font-bold">
                    সর্বোচ্চ: {stats.highestWinStreak.toLocaleString('bn-BD')}
                  </span>
                </div>
              </div>

              {/* Tournament Trophies */}
              <div className="p-3 rounded-2xl bg-rose-50/70 border border-rose-200 flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-rose-600 text-white flex items-center justify-center shrink-0 shadow-xs">
                  <Trophy className="w-5 h-5 text-amber-300" />
                </div>
                <div>
                  <span className="text-[10px] font-extrabold text-rose-800 block">টুর্নামেন্ট ট্রফি</span>
                  <span className="text-base font-black text-rose-950">
                    {stats.tournamentTrophies.toLocaleString('bn-BD')} টি
                  </span>
                  <span className="text-[9px] block text-rose-700 font-bold">গ্র্যান্ড চ্যাম্পিয়ন</span>
                </div>
              </div>

              {/* Pawns to Home */}
              <div className="p-3 rounded-2xl bg-emerald-50/70 border border-emerald-200 flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-xs">
                  <Target className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[10px] font-extrabold text-emerald-800 block">ঘরে পৌঁছানো গুটি</span>
                  <span className="text-base font-black text-emerald-950">
                    {stats.totalTokensHome.toLocaleString('bn-BD')} টি
                  </span>
                  <span className="text-[9px] block text-emerald-700 font-bold">হোম রান সফল</span>
                </div>
              </div>

              {/* Pawns Captured */}
              <div className="p-3 rounded-2xl bg-purple-50/70 border border-purple-200 flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-purple-600 text-white flex items-center justify-center shrink-0 shadow-xs">
                  <Swords className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[10px] font-extrabold text-purple-800 block">গুটি কাটা</span>
                  <span className="text-base font-black text-purple-950">
                    {stats.totalTokensCaptured.toLocaleString('bn-BD')} বার
                  </span>
                  <span className="text-[9px] block text-purple-700 font-bold">প্রতিপক্ষের শিকার</span>
                </div>
              </div>

              {/* Total Sixes Rolled */}
              <div className="p-3 rounded-2xl bg-indigo-50/70 border border-indigo-200 flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-indigo-600 text-white flex items-center justify-center shrink-0 shadow-xs">
                  <Dice5 className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[10px] font-extrabold text-indigo-800 block">ছক্কা (৬) ফেলা</span>
                  <span className="text-base font-black text-indigo-950">
                    {stats.totalSixesRolled.toLocaleString('bn-BD')} বার
                  </span>
                  <span className="text-[9px] block text-indigo-700 font-bold">লাকি ডাইস রোল</span>
                </div>
              </div>

              {/* Win/Loss Ratio */}
              <div className="p-3 rounded-2xl bg-teal-50/70 border border-teal-200 flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-teal-600 text-white flex items-center justify-center shrink-0 shadow-xs">
                  <TrendingUp className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[10px] font-extrabold text-teal-800 block">উইন/লস অনুপাত</span>
                  <span className="text-base font-black text-teal-950">
                    {totalLosses === 0
                      ? 'অপরাজেয়'
                      : (totalWins / Math.max(1, totalLosses)).toFixed(2)}
                  </span>
                  <span className="text-[9px] block text-teal-700 font-bold">ডমিন্যান্স রেটিং</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab Content 2: Mode Breakdown */}
      {activeTab === 'modes' && (
        <div className="space-y-3">
          <div className="bg-amber-50 p-3 rounded-2xl border border-amber-200 text-xs font-bold text-amber-900 flex items-center justify-between">
            <span>বিভিন্ন গেম মোডে আপনার জয়ের পরিসংখ্যান</span>
            <span className="text-[11px] text-amber-700 font-extrabold">৬টি মোড বিশ্লেষণ</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {(Object.keys(modeConfigMap) as GameMode[]).map((mode) => {
              const cfg = modeConfigMap[mode];
              const modeData = stats.modeBreakdown?.[mode] || { played: 0, won: 0 };
              const modeLosses = Math.max(0, modeData.played - modeData.won);
              const modeRate =
                modeData.played > 0 ? Math.round((modeData.won / modeData.played) * 100) : 0;

              return (
                <div
                  key={mode}
                  className={`p-3.5 rounded-2xl border-2 bg-white ${cfg.bgClass} flex flex-col justify-between shadow-xs`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div className="p-1.5 rounded-xl bg-white shadow-xs border border-slate-200">
                        {cfg.icon}
                      </div>
                      <span className="text-xs font-black text-slate-900">{cfg.titleBn}</span>
                    </div>
                    <span
                      className={`text-xs font-black px-2 py-0.5 rounded-full ${
                        modeRate >= 50 ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-700'
                      }`}
                    >
                      {modeRate.toLocaleString('bn-BD')}% জয়
                    </span>
                  </div>

                  <div className="space-y-1.5">
                    <div className="flex justify-between text-[11px] font-bold text-slate-600">
                      <span>ম্যাচ: {modeData.played.toLocaleString('bn-BD')} টি</span>
                      <span>
                        জয়: {modeData.won.toLocaleString('bn-BD')} | হার: {modeLosses.toLocaleString('bn-BD')}
                      </span>
                    </div>

                    <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-amber-500 to-emerald-500 rounded-full transition-all duration-300"
                        style={{ width: `${modeRate}%` }}
                      />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Tab Content 3: Match History */}
      {activeTab === 'history' && (
        <div className="space-y-2.5">
          {(!stats.history || stats.history.length === 0) ? (
            <div className="text-center py-10 bg-white rounded-3xl border-2 border-dashed border-slate-200 p-6">
              <Dice5 className="w-12 h-12 text-slate-300 mx-auto mb-2" />
              <p className="text-sm font-black text-slate-700">কোনো সাম্প্রতিক ম্যাচ হিস্ট্রি নেই</p>
              <p className="text-xs text-slate-400 font-medium mt-1">
                খেলা শেষ হলে স্বয়ংক্রিয়ভাবে এখানে ম্যাচ রেকর্ড যুক্ত হবে।
              </p>
            </div>
          ) : (
            stats.history.map((item) => {
              const isWin = item.result === 'win';
              const cfg = modeConfigMap[item.gameMode] || modeConfigMap['vs-bot'];

              return (
                <div
                  key={item.id}
                  className={`p-3 rounded-2xl border-2 transition-all flex items-center justify-between gap-3 bg-white shadow-xs ${
                    isWin ? 'border-emerald-200 bg-emerald-50/20' : 'border-slate-200'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-10 h-10 rounded-2xl flex items-center justify-center font-black shadow-xs shrink-0 ${
                        isWin
                          ? 'bg-emerald-500 text-white border-b-2 border-emerald-700'
                          : 'bg-slate-200 text-slate-600 border-b-2 border-slate-300'
                      }`}
                    >
                      {isWin ? <Trophy className="w-5 h-5" /> : <Shield className="w-5 h-5" />}
                    </div>

                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-black text-slate-900">{cfg.titleBn}</span>
                        <span
                          className={`text-[10px] font-black px-1.5 py-0.2 rounded-md uppercase ${
                            isWin ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-700'
                          }`}
                        >
                          {isWin ? 'বিজয় 🏆' : 'পরাজিত'}
                        </span>
                      </div>
                      <div className="flex items-center gap-2 text-[10px] text-slate-500 font-bold mt-0.5">
                        <span>{item.date || formatBanglaDate(item.timestamp)}</span>
                        <span>•</span>
                        <span>ঘরে নেওয়া: {item.tokensReachedHome.toLocaleString('bn-BD')}/৪</span>
                        <span>•</span>
                        <span>কাটা গুটি: {item.tokensCaptured.toLocaleString('bn-BD')}</span>
                      </div>
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    {item.coinsEarned > 0 ? (
                      <span className="text-xs font-black text-amber-600 flex items-center gap-1 bg-amber-50 px-2.5 py-1 rounded-xl border border-amber-200">
                        <Coins className="w-3.5 h-3.5 fill-amber-400" />+
                        {item.coinsEarned.toLocaleString('bn-BD')}
                      </span>
                    ) : (
                      <span className="text-[11px] font-bold text-slate-400">+০ কয়েন</span>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}

      {/* Tab Content 4: Achievements */}
      {activeTab === 'achievements' && (
        <div className="space-y-2.5">
          <div className="bg-amber-50 p-3 rounded-2xl border border-amber-200 text-xs font-bold text-amber-900 flex items-center justify-between">
            <span>খেলার মাইলস্টোন অর্জন করে কয়েন রিওয়ার্ড সংগ্রহ করুন</span>
            <span className="bg-amber-200 text-amber-950 text-[10px] font-black px-2 py-0.5 rounded-full">
              {unlockedCount}/{achievements.length} আনলকড
            </span>
          </div>

          <div className="grid grid-cols-1 gap-2.5">
            {achievements.map((ach) => {
              const progressRatio = Math.min(100, Math.round((ach.progress / ach.maxProgress) * 100));

              return (
                <div
                  key={ach.id}
                  className={`p-3.5 rounded-2xl border-2 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white shadow-xs ${
                    ach.isUnlocked
                      ? 'border-emerald-300 bg-emerald-50/20'
                      : 'border-slate-200 opacity-90'
                  }`}
                >
                  <div className="flex items-start sm:items-center gap-3">
                    <div
                      className={`w-10 h-10 rounded-2xl flex items-center justify-center shrink-0 shadow-xs ${
                        ach.isUnlocked
                          ? 'bg-gradient-to-tr from-amber-500 to-yellow-400 text-amber-950 border-b-2 border-amber-600'
                          : 'bg-slate-100 text-slate-400 border border-slate-300'
                      }`}
                    >
                      {ach.isUnlocked ? (
                        <CheckCircle2 className="w-5 h-5 text-emerald-950" />
                      ) : (
                        <Award className="w-5 h-5 text-slate-400" />
                      )}
                    </div>

                    <div>
                      <div className="flex items-center gap-2">
                        <h5 className="text-xs font-black text-slate-900">{ach.titleBn}</h5>
                        {ach.isUnlocked ? (
                          <span className="bg-emerald-100 text-emerald-800 text-[10px] font-black px-1.5 py-0.2 rounded-md">
                            সম্পন্ন ✓
                          </span>
                        ) : (
                          <span className="bg-slate-100 text-slate-600 text-[10px] font-bold px-1.5 py-0.2 rounded-md">
                            চলমান
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-slate-500 font-medium mt-0.5">
                        {ach.descriptionBn}
                      </p>
                    </div>
                  </div>

                  <div className="flex sm:flex-col items-center sm:items-end justify-between gap-1.5 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-100">
                    {ach.rewardCoins && (
                      <span className="text-xs font-black text-amber-600 flex items-center gap-1">
                        <Coins className="w-3.5 h-3.5 fill-amber-400" />+
                        {ach.rewardCoins.toLocaleString('bn-BD')}
                      </span>
                    )}

                    <div className="w-24 sm:w-28 bg-slate-100 h-2 rounded-full overflow-hidden border border-slate-200">
                      <div
                        className={`h-full rounded-full transition-all ${
                          ach.isUnlocked
                            ? 'bg-emerald-500'
                            : 'bg-gradient-to-r from-amber-400 to-amber-600'
                        }`}
                        style={{ width: `${progressRatio}%` }}
                      />
                    </div>
                    <span className="text-[9px] font-extrabold text-slate-400">
                      {ach.progress.toLocaleString('bn-BD')} /{' '}
                      {ach.maxProgress.toLocaleString('bn-BD')}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Footer / Reset Stats Action */}
      <div className="mt-4 pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between text-xs text-slate-500 gap-2">
        <span className="text-[11px] font-bold">
          সর্বশেষ আপডেট: {formatBanglaDate(stats.lastUpdated || Date.now())}
        </span>

        {onResetStats && (
          <div>
            {!showResetConfirm ? (
              <button
                onClick={() => setShowResetConfirm(true)}
                className="flex items-center gap-1 text-[11px] font-bold text-slate-500 hover:text-red-600 transition-colors cursor-pointer"
              >
                <RotateCcw className="w-3 h-3" />
                <span>পরিসংখ্যান রিসেট করুন</span>
              </button>
            ) : (
              <div className="flex items-center gap-2 bg-red-50 px-2.5 py-1 rounded-xl border border-red-200">
                <span className="text-[10px] font-black text-red-700">সত্যিই সব মুছবেন?</span>
                <button
                  onClick={() => {
                    onResetStats();
                    setShowResetConfirm(false);
                  }}
                  className="bg-red-600 hover:bg-red-700 text-white text-[10px] font-black px-2 py-0.5 rounded-lg shadow-xs cursor-pointer"
                >
                  হ্যাঁ, মুছুন
                </button>
                <button
                  onClick={() => setShowResetConfirm(false)}
                  className="bg-slate-200 text-slate-700 text-[10px] font-bold px-1.5 py-0.5 rounded-lg cursor-pointer"
                >
                  না
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
export default GameStats;
