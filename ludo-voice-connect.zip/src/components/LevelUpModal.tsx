import React, { useEffect } from 'react';
import { Sparkles, Crown, Award, CheckCircle2, ArrowUpCircle } from 'lucide-react';
import { LevelUpEventData } from '../types';
import { Sound } from '../utils/soundEffects';

interface LevelUpModalProps {
  isOpen: boolean;
  eventData: LevelUpEventData | null;
  onClose: () => void;
  onClaim: (coins: number, diamonds: number) => void;
}

export const LevelUpModal: React.FC<LevelUpModalProps> = ({
  isOpen,
  eventData,
  onClose,
  onClaim,
}) => {
  useEffect(() => {
    if (isOpen) {
      Sound.playLevelUp();
    }
  }, [isOpen]);

  if (!isOpen || !eventData) return null;

  const handleClaim = () => {
    Sound.playDiamondCollect();
    Sound.playCoinSound();
    onClaim(eventData.rewardCoins, eventData.rewardDiamonds);
    onClose();
  };

  return (
    <div
      id="level-up-celebration-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-300"
    >
      <div className="relative w-full max-w-md bg-gradient-to-b from-slate-900 via-indigo-950 to-slate-950 rounded-3xl p-6 sm:p-8 text-center text-white border-2 border-amber-400 shadow-2xl shadow-amber-500/20 overflow-hidden">
        {/* Background glow effects */}
        <div className="absolute -top-24 left-1/2 -translate-x-1/2 w-64 h-64 bg-amber-500/25 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 left-1/2 -translate-x-1/2 w-64 h-64 bg-cyan-500/25 rounded-full blur-3xl pointer-events-none" />

        {/* Celebration Badges */}
        <div className="relative mb-5 flex flex-col items-center">
          <div className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-amber-500/20 border border-amber-400/50 text-amber-300 text-xs font-black tracking-wider uppercase mb-3 shadow-sm animate-pulse">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>অভিনন্দন! লেভেল আপ!</span>
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          </div>

          {/* Level Circle with Golden Ring */}
          <div className="relative w-28 h-28 flex items-center justify-center">
            <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-amber-400 via-yellow-300 to-amber-500 animate-spin-slow opacity-80 blur-[2px]" />
            <div className="absolute inset-1 rounded-full bg-slate-900 flex flex-col items-center justify-center border-2 border-amber-300 shadow-inner">
              <span className="text-[10px] font-black text-amber-400 uppercase tracking-widest flex items-center gap-0.5">
                <Crown className="w-3 h-3 text-amber-300" /> LEVEL
              </span>
              <span className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-b from-yellow-100 via-amber-300 to-yellow-500 leading-none">
                {eventData.newLevel.toLocaleString('bn-BD')}
              </span>
              <span className="text-[10px] font-bold text-slate-300">
                (আগে {eventData.previousLevel.toLocaleString('bn-BD')})
              </span>
            </div>

            <div className="absolute -bottom-2 px-3 py-0.5 rounded-full bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 text-[11px] font-black shadow-md flex items-center gap-1 border border-yellow-200">
              <ArrowUpCircle className="w-3.5 h-3.5" />
              <span>লেভেল আপ!</span>
            </div>
          </div>
        </div>

        {/* Tier Title */}
        <div className="mb-5">
          <h2 className="text-xl font-black text-white flex items-center justify-center gap-2">
            <span>{eventData.tierTitleBn}</span>
          </h2>
          <p className="text-xs text-slate-300 mt-1">
            আপনার অভিজ্ঞতা বৃদ্ধির সাথে সাথে নতুন পুরস্কার ও মর্যাদা আনলক হয়েছে!
          </p>
        </div>

        {/* Reward cards */}
        <div className="grid grid-cols-2 gap-3 mb-6">
          {/* Coins Reward */}
          <div className="p-3 rounded-2xl bg-amber-500/10 border border-amber-400/40 flex flex-col items-center text-center">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 flex items-center justify-center text-xl mb-1 shadow-inner">
              🪙
            </div>
            <span className="text-[11px] font-bold text-amber-300">ফ্রি কয়েন</span>
            <span className="text-lg font-black text-amber-400">
              +{eventData.rewardCoins.toLocaleString('bn-BD')}
            </span>
          </div>

          {/* Diamonds Reward */}
          <div className="p-3 rounded-2xl bg-cyan-500/10 border border-cyan-400/40 flex flex-col items-center text-center">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/20 flex items-center justify-center text-xl mb-1 shadow-inner">
              💎
            </div>
            <span className="text-[11px] font-bold text-cyan-300">ফ্রি ডায়মন্ড</span>
            <span className="text-lg font-black text-cyan-400">
              +{eventData.rewardDiamonds.toLocaleString('bn-BD')}
            </span>
          </div>
        </div>

        {/* Exclusive item if any */}
        {eventData.exclusivePerk && (
          <div className="mb-6 p-2.5 rounded-2xl bg-gradient-to-r from-purple-900/40 via-indigo-900/40 to-purple-900/40 border border-purple-400/50 flex items-center gap-3 text-left">
            <div className="w-8 h-8 rounded-xl bg-purple-500/20 flex items-center justify-center text-purple-300 shrink-0">
              <Award className="w-5 h-5 text-purple-300" />
            </div>
            <div>
              <span className="text-[10px] uppercase tracking-wider font-extrabold text-purple-300 block">
                আনলক হওয়া স্পেশাল পার্ক
              </span>
              <span className="text-xs font-black text-white">
                {eventData.exclusivePerk}
              </span>
            </div>
          </div>
        )}

        {/* Claim Action Button */}
        <button
          id="btn-claim-level-up-rewards"
          onClick={handleClaim}
          className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 active:scale-95 text-slate-950 font-black text-base shadow-lg shadow-amber-500/30 transition-all flex items-center justify-center gap-2 cursor-pointer border-t border-yellow-200"
        >
          <CheckCircle2 className="w-5 h-5 text-slate-950" />
          <span>পুরস্কার সংগ্রহ করুন</span>
        </button>
      </div>
    </div>
  );
};
