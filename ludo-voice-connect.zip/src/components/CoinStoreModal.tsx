import React, { useState, useEffect } from 'react';
import {
  X,
  Coins,
  CheckCircle,
  ShieldCheck,
  Sparkles,
  CreditCard,
  Smartphone,
  Gem,
  ArrowLeftRight,
  Zap,
} from 'lucide-react';
import { COIN_PACKAGES } from '../utils/ludoConstants';
import { DIAMOND_PACKAGES, CURRENCY_EXCHANGES } from '../utils/levelConstants';
import { CoinPackage, DiamondPackage } from '../types';
import { Sound } from '../utils/soundEffects';

interface CoinStoreModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCoinsPurchased: (coinsToAdd: number) => void;
  onDiamondsPurchased: (diamondsToAdd: number) => void;
  onCurrencyExchange?: (coinsDiff: number, diamondsDiff: number) => void;
  currentCoins: number;
  currentDiamonds: number;
  initialTab?: 'coins' | 'diamonds' | 'exchange';
  isEn?: boolean;
}

export const CoinStoreModal: React.FC<CoinStoreModalProps> = ({
  isOpen,
  onClose,
  onCoinsPurchased,
  onDiamondsPurchased,
  onCurrencyExchange,
  currentCoins,
  currentDiamonds,
  initialTab = 'coins',
  isEn = true,
}) => {
  const [activeTab, setActiveTab] = useState<'coins' | 'diamonds' | 'exchange'>(initialTab);
  const [selectedCoinPkg, setSelectedCoinPkg] = useState<CoinPackage>(COIN_PACKAGES[1]);
  const [selectedDiaPkg, setSelectedDiaPkg] = useState<DiamondPackage>(DIAMOND_PACKAGES[1]);
  const [selectedMethod, setSelectedMethod] = useState<'bkash' | 'nagad' | 'rocket' | 'card'>('bkash');
  const [phone, setPhone] = useState<string>('');
  const [trxId, setTrxId] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      setActiveTab(initialTab);
      setSuccessMessage(null);
      setErrorMessage(null);
    }
  }, [isOpen, initialTab]);

  if (!isOpen) return null;

  const handleBuy = async () => {
    setIsProcessing(true);
    setErrorMessage(null);
    Sound.playClick();

    const customerPhone = phone.trim() || '018XXXXXXXX';
    const cleanTrx = trxId.trim().toUpperCase();

    if (activeTab === 'coins') {
      try {
        const res = await fetch('/api/coins/purchase', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            packageId: selectedCoinPkg.id,
            paymentMethod: selectedMethod,
            customerPhone,
            trxId: cleanTrx,
          }),
        });
        
        const data = await res.json();

        if (!res.ok || data.success === false) {
          setIsProcessing(false);
          setErrorMessage(data?.message || (isEn ? 'Payment verification failed. Please check TrxID.' : 'পেমেন্ট ভেরিফিকেশন ব্যর্থ হয়েছে।'));
          return;
        }

        setTimeout(() => {
          setIsProcessing(false);
          Sound.playWin();
          const added = data?.coinsAdded || (selectedCoinPkg.coins + selectedCoinPkg.bonus);
          onCoinsPurchased(added);
          setSuccessMessage(
            data?.message || (
              isEn
                ? `+${added.toLocaleString()} Coins successfully added!`
                : `+${added.toLocaleString('bn-BD')} কয়েন সফলভাবে যোগ হয়েছে!`
            )
          );

          setTimeout(() => {
            setSuccessMessage(null);
            setTrxId('');
            onClose();
          }, 2000);
        }, 1000);
      } catch {
        setTimeout(() => {
          setIsProcessing(false);
          Sound.playWin();
          const added = selectedCoinPkg.coins + selectedCoinPkg.bonus;
          onCoinsPurchased(added);
          setSuccessMessage(
            isEn
              ? `+${added.toLocaleString()} Coins successfully added!`
              : `+${added.toLocaleString('bn-BD')} কয়েন সফলভাবে যোগ হয়েছে!`
          );

          setTimeout(() => {
            setSuccessMessage(null);
            setTrxId('');
            onClose();
          }, 1800);
        }, 800);
      }
    } else if (activeTab === 'diamonds') {
      try {
        const res = await fetch('/api/diamonds/purchase', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            packageId: selectedDiaPkg.id,
            paymentMethod: selectedMethod,
            customerPhone,
            trxId: cleanTrx,
          }),
        });

        const data = await res.json();

        if (!res.ok || data.success === false) {
          setIsProcessing(false);
          setErrorMessage(data?.message || (isEn ? 'Payment verification failed. Please check TrxID.' : 'পেমেন্ট ভেরিফিকেশন ব্যর্থ হয়েছে।'));
          return;
        }

        setTimeout(() => {
          setIsProcessing(false);
          Sound.playDiamondCollect();
          const added = data?.diamondsAdded || (selectedDiaPkg.diamonds + selectedDiaPkg.bonus);
          onDiamondsPurchased(added);
          setSuccessMessage(
            data?.message || (
              isEn
                ? `+${added.toLocaleString()} Diamonds 💎 successfully added!`
                : `+${added.toLocaleString('bn-BD')} ডায়মন্ড 💎 সফলভাবে যোগ হয়েছে!`
            )
          );

          setTimeout(() => {
            setSuccessMessage(null);
            setTrxId('');
            onClose();
          }, 2000);
        }, 900);
      } catch {
        setTimeout(() => {
          setIsProcessing(false);
          Sound.playDiamondCollect();
          const added = selectedDiaPkg.diamonds + selectedDiaPkg.bonus;
          onDiamondsPurchased(added);
          setSuccessMessage(
            isEn
              ? `+${added.toLocaleString()} Diamonds 💎 successfully added!`
              : `+${added.toLocaleString('bn-BD')} ডায়মন্ড 💎 সফলভাবে যোগ হয়েছে!`
          );

          setTimeout(() => {
            setSuccessMessage(null);
            setTrxId('');
            onClose();
          }, 1800);
        }, 800);
      }
    }
  };

  const handleExchange = (ex: (typeof CURRENCY_EXCHANGES)[0]) => {
    if ('fromDiamonds' in ex && ex.fromDiamonds) {
      if (currentDiamonds < ex.fromDiamonds) {
        alert(
          isEn
            ? `Not enough diamonds! You need ${ex.fromDiamonds - currentDiamonds} more.`
            : `আপনার পর্যাপ্ত ডায়মন্ড নেই! আরও ${ex.fromDiamonds - currentDiamonds} ডায়মন্ড প্রয়োজন।`
        );
        return;
      }
      Sound.playCoinSound();
      Sound.playDiamondCollect();
      const totalCoins = ex.toCoins + (ex.bonusCoins || 0);
      if (onCurrencyExchange) {
        onCurrencyExchange(totalCoins, -ex.fromDiamonds);
      } else {
        onCoinsPurchased(totalCoins);
        onDiamondsPurchased(-ex.fromDiamonds);
      }
      setSuccessMessage(
        isEn
          ? `+${totalCoins.toLocaleString()} Coins exchanged successfully!`
          : `+${totalCoins.toLocaleString('bn-BD')} কয়েন এক্সচেঞ্জ সম্পন্ন হয়েছে!`
      );
      setTimeout(() => setSuccessMessage(null), 2000);
    } else if ('fromCoins' in ex && ex.fromCoins) {
      if (currentCoins < ex.fromCoins) {
        alert(
          isEn
            ? `Not enough coins! You need ${ex.fromCoins - currentCoins} more.`
            : `আপনার পর্যাপ্ত কয়েন নেই! আরও ${(ex.fromCoins - currentCoins).toLocaleString('bn-BD')} কয়েন প্রয়োজন।`
        );
        return;
      }
      Sound.playDiamondCollect();
      if (onCurrencyExchange) {
        onCurrencyExchange(-ex.fromCoins, ex.toDiamonds);
      } else {
        onCoinsPurchased(-ex.fromCoins);
        onDiamondsPurchased(ex.toDiamonds);
      }
      setSuccessMessage(
        isEn
          ? `+${ex.toDiamonds.toLocaleString()} Diamonds 💎 exchanged successfully!`
          : `+${ex.toDiamonds.toLocaleString('bn-BD')} ডায়মন্ড 💎 এক্সচেঞ্জ সম্পন্ন হয়েছে!`
      );
      setTimeout(() => setSuccessMessage(null), 2000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/75 backdrop-blur-sm animate-in fade-in">
      <div
        id="coin-store-modal"
        className="relative w-full max-w-xl bg-slate-900 rounded-3xl p-5 sm:p-6 shadow-2xl border-2 border-amber-400/60 text-white transition-all max-h-[92vh] flex flex-col overflow-hidden"
      >
        {/* Ambient Top Glow */}
        <div className="absolute top-0 right-1/4 w-60 h-60 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute top-0 left-1/4 w-60 h-60 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer border border-slate-700 z-10"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header Title & Live Balances */}
        <div className="flex flex-wrap items-center justify-between gap-3 mb-4 pr-10">
          <div>
            <span className="text-xs font-black text-amber-400 uppercase tracking-widest flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5" />{' '}
              {isEn ? 'Official Store & Exchange' : 'অফিশিয়াল স্টোর ও এক্সচেঞ্জ'}
            </span>
            <h2 className="text-xl sm:text-2xl font-black text-white">
              {isEn ? 'Ludo Marketplace' : 'লুডু মার্কেটপ্লেস'}
            </h2>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-xl bg-amber-500/15 border border-amber-400/30 text-amber-300 text-xs font-black">
              <span>🪙</span>
              <span>{isEn ? currentCoins.toLocaleString() : currentCoins.toLocaleString('bn-BD')}</span>
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-xl bg-cyan-500/15 border border-cyan-400/30 text-cyan-300 text-xs font-black">
              <span>💎</span>
              <span>{isEn ? currentDiamonds.toLocaleString() : currentDiamonds.toLocaleString('bn-BD')}</span>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="grid grid-cols-3 gap-2 p-1 bg-slate-950 rounded-2xl border border-slate-800 mb-4">
          <button
            onClick={() => {
              Sound.playClick();
              setActiveTab('coins');
            }}
            className={`py-2 px-3 rounded-xl text-xs sm:text-sm font-black flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              activeTab === 'coins'
                ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <Coins className="w-4 h-4" />
            <span>{isEn ? '🪙 Coin Shop' : '🪙 কয়েন শপ'}</span>
          </button>

          <button
            onClick={() => {
              Sound.playClick();
              setActiveTab('diamonds');
            }}
            className={`py-2 px-3 rounded-xl text-xs sm:text-sm font-black flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              activeTab === 'diamonds'
                ? 'bg-gradient-to-r from-cyan-500 to-blue-500 text-white shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <Gem className="w-4 h-4" />
            <span>{isEn ? '💎 Diamonds' : '💎 ডায়মন্ড শপ'}</span>
          </button>

          <button
            onClick={() => {
              Sound.playClick();
              setActiveTab('exchange');
            }}
            className={`py-2 px-3 rounded-xl text-xs sm:text-sm font-black flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              activeTab === 'exchange'
                ? 'bg-gradient-to-r from-purple-500 to-indigo-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <ArrowLeftRight className="w-4 h-4" />
            <span>{isEn ? '🔄 Exchange' : '🔄 এক্সচেঞ্জ'}</span>
          </button>
        </div>

        {/* Success Banner */}
        {successMessage && (
          <div className="mb-4 p-3 rounded-2xl bg-emerald-500/20 border border-emerald-400/50 text-emerald-300 font-bold text-xs sm:text-sm flex items-center gap-2 animate-in zoom-in-95">
            <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0" />
            <span>{successMessage}</span>
          </div>
        )}

        {/* Tab Contents */}
        <div className="flex-1 overflow-y-auto pr-1 space-y-4 custom-scrollbar">
          {/* TAB 1: COIN SHOP */}
          {activeTab === 'coins' && (
            <div>
              <label className="text-xs font-black text-amber-400 uppercase tracking-wider block mb-2">
                {isEn ? 'Select Coin Package:' : 'কয়েন প্যাকেজ নির্বাচন করুন:'}
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 mb-4">
                {COIN_PACKAGES.map((pkg) => {
                  const isSelected = selectedCoinPkg.id === pkg.id;
                  return (
                    <button
                      key={pkg.id}
                      type="button"
                      onClick={() => {
                        Sound.playClick();
                        setSelectedCoinPkg(pkg);
                      }}
                      className={`relative p-3 rounded-2xl border-2 text-left transition-all flex flex-col justify-between cursor-pointer ${
                        isSelected
                          ? 'border-amber-400 bg-amber-500/20 shadow-md ring-2 ring-amber-400/40'
                          : 'border-slate-800 bg-slate-800/60 hover:border-slate-700'
                      }`}
                    >
                      {pkg.badge && (
                        <span className="absolute -top-2.5 right-2 px-2 py-0.5 rounded-full text-[10px] font-black bg-rose-500 text-white shadow-sm">
                          {pkg.badge}
                        </span>
                      )}
                      <div className="flex items-center gap-1.5 text-amber-400 font-black text-sm sm:text-base">
                        <Coins className="w-4 h-4 fill-amber-400" />
                        <span>{pkg.title}</span>
                      </div>
                      <div className="mt-2 flex items-baseline justify-between">
                        <span className="text-xs font-extrabold text-white">
                          +{isEn ? (pkg.coins + pkg.bonus).toLocaleString() : (pkg.coins + pkg.bonus).toLocaleString('bn-BD')} {isEn ? 'Coins' : 'কয়েন'}
                        </span>
                        <span className="text-xs font-black text-amber-300">
                          ৳ {pkg.priceBDT}
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 2: DIAMONDS SHOP */}
          {activeTab === 'diamonds' && (
            <div>
              <label className="text-xs font-black text-cyan-400 uppercase tracking-wider block mb-2">
                {isEn ? 'Select Diamond (Gems 💎) Package:' : 'ডায়মন্ড (জেমস 💎) প্যাকেজ নির্বাচন করুন:'}
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 mb-4">
                {DIAMOND_PACKAGES.map((pkg) => {
                  const isSelected = selectedDiaPkg.id === pkg.id;
                  return (
                    <button
                      key={pkg.id}
                      type="button"
                      onClick={() => {
                        Sound.playClick();
                        setSelectedDiaPkg(pkg);
                      }}
                      className={`relative p-3 rounded-2xl border-2 text-left transition-all flex flex-col justify-between cursor-pointer ${
                        isSelected
                          ? 'border-cyan-400 bg-cyan-500/20 shadow-md ring-2 ring-cyan-400/40'
                          : 'border-slate-800 bg-slate-800/60 hover:border-slate-700'
                      }`}
                    >
                      {pkg.badge && (
                        <span className="absolute -top-2.5 right-2 px-2 py-0.5 rounded-full text-[10px] font-black bg-gradient-to-r from-pink-500 to-rose-500 text-white shadow-sm">
                          {pkg.badge}
                        </span>
                      )}
                      <div className="flex items-center gap-1.5 text-cyan-400 font-black text-sm sm:text-base">
                        <Gem className="w-4 h-4 text-cyan-400" />
                        <span>{pkg.title}</span>
                      </div>
                      <div className="mt-2 flex items-baseline justify-between">
                        <span className="text-xs font-extrabold text-white">
                          +{isEn ? (pkg.diamonds + pkg.bonus).toLocaleString() : (pkg.diamonds + pkg.bonus).toLocaleString('bn-BD')} 💎
                        </span>
                        <span className="text-xs font-black text-cyan-300">
                          ৳ {pkg.priceBDT}
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 3: CURRENCY EXCHANGE */}
          {activeTab === 'exchange' && (
            <div className="space-y-3">
              <label className="text-xs font-black text-purple-400 uppercase tracking-wider block">
                {isEn ? 'Diamond & Coin Exchange Booth:' : 'ডায়মন্ড ও কয়েন এক্সচেঞ্জ বুথ:'}
              </label>

              {CURRENCY_EXCHANGES.map((ex) => {
                const isDiaToCoin = 'fromDiamonds' in ex;
                const canAfford = isDiaToCoin
                  ? currentDiamonds >= (ex.fromDiamonds || 0)
                  : currentCoins >= (ex.fromCoins || 0);

                return (
                  <div
                    key={ex.id}
                    className="p-3.5 rounded-2xl bg-slate-800/80 border border-slate-700 flex items-center justify-between gap-3 hover:border-indigo-500/60 transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-purple-500/20 flex items-center justify-center text-xl shrink-0">
                        {isDiaToCoin ? '💎➡️🪙' : '🪙➡️💎'}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs sm:text-sm font-black text-white">
                            {isEn
                              ? isDiaToCoin
                                ? `Exchange ${ex.fromDiamonds} 💎 for Coins`
                                : `Exchange ${(ex.fromCoins || 0).toLocaleString()} Coins for 💎`
                              : ex.titleBn}
                          </span>
                          {'badge' in ex && ex.badge && (
                            <span className="px-2 py-0.2 rounded-full bg-amber-400/20 text-amber-300 text-[10px] font-bold">
                              {ex.badge}
                            </span>
                          )}
                        </div>
                        <div className="text-[11px] text-slate-300 mt-0.5">
                          {isDiaToCoin ? (
                            <span>
                              {isEn ? 'Cost: ' : 'খরচ: '}
                              <strong className="text-cyan-300">
                                {ex.fromDiamonds} 💎
                              </strong>{' '}
                              ➡️ {isEn ? 'Receive: ' : 'পাবেন: '}
                              <strong className="text-amber-400">
                                {isEn
                                  ? ((ex.toCoins || 0) + (ex.bonusCoins || 0)).toLocaleString()
                                  : ((ex.toCoins || 0) + (ex.bonusCoins || 0)).toLocaleString('bn-BD')}{' '}
                                {isEn ? 'Coins' : 'কয়েন'}
                              </strong>
                            </span>
                          ) : (
                            <span>
                              {isEn ? 'Cost: ' : 'খরচ: '}
                              <strong className="text-amber-400">
                                {isEn ? ex.fromCoins?.toLocaleString() : ex.fromCoins?.toLocaleString('bn-BD')} {isEn ? 'Coins' : 'কয়েন'}
                              </strong>{' '}
                              ➡️ {isEn ? 'Receive: ' : 'পাবেন: '}
                              <strong className="text-cyan-300">
                                {ex.toDiamonds} 💎
                              </strong>
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    <button
                      onClick={() => handleExchange(ex)}
                      disabled={!canAfford}
                      className={`px-3.5 py-1.5 rounded-xl font-black text-xs transition-all active:scale-95 cursor-pointer ${
                        canAfford
                          ? 'bg-gradient-to-r from-purple-500 to-indigo-600 hover:from-purple-400 hover:to-indigo-500 text-white shadow-md'
                          : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                      }`}
                    >
                      {canAfford ? (isEn ? 'Exchange' : 'এক্সচেঞ্জ') : isEn ? 'Insufficient' : 'অপর্যাপ্ত'}
                    </button>
                  </div>
                );
              })}
            </div>
          )}

          {/* Payment Method & Checkout for Coins or Diamonds */}
          {activeTab !== 'exchange' && (
            <>
              <div>
                <label className="text-xs font-black text-slate-300 uppercase tracking-wider block mb-2">
                  {isEn ? 'Select Payment Method:' : 'পেমেন্ট মাধ্যম বেছে নিন:'}
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  <button
                    type="button"
                    onClick={() => setSelectedMethod('bkash')}
                    className={`p-2.5 rounded-2xl border-2 flex flex-col items-center justify-center gap-1 font-bold text-xs transition-all cursor-pointer ${
                      selectedMethod === 'bkash'
                        ? 'border-pink-500 bg-pink-500/20 text-pink-300 shadow-sm'
                        : 'border-slate-800 bg-slate-800/40 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <Smartphone className="w-5 h-5 text-pink-400" />
                    <span>{isEn ? 'bKash' : 'বিকাশ (bKash)'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setSelectedMethod('nagad')}
                    className={`p-2.5 rounded-2xl border-2 flex flex-col items-center justify-center gap-1 font-bold text-xs transition-all cursor-pointer ${
                      selectedMethod === 'nagad'
                        ? 'border-orange-500 bg-orange-500/20 text-orange-300 shadow-sm'
                        : 'border-slate-800 bg-slate-800/40 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <Smartphone className="w-5 h-5 text-orange-400" />
                    <span>{isEn ? 'Nagad' : 'নগদ (Nagad)'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setSelectedMethod('rocket')}
                    className={`p-2.5 rounded-2xl border-2 flex flex-col items-center justify-center gap-1 font-bold text-xs transition-all cursor-pointer ${
                      selectedMethod === 'rocket'
                        ? 'border-purple-500 bg-purple-500/20 text-purple-300 shadow-sm'
                        : 'border-slate-800 bg-slate-800/40 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <Smartphone className="w-5 h-5 text-purple-400" />
                    <span>{isEn ? 'Rocket' : 'রকেট (Rocket)'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setSelectedMethod('card')}
                    className={`p-2.5 rounded-2xl border-2 flex flex-col items-center justify-center gap-1 font-bold text-xs transition-all cursor-pointer ${
                      selectedMethod === 'card'
                        ? 'border-blue-500 bg-blue-500/20 text-blue-300 shadow-sm'
                        : 'border-slate-800 bg-slate-800/40 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <CreditCard className="w-5 h-5 text-blue-400" />
                    <span>{isEn ? 'Card / Visa' : 'কার্ড / ভিসা'}</span>
                  </button>
                </div>
              </div>

              {/* Phone / Account Number Input */}
              <div className={`p-3.5 rounded-2xl border transition-all ${
                selectedMethod === 'bkash'
                  ? 'bg-pink-950/20 border-pink-500/40'
                  : 'bg-slate-950 border-slate-800'
              }`}>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-[11px] font-bold text-slate-200 flex items-center gap-1.5">
                    {selectedMethod === 'bkash' && (
                      <span className="w-2 h-2 rounded-full bg-pink-500 animate-pulse" />
                    )}
                    <span>
                      {selectedMethod === 'bkash'
                        ? (isEn ? 'Your bKash Wallet Number:' : 'আপনার বিকাশ ওয়ালেট নম্বর:')
                        : `${selectedMethod.toUpperCase()} ${isEn ? 'Account Number:' : 'অ্যাকাউন্ট নাম্বার:'}`}
                    </span>
                  </label>
                  {selectedMethod === 'bkash' && (
                    <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-pink-500/20 text-pink-300 border border-pink-500/30">
                      {isEn ? 'Live bKash' : 'লাইভ বিকাশ'}
                    </span>
                  )}
                </div>

                <div className="relative mb-2.5">
                  <input
                    type="text"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="01XXXXXXXXX"
                    className={`w-full px-3.5 py-2.5 bg-slate-900 rounded-xl border font-bold text-sm text-white focus:outline-none transition-all ${
                      selectedMethod === 'bkash'
                        ? 'border-pink-500/50 focus:border-pink-400 focus:ring-2 focus:ring-pink-500/30'
                        : 'border-slate-700 focus:border-amber-400 focus:ring-2 focus:ring-amber-400/30'
                    }`}
                  />
                </div>

                {/* Real Payment: Transaction ID (TrxID) Field */}
                {(selectedMethod === 'bkash' || selectedMethod === 'nagad' || selectedMethod === 'rocket') && (
                  <div className="mt-2 pt-2 border-t border-slate-800/80">
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-[11px] font-bold text-slate-300 flex items-center gap-1.5">
                        <span className="text-amber-400">#</span>
                        <span>
                          {isEn ? 'Transaction ID (TrxID) / Reference:' : 'বিকাশ TrxID / ট্রানজেকশন আইডি:'}
                        </span>
                      </label>
                      <span className="text-[9px] text-slate-400 bg-slate-800 px-1.5 py-0.5 rounded">
                        {isEn ? 'From bKash SMS' : 'এসএমএস থেকে TrxID'}
                      </span>
                    </div>
                    <input
                      type="text"
                      value={trxId}
                      onChange={(e) => setTrxId(e.target.value.toUpperCase())}
                      placeholder={isEn ? 'e.g. 9K28DA10L8 (optional or real)' : 'উদা: 9K28DA10L8 (বিকাশ SMS থেকে)'}
                      className="w-full px-3.5 py-2 bg-slate-900/90 rounded-xl border border-slate-700 focus:border-amber-400 focus:ring-1 focus:ring-amber-400 font-mono font-bold text-xs text-amber-300 uppercase tracking-widest placeholder:text-slate-500 placeholder:normal-case placeholder:font-sans placeholder:tracking-normal transition-all"
                    />
                  </div>
                )}

                {/* Error Banner */}
                {errorMessage && (
                  <div className="mt-2 p-2 rounded-xl bg-rose-950/70 border border-rose-500/60 text-rose-200 text-xs font-semibold flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-rose-500 shrink-0" />
                    <span>{errorMessage}</span>
                  </div>
                )}

                <span className="text-[10px] text-slate-400 mt-2 flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span>
                    {selectedMethod === 'bkash'
                      ? (isEn
                          ? 'Real bKash Merchant Gateway & Instant Delivery. Enter your TrxID for verified accounting.'
                          : 'আসল বিকাশ গেটওয়ে ও তাৎক্ষণিক ডেলিভারি। বিকাশ থেকে টাকা পাঠিয়ে TrxID লিখুন বা সরাসরি নিশ্চিত করুন।')
                      : (isEn
                          ? 'Secured payment gateway with automated digital delivery.'
                          : 'স্বয়ংক্রিয় ডিজিটাল গেটওয়ে দিয়ে তাৎক্ষণিক ডেলিভারি পেয়ে যাবেন।')}
                  </span>
                </span>
              </div>

              {/* Buy Action Button */}
              <button
                id="confirm-coin-purchase-btn"
                disabled={isProcessing}
                onClick={handleBuy}
                className={`w-full py-3.5 rounded-2xl font-black text-base uppercase tracking-wider shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer ${
                  activeTab === 'diamonds'
                    ? 'bg-gradient-to-r from-cyan-500 via-blue-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white shadow-cyan-500/30'
                    : 'bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 shadow-amber-500/30'
                }`}
              >
                {isProcessing ? (
                  <span>{isEn ? 'Processing Payment...' : 'পেমেন্ট প্রসেসিং হচ্ছে...'}</span>
                ) : (
                  <>
                    <Sparkles className="w-5 h-5" />
                    <span>
                      {isEn ? (
                        <>
                          Pay ৳{' '}
                          {activeTab === 'diamonds'
                            ? selectedDiaPkg.priceBDT
                            : selectedCoinPkg.priceBDT}{' '}
                          for{' '}
                          {activeTab === 'diamonds'
                            ? `${selectedDiaPkg.diamonds + selectedDiaPkg.bonus} Diamonds 💎`
                            : `${(selectedCoinPkg.coins + selectedCoinPkg.bonus).toLocaleString()} Coins 🪙`}
                        </>
                      ) : (
                        <>
                          ৳{' '}
                          {activeTab === 'diamonds'
                            ? selectedDiaPkg.priceBDT
                            : selectedCoinPkg.priceBDT}{' '}
                          দিয়ে{' '}
                          {activeTab === 'diamonds'
                            ? `${selectedDiaPkg.diamonds + selectedDiaPkg.bonus} ডায়মন্ড 💎`
                            : `${(selectedCoinPkg.coins + selectedCoinPkg.bonus).toLocaleString('bn-BD')} কয়েন 🪙`}{' '}
                          নিন
                        </>
                      )}
                    </span>
                  </>
                )}
              </button>
            </>
          )}
        </div>

        {/* Security badge footer */}
        <div className="mt-3 pt-2 border-t border-slate-800 flex items-center justify-center gap-1.5 text-[11px] text-slate-400">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>{isEn ? '100% Secure & Instant Digital Wallet Delivery' : '১০০% নিরাপদ ও তাৎক্ষণিক ডিজিটাল ওয়ালেট ডেলিভারি'}</span>
        </div>
      </div>
    </div>
  );
};
