import React, { useState, useEffect } from 'react';
import {
  X,
  ShieldAlert,
  ShieldCheck,
  Wallet,
  AlertTriangle,
  Film,
  Flame,
  Upload,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import {
  UserProfile,
  VideoContent,
  CreatorMonetizationProfile,
  WithdrawalTransaction,
  PolicyScanResult,
} from '../types';
import {
  loadVideoFeed,
  saveVideoFeed,
  loadCreatorMonetizationProfile,
  saveCreatorMonetizationProfile,
  loadWithdrawalTransactions,
  requestCreatorWithdrawal,
  sendDiamondGiftToVideo,
  registerVideoViewAndEarning,
  scanContentForPolicyViolation,
  CREATOR_MONETIZATION_CATEGORIES,
} from '../utils/videoMonetizationService';
import { loadUserAgeConfig } from '../utils/ageLimitService';
import { Sound } from '../utils/soundEffects';
import { VideoFeedPlayerTab } from './studio/VideoFeedPlayerTab';
import { VideoUploadStudioTab } from './studio/VideoUploadStudioTab';
import { CreatorMonetizationTab } from './studio/CreatorMonetizationTab';

interface JoyVideoStudioModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile;
  userCoins: number;
  userDiamonds: number;
  onDeductDiamonds?: (count: number) => void;
  onOpenAdvertiserModal?: () => void;
  onOpenShortsScrollPlayer?: () => void;
}

export const JoyVideoStudioModal: React.FC<JoyVideoStudioModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  userCoins,
  userDiamonds,
  onDeductDiamonds,
  onOpenAdvertiserModal,
  onOpenShortsScrollPlayer,
}) => {
  const [activeTab, setActiveTab] = useState<'feed' | 'studio' | 'monetization' | 'rules'>('feed');
  const [videos, setVideos] = useState<VideoContent[]>([]);
  const [selectedVideoIndex, setSelectedVideoIndex] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [likedVideoIds, setLikedVideoIds] = useState<Record<string, boolean>>({});

  // Creator Profile & Transactions
  const userAgeConfig = loadUserAgeConfig(currentUser);
  const isAdultUser = userAgeConfig.age >= 18 && userAgeConfig.ageCategory === 'adult_18_plus';
  const [creatorProfile, setCreatorProfile] = useState<CreatorMonetizationProfile>(() =>
    loadCreatorMonetizationProfile(currentUser, 'BD')
  );
  const [withdrawals, setWithdrawals] = useState<WithdrawalTransaction[]>([]);

  // Studio Upload Form States
  const [videoTitle, setVideoTitle] = useState('');
  const [videoDesc, setVideoDesc] = useState('');
  const [videoTags, setVideoTags] = useState('ফানি, লুডু, জয়লুডু');
  const [videoType, setVideoType] = useState<VideoContent['videoType']>('funny_moment');
  const [scanResult, setScanResult] = useState<PolicyScanResult | null>(null);
  const [uploadSuccessMsg, setUploadSuccessMsg] = useState<string | null>(null);

  // Diamond Gift Modal
  const [isGiftModalOpen, setIsGiftModalOpen] = useState(false);
  const [giftDiamondAmount, setGiftDiamondAmount] = useState<number>(10);
  const [giftSuccessMsg, setGiftSuccessMsg] = useState<string | null>(null);

  // Withdrawal Form States
  const [withdrawAmount, setWithdrawAmount] = useState<number>(100);
  const [withdrawMethod, setWithdrawMethod] = useState<'bkash' | 'nagad' | 'rocket' | 'bank'>('bkash');
  const [withdrawPhone, setWithdrawPhone] = useState(currentUser.phone || '01700000000');
  const [withdrawMsg, setWithdrawMsg] = useState<{ success: boolean; text: string } | null>(null);

  // Comments State
  const [commentInput, setCommentInput] = useState('');
  const [localComments, setLocalComments] = useState<Record<string, string[]>>({
    'vid-joy-funny-01': ['হাসতে হাসতে পেটে খিল ধরে গেল! 😂', 'আমার সাথেও এমন হয়েছিল একবার 🤣'],
    'vid-joy-edu-02': ['দারুণ স্ট্র্যাটেজি ভাই! স্টার পয়েন্ট লক করার টেকনিক শিখে অনেক ম্যাচ জিতলাম 👏', 'অসাধারণ টিউটোরিয়াল ❤️'],
    'vid-joy-creative-03': ['খুবই সুন্দর এবং সুস্থ পারিবারিক বিনোদন ✨'],
    'vid-joy-adda-06': ['লালনগীতি আর লুডুর আড্ডা সত্যি অতুলনীয়! ☕🎤'],
  });

  // Load feed and withdrawals on open
  useEffect(() => {
    if (isOpen) {
      const feed = loadVideoFeed();
      setVideos(feed);
      const prof = loadCreatorMonetizationProfile(currentUser, 'BD');
      setCreatorProfile(prof);
      setWithdrawals(loadWithdrawalTransactions());
      setSelectedVideoIndex(0);
      setIsPlaying(true);
    }
  }, [isOpen, currentUser]);

  // Real-time Policy Scan
  useEffect(() => {
    if (videoTitle || videoDesc || videoTags) {
      const tagsArr = videoTags.split(',').map((t) => t.trim()).filter(Boolean);
      const result = scanContentForPolicyViolation(
        videoTitle,
        videoDesc,
        tagsArr,
        userAgeConfig.age,
        false
      );
      setScanResult(result);
    } else {
      setScanResult(null);
    }
  }, [videoTitle, videoDesc, videoTags, userAgeConfig.age]);

  if (!isOpen) return null;

  const currentVideo = videos[selectedVideoIndex] || videos[0];

  // Handle Like Video
  const handleToggleLike = (video: VideoContent) => {
    Sound.playClick();
    const isLiked = likedVideoIds[video.id];
    setLikedVideoIds((prev) => ({ ...prev, [video.id]: !isLiked }));

    const updated = videos.map((v) => {
      if (v.id === video.id) {
        return {
          ...v,
          likesCount: isLiked ? Math.max(0, v.likesCount - 1) : v.likesCount + 1,
        };
      }
      return v;
    });
    setVideos(updated);
    saveVideoFeed(updated);

    if (!isLiked) {
      confetti({
        particleCount: 25,
        spread: 40,
        origin: { y: 0.7 },
      });
    }
  };

  // Handle Send Diamond Gift Tip
  const handleSendGift = () => {
    if (!currentVideo) return;
    if (userDiamonds < giftDiamondAmount) {
      Sound.playAlert();
      alert(`আপনার পর্যাপ্ত ডায়মন্ড নেই! প্রয়োজন ${giftDiamondAmount} 💎, আপনার আছে ${userDiamonds} 💎`);
      return;
    }

    if (onDeductDiamonds) {
      onDeductDiamonds(giftDiamondAmount);
    }

    const res = sendDiamondGiftToVideo(currentVideo.id, giftDiamondAmount, currentUser);
    if (res.success && res.updatedVideo) {
      Sound.playRewardClaim();
      confetti({
        particleCount: 60,
        spread: 70,
        origin: { y: 0.5 },
      });

      const updated = videos.map((v) => (v.id === currentVideo.id ? res.updatedVideo! : v));
      setVideos(updated);
      setGiftSuccessMsg(`🎉 ক্রিয়েটরকে ৳${res.earnedBDT.toFixed(2)} মূল্যের ${giftDiamondAmount}💎 উপহার পাঠানো হয়েছে!`);
      setTimeout(() => {
        setGiftSuccessMsg(null);
        setIsGiftModalOpen(false);
      }, 1600);
    }
  };

  // Handle Add Comment
  const handleAddComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentInput.trim() || !currentVideo) return;

    const check = scanContentForPolicyViolation(commentInput, '', []);
    if (!check.isSafe) {
      Sound.playAlert();
      alert(check.reasonBn || 'অনুপযুক্ত শব্দ ফিল্টার করা হয়েছে!');
      return;
    }

    Sound.playClick();
    const vidId = currentVideo.id;
    const currentList = localComments[vidId] || [];
    setLocalComments({
      ...localComments,
      [vidId]: [commentInput.trim(), ...currentList],
    });
    setCommentInput('');
  };

  // Handle Video Upload/Publish
  const handlePublishVideo = (e: React.FormEvent) => {
    e.preventDefault();

    if (!isAdultUser) {
      Sound.playAlert();
      alert('🔞 বয়স সীমা সতর্কতা: সরকারি ও ডিজিটাল নিরাপত্তা নীতি অনুযায়ী ১৮ বছরের নিচে কেউ ভিডিও আপলোড করতে পারবে না।');
      return;
    }

    const tagsArr = videoTags.split(',').map((t) => t.trim()).filter(Boolean);
    const check = scanContentForPolicyViolation(
      videoTitle,
      videoDesc,
      tagsArr,
      userAgeConfig.age,
      false
    );

    if (!check.isSafe) {
      Sound.playAlert();
      alert(check.reasonBn);
      return;
    }

    if (!videoTitle.trim()) {
      alert('অনুগ্রহ করে ভিডিওর আকর্ষণীয় শিরোনাম লিখুন!');
      return;
    }

    const categoryMeta = CREATOR_MONETIZATION_CATEGORIES[videoType] || CREATOR_MONETIZATION_CATEGORIES.funny_moment;

    const newVideo: VideoContent = {
      id: 'vid-user-' + Date.now(),
      title: videoTitle.trim(),
      description: videoDesc.trim() || 'জয় লুডু ক্রিয়েটর ভিডিও! #JoyLudo',
      creatorId: currentUser.id,
      creatorName: currentUser.name || 'আমার জয় লুডু চ্যানেল',
      creatorAvatar: currentUser.avatarUrl ? undefined : {
        skinColor: '#fcd34d',
        hairStyle: 'short',
        hairColor: '#1e293b',
        eyes: 'cool',
        mouth: 'smile',
        clothing: 'hoodie',
        clothingColor: '#dc2626',
        accessory: 'golden_chain',
        bgGradient: 'from-amber-600 to-red-600',
      },
      creatorPhoto: currentUser.avatarUrl,
      creatorCountry: 'BD',
      videoType: videoType,
      categoryLabelBn: categoryMeta.badge,
      durationSeconds: 30 + Math.floor(Math.random() * 25),
      viewsCount: 1,
      likesCount: 0,
      commentsCount: 0,
      sharesCount: 0,
      earningsBDT: Number(categoryMeta.viewBonusRateBDT.toFixed(2)),
      rpmRateBDT: categoryMeta.rpmRateBDT,
      diamondsReceived: 0,
      isMonetized: true,
      isKidsSafe: true,
      status: 'published',
      createdAt: Date.now(),
      tags: tagsArr.length > 0 ? tagsArr : ['জয়লুডু', 'লুডুশর্টস'],
      gameSnippet: {
        playerColor: 'red',
        diceRoll: 6,
        tokensCaptured: 2,
        coinsWon: 20000,
      },
    };

    const updatedFeed = [newVideo, ...videos];
    setVideos(updatedFeed);
    saveVideoFeed(updatedFeed);

    const updatedProf = {
      ...creatorProfile,
      totalVideosCount: creatorProfile.totalVideosCount + 1,
      balanceBDT: Number((creatorProfile.balanceBDT + categoryMeta.viewBonusRateBDT).toFixed(2)),
      totalEarnedBDT: Number((creatorProfile.totalEarnedBDT + categoryMeta.viewBonusRateBDT).toFixed(2)),
    };
    setCreatorProfile(updatedProf);
    saveCreatorMonetizationProfile(currentUser.id, updatedProf);

    Sound.playRewardClaim();
    confetti({
      particleCount: 70,
      spread: 80,
      origin: { y: 0.5 },
    });

    setUploadSuccessMsg('🎉 অভিনন্দন! আপনার ভিডিও সফলভাবে প্রকাশিত হয়েছে এবং মনিটাইজেশন বোনাস যুক্ত হয়েছে!');
    setVideoTitle('');
    setVideoDesc('');

    setTimeout(() => {
      setUploadSuccessMsg(null);
      setActiveTab('feed');
      setSelectedVideoIndex(0);
    }, 1800);
  };

  // Handle Withdrawal Request
  const handleWithdrawalSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!withdrawPhone.trim()) {
      alert('অনুগ্রহ করে সঠিক মোবাইল নম্বর প্রদান করুন!');
      return;
    }

    const res = requestCreatorWithdrawal(
      currentUser.id,
      withdrawAmount,
      withdrawMethod,
      withdrawPhone,
      currentUser.name
    );

    if (res.success) {
      Sound.playRewardClaim();
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.6 },
      });
      setWithdrawMsg({ success: true, text: res.messageBn });
      setCreatorProfile(loadCreatorMonetizationProfile(currentUser, 'BD'));
      setWithdrawals(loadWithdrawalTransactions());
    } else {
      Sound.playAlert();
      setWithdrawMsg({ success: false, text: res.messageBn });
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-4xl bg-slate-950 text-white rounded-3xl border-2 border-amber-500/60 shadow-2xl flex flex-col h-[94vh] max-h-[850px] overflow-hidden">
        {/* Header Bar */}
        <div className="px-5 py-3.5 bg-gradient-to-r from-amber-600 via-rose-600 to-purple-700 flex items-center justify-between border-b border-amber-400/30 shrink-0 shadow-lg">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-black/30 border border-amber-300/40 flex items-center justify-center text-amber-300 shadow-inner">
              <Film className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-black text-white tracking-wide">
                  🎬 জয় ভিডিও স্টুডিও ও ক্রিয়েটর ইনকাম প্রোগ্রাম
                </h2>
                <span className="px-2 py-0.5 rounded-full bg-amber-400 text-slate-950 text-[10px] font-black uppercase shadow-sm">
                  Earn BDT ৳
                </span>
              </div>
              <p className="text-xs text-amber-100 font-medium">
                ফানি, শিক্ষামূলক ও যেকোনো ভালো ভিডিও বানিয়ে আয় করুন • বিকাশ, নগদ ও রকেটে পেআউট 🇧🇩
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Quick Wallet preview */}
            <div className="hidden sm:flex items-center gap-1.5 px-3 py-1 bg-black/40 rounded-xl border border-amber-400/40 text-xs">
              <Wallet className="w-3.5 h-3.5 text-amber-300" />
              <span className="text-slate-300 text-[11px]">ব্যালেন্স:</span>
              <span className="font-mono font-black text-amber-300">
                ৳{creatorProfile.balanceBDT.toFixed(2)}
              </span>
            </div>

            <button
              onClick={() => {
                Sound.playClick();
                onClose();
              }}
              className="w-9 h-9 rounded-2xl bg-black/40 hover:bg-rose-600 text-white flex items-center justify-center transition-all cursor-pointer border border-white/20"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-1.5 px-4 pt-2.5 pb-2 bg-slate-900/95 border-b border-slate-800 shrink-0 overflow-x-auto">
          {[
            { id: 'feed', label: '🔥 ট্রেন্ডিং ভিডিও ফিড', icon: Flame },
            { id: 'studio', label: '🎥 ভিডিও তৈরি ও আপলোড', icon: Upload },
            { id: 'monetization', label: '💰 ইনকাম ও টাকা উত্তোলন (৳)', icon: Wallet },
            { id: 'rules', label: '📜 ১৮+ নিয়ম ও নিরাপত্তা পলিসি', icon: ShieldCheck },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => {
                  Sound.playClick();
                  setActiveTab(tab.id as any);
                }}
                className={`px-3.5 py-2 rounded-2xl text-xs font-black shrink-0 transition-all flex items-center gap-1.5 cursor-pointer ${
                  isActive
                    ? 'bg-gradient-to-r from-amber-500 to-rose-500 text-slate-950 shadow-md scale-102 font-black'
                    : 'bg-slate-950 text-slate-400 hover:bg-slate-800 hover:text-slate-200'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Main Content Area */}
        <div className="flex-1 overflow-y-auto p-3 sm:p-5 bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950">
          {/* TAB 1: VIDEO FEED */}
          {activeTab === 'feed' && (
            <VideoFeedPlayerTab
              videos={videos}
              selectedVideoIndex={selectedVideoIndex}
              isPlaying={isPlaying}
              likedVideoIds={likedVideoIds}
              localComments={localComments}
              commentInput={commentInput}
              onSelectVideoIndex={setSelectedVideoIndex}
              onTogglePlay={() => setIsPlaying(!isPlaying)}
              onToggleLike={handleToggleLike}
              onOpenGiftModal={() => setIsGiftModalOpen(true)}
              onCommentInputChange={setCommentInput}
              onAddComment={handleAddComment}
              onOpenShortsScrollPlayer={onOpenShortsScrollPlayer}
            />
          )}

          {/* TAB 2: STUDIO UPLOAD */}
          {activeTab === 'studio' && (
            <VideoUploadStudioTab
              isAdultUser={isAdultUser}
              videoTitle={videoTitle}
              videoDesc={videoDesc}
              videoTags={videoTags}
              videoType={videoType}
              scanResult={scanResult}
              uploadSuccessMsg={uploadSuccessMsg}
              onVideoTitleChange={setVideoTitle}
              onVideoDescChange={setVideoDesc}
              onVideoTagsChange={setVideoTags}
              onVideoTypeChange={setVideoType}
              onSubmit={handlePublishVideo}
            />
          )}

          {/* TAB 3: CREATOR MONETIZATION */}
          {activeTab === 'monetization' && (
            <CreatorMonetizationTab
              currentUser={currentUser}
              creatorProfile={creatorProfile}
              withdrawals={withdrawals}
              withdrawAmount={withdrawAmount}
              withdrawMethod={withdrawMethod}
              withdrawPhone={withdrawPhone}
              withdrawMsg={withdrawMsg}
              onWithdrawAmountChange={setWithdrawAmount}
              onWithdrawMethodChange={setWithdrawMethod}
              onWithdrawPhoneChange={setWithdrawPhone}
              onWithdrawalSubmit={handleWithdrawalSubmit}
              onOpenAdvertiserModal={onOpenAdvertiserModal}
              onBonusClaimed={(newBal) => {
                setCreatorProfile((prev) => ({ ...prev, balanceBDT: newBal }));
              }}
            />
          )}

          {/* TAB 4: COMMUNITY RULES & 18+ POLICY */}
          {activeTab === 'rules' && (
            <div className="max-w-2xl mx-auto space-y-4 animate-fade-in text-xs leading-relaxed text-slate-300">
              <div className="p-5 rounded-3xl bg-slate-900 border border-slate-800 space-y-3 shadow-xl">
                <div className="flex items-center gap-2 border-b border-slate-800 pb-2.5">
                  <ShieldCheck className="w-5 h-5 text-amber-400" />
                  <h3 className="text-sm font-black text-white">
                    জয় লুডু ভিডিও কন্টেন্ট ও মনিটাইজেশন নীতিমালা
                  </h3>
                </div>

                <div className="space-y-2.5">
                  <div className="p-3 rounded-2xl bg-rose-950/30 border border-rose-500/40 space-y-1">
                    <span className="font-black text-rose-300 flex items-center gap-1.5">
                      <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                      ১. ১৮+ বয়স সীমা বাধ্যতামূলক (Strict 18+ Rule)
                    </span>
                    <p className="text-[11px] text-slate-300">
                      ১৮ বছরের নিচে কোনো ব্যবহারকারী ভিডিও আপলোড বা চ্যানেল পরিচালনা করতে পারবে না। অপ্রাপ্তবয়স্কদের সুরক্ষার জন্য শুধুমাত্র প্রাপ্তবয়স্ক ১৮+ ভেরিফাইড ক্রিয়েটররা ভিডিও প্রকাশ ও উপার্জন করতে পারবে।
                    </p>
                  </div>

                  <div className="p-3 rounded-2xl bg-rose-950/30 border border-rose-500/40 space-y-1">
                    <span className="font-black text-rose-300 flex items-center gap-1.5">
                      <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                      ২. শিশুদের ছবি ও ভিডিও স্বয়ংক্রিয় বাতিল (Child Protection Auto-Removal)
                    </span>
                    <p className="text-[11px] text-slate-300">
                      বাচ্চা বা শিশুদের কোনো ভিডিও, ছবি বা ফটো আপলোড করা সম্পূর্ণ নিষিদ্ধ। সিস্টেম দ্বারা এই ধরনের কন্টেন্ট শনাক্ত হওয়ামাত্র স্বয়ংক্রিয়ভাবে বাতিল ও রিমুভ করা হবে।
                    </p>
                  </div>

                  <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 space-y-1.5">
                    <span className="font-black text-amber-300 block">
                      ৩. সম্পূর্ণ নিষিদ্ধ কন্টেন্টসমূহ (Prohibited List):
                    </span>
                    <ul className="space-y-1 text-[11px] text-slate-400 pl-2">
                      <li>• <strong>রাজনৈতিক প্রচার:</strong> যেকোনো প্রকার রাজনৈতিক বক্তব্য, দলবাজি বা উস্কানিমূলক কন্টেন্ট।</li>
                      <li>• <strong>ধর্মীয় অবমাননা ও বিদ্বেষ:</strong> সকল ধর্মের প্রতি শ্রদ্ধা বাধ্যতামূলক। কোনো প্রকার সাম্প্রদায়িক কটূক্তি নিষিদ্ধ।</li>
                      <li>• <strong>গুজব ও ভুয়া তথ্য:</strong> সমাজ বা খেলায় বিভ্রান্তি সৃষ্টিকারী অসত্য খবর প্রকাশ নিষিদ্ধ।</li>
                      <li>• <strong>গালাগালি ও অশ্লীল ভাষা:</strong> কুরুচিপূর্ণ, অশালীন ও গালাগালিমূলক শব্দ নিষিদ্ধ।</li>
                      <li>• <strong>সহিংসতা ও উস্কানি:</strong> কাউকে হুমকি বা শারীরিক ক্ষতিসাধন সংক্রান্ত আচরণ সম্পূর্ণ নিষিদ্ধ।</li>
                    </ul>
                  </div>

                  <div className="p-3 rounded-2xl bg-emerald-950/30 border border-emerald-500/40 space-y-1">
                    <span className="font-black text-emerald-300 block">
                      ৪. অঞ্চলভিত্তিক মনিটাইজেশন (Regional Monetization Policy):
                    </span>
                    <p className="text-[11px] text-slate-300">
                      বর্তমানে শুধুমাত্র <strong>বাংলাদেশে (Bangladesh)</strong> বিকাশ, নগদ ও রকেটে টাকা উত্তোলন সুবিধা চালু রয়েছে। অন্যান্য দেশগুলোতে আমাদের পক্ষ থেকে চূড়ান্ত অনুমতি প্রদানের পর পর্যায়ক্রমে চালু করা হবে।
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Diamond Gift Tip Modal */}
        {isGiftModalOpen && currentVideo && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
            <div className="relative w-full max-w-sm bg-slate-950 text-white rounded-3xl border-2 border-amber-400 shadow-2xl p-5 text-center space-y-4">
              <div className="w-14 h-14 rounded-full bg-amber-500/20 border border-amber-400 text-amber-300 flex items-center justify-center mx-auto text-2xl">
                🎁
              </div>

              <div>
                <h3 className="text-base font-black text-white">ক্রিয়েটরকে ডায়মন্ড উপহার পাঠান</h3>
                <p className="text-xs text-slate-300 mt-1">
                  ক্রিয়েটর: <strong>{currentVideo.creatorName}</strong>
                </p>
                <p className="text-[11px] text-amber-300 font-bold mt-0.5">
                  (১ ডায়মন্ড 💎 = ৳১.০০ ক্রিয়েটরের আয়)
                </p>
              </div>

              {/* Amount Selectors */}
              <div className="grid grid-cols-4 gap-2">
                {[5, 10, 25, 50].map((amt) => (
                  <button
                    key={amt}
                    type="button"
                    onClick={() => {
                      Sound.playButtonTick();
                      setGiftDiamondAmount(amt);
                    }}
                    className={`py-2 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                      giftDiamondAmount === amt
                        ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-md font-black'
                        : 'bg-slate-900 text-slate-300 border-slate-800'
                    }`}
                  >
                    {amt} 💎
                  </button>
                ))}
              </div>

              <div className="text-xs text-slate-400">
                আপনার ডায়মন্ড ব্যালেন্স: <strong className="text-amber-300">{userDiamonds} 💎</strong>
              </div>

              {giftSuccessMsg && (
                <div className="p-2.5 rounded-xl bg-emerald-950 border border-emerald-500 text-emerald-300 text-xs font-bold">
                  {giftSuccessMsg}
                </div>
              )}

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsGiftModalOpen(false)}
                  className="flex-1 py-2.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold cursor-pointer"
                >
                  বাতিল
                </button>
                <button
                  type="button"
                  onClick={handleSendGift}
                  className="flex-1 py-2.5 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 text-slate-950 font-black text-xs shadow-md cursor-pointer active:scale-95"
                >
                  পাঠিয়ে দিন ({giftDiamondAmount}💎)
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
