import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Heart,
  MessageCircle,
  Share2,
  Bookmark,
  MoreVertical,
  Volume2,
  VolumeX,
  Play,
  Pause,
  Sparkles,
  Award,
  Gift,
  HardDrive,
  Check,
  Send,
  Music,
  ChevronUp,
  ChevronDown,
  Wifi,
  WifiOff,
  Film,
  Camera,
  Search,
  Flame,
  Gamepad2,
  X,
  Plus,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { VideoContent, UserProfile } from '../types';
import { Sound } from '../utils/soundEffects';
import { AvatarDisplay } from './AvatarDisplay';
import {
  loadVideoFeed,
  saveVideoFeed,
  sendDiamondGiftToVideo,
  scanContentForPolicyViolation,
} from '../utils/videoMonetizationService';
import {
  getOfflineCachedVideos,
  saveVideoToOfflineCache,
  removeVideoFromOfflineCache,
  getOfflineStorageMetrics,
  isAppInOfflineMode,
  OfflineStorageMetrics,
} from '../utils/offlineVideoService';

interface HomeReelsFeedProps {
  currentUser: UserProfile;
  userDiamonds: number;
  onDeductDiamonds?: (count: number) => void;
  onOpenStudioModal: () => void;
  onPlayGameClick: () => void;
  onOpenLiveAdda: () => void;
}

interface FloatingHeart {
  id: number;
  x: number;
  y: number;
}

export const HomeReelsFeed: React.FC<HomeReelsFeedProps> = ({
  currentUser,
  userDiamonds,
  onDeductDiamonds,
  onOpenStudioModal,
  onPlayGameClick,
  onOpenLiveAdda,
}) => {
  // Video Feed List & Filter State
  const [allVideos, setAllVideos] = useState<VideoContent[]>(() => loadVideoFeed());
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [videoProgress, setVideoProgress] = useState<number>(0);
  const [isFollowingMap, setIsFollowingMap] = useState<Record<string, boolean>>({});

  // Offline & Storage
  const [isOfflineMode, setIsOfflineMode] = useState<boolean>(() => isAppInOfflineMode());
  const [cachedVideoIds, setCachedVideoIds] = useState<Record<string, boolean>>({});
  const [storageMetrics, setStorageMetrics] = useState<OfflineStorageMetrics>({
    totalVideos: 0,
    totalSizeKB: 0,
    totalSizeMB: '0.0',
    cacheLimitVideos: 30,
  });

  // Engagement States
  const [likedMap, setLikedMap] = useState<Record<string, boolean>>({
    'vid-joy-funny-01': true,
  });
  const [savedMap, setSavedMap] = useState<Record<string, boolean>>({});
  const [floatingHearts, setFloatingHearts] = useState<FloatingHeart[]>([]);
  const [isCommentDrawerOpen, setIsCommentDrawerOpen] = useState<boolean>(false);
  const [commentInput, setCommentInput] = useState<string>('');
  const [commentsMap, setCommentsMap] = useState<Record<string, string[]>>({
    'vid-joy-funny-01': [
      'হাসতে হাসতে শেষ ভাই! নিজের গুটি কাটার মতো মজা আর নেই 🤣',
      'অসাধারণ কমেডি রিঅ্যাকশন ❤️',
      'পরের পার্ট কবে আসবে ভাইয়া?',
    ],
    'vid-joy-edu-02': [
      'স্টার পয়েন্ট লক করার এই টেকনিকটা জানতাম না! অনেক ধন্যবাদ 🧠',
      'প্রো টিপস! আমি আজকেই ট্রাই করে ম্যাচ জিতলাম 🏆',
    ],
    'vid-joy-creative-03': [
      'খুব সুন্দর সুস্থ পারিবারিক বিনোদন ✨',
      'চমৎকার অ্যানিমেশন এবং ভয়েস কোয়ালিটি 🌟',
    ],
  });

  // Tip & Diamond Gift Modal
  const [isGiftTipModalOpen, setIsGiftTipModalOpen] = useState<boolean>(false);
  const [selectedGiftDiamonds, setSelectedGiftDiamonds] = useState<number>(10);
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  // Touch Swipe & Wheel Ref
  const touchStartYRef = useRef<number>(0);
  const isScrollingRef = useRef<boolean>(false);
  const progressTimerRef = useRef<any>(null);

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 2500);
  };

  // Reload feed
  const reloadFeed = useCallback(() => {
    const onlineFeed = loadVideoFeed();
    const offlineFeed = getOfflineCachedVideos();

    const idMap: Record<string, boolean> = {};
    offlineFeed.forEach((v) => {
      idMap[v.id] = true;
    });
    setCachedVideoIds(idMap);
    setStorageMetrics(getOfflineStorageMetrics());

    if (isOfflineMode || activeCategory === 'offline') {
      setAllVideos(offlineFeed.length > 0 ? offlineFeed : onlineFeed);
    } else {
      setAllVideos(onlineFeed);
    }
  }, [isOfflineMode, activeCategory]);

  useEffect(() => {
    reloadFeed();
  }, [reloadFeed]);

  // Filtered Video Feed
  const filteredVideos = allVideos.filter((v) => {
    if (activeCategory === 'all') return true;
    if (activeCategory === 'offline') return cachedVideoIds[v.id];
    if (activeCategory === 'funny') return v.videoType === 'funny_moment';
    if (activeCategory === 'education') return v.videoType === 'educational_guide' || v.videoType === 'tutorial';
    if (activeCategory === 'creative') return v.videoType === 'creative_good_content';
    if (activeCategory === 'epic') return v.videoType === 'epic_win' || v.videoType === 'gameplay_highlight';
    if (activeCategory === 'adda') return v.videoType === 'voice_adda_clip';
    return true;
  });

  const currentVideo = filteredVideos[currentIndex] || filteredVideos[0] || allVideos[0];

  // Video progress & auto-play next
  useEffect(() => {
    if (!isPlaying || !currentVideo) {
      if (progressTimerRef.current) clearInterval(progressTimerRef.current);
      return;
    }

    const durationSec = currentVideo.durationSeconds || 24;
    const intervalMs = 200;
    const stepPercent = (intervalMs / (durationSec * 1000)) * 100;

    progressTimerRef.current = setInterval(() => {
      setVideoProgress((prev) => {
        if (prev >= 100) {
          if (filteredVideos.length > 1) {
            handleScrollNext();
            return 0;
          }
          return 0; // loop
        }
        return prev + stepPercent;
      });
    }, intervalMs);

    return () => {
      if (progressTimerRef.current) clearInterval(progressTimerRef.current);
    };
  }, [isPlaying, currentIndex, currentVideo, filteredVideos.length]);

  // Scroll Navigation Handlers (Next / Previous Reel)
  const handleScrollNext = () => {
    if (filteredVideos.length === 0) return;
    Sound.playButtonTick();
    setVideoProgress(0);
    setCurrentIndex((prev) => (prev < filteredVideos.length - 1 ? prev + 1 : 0));
  };

  const handleScrollPrev = () => {
    if (filteredVideos.length === 0) return;
    Sound.playButtonTick();
    setVideoProgress(0);
    setCurrentIndex((prev) => (prev > 0 ? prev - 1 : filteredVideos.length - 1));
  };

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (isCommentDrawerOpen || isGiftTipModalOpen) return;
      if (e.key === 'ArrowDown' || e.key === 'j') {
        e.preventDefault();
        handleScrollNext();
      } else if (e.key === 'ArrowUp' || e.key === 'k') {
        e.preventDefault();
        handleScrollPrev();
      } else if (e.key === ' ') {
        e.preventDefault();
        setIsPlaying((p) => !p);
      } else if (e.key === 'm') {
        setIsMuted((m) => !m);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isCommentDrawerOpen, isGiftTipModalOpen, filteredVideos.length]);

  // Wheel scroll with throttle
  const handleWheel = (e: React.WheelEvent) => {
    if (isScrollingRef.current) return;
    if (Math.abs(e.deltaY) > 30) {
      isScrollingRef.current = true;
      if (e.deltaY > 0) {
        handleScrollNext();
      } else {
        handleScrollPrev();
      }
      setTimeout(() => {
        isScrollingRef.current = false;
      }, 400);
    }
  };

  // Touch swipe
  const handleTouchStart = (e: React.TouchEvent) => {
    if (e.touches && e.touches.length > 0) {
      touchStartYRef.current = e.touches[0].clientY;
    }
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (!e.changedTouches || e.changedTouches.length === 0) return;
    const touchEndY = e.changedTouches[0].clientY;
    const diff = touchStartYRef.current - touchEndY;
    if (Math.abs(diff) > 40) {
      if (diff > 0) {
        handleScrollNext(); // swipe up -> next video
      } else {
        handleScrollPrev(); // swipe down -> prev video
      }
    }
  };

  // Tap anywhere on video to toggle play/pause or double tap to like
  const handleVideoAreaClick = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    // spawn heart animation
    const newHeart: FloatingHeart = { id: Date.now(), x, y };
    setFloatingHearts((prev) => [...prev, newHeart]);
    setTimeout(() => {
      setFloatingHearts((prev) => prev.filter((h) => h.id !== newHeart.id));
    }, 900);

    if (currentVideo && !likedMap[currentVideo.id]) {
      handleToggleLike();
    }
  };

  // Like video
  const handleToggleLike = () => {
    if (!currentVideo) return;
    Sound.playClick();
    const isLiked = likedMap[currentVideo.id];
    setLikedMap((prev) => ({ ...prev, [currentVideo.id]: !isLiked }));

    const updated = allVideos.map((v) => {
      if (v.id === currentVideo.id) {
        return {
          ...v,
          likesCount: isLiked ? Math.max(0, v.likesCount - 1) : v.likesCount + 1,
        };
      }
      return v;
    });
    setAllVideos(updated);
    saveVideoFeed(updated);

    if (!isLiked) {
      confetti({ particleCount: 30, spread: 50, origin: { y: 0.6 } });
    }
  };

  // Toggle Save / Bookmark
  const handleToggleSave = () => {
    if (!currentVideo) return;
    Sound.playClick();
    const isSaved = savedMap[currentVideo.id];
    setSavedMap((prev) => ({ ...prev, [currentVideo.id]: !isSaved }));
    showToast(!isSaved ? '✅ ভিডিওটি সেভ তালিকায় যোগ করা হয়েছে।' : 'সেভ তালিকা থেকে সরানো হয়েছে।');
  };

  // Toggle Follow
  const handleToggleFollow = (creatorName: string) => {
    Sound.playClick();
    const isFollowed = isFollowingMap[creatorName];
    setIsFollowingMap((prev) => ({ ...prev, [creatorName]: !isFollowed }));
    showToast(!isFollowed ? `❤️ ${creatorName}-কে ফলো করা হয়েছে!` : 'আনফলো করা হয়েছে।');
  };

  // Offline Cache Toggle
  const handleToggleOfflineCache = (video: VideoContent) => {
    Sound.playClick();
    const isCached = cachedVideoIds[video.id];

    if (isCached) {
      const res = removeVideoFromOfflineCache(video.id);
      if (res.success) {
        setCachedVideoIds((prev) => ({ ...prev, [video.id]: false }));
        setStorageMetrics(getOfflineStorageMetrics());
        showToast('🗑️ ভিডিওটি অফলাইন ক্যাশ থেকে সরানো হয়েছে।');
      }
    } else {
      const res = saveVideoToOfflineCache(video);
      if (res.success) {
        setCachedVideoIds((prev) => ({ ...prev, [video.id]: true }));
        setStorageMetrics(getOfflineStorageMetrics());
        confetti({ particleCount: 35, spread: 50, origin: { y: 0.7 } });
        showToast('💾 ভিডিওটি অফলাইনে সেভ হয়েছে! ইন্টারনেট ছাড়াই চলবে।');
      } else {
        showToast(res.messageBn);
      }
    }
  };

  // Share
  const handleShare = () => {
    Sound.playClick();
    if (navigator.share) {
      navigator
        .share({
          title: currentVideo?.titleBn || 'জয় লুডু রিলস ভিডিও',
          text: currentVideo?.descriptionBn || 'জয় লুডু-তে চমৎকার ভিডিও দেখুন!',
          url: window.location.href,
        })
        .catch(() => {});
    } else {
      navigator.clipboard?.writeText(window.location.href);
      showToast('🔗 ভিডিও লিঙ্ক কপি হয়েছে! বন্ধুদের সাথে শেয়ার করুন।');
    }
  };

  // Send Diamond Tip
  const handleSendGiftTip = () => {
    if (!currentVideo) return;
    if (userDiamonds < selectedGiftDiamonds) {
      Sound.playAlert();
      showToast(`পর্যাপ্ত ডায়মন্ড নেই! প্রয়োজন ${selectedGiftDiamonds}💎, আপনার আছে ${userDiamonds}💎`);
      return;
    }

    if (onDeductDiamonds) {
      onDeductDiamonds(selectedGiftDiamonds);
    }

    const res = sendDiamondGiftToVideo(currentVideo.id, selectedGiftDiamonds, currentUser);
    if (res.success && res.updatedVideo) {
      Sound.playRewardClaim();
      confetti({ particleCount: 65, spread: 70, origin: { y: 0.5 } });

      const updated = allVideos.map((v) => (v.id === currentVideo.id ? res.updatedVideo! : v));
      setAllVideos(updated);
      setIsGiftTipModalOpen(false);
      showToast(`🎉 ক্রিয়েটরকে ৳${res.earnedBDT.toFixed(2)} মূল্যের ${selectedGiftDiamonds}💎 পাঠানো হয়েছে!`);
    }
  };

  // Add Comment
  const handleAddComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentInput.trim() || !currentVideo) return;

    const check = scanContentForPolicyViolation(commentInput, '', []);
    if (!check.isSafe) {
      Sound.playAlert();
      showToast(check.reasonBn || 'অনুপযুক্ত শব্দ ফিল্টার করা হয়েছে!');
      return;
    }

    Sound.playClick();
    const vidId = currentVideo.id;
    const list = commentsMap[vidId] || [];
    setCommentsMap({
      ...commentsMap,
      [vidId]: [commentInput.trim(), ...list],
    });
    setCommentInput('');
    showToast('মন্তব্য যুক্ত হয়েছে ✓');
  };

  return (
    <div
      id="home-reels-feed-container"
      className="relative w-full max-w-[480px] mx-auto h-[calc(100vh-140px)] min-h-[580px] max-h-[860px] rounded-3xl bg-slate-950 border-2 border-slate-800 shadow-2xl overflow-hidden flex flex-col justify-between select-none"
      onWheel={handleWheel}
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
    >
      {/* Toast Notice */}
      {toastMsg && (
        <div className="absolute top-14 left-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-2xl bg-slate-900/95 border border-amber-400 text-amber-300 text-xs font-bold shadow-2xl animate-fade-in flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-amber-400 animate-spin" />
          <span>{toastMsg}</span>
        </div>
      )}

      {/* Floating Hearts from Double Taps */}
      {floatingHearts.map((heart) => (
        <div
          key={heart.id}
          className="absolute z-40 pointer-events-none animate-ping text-rose-500 font-bold"
          style={{ left: heart.x, top: heart.y }}
        >
          <Heart className="w-14 h-14 fill-rose-500 text-rose-500 drop-shadow-lg" />
        </div>
      ))}

      {/* REELS TOP HEADER (Like Facebook Reels Header) */}
      <div className="absolute top-0 left-0 right-0 z-30 px-4 py-3 bg-gradient-to-b from-black/90 via-black/40 to-transparent flex items-center justify-between text-white">
        <div className="flex items-center gap-2">
          <h2 className="text-lg font-black tracking-tight text-white flex items-center gap-1.5">
            <span>Reels</span>
            <span className="px-1.5 py-0.5 rounded-full bg-rose-600 text-[9px] font-black uppercase text-white animate-pulse">
              LIVE
            </span>
          </h2>
        </div>

        <div className="flex items-center gap-2">
          {/* Create Reel Video Studio */}
          <button
            onClick={() => {
              Sound.playClick();
              onOpenStudioModal();
            }}
            className="w-9 h-9 rounded-full bg-white/15 hover:bg-rose-600 text-white flex items-center justify-center transition-all cursor-pointer shadow"
            title="Create Reel or Upload Video"
          >
            <Camera className="w-4 h-4" />
          </button>

          {/* Sound Toggle */}
          <button
            onClick={() => {
              Sound.playClick();
              setIsMuted(!isMuted);
            }}
            className="w-9 h-9 rounded-full bg-white/15 hover:bg-white/25 text-white flex items-center justify-center transition-all cursor-pointer shadow"
            title={isMuted ? 'Unmute' : 'Mute'}
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
          </button>

          {/* Quick Play Ludo Game Button */}
          <button
            onClick={() => {
              Sound.playClick();
              onPlayGameClick();
            }}
            className="px-2.5 py-1.5 rounded-full bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white font-black text-xs flex items-center gap-1 shadow-md active:scale-95 transition-all"
            title="Jump straight to Ludo board"
          >
            <Gamepad2 className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Play Ludo</span>
          </button>
        </div>
      </div>

      {/* CATEGORY CHIPS SCROLLER (Top Sub-bar) */}
      <div className="absolute top-12 left-0 right-0 z-20 px-3 py-1 flex items-center gap-1.5 overflow-x-auto no-scrollbar">
        {[
          { id: 'all', label: '🔥 Trending' },
          { id: 'funny', label: '😂 Funny' },
          { id: 'education', label: '🧠 Tricks' },
          { id: 'creative', label: '✨ Creative' },
          { id: 'epic', label: '🏆 Epic Wins' },
          { id: 'adda', label: '🎙️ Tea Adda' },
        ].map((cat) => (
          <button
            key={cat.id}
            onClick={() => {
              Sound.playButtonTick();
              setActiveCategory(cat.id);
              setCurrentIndex(0);
              setVideoProgress(0);
            }}
            className={`px-3 py-0.8 rounded-full text-[11px] font-bold shrink-0 transition-all cursor-pointer backdrop-blur-md ${
              activeCategory === cat.id
                ? 'bg-white text-slate-950 font-black shadow-md'
                : 'bg-black/50 text-white/80 border border-white/10 hover:bg-black/70'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* MAIN VIDEO STAGE / VISUAL CANVAS */}
      <div
        id="reels-main-video-canvas"
        className="relative w-full h-full flex flex-col justify-between p-4 bg-gradient-to-b from-slate-900 via-slate-950 to-black overflow-hidden cursor-pointer"
        onClick={handleVideoAreaClick}
      >
        {/* Background Visual Graphic Poster Simulation */}
        <div className="absolute inset-0 bg-radial from-indigo-900/30 via-slate-950/80 to-black pointer-events-none" />

        {/* Video Center Highlight Visual */}
        <div className="z-10 flex flex-col items-center justify-center my-auto text-center space-y-4 pt-12">
          {/* Animated Graphic Frame */}
          <div className="relative w-40 h-40 sm:w-48 sm:h-48 rounded-3xl bg-gradient-to-tr from-amber-500 via-rose-600 to-indigo-600 p-1 shadow-2xl border-4 border-amber-300/80 transform hover:scale-105 transition-all">
            <div className="w-full h-full rounded-2xl bg-slate-950 flex flex-col items-center justify-center relative overflow-hidden">
              {/* Category Animated Icon */}
              <span className="text-6xl animate-bounce">
                {currentVideo?.videoType === 'funny_moment'
                  ? '🤣'
                  : currentVideo?.videoType === 'educational_guide' || currentVideo?.videoType === 'tutorial'
                  ? '🧠'
                  : currentVideo?.videoType === 'voice_adda_clip'
                  ? '🎙️'
                  : currentVideo?.videoType === 'creative_good_content'
                  ? '✨'
                  : '🎲'}
              </span>

              {/* Dice Outcome Badge */}
              <div className="absolute top-2 right-2 px-2 py-0.5 rounded-full bg-yellow-400 text-slate-950 text-xs font-black shadow animate-pulse">
                🎲 {currentVideo?.gameSnippet?.diceRoll || 6}
              </div>

              {/* Bubble Highlight */}
              <div className="absolute bottom-2 px-2.5 py-1 bg-black/80 rounded-lg text-[10px] font-black text-amber-300 truncate max-w-[140px] border border-amber-400/30">
                {currentVideo?.videoType === 'funny_moment'
                  ? 'ওরে ভাই একি চাল! 🤣'
                  : currentVideo?.videoType === 'educational_guide'
                  ? 'সেফ জোন ট্রিকস 🔒'
                  : 'লুডু ভাইরাল মোমেন্ট 🏆'}
              </div>
            </div>
          </div>

          {/* Quick Info Pill */}
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-black/60 backdrop-blur-md border border-white/15 text-xs text-amber-200 shadow-md">
            <span>🏆 গুটি কাট: {currentVideo?.gameSnippet?.tokensCaptured || 2} টি</span>
            <span>•</span>
            <span>🪙 কয়েন জয়: +{(currentVideo?.gameSnippet?.coinsWon || 15000).toLocaleString()}</span>
          </div>

          {/* Play/Pause state indicator */}
          {!isPlaying && (
            <div className="absolute inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center pointer-events-none">
              <div className="w-16 h-16 rounded-full bg-black/80 border-2 border-white/40 flex items-center justify-center text-white text-2xl shadow-2xl animate-pulse">
                ▶
              </div>
            </div>
          )}
        </div>

        {/* REELS RIGHT FLOATING ACTIONS (Matching Facebook Reels UI) */}
        <div className="absolute right-3 bottom-20 z-30 flex flex-col items-center gap-4 text-white">
          {/* 1. Like Button */}
          <div className="flex flex-col items-center">
            <button
              onClick={(e) => {
                e.stopPropagation();
                handleToggleLike();
              }}
              className={`w-11 h-11 rounded-full flex items-center justify-center backdrop-blur-md shadow-lg transition-all active:scale-75 ${
                currentVideo && likedMap[currentVideo.id]
                  ? 'bg-rose-600 text-white animate-bounce'
                  : 'bg-black/50 hover:bg-black/70 text-white'
              }`}
            >
              <Heart
                className={`w-6 h-6 ${
                  currentVideo && likedMap[currentVideo.id] ? 'fill-white' : ''
                }`}
              />
            </button>
            <span className="text-[11px] font-black mt-1 drop-shadow">
              {(
                (currentVideo?.likesCount || 1200) +
                (currentVideo && likedMap[currentVideo.id] ? 1 : 0)
              ).toLocaleString()}
            </span>
          </div>

          {/* 2. Comments Button */}
          <div className="flex flex-col items-center">
            <button
              onClick={(e) => {
                e.stopPropagation();
                Sound.playClick();
                setIsCommentDrawerOpen(true);
              }}
              className="w-11 h-11 rounded-full bg-black/50 hover:bg-black/70 flex items-center justify-center backdrop-blur-md text-white shadow-lg active:scale-75 transition-all"
            >
              <MessageCircle className="w-6 h-6" />
            </button>
            <span className="text-[11px] font-black mt-1 drop-shadow">
              {(commentsMap[currentVideo?.id || '']?.length || 12).toLocaleString()}
            </span>
          </div>

          {/* 3. Share Button */}
          <div className="flex flex-col items-center">
            <button
              onClick={(e) => {
                e.stopPropagation();
                handleShare();
              }}
              className="w-11 h-11 rounded-full bg-black/50 hover:bg-black/70 flex items-center justify-center backdrop-blur-md text-white shadow-lg active:scale-75 transition-all"
            >
              <Share2 className="w-6 h-6" />
            </button>
            <span className="text-[11px] font-black mt-1 drop-shadow">
              {(currentVideo?.sharesCount || 45).toLocaleString()}
            </span>
          </div>

          {/* 4. Bookmark / Save Button */}
          <div className="flex flex-col items-center">
            <button
              onClick={(e) => {
                e.stopPropagation();
                handleToggleSave();
              }}
              className={`w-11 h-11 rounded-full flex items-center justify-center backdrop-blur-md shadow-lg transition-all active:scale-75 ${
                currentVideo && savedMap[currentVideo.id]
                  ? 'bg-amber-500 text-slate-950 font-black'
                  : 'bg-black/50 hover:bg-black/70 text-white'
              }`}
            >
              <Bookmark
                className={`w-5 h-5 ${
                  currentVideo && savedMap[currentVideo.id] ? 'fill-slate-950' : ''
                }`}
              />
            </button>
            <span className="text-[11px] font-black mt-1 drop-shadow">Save</span>
          </div>

          {/* 5. Diamond Tip Gift to Creator */}
          <div className="flex flex-col items-center">
            <button
              onClick={(e) => {
                e.stopPropagation();
                Sound.playClick();
                setIsGiftTipModalOpen(true);
              }}
              className="w-11 h-11 rounded-full bg-gradient-to-tr from-amber-400 to-yellow-600 text-slate-950 font-black flex items-center justify-center shadow-lg active:scale-75 transition-all border border-yellow-200 animate-pulse"
              title="Send Diamond Gift to Creator"
            >
              <Gift className="w-5 h-5" />
            </button>
            <span className="text-[10px] font-black mt-1 text-amber-300 drop-shadow">Tip</span>
          </div>

          {/* 6. Rotating Music Disc */}
          <div className="w-10 h-10 rounded-full border-2 border-white/40 bg-gradient-to-tr from-rose-600 to-indigo-600 flex items-center justify-center animate-spin text-white shadow-lg">
            <Music className="w-4 h-4" />
          </div>
        </div>

        {/* REELS BOTTOM INFO OVERLAY (Creator, Follow, Title, Tags, CTA button) */}
        <div className="z-20 flex flex-col gap-2 max-w-[80%] pr-2">
          {/* Creator Profile Row */}
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-amber-400 to-rose-500 p-0.5 shadow-md flex items-center justify-center overflow-hidden">
              {currentVideo?.creatorAvatar ? (
                <AvatarDisplay avatar={currentVideo.creatorAvatar} size={36} />
              ) : (
                <div className="w-full h-full rounded-full bg-slate-900 flex items-center justify-center text-white font-black text-sm">
                  👤
                </div>
              )}
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-sm font-black text-white drop-shadow">
                  {currentVideo?.creatorName || 'Tea Adda Creator'}
                </span>
                <span className="text-[10px] text-amber-300">✓</span>
              </div>
              <span className="text-[10px] text-slate-300 font-medium">
                {currentVideo?.videoType === 'funny_moment' ? '😂 Comedy Creator' : '🎮 Pro Ludo Player'}
              </span>
            </div>

            {/* Follow Button */}
            <button
              onClick={(e) => {
                e.stopPropagation();
                handleToggleFollow(currentVideo?.creatorName || 'Creator');
              }}
              className={`px-3 py-1 rounded-full text-xs font-black transition-all cursor-pointer shadow ml-1 ${
                isFollowingMap[currentVideo?.creatorName || 'Creator']
                  ? 'bg-white/20 text-white'
                  : 'bg-rose-600 hover:bg-rose-500 text-white animate-pulse'
              }`}
            >
              {isFollowingMap[currentVideo?.creatorName || 'Creator'] ? 'Following' : '+ Follow'}
            </button>
          </div>

          {/* Video Title & Caption */}
          <div>
            <h3 className="text-sm font-bold text-white line-clamp-2 drop-shadow">
              {currentVideo?.titleBn || 'Tea Adda Viral Moment'}
            </h3>
            <p className="text-xs text-slate-200/90 line-clamp-2 mt-0.5 font-normal">
              {currentVideo?.descriptionBn || 'Amazing Ludo match highlights and gameplay clips!'}
            </p>
          </div>

          {/* Hashtags & Music Track */}
          <div className="flex items-center gap-2 text-[11px] text-amber-300 font-bold overflow-hidden">
            <div className="flex items-center gap-1 truncate">
              <Music className="w-3.5 h-3.5 shrink-0 text-white" />
              <span className="truncate">{currentVideo?.audioTrackName || 'Tea Adda Original Sound - Beat Track'}</span>
            </div>
          </div>

          {/* Action CTA Button */}
          <div className="pt-1">
            <button
              onClick={(e) => {
                e.stopPropagation();
                Sound.playClick();
                onPlayGameClick();
              }}
              className="w-full py-2 px-4 rounded-xl bg-gradient-to-r from-cyan-600 via-blue-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white font-black text-xs shadow-lg flex items-center justify-center gap-2 active:scale-95 transition-all"
            >
              <Gamepad2 className="w-4 h-4" />
              <span>🎮 Play This Move in Ludo</span>
            </button>
          </div>
        </div>

        {/* Video Progress Bar at the Very Bottom */}
        <div className="absolute bottom-0 left-0 right-0 h-1 bg-white/20 z-30">
          <div
            className="h-full bg-gradient-to-r from-amber-400 to-rose-500 transition-all duration-200"
            style={{ width: `${videoProgress}%` }}
          />
        </div>
      </div>

      {/* Floating Prev / Next Quick Scroll Arrows on side for Desktop */}
      <div className="absolute left-2 top-1/2 -translate-y-1/2 z-30 hidden sm:flex flex-col gap-2">
        <button
          onClick={handleScrollPrev}
          className="w-8 h-8 rounded-full bg-black/60 hover:bg-black/90 text-white flex items-center justify-center transition-all cursor-pointer shadow-lg"
          title="Previous Video (Arrow Up)"
        >
          <ChevronUp className="w-5 h-5" />
        </button>
        <button
          onClick={handleScrollNext}
          className="w-8 h-8 rounded-full bg-black/60 hover:bg-black/90 text-white flex items-center justify-center transition-all cursor-pointer shadow-lg"
          title="Next Video (Arrow Down)"
        >
          <ChevronDown className="w-5 h-5" />
        </button>
      </div>

      {/* COMMENT DRAWER MODAL */}
      {isCommentDrawerOpen && (
        <div
          className="absolute inset-0 z-50 bg-black/80 backdrop-blur-md flex flex-col justify-end animate-fade-in"
          onClick={() => setIsCommentDrawerOpen(false)}
        >
          <div
            className="bg-slate-900 rounded-t-3xl border-t-2 border-slate-700 p-4 max-h-[70vh] flex flex-col justify-between"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <MessageCircle className="w-5 h-5 text-amber-400" />
                <h3 className="text-sm font-black text-white">
                  Comments (
                  {(commentsMap[currentVideo?.id || '']?.length || 0).toLocaleString()}
                  )
                </h3>
              </div>
              <button
                onClick={() => setIsCommentDrawerOpen(false)}
                className="w-7 h-7 rounded-full bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Comment List */}
            <div className="flex-1 overflow-y-auto py-3 space-y-2.5 max-h-[40vh]">
              {(commentsMap[currentVideo?.id || ''] || []).map((cmt, idx) => (
                <div key={idx} className="p-2.5 rounded-2xl bg-slate-950 border border-slate-800 flex gap-2.5">
                  <div className="w-7 h-7 rounded-full bg-amber-500/20 text-amber-300 font-black text-xs flex items-center justify-center shrink-0">
                    👤
                  </div>
                  <div className="flex-1">
                    <span className="text-[11px] font-bold text-slate-400 block">Ludo Fan</span>
                    <p className="text-xs text-white leading-relaxed">{cmt}</p>
                  </div>
                </div>
              ))}
            </div>

            {/* Comment Input Form */}
            <form onSubmit={handleAddComment} className="pt-3 border-t border-slate-800 flex gap-2">
              <input
                type="text"
                value={commentInput}
                onChange={(e) => setCommentInput(e.target.value)}
                placeholder="Write a comment..."
                className="flex-1 bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
              />
              <button
                type="submit"
                className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white font-black text-xs rounded-xl flex items-center gap-1 cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Send</span>
              </button>
            </form>
          </div>
        </div>
      )}

      {/* DIAMOND GIFT MODAL */}
      {isGiftTipModalOpen && (
        <div
          className="absolute inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in"
          onClick={() => setIsGiftTipModalOpen(false)}
        >
          <div
            className="bg-slate-900 border-2 border-amber-400 rounded-3xl p-5 w-full max-w-sm text-white shadow-2xl text-center space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="w-12 h-12 rounded-2xl bg-amber-400/20 text-amber-400 flex items-center justify-center mx-auto text-2xl">
              💎
            </div>
            <div>
              <h3 className="text-base font-black text-white">Send Diamond Tip to Creator</h3>
              <p className="text-xs text-slate-300 mt-1">
                Support and cheer your favorite content creator
              </p>
            </div>

            <div className="grid grid-cols-3 gap-2">
              {[10, 50, 100].map((count) => (
                <button
                  key={count}
                  onClick={() => setSelectedGiftDiamonds(count)}
                  className={`p-2.5 rounded-2xl border-2 font-black text-xs flex flex-col items-center gap-1 transition-all cursor-pointer ${
                    selectedGiftDiamonds === count
                      ? 'border-amber-400 bg-amber-400/20 text-amber-300'
                      : 'border-slate-800 bg-slate-950 text-slate-300'
                  }`}
                >
                  <span className="text-base">💎 {count}</span>
                  <span className="text-[10px] text-slate-400 font-normal">${(count * 0.05).toFixed(2)}</span>
                </button>
              ))}
            </div>

            <div className="flex gap-2 pt-2">
              <button
                onClick={() => setIsGiftTipModalOpen(false)}
                className="flex-1 py-2 bg-slate-800 text-slate-300 text-xs font-bold rounded-xl cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleSendGiftTip}
                className="flex-1 py-2 bg-gradient-to-r from-amber-400 to-yellow-500 text-slate-950 text-xs font-black rounded-xl shadow-lg cursor-pointer"
              >
                Send ({selectedGiftDiamonds}💎)
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
