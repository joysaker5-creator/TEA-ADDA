import React, { useEffect, useState } from 'react';
import { Zap, Clock, Flame, AlertCircle } from 'lucide-react';
import { Player, PlayerColor } from '../types';
import { COLOR_CONFIG } from '../utils/ludoConstants';
import { Sound } from '../utils/soundEffects';

interface QuickMatchHUDProps {
  players: Player[];
  currentTurnColor: PlayerColor;
  onTimeOut: () => void;
  targetTokens?: number;
  hasRolled: boolean;
  isRolling: boolean;
}

export const QuickMatchHUD: React.FC<QuickMatchHUDProps> = ({
  players,
  currentTurnColor,
  onTimeOut,
  targetTokens = 2,
  hasRolled,
  isRolling,
}) => {
  const [timeLeft, setTimeLeft] = useState<number>(15);

  // Reset timer on turn switch
  useEffect(() => {
    setTimeLeft(15);
  }, [currentTurnColor]);

  // Countdown timer effect
  useEffect(() => {
    if (timeLeft <= 0) {
      onTimeOut();
      return;
    }

    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev === 4 || prev === 3 || prev === 2) {
          Sound.playClick();
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [timeLeft, onTimeOut]);

  const percentage = (timeLeft / 15) * 100;
  const isUrgent = timeLeft <= 5;

  return (
    <div className="w-full max-w-[560px] mx-auto mb-2.5 bg-gradient-to-r from-amber-500 via-orange-500 to-red-500 text-white rounded-2xl p-2.5 sm:p-3 shadow-lg border-b-4 border-red-700">
      <div className="flex flex-wrap items-center justify-between gap-2">
        {/* Left info badge */}
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-xl bg-white/20 backdrop-blur-md flex items-center justify-center text-yellow-200 shadow-inner">
            <Zap className="w-4 h-4 fill-yellow-300" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-black tracking-wide leading-tight">
                কুইক ম্যাচ (দ্রুত খেলা)
              </span>
              <span className="bg-yellow-300 text-slate-950 text-[9px] font-black px-1.5 py-0.2 rounded-md uppercase">
                টার্গেট ২ গুটি
              </span>
            </div>
            <p className="text-[10px] text-yellow-100 font-bold leading-tight">
              🔥 ১ অথবা ৬ এ গুটি বের হবে • দ্রুততম বিজয়ী
            </p>
          </div>
        </div>

        {/* Turn Timer Bar & Countdown */}
        <div className="flex items-center gap-2 bg-black/25 backdrop-blur-sm px-3 py-1.5 rounded-xl border border-white/20">
          <Clock className={`w-3.5 h-3.5 ${isUrgent ? 'text-yellow-300 animate-spin' : 'text-white'}`} />
          <span
            className={`text-xs font-black tracking-tight ${
              isUrgent ? 'text-yellow-200 animate-pulse text-sm' : 'text-white'
            }`}
          >
            {timeLeft}s
          </span>

          <div className="w-14 sm:w-20 h-2 bg-white/30 rounded-full overflow-hidden">
            <div
              className={`h-full transition-all duration-1000 ${
                isUrgent ? 'bg-yellow-300' : 'bg-white'
              }`}
              style={{ width: `${percentage}%` }}
            />
          </div>
        </div>
      </div>

      {/* Mini tokens progress */}
      <div className="mt-2 pt-1.5 border-t border-white/20 flex items-center justify-between text-[11px] font-bold">
        {players.map((p) => {
          const homeCount = p.tokens.filter((t) => t.isHome).length;
          const isTurn = p.color === currentTurnColor;
          return (
            <div
              key={p.color}
              className={`flex items-center gap-1 px-1.5 py-0.5 rounded-lg transition-all ${
                isTurn ? 'bg-white text-slate-900 font-black shadow-sm' : 'text-white/90'
              }`}
            >
              <div
                className="w-2.5 h-2.5 rounded-full border border-white"
                style={{ backgroundColor: ((p.color && COLOR_CONFIG[p.color]) || COLOR_CONFIG.red).hex }}
              />
              <span className="truncate max-w-[55px] sm:max-w-[70px]">{p.name}</span>:
              <span>
                {homeCount}/{targetTokens}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
};
