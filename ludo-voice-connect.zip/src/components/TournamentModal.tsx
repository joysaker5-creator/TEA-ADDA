import React from 'react';
import { Trophy, Award, Play, RotateCcw, X, Shield, Star, CheckCircle2 } from 'lucide-react';
import { TournamentMatch, TournamentStage, PlayerColor } from '../types';
import { COLOR_CONFIG } from '../utils/ludoConstants';
import { AvatarDisplay } from './AvatarDisplay';

interface TournamentModalProps {
  isOpen: boolean;
  onClose: () => void;
  matches: TournamentMatch[];
  currentStage: TournamentStage;
  onPlayNextMatch: () => void;
  onResetTournament: () => void;
  isTournamentOver: boolean;
  championName?: string;
  championColor?: PlayerColor;
  prizePool: number;
}

export const TournamentModal: React.FC<TournamentModalProps> = ({
  isOpen,
  onClose,
  matches,
  currentStage,
  onPlayNextMatch,
  onResetTournament,
  isTournamentOver,
  championName,
  championColor,
  prizePool,
}) => {
  if (!isOpen) return null;

  const quarterMatches = matches.filter((m) => m.stage === 'quarter');
  const semiMatches = matches.filter((m) => m.stage === 'semi');
  const finalMatch = matches.find((m) => m.stage === 'final');

  const getStageTitle = (stage: TournamentStage) => {
    switch (stage) {
      case 'quarter':
        return 'রাউন্ড ১: কোয়ার্টার-ফাইনাল';
      case 'semi':
        return 'রাউন্ড ২: সেমি-ফাইনাল';
      case 'final':
        return 'গ্র্যান্ড ফাইনাল 🏆';
      case 'champion':
        return 'টুর্নামেন্ট সমাপ্ত 🏆';
    }
  };

  const renderMatchCard = (match: TournamentMatch, isSmall = false) => {
    const isCurrent = match.status === 'current';
    const isCompleted = match.status === 'completed';

    return (
      <div
        key={match.id}
        className={`relative rounded-2xl p-2.5 transition-all border-2 ${
          isCurrent
            ? 'bg-amber-50 border-amber-500 shadow-md ring-2 ring-amber-400/50'
            : isCompleted
            ? 'bg-slate-50 border-slate-200 opacity-95'
            : 'bg-white border-dashed border-slate-300'
        }`}
      >
        {isCurrent && (
          <span className="absolute -top-2.5 right-2 bg-red-500 text-white text-[9px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider animate-pulse flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-white animate-ping" />
            LIVE
          </span>
        )}

        {(() => {
          const p1Cfg = (match.player1?.color && COLOR_CONFIG[match.player1.color]) || COLOR_CONFIG.red;
          const p2Cfg = (match.player2?.color && COLOR_CONFIG[match.player2.color]) || COLOR_CONFIG.blue;

          return (
            <div className="space-y-1.5">
              {/* Player 1 */}
              <div
                className={`flex items-center justify-between p-1.5 rounded-xl border ${
                  match.winnerColor === match.player1?.color
                    ? 'bg-emerald-50 border-emerald-300 font-black'
                    : 'bg-white border-slate-100'
                }`}
              >
                <div className="flex items-center gap-2 min-w-0">
                  <AvatarDisplay avatar={match.player1?.avatar} size={isSmall ? 24 : 28} />
                  <div className="truncate">
                    <span className="text-xs font-black text-slate-900 block truncate leading-tight">
                      {match.player1?.name || 'Player 1'} {match.player1?.isUser && '(You)'}
                    </span>
                    <span
                      className="text-[9px] font-extrabold"
                      style={{ color: p1Cfg.hex }}
                    >
                      {p1Cfg.name}
                    </span>
                  </div>
                </div>
                {match.winnerColor && match.winnerColor === match.player1?.color && (
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                )}
              </div>

              {/* VS Divider */}
              <div className="text-center text-[10px] font-black text-slate-400 -my-1">vs</div>

              {/* Player 2 */}
              <div
                className={`flex items-center justify-between p-1.5 rounded-xl border ${
                  match.winnerColor === match.player2?.color
                    ? 'bg-emerald-50 border-emerald-300 font-black'
                    : 'bg-white border-slate-100'
                }`}
              >
                <div className="flex items-center gap-2 min-w-0">
                  <AvatarDisplay avatar={match.player2?.avatar} size={isSmall ? 24 : 28} />
                  <div className="truncate">
                    <span className="text-xs font-black text-slate-900 block truncate leading-tight">
                      {match.player2?.name || 'Player 2'} {match.player2?.isUser && '(You)'}
                    </span>
                    <span
                      className="text-[9px] font-extrabold"
                      style={{ color: p2Cfg.hex }}
                    >
                      {p2Cfg.name}
                    </span>
                  </div>
                </div>
                {match.winnerColor && match.winnerColor === match.player2?.color && (
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                )}
              </div>
            </div>
          );
        })()}
      </div>
    );
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in overflow-y-auto">
      <div
        id="tournament-modal"
        className="relative w-full max-w-3xl bg-white rounded-3xl p-5 sm:p-6 shadow-2xl border-4 border-amber-300 text-slate-900 overflow-hidden my-auto"
      >
        {/* Close Button */}
        <button
          id="close-tournament-modal"
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors"
          title="বন্ধ করুন"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="text-center mb-5">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-100 border border-amber-300 text-amber-900 text-xs font-black uppercase tracking-wider mb-2">
            <Trophy className="w-3.5 h-3.5 text-amber-600" />
            লুডু নকআউট চ্যাম্পিয়নশিপ
          </div>
          <h2 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
            টুর্নামেন্ট ব্র্যাকেট
          </h2>
          <p className="text-xs text-slate-600 font-semibold mt-0.5">
            বর্তমান ধাপ: <span className="text-red-600 font-bold">{getStageTitle(currentStage)}</span> • প্রাইজপুল: {prizePool.toLocaleString('bn-BD')} কয়েন 💰
          </p>
        </div>

        {/* Champion celebration banner if tournament over */}
        {isTournamentOver && championName && (
          <div className="mb-6 p-4 rounded-2xl bg-gradient-to-r from-amber-400 via-yellow-300 to-amber-500 border-2 border-amber-600 text-center shadow-lg animate-bounce">
            <span className="text-2xl">👑 🏆 👑</span>
            <h3 className="text-xl font-black text-amber-950 mt-1">
              {championName} টুর্নামেন্ট চ্যাম্পিয়ন হয়েছেন!
            </h3>
            <p className="text-xs font-extrabold text-amber-900 mt-0.5">
              +{prizePool.toLocaleString('bn-BD')} কয়েন গ্র্যান্ড প্রাইজ লাভ করেছেন!
            </p>
          </div>
        )}

        {/* Bracket Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          {/* Column 1: Quarter Finals */}
          <div className="bg-amber-50/60 p-3 rounded-2xl border border-amber-200">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-black text-amber-950 uppercase tracking-wider">
                কোয়ার্টার-ফাইনাল
              </span>
              <span className="text-[10px] font-extrabold text-amber-700 bg-amber-200/70 px-2 py-0.5 rounded-full">
                ৪ ম্যাচ
              </span>
            </div>
            <div className="space-y-2.5">
              {quarterMatches.map((m) => renderMatchCard(m, true))}
            </div>
          </div>

          {/* Column 2: Semi Finals */}
          <div className="bg-amber-50/60 p-3 rounded-2xl border border-amber-200 flex flex-col justify-center">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-black text-amber-950 uppercase tracking-wider">
                সেমি-ফাইনাল
              </span>
              <span className="text-[10px] font-extrabold text-amber-700 bg-amber-200/70 px-2 py-0.5 rounded-full">
                ২ ম্যাচ
              </span>
            </div>
            <div className="space-y-4 my-auto">
              {semiMatches.map((m) => renderMatchCard(m, false))}
            </div>
          </div>

          {/* Column 3: Grand Final */}
          <div className="bg-gradient-to-b from-amber-100 via-amber-50 to-orange-100 p-3 rounded-2xl border-2 border-amber-400 flex flex-col justify-center text-center">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-black text-amber-950 uppercase tracking-wider flex items-center gap-1">
                <Trophy className="w-3.5 h-3.5 text-amber-700" />
                গ্র্যান্ড ফাইনাল
              </span>
              <span className="text-[10px] font-black text-white bg-red-500 px-2 py-0.5 rounded-full">
                ট্রফি ম্যাচ
              </span>
            </div>

            <div className="my-auto">
              {finalMatch ? (
                renderMatchCard(finalMatch, false)
              ) : (
                <div className="p-4 rounded-xl border-2 border-dashed border-amber-300 text-amber-800 text-xs font-bold">
                  সেমি-ফাইনাল শেষে ফাইনালিস্ট নির্ধারিত হবে
                </div>
              )}

              {/* Grand Trophy Visual */}
              <div className="mt-3 p-3 rounded-2xl bg-amber-200/60 border border-amber-300 flex items-center justify-center gap-2">
                <Trophy className="w-6 h-6 text-amber-700 fill-amber-400" />
                <div className="text-left">
                  <span className="text-xs font-black text-amber-950 block">গ্র্যান্ড ট্রফি ও কাপ</span>
                  <span className="text-[10px] font-black text-amber-900">
                    +{prizePool.toLocaleString('bn-BD')} কয়েন বোনাস 🪙
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Actions */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2 border-t border-slate-200">
          <button
            id="reset-tournament-btn"
            onClick={onResetTournament}
            className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-black flex items-center justify-center gap-1.5 transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>নতুন টুর্নামেন্ট শুরু করুন</span>
          </button>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              id="tournament-close-btn"
              onClick={onClose}
              className="flex-1 sm:flex-initial px-5 py-2.5 rounded-xl border border-slate-300 hover:bg-slate-50 text-slate-700 text-xs font-black transition-colors"
            >
              বন্ধ করুন
            </button>

            {!isTournamentOver && (
              <button
                id="play-tournament-round-btn"
                onClick={() => {
                  onPlayNextMatch();
                  onClose();
                }}
                className="flex-1 sm:flex-initial px-6 py-2.5 rounded-xl bg-gradient-to-r from-red-500 to-rose-600 hover:from-red-600 hover:to-rose-700 text-white text-xs font-black shadow-md border-b-4 border-red-800 active:translate-y-0.5 active:border-b-0 flex items-center justify-center gap-2 transition-all"
              >
                <Play className="w-4 h-4 fill-white" />
                <span>বর্তমান ম্যাচ খেলুন</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
