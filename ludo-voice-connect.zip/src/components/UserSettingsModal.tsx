import React, { useState } from 'react';
import {
  X,
  Settings,
  Volume2,
  VolumeX,
  Music,
  Smartphone,
  Mic,
  Sliders,
  Globe,
  Bell,
  ShieldCheck,
  RotateCcw,
  Check,
  Gamepad2,
  Lock,
  User,
  Sparkles,
  Info,
  CheckCircle2,
  Clock,
  Download
} from 'lucide-react';
import { UserSettings, loadUserSettings, saveUserSettings, DEFAULT_USER_SETTINGS } from '../utils/userSettingsService';
import { Sound } from '../utils/soundEffects';

interface UserSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenProfile?: () => void;
  onOpenAgeSafety?: () => void;
  onOpenRules?: () => void;
  onSettingsUpdated?: (settings: UserSettings) => void;
  isEn?: boolean;
}

type TabType = 'sound' | 'gameplay' | 'notifications' | 'privacy' | 'about';

export const UserSettingsModal: React.FC<UserSettingsModalProps> = ({
  isOpen,
  onClose,
  onOpenProfile,
  onOpenAgeSafety,
  onOpenRules,
  onSettingsUpdated,
  isEn: propIsEn,
}) => {
  const [settings, setSettings] = useState<UserSettings>(() => loadUserSettings());
  const [activeTab, setActiveTab] = useState<TabType>('sound');
  const [showSavedToast, setShowSavedToast] = useState(false);

  const isEn = propIsEn !== undefined ? propIsEn : settings.language === 'en';

  if (!isOpen) return null;

  const updateSetting = <K extends keyof UserSettings>(key: K, value: UserSettings[K]) => {
    const updated = { ...settings, [key]: value };
    setSettings(updated);
    saveUserSettings(updated);
    if (onSettingsUpdated) {
      onSettingsUpdated(updated);
    }
    Sound.playClick();
    setShowSavedToast(true);
    setTimeout(() => setShowSavedToast(false), 2000);
  };

  const handleResetDefaults = () => {
    Sound.playClick();
    setSettings(DEFAULT_USER_SETTINGS);
    saveUserSettings(DEFAULT_USER_SETTINGS);
    if (onSettingsUpdated) {
      onSettingsUpdated(DEFAULT_USER_SETTINGS);
    }
    setShowSavedToast(true);
    setTimeout(() => setShowSavedToast(false), 2000);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md animate-fade-in"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-2xl bg-slate-900 border-2 border-amber-400/80 rounded-3xl p-4 sm:p-6 text-white shadow-2xl overflow-hidden max-h-[90vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3.5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-500 to-yellow-400 flex items-center justify-center text-slate-950 shadow-md">
              <Settings className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-black text-white flex items-center gap-2">
                {isEn ? 'Game Settings' : 'অ্যাপ সেটিংস (Settings)'}
                {showSavedToast && (
                  <span className="text-[10px] bg-emerald-500 text-slate-950 font-bold px-2 py-0.5 rounded-full flex items-center gap-1 animate-pulse">
                    <Check className="w-3 h-3" /> {isEn ? 'Saved' : 'সেভ হয়েছে'}
                  </span>
                )}
              </h3>
              <p className="text-xs text-slate-400">
                {isEn ? 'Sound, gameplay, language & privacy controls' : 'সাউন্ড, গেমপ্লে, ভাষা ও নিরাপত্তা নিয়ন্ত্রণ করুন'}
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              Sound.playClick();
              onClose();
            }}
            className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center cursor-pointer transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1.5 overflow-x-auto py-2.5 border-b border-slate-800/80 no-scrollbar">
          <button
            onClick={() => {
              Sound.playClick();
              setActiveTab('sound');
            }}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-black shrink-0 transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'sound'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'bg-slate-800/70 text-slate-300 hover:bg-slate-800'
            }`}
          >
            <Volume2 className="w-3.5 h-3.5" />
            {isEn ? 'Sound & Audio' : 'সাউন্ড ও মিউজিক'}
          </button>

          <button
            onClick={() => {
              Sound.playClick();
              setActiveTab('gameplay');
            }}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-black shrink-0 transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'gameplay'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'bg-slate-800/70 text-slate-300 hover:bg-slate-800'
            }`}
          >
            <Gamepad2 className="w-3.5 h-3.5" />
            {isEn ? 'Gameplay' : 'গেমপ্লে সেটিংস'}
          </button>

          <button
            onClick={() => {
              Sound.playClick();
              setActiveTab('notifications');
            }}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-black shrink-0 transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'notifications'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'bg-slate-800/70 text-slate-300 hover:bg-slate-800'
            }`}
          >
            <Bell className="w-3.5 h-3.5" />
            {isEn ? 'Alerts & Language' : 'নোটিফিকেশন ও ভাষা'}
          </button>

          <button
            onClick={() => {
              Sound.playClick();
              setActiveTab('privacy');
            }}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-black shrink-0 transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'privacy'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'bg-slate-800/70 text-slate-300 hover:bg-slate-800'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            {isEn ? 'Safety & Controls' : 'নিরাপত্তা ও স্ক্রিন টাইম'}
          </button>

          <button
            onClick={() => {
              Sound.playClick();
              setActiveTab('about');
            }}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-black shrink-0 transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'about'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'bg-slate-800/70 text-slate-300 hover:bg-slate-800'
            }`}
          >
            <Info className="w-3.5 h-3.5" />
            {isEn ? 'About App' : 'অ্যাপ তথ্য'}
          </button>
        </div>

        {/* Tab Contents */}
        <div className="overflow-y-auto pr-1 my-3 space-y-3.5 text-xs text-slate-300 leading-relaxed flex-1">
          {/* TAB 1: SOUND & AUDIO */}
          {activeTab === 'sound' && (
            <div className="space-y-3">
              {/* Sound Effects Toggle */}
              <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-400/30">
                    {settings.soundEffects ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
                  </div>
                  <div>
                    <h4 className="text-xs font-black text-white">
                      {isEn ? 'Sound Effects (Sound FX)' : 'গেম সাউন্ড এফেক্টস (Sound FX)'}
                    </h4>
                    <p className="text-[11px] text-slate-400">
                      {isEn ? 'Dice rolls, token steps & victory sounds' : 'ডাইস রোল, গুটির চাল ও বিজয়ের সাউন্ড'}
                    </p>
                  </div>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings.soundEffects}
                    onChange={(e) => updateSetting('soundEffects', e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-amber-500"></div>
                </label>
              </div>

              {/* Sound FX Volume Slider */}
              {settings.soundEffects && (
                <div className="p-3 rounded-2xl bg-slate-950/50 border border-slate-800/80">
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-[11px] font-bold text-slate-300">
                      {isEn ? 'Effects Volume' : 'সাউন্ড ভলিউম'}
                    </span>
                    <span className="text-[11px] font-black text-amber-400">{settings.soundVolume}%</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={settings.soundVolume}
                    onChange={(e) => updateSetting('soundVolume', Number(e.target.value))}
                    className="w-full accent-amber-500 bg-slate-800 h-2 rounded-lg cursor-pointer"
                  />
                </div>
              )}

              {/* Background Music Toggle */}
              <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center border border-purple-400/30">
                    <Music className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-black text-white">
                      {isEn ? 'Background Music (BGM)' : 'ব্যাকগ্রাউন্ড মিউজিক (BGM)'}
                    </h4>
                    <p className="text-[11px] text-slate-400">
                      {isEn ? 'Soothing ambient lobby and gameplay tunes' : 'লবি ও খেলার শান্ত ও মিষ্টি আবহ সুর'}
                    </p>
                  </div>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings.backgroundMusic}
                    onChange={(e) => updateSetting('backgroundMusic', e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-500"></div>
                </label>
              </div>

              {/* Vibration Toggle */}
              <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-sky-500/20 text-sky-400 flex items-center justify-center border border-sky-400/30">
                    <Smartphone className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-black text-white">
                      {isEn ? 'Haptic Feedback & Vibration' : 'ভাইব্রেশন ও হ্যাপটিক টাচ (Vibration)'}
                    </h4>
                    <p className="text-[11px] text-slate-400">
                      {isEn ? 'Gentle vibration on roll of 6 and turn alert' : 'ছক্কা পড়লে ও নিজের চাল এলে ফোন মৃদু কাঁপবে'}
                    </p>
                  </div>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings.vibration}
                    onChange={(e) => updateSetting('vibration', e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-sky-500"></div>
                </label>
              </div>

              {/* Voice Chat Toggle */}
              <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-400/30">
                    <Mic className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-black text-white">
                      {isEn ? 'Voice Chat & Audio Club' : 'ভয়েস চ্যাট ও আড্ডা অডিও'}
                    </h4>
                    <p className="text-[11px] text-slate-400">
                      {isEn ? 'Enable speaking with online friends in matches' : 'অনলাইন বন্ধুদের সাথে কথা বলা সক্রিয় রাখুন'}
                    </p>
                  </div>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings.voiceChatEnabled}
                    onChange={(e) => updateSetting('voiceChatEnabled', e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-500"></div>
                </label>
              </div>
            </div>
          )}

          {/* TAB 2: GAMEPLAY SETTINGS */}
          {activeTab === 'gameplay' && (
            <div className="space-y-3">
              {/* Auto Move Single Token */}
              <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-400/30">
                    <Sparkles className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-black text-white">
                      {isEn ? 'Auto-Move Single Token' : 'একক গুটি অটো-মুভ (Auto Move)'}
                    </h4>
                    <p className="text-[11px] text-slate-400">
                      {isEn ? 'Automatically advance when only 1 token has a valid move' : 'চালার জন্য মাত্র ১টি গুটি সক্রিয় থাকলে স্বয়ংক্রিয়ভাবে চালবে'}
                    </p>
                  </div>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings.autoMoveSingleToken}
                    onChange={(e) => updateSetting('autoMoveSingleToken', e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-amber-500"></div>
                </label>
              </div>

              {/* Dice Animation Speed */}
              <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <Sliders className="w-4 h-4 text-amber-400" />
                    <h4 className="text-xs font-black text-white">
                      {isEn ? 'Dice & Animation Speed' : 'ডাইস ও অ্যানিমেশন স্পিড'}
                    </h4>
                  </div>
                  <span className="text-[10px] text-slate-400">
                    {isEn ? 'Match pacing control' : 'খেলার গতি নিয়ন্ত্রণ'}
                  </span>
                </div>
                <div className="grid grid-cols-3 gap-2">
                  {(
                    [
                      { id: 'normal', label: isEn ? 'Normal' : 'স্বাভাবিক (Normal)', desc: isEn ? 'Classic feel' : 'ক্লাসিক অনুভূতি' },
                      { id: 'fast', label: isEn ? 'Fast' : 'দ্রুত (Fast)', desc: isEn ? 'Smooth & fast' : 'স্মুথ ও ফাস্ট' },
                      { id: 'turbo', label: isEn ? 'Turbo' : 'টার্বো (Turbo)', desc: isEn ? 'Instant move' : 'ইনস্ট্যান্ট চাল' },
                    ] as const
                  ).map((speed) => (
                    <button
                      key={speed.id}
                      onClick={() => updateSetting('diceSpeed', speed.id)}
                      className={`p-2 rounded-xl text-center border transition-all cursor-pointer ${
                        settings.diceSpeed === speed.id
                          ? 'bg-amber-500/20 border-amber-400 text-amber-300 shadow-xs'
                          : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      <span className="text-xs font-bold block">{speed.label}</span>
                      <span className="text-[9px] text-slate-400 block mt-0.5">{speed.desc}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Highlight Movable Tokens */}
              <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center border border-indigo-400/30">
                    <CheckCircle2 className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-black text-white">
                      {isEn ? 'Highlight Movable Tokens' : 'চালযোগ্য গুটি গ্লো ও নির্দেশক'}
                    </h4>
                    <p className="text-[11px] text-slate-400">
                      {isEn ? 'Show luminous glow around tokens with valid turns' : 'যেসব গুটি চালানো সম্ভব তা উজ্জ্বলভাবে জ্বলজ্বল করবে'}
                    </p>
                  </div>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings.highlightMovableTokens}
                    onChange={(e) => updateSetting('highlightMovableTokens', e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-500"></div>
                </label>
              </div>

              {/* High Quality Graphics */}
              <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-pink-500/20 text-pink-400 flex items-center justify-center border border-pink-400/30">
                    <Sparkles className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-black text-white">
                      {isEn ? 'High-Quality Visual Effects' : 'হাই-কোয়ালিটি পার্টিকেল ও ইফেক্টস'}
                    </h4>
                    <p className="text-[11px] text-slate-400">
                      {isEn ? 'Fireworks, confetti & animated particle celebrations' : 'গুটি কাটা ও বিজয়ের চমৎকার আতশবাজি ও কনফেটি'}
                    </p>
                  </div>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings.highQualityGraphics}
                    onChange={(e) => updateSetting('highQualityGraphics', e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-pink-500"></div>
                </label>
              </div>
            </div>
          )}

          {/* TAB 3: NOTIFICATIONS & LANGUAGE */}
          {activeTab === 'notifications' && (
            <div className="space-y-3">
              {/* Language Selection */}
              <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <Globe className="w-4 h-4 text-amber-400" />
                    <h4 className="text-xs font-black text-white">
                      {isEn ? 'App Language' : 'অ্যাপের ভাষা (Language)'}
                    </h4>
                  </div>
                  <span className="text-[10px] text-slate-400">
                    {isEn ? 'Choose preferred UI language' : 'পছন্দের ভাষা নির্বাচন করুন'}
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => updateSetting('language', 'bn')}
                    className={`p-2.5 rounded-xl text-center border transition-all cursor-pointer ${
                      settings.language === 'bn'
                        ? 'bg-amber-500/20 border-amber-400 text-amber-300 font-black shadow-xs'
                        : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    <span className="text-sm block">🇧🇩 বাংলা (Bengali)</span>
                    <span className="text-[10px] text-slate-400 block mt-0.5">
                      {isEn ? 'Bengali Language' : 'ডিফল্ট ভাষা'}
                    </span>
                  </button>

                  <button
                    onClick={() => updateSetting('language', 'en')}
                    className={`p-2.5 rounded-xl text-center border transition-all cursor-pointer ${
                      settings.language === 'en'
                        ? 'bg-amber-500/20 border-amber-400 text-amber-300 font-black shadow-xs'
                        : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    <span className="text-sm block">🇺🇸 English</span>
                    <span className="text-[10px] text-slate-400 block mt-0.5">Global Mode</span>
                  </button>
                </div>
              </div>

              {/* Tournament Notifications */}
              <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-400/30">
                    <Bell className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-black text-white">
                      {isEn ? 'Tournament & Events Alerts' : 'টুর্নামেন্ট ও ইভেন্ট অ্যালার্ট'}
                    </h4>
                    <p className="text-[11px] text-slate-400">
                      {isEn ? 'Get notified before mega cups and tournaments start' : 'দৈনিক মেগা টুর্নামেন্ট শুরুর নোটিফিকেশন'}
                    </p>
                  </div>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings.notifTournament}
                    onChange={(e) => updateSetting('notifTournament', e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-amber-500"></div>
                </label>
              </div>

              {/* Daily Coin Bonus Notification */}
              <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-yellow-500/20 text-yellow-400 flex items-center justify-center border border-yellow-400/30">
                    <Sparkles className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-black text-white">
                      {isEn ? 'Daily Coin Bonus Reminders' : 'দৈনিক ফ্রি কয়েন বোনাস রিমাইন্ডার'}
                    </h4>
                    <p className="text-[11px] text-slate-400">
                      {isEn ? 'Daily login reminder to claim free coins & diamonds' : 'প্রতিদিনের লগইন কয়েন উপহার ক্লেইম করার নোটিস'}
                    </p>
                  </div>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings.notifDailyBonus}
                    onChange={(e) => updateSetting('notifDailyBonus', e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-yellow-500"></div>
                </label>
              </div>

              {/* Friend Messages Notification */}
              <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center border border-blue-400/30">
                    <Bell className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-black text-white">
                      {isEn ? 'Friends Inbox & Chat Alerts' : 'বন্ধুদের ইনবক্স চ্যাট নোটিফিকেশন'}
                    </h4>
                    <p className="text-[11px] text-slate-400">
                      {isEn ? 'Alerts when friends send messages or gift coins' : 'বন্ধু কোনো বার্তা বা কয়েন গিফট পাঠালে অ্যালার্ট'}
                    </p>
                  </div>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings.notifFriendMessages}
                    onChange={(e) => updateSetting('notifFriendMessages', e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-500"></div>
                </label>
              </div>
            </div>
          )}

          {/* TAB 4: PRIVACY & SAFETY */}
          {activeTab === 'privacy' && (
            <div className="space-y-3">
              {/* Parental Safety & Screen Time Quick Link */}
              <div className="p-3.5 rounded-2xl bg-gradient-to-r from-emerald-950/90 to-slate-900 border border-emerald-500/50 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-400/30">
                    <Clock className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-black text-emerald-300">
                      {isEn ? 'Parental Controls & Screen Time' : 'প্যারেন্টাল কন্ট্রোল ও স্ক্রিন টাইম'}
                    </h4>
                    <p className="text-[11px] text-slate-300">
                      {isEn ? 'Age verification, daily play limits & safety PIN' : 'বয়স যাচাইকরণ, দৈনিক সময়সীমা ও নিরাপত্তা পিন'}
                    </p>
                  </div>
                </div>
                {onOpenAgeSafety && (
                  <button
                    onClick={() => {
                      Sound.playClick();
                      onOpenAgeSafety();
                    }}
                    className="px-3.5 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs rounded-xl cursor-pointer shadow-md transition-all shrink-0"
                  >
                    {isEn ? 'Setup' : 'সেটআপ'}
                  </button>
                )}
              </div>

              {/* Allow Invites From Strangers */}
              <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center border border-indigo-400/30">
                    <User className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-black text-white">
                      {isEn ? 'Accept Match Invites From Others' : 'অপরিচিতদের ম্যাচের আমন্ত্রণ গ্রহণ'}
                    </h4>
                    <p className="text-[11px] text-slate-400">
                      {isEn ? 'Allow other players to send you room match invitations' : 'অনলাইন খেলোয়াড়রা আপনাকে ম্যাচে ইনভাইট পাঠাতে পারবে'}
                    </p>
                  </div>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings.allowInvitesFromStrangers}
                    onChange={(e) => updateSetting('allowInvitesFromStrangers', e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-500"></div>
                </label>
              </div>

              {/* Low Data Saver Mode */}
              <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center border border-cyan-400/30">
                    <ShieldCheck className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-black text-white">
                      {isEn ? 'Data Saver Mode (Low Data)' : 'ডাটা সেভার মোড (Low Data Mode)'}
                    </h4>
                    <p className="text-[11px] text-slate-400">
                      {isEn ? 'Disable background video preloading to save mobile bandwidth' : 'মোবাইল ডাটা খরচ হ্রাস করতে ভিডিও প্রি-লোড বন্ধ রাখবে'}
                    </p>
                  </div>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings.lowDataMode}
                    onChange={(e) => updateSetting('lowDataMode', e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-cyan-500"></div>
                </label>
              </div>

              {/* Profile Shortcut */}
              {onOpenProfile && (
                <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center border border-purple-400/30">
                      <User className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-xs font-black text-white">
                        {isEn ? 'Profile & Account Management' : 'প্রোফাইল ও অ্যাকাউন্ট ম্যানেজমেন্ট'}
                      </h4>
                      <p className="text-[11px] text-slate-400">
                        {isEn ? 'Change display name, avatar picture and country flag' : 'নাম, অবতার ছবি ও দেশের পতাকা পরিবর্তন'}
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={() => {
                      Sound.playClick();
                      onOpenProfile();
                    }}
                    className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs rounded-xl cursor-pointer transition-all shrink-0 border border-slate-700"
                  >
                    {isEn ? 'Edit' : 'সম্পাদনা'}
                  </button>
                </div>
              )}
            </div>
          )}

          {/* TAB 5: ABOUT & POLICY */}
          {activeTab === 'about' && (
            <div className="space-y-3">
              {/* Zero Money Policy Card */}
              <div className="p-3.5 rounded-2xl bg-emerald-950/60 border border-emerald-500/40 space-y-1.5">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <h4 className="text-xs font-black text-emerald-300">
                    {isEn ? 'Zero-Money Fair Play Policy' : 'জিরো-মানি ফেয়ার প্লে পলিসি'}
                  </h4>
                </div>
                <p className="text-[11px] text-emerald-100/90 leading-normal">
                  {isEn
                    ? 'No real money is ever accepted or paid out. This game is strictly for entertainment and social engagement. Winning grants free virtual coins and achievements.'
                    : 'লুডু খেলার জন্য কোনো নগদ টাকা নেওয়া বা দেওয়া হয় না। খেলা সম্পূর্ণ বিনোদনমূলক ও সামাজিক। খেলায় জিতলে ফ্রি ভার্চুয়াল কয়েন বোনাস ও রিওয়ার্ড পাওয়া যায়।'}
                </p>
              </div>

              {/* Version & Build Info */}
              <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400">{isEn ? 'App Name' : 'অ্যাপ নাম'}</span>
                  <span className="font-black text-white">{isEn ? 'Joy Ludo Pro' : 'জয় লুডু প্রো (Joy Ludo Pro)'}</span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400">{isEn ? 'Version' : 'ভার্সন'}</span>
                  <span className="font-bold text-amber-400">v3.4.0 (2026 Build)</span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400">{isEn ? 'Game Engine' : 'গেমিং ইঞ্জিন'}</span>
                  <span className="font-bold text-slate-300">Web Audio + Canvas Pro</span>
                </div>
              </div>

              {/* Rules Shortcut */}
              {onOpenRules && (
                <button
                  onClick={() => {
                    Sound.playClick();
                    onOpenRules();
                  }}
                  className="w-full p-3 rounded-2xl bg-slate-950/80 border border-slate-800 hover:border-amber-400 text-left flex items-center justify-between transition-all cursor-pointer"
                >
                  <span className="text-xs font-black text-white">
                    {isEn ? 'View Complete Ludo Rules & Strategy Guide' : 'লুডু খেলার সম্পূর্ণ নিয়ম ও গাইড দেখুন'}
                  </span>
                  <span className="text-xs text-amber-400">{isEn ? 'Read →' : 'পড়ুন →'}</span>
                </button>
              )}
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="pt-3 border-t border-slate-800 flex items-center justify-between gap-2">
          <button
            onClick={handleResetDefaults}
            className="px-3.5 py-2 rounded-xl bg-slate-800/80 hover:bg-slate-800 text-slate-400 hover:text-white font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer border border-slate-700"
            title={isEn ? 'Reset all settings to default' : 'সব সেটিংস ডিফল্ট মানে ফিরিয়ে নিন'}
          >
            <RotateCcw className="w-3.5 h-3.5" />
            {isEn ? 'Reset Defaults' : 'ডিফল্ট রিসেট'}
          </button>

          <button
            onClick={() => {
              Sound.playClick();
              onClose();
            }}
            className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-xs shadow-md transition-all cursor-pointer"
          >
            {isEn ? 'Save & Close' : 'সম্পন্ন (Save & Close)'}
          </button>
        </div>
      </div>
    </div>
  );
};
