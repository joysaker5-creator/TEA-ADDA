import React, { useState, useRef } from 'react';
import {
  X,
  Palette,
  Dices,
  Sparkles,
  RotateCcw,
  Check,
  Crown,
  Shield,
  Gem,
  Star,
  Layers,
  Image as ImageIcon,
  Upload,
  Sun,
  Sliders,
  Sparkle,
  Trash2,
} from 'lucide-react';
import {
  CustomizationConfig,
  BoardThemeId,
  DiceStyleId,
  DiceFaceStyle,
  TokenStyleId,
  GameBackgroundId,
  PlayerColor,
} from '../types';
import {
  BOARD_THEMES,
  DICE_STYLES,
  DICE_FACE_OPTIONS,
  TOKEN_STYLES,
  GAME_BACKGROUNDS,
  CURATED_WALLPAPERS,
  PRESET_BUNDLES,
  DEFAULT_CUSTOMIZATION,
} from '../utils/customizationConstants';
import { TokenPiece } from './TokenPiece';
import { DicePiece } from './DicePiece';
import { Sound } from '../utils/soundEffects';

interface CustomizationModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: CustomizationConfig;
  onSaveConfig: (newConfig: CustomizationConfig) => void;
  defaultTab?: 'background' | 'board' | 'dice' | 'token' | 'presets';
  isEn?: boolean;
}

export const CustomizationModal: React.FC<CustomizationModalProps> = ({
  isOpen,
  onClose,
  config,
  onSaveConfig,
  defaultTab = 'background',
  isEn = false,
}) => {
  const [activeTab, setActiveTab] = useState<'background' | 'board' | 'dice' | 'token' | 'presets'>(defaultTab);
  const [tempConfig, setTempConfig] = useState<CustomizationConfig>(config);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Interactive Test Dice in modal preview
  const [previewDiceValue, setPreviewDiceValue] = useState<number>(6);
  const [isPreviewRolling, setIsPreviewRolling] = useState<boolean>(false);

  if (!isOpen) return null;

  const handleTestRoll = () => {
    if (isPreviewRolling) return;
    setIsPreviewRolling(true);
    Sound.playDiceRoll();

    let rolls = 0;
    const interval = setInterval(() => {
      setPreviewDiceValue(Math.floor(Math.random() * 6) + 1);
      rolls++;
      if (rolls >= 6) {
        clearInterval(interval);
        const finalVal = Math.floor(Math.random() * 6) + 1;
        setPreviewDiceValue(finalVal);
        setIsPreviewRolling(false);
      }
    }, 90);
  };

  const handleApplyPreset = (presetConfig: CustomizationConfig) => {
    Sound.playClick();
    setTempConfig(presetConfig);
    onSaveConfig(presetConfig);
  };

  const handleUpdate = <K extends keyof CustomizationConfig>(key: K, value: CustomizationConfig[K]) => {
    Sound.playButtonTick();
    const updated = { ...tempConfig, [key]: value };
    setTempConfig(updated);
    onSaveConfig(updated);
  };

  const handleResetDefaults = () => {
    Sound.playClick();
    setTempConfig(DEFAULT_CUSTOMIZATION);
    onSaveConfig(DEFAULT_CUSTOMIZATION);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const MAX_WIDTH = 1920;
        const MAX_HEIGHT = 1080;
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > MAX_WIDTH) {
            height = Math.round((height * MAX_WIDTH) / width);
            width = MAX_WIDTH;
          }
        } else {
          if (height > MAX_HEIGHT) {
            width = Math.round((width * MAX_HEIGHT) / height);
            height = MAX_HEIGHT;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
          Sound.playWin();
          const updated: CustomizationConfig = {
            ...tempConfig,
            gameBackground: 'custom_photo',
            customBgUrl: dataUrl,
          };
          setTempConfig(updated);
          onSaveConfig(updated);
        }
      };
      if (typeof event.target?.result === 'string') {
        img.src = event.target.result;
      }
    };
    reader.readAsDataURL(file);
  };

  const currentBoardDef = BOARD_THEMES.find((b) => b.id === tempConfig.boardTheme) || BOARD_THEMES[0];
  const currentDiceDef = DICE_STYLES.find((d) => d.id === tempConfig.diceStyle) || DICE_STYLES[0];
  const currentTokenDef = TOKEN_STYLES.find((t) => t.id === tempConfig.tokenStyle) || TOKEN_STYLES[0];
  const currentBgDef = GAME_BACKGROUNDS.find((g) => g.id === tempConfig.gameBackground) || GAME_BACKGROUNDS[0];

  const colors: PlayerColor[] = ['red', 'green', 'yellow', 'blue'];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl max-h-[94vh] flex flex-col bg-slate-50 border-4 border-amber-300 rounded-3xl shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="px-4 sm:px-6 py-3.5 bg-gradient-to-r from-amber-500 via-amber-400 to-yellow-500 border-b-2 border-amber-600 flex items-center justify-between shadow-sm">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-amber-950/90 text-amber-300 flex items-center justify-center shadow-md">
              <Palette className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black text-amber-950 leading-tight">
                {isEn ? 'Ludo Customization & Background Studio' : 'লুডু কাস্টমাইজেশন ও ব্যাকগ্রাউন্ড স্টুডিও'}
              </h2>
              <p className="text-[11px] font-bold text-amber-900 leading-tight">
                {isEn ? 'Change game background, board theme, dice and tokens' : 'গেম ব্যাকগ্রাউন্ড, বোর্ড থিম, ডাইস ও গুটি পরিবর্তন করুন'}
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              Sound.playClick();
              onClose();
            }}
            className="w-8 h-8 rounded-full bg-amber-950/10 hover:bg-amber-950/20 text-amber-950 flex items-center justify-center transition-all active:scale-95 cursor-pointer"
            title={isEn ? 'Close' : 'বন্ধ করুন'}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Live Interactive Preview Bar */}
        <div className="p-3 sm:p-4 bg-gradient-to-r from-slate-950 via-slate-900 to-slate-950 border-b-2 border-slate-700 text-white">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
            {/* Live Background & Board Theme Preview */}
            <div className="flex items-center gap-3 w-full sm:w-auto">
              <div className="relative p-2 rounded-2xl border-2 border-slate-700 bg-slate-800/90 shadow-md flex items-center gap-2.5">
                {/* Background Swatch Indicator */}
                <div
                  className={`w-9 h-9 rounded-xl border border-white/40 shadow-inner flex items-center justify-center overflow-hidden relative ${
                    tempConfig.gameBackground === 'custom_photo' && tempConfig.customBgUrl
                      ? ''
                      : `bg-gradient-to-br ${currentBgDef.previewGradient}`
                  }`}
                >
                  {tempConfig.gameBackground === 'custom_photo' && tempConfig.customBgUrl ? (
                    <img
                      src={tempConfig.customBgUrl}
                      alt="Custom Background"
                      className="w-full h-full object-cover"
                    />
                  ) : tempConfig.gameBackground === 'bd_flag' ? (
                    <div className="w-full h-full bg-[#006a4e] flex items-center justify-center relative">
                      <div className="w-4 h-4 rounded-full bg-[#f42a41] shadow-xs" />
                    </div>
                  ) : (
                    <span className="text-[10px]">🎨</span>
                  )}
                </div>

                <div className="flex flex-col">
                  <span className="text-[10px] font-extrabold text-amber-400 uppercase tracking-wider">
                    {isEn ? 'Background: ' : 'ব্যাকগ্রাউন্ড: '}{isEn ? currentBgDef.nameEn : currentBgDef.nameBn}
                  </span>
                  <span className="text-xs font-bold text-slate-200">
                    {isEn ? 'Board: ' : 'বোর্ড: '}{isEn ? currentBoardDef.nameEn : currentBoardDef.nameBn}
                  </span>
                </div>

                {/* 4 team tokens showcase */}
                <div className="flex items-center gap-1.5 pl-2 border-l border-slate-600">
                  {colors.map((c) => (
                    <TokenPiece
                      key={c}
                      color={c}
                      styleId={tempConfig.tokenStyle}
                      size="sm"
                      title={isEn ? `${c} token` : `${c} গুটি`}
                    />
                  ))}
                </div>
              </div>
            </div>

            {/* Interactive Test Dice */}
            <div className="flex items-center gap-3 w-full sm:w-auto justify-end">
              <div className="flex flex-col items-end">
                <span className="text-[10px] font-extrabold text-slate-300">
                  {isEn ? currentDiceDef.nameEn : currentDiceDef.nameBn}
                </span>
                <span className="text-[9px] text-amber-400 font-medium">
                  {tempConfig.diceFace === 'bengali_numbers'
                    ? (isEn ? 'Bengali Numerals' : 'বাংলা সংখ্যা')
                    : tempConfig.diceFace === 'english_numbers'
                    ? (isEn ? 'English Digits' : 'ইংরেজি ডিজিট')
                    : (isEn ? 'Classic Dots' : 'ঐতিহ্যবাহী ডট')}
                </span>
              </div>

              <DicePiece
                value={previewDiceValue}
                styleId={tempConfig.diceStyle}
                faceStyle={tempConfig.diceFace}
                isRolling={isPreviewRolling}
                size={46}
                onClick={handleTestRoll}
              />

              <button
                id="test-roll-dice-btn"
                disabled={isPreviewRolling}
                onClick={handleTestRoll}
                className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-amber-950 font-black text-xs shadow-md border-b-2 border-amber-600 flex items-center gap-1.5 transition-all active:scale-95 cursor-pointer"
              >
                <Dices className="w-3.5 h-3.5" />
                <span>{isEn ? 'Test Roll' : 'রোল টেস্ট'}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-1 px-4 pt-3 border-b border-slate-200 bg-white select-none overflow-x-auto">
          {/* TAB: Game Backgrounds */}
          <button
            onClick={() => {
              Sound.playClick();
              setActiveTab('background');
            }}
            className={`flex items-center gap-1.5 px-3.5 py-2 font-black text-xs rounded-t-2xl border-t-2 border-x-2 transition-all shrink-0 cursor-pointer ${
              activeTab === 'background'
                ? 'bg-slate-50 border-amber-400 text-amber-950 border-b-0 translate-y-[1px] shadow-xs'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <ImageIcon className="w-4 h-4 text-purple-600" />
            <span>{isEn ? `Background (${GAME_BACKGROUNDS.length})` : `গেম ব্যাকগ্রাউন্ড (${GAME_BACKGROUNDS.length})`}</span>
            <span className="bg-amber-400 text-amber-950 text-[9px] font-black px-1.5 py-0.2 rounded-md ml-0.5">
              {isEn ? 'NEW' : 'নতুন'}
            </span>
          </button>

          {/* TAB: Board Themes */}
          <button
            onClick={() => {
              Sound.playClick();
              setActiveTab('board');
            }}
            className={`flex items-center gap-1.5 px-3.5 py-2 font-black text-xs rounded-t-2xl border-t-2 border-x-2 transition-all shrink-0 cursor-pointer ${
              activeTab === 'board'
                ? 'bg-slate-50 border-amber-400 text-amber-950 border-b-0 translate-y-[1px] shadow-xs'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Palette className="w-4 h-4 text-amber-600" />
            <span>{isEn ? `Board Themes (${BOARD_THEMES.length})` : `বোর্ড থিম (${BOARD_THEMES.length})`}</span>
          </button>

          {/* TAB: Dice Styles */}
          <button
            onClick={() => {
              Sound.playClick();
              setActiveTab('dice');
            }}
            className={`flex items-center gap-1.5 px-3.5 py-2 font-black text-xs rounded-t-2xl border-t-2 border-x-2 transition-all shrink-0 cursor-pointer ${
              activeTab === 'dice'
                ? 'bg-slate-50 border-amber-400 text-amber-950 border-b-0 translate-y-[1px] shadow-xs'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Dices className="w-4 h-4 text-amber-600" />
            <span>{isEn ? `Dice Styles (${DICE_STYLES.length})` : `ডাইস স্টাইল (${DICE_STYLES.length})`}</span>
          </button>

          {/* TAB: Tokens */}
          <button
            onClick={() => {
              Sound.playClick();
              setActiveTab('token');
            }}
            className={`flex items-center gap-1.5 px-3.5 py-2 font-black text-xs rounded-t-2xl border-t-2 border-x-2 transition-all shrink-0 cursor-pointer ${
              activeTab === 'token'
                ? 'bg-slate-50 border-amber-400 text-amber-950 border-b-0 translate-y-[1px] shadow-xs'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Crown className="w-4 h-4 text-amber-600" />
            <span>{isEn ? `Tokens (${TOKEN_STYLES.length})` : `গুটি / টোকেন (${TOKEN_STYLES.length})`}</span>
          </button>

          {/* TAB: Presets */}
          <button
            onClick={() => {
              Sound.playClick();
              setActiveTab('presets');
            }}
            className={`flex items-center gap-1.5 px-3.5 py-2 font-black text-xs rounded-t-2xl border-t-2 border-x-2 transition-all shrink-0 cursor-pointer ${
              activeTab === 'presets'
                ? 'bg-slate-50 border-amber-400 text-amber-950 border-b-0 translate-y-[1px] shadow-xs'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Sparkles className="w-4 h-4 text-amber-600" />
            <span>{isEn ? 'Presets' : 'বান্ডেল প্রিসেট'}</span>
          </button>
        </div>

        {/* Modal Body - Tab Contents */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          {/* TAB 0: GAME BACKGROUNDS */}
          {activeTab === 'background' && (
            <div className="space-y-5">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-black text-slate-900">
                    {isEn ? 'Select Game Background & Environment' : 'লুডু গেম ব্যাকগ্রাউন্ড ও পরিবেশ নির্বাচন করুন'}
                  </h3>
                  <p className="text-xs text-slate-600">
                    {isEn ? 'Customize the game table and overall board atmosphere' : 'খেলার টেবিল ও সমগ্র অ্যাপের ব্যাকগ্রাউন্ড আপনার পছন্দমতো সাজান'}
                  </p>
                </div>
              </div>

              {/* Upload Custom Wallpaper / Photo from Device Gallery */}
              <div className="p-4 rounded-3xl bg-gradient-to-br from-purple-900 via-indigo-950 to-slate-950 border-2 border-purple-400 text-white shadow-lg space-y-3">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-2xl bg-purple-500/30 border border-purple-400/50 flex items-center justify-center text-amber-300 shadow-inner">
                      <Upload className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-sm font-black text-white leading-tight flex items-center gap-1.5">
                        {isEn ? 'Custom Photo from Gallery' : 'গ্যালারি থেকে নিজস্ব ব্যাকগ্রাউন্ড ছবি'}
                        <span className="text-[10px] bg-amber-400 text-amber-950 font-black px-1.5 py-0.2 rounded-full">
                          {isEn ? 'Custom' : 'কাস্টম'}
                        </span>
                      </h4>
                      <p className="text-xs text-purple-200">
                        {isEn ? 'Set any photo or wallpaper from your device as background' : 'মোবাইল বা পিসি গ্যালারি থেকে যেকোনো ফটো বা ওয়ালপেপার ব্যাকগ্রাউন্ডে সেট করুন'}
                      </p>
                    </div>
                  </div>

                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={handleFileUpload}
                  />

                  <div className="flex items-center gap-2 self-stretch sm:self-auto">
                    <button
                      id="upload-custom-bg-btn"
                      onClick={() => fileInputRef.current?.click()}
                      className="flex-1 sm:flex-none px-4 py-2.5 rounded-2xl bg-gradient-to-r from-amber-400 to-yellow-500 hover:from-amber-300 hover:to-yellow-400 text-amber-950 font-black text-xs shadow-md border-b-2 border-amber-600 flex items-center justify-center gap-2 transition-all active:scale-95 cursor-pointer"
                    >
                      <Upload className="w-4 h-4" />
                      <span>{isEn ? 'Select Photo from Gallery' : 'গ্যালারি থেকে ফটো নির্বাচন'}</span>
                    </button>

                    {tempConfig.gameBackground === 'custom_photo' && tempConfig.customBgUrl && (
                      <button
                        onClick={() => {
                          Sound.playClick();
                          handleUpdate('gameBackground', 'classic_amber');
                        }}
                        className="p-2.5 rounded-2xl bg-rose-500/20 hover:bg-rose-500/30 border border-rose-400 text-rose-300 transition-all"
                        title={isEn ? 'Remove Custom Photo' : 'কাস্টম ছবি বাতিল করুন'}
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>

                {/* Custom Photo Active Preview & Controls */}
                {tempConfig.gameBackground === 'custom_photo' && tempConfig.customBgUrl && (
                  <div className="p-3 rounded-2xl bg-purple-950/80 border border-purple-500/50 flex flex-col sm:flex-row items-center justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className="w-16 h-12 rounded-xl overflow-hidden border-2 border-amber-400 shadow-md">
                        <img
                          src={tempConfig.customBgUrl}
                          alt="Custom background"
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div>
                        <span className="text-xs font-black text-amber-300 block">
                          {isEn ? 'Custom Background Active' : 'কাস্টম ব্যাকগ্রাউন্ড সক্রিয়'}
                        </span>
                        <span className="text-[11px] text-slate-300 font-medium">
                          {isEn ? 'Adjust brightness for optimal board visibility' : 'উজ্জ্বলতা পরিবর্তন করে বোর্ডের স্পষ্টতা সমন্বয় করতে পারেন'}
                        </span>
                      </div>
                    </div>

                    {/* Brightness Adjustment */}
                    <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
                      <Sun className="w-4 h-4 text-amber-300 shrink-0" />
                      <span className="text-xs text-slate-300 font-bold shrink-0">{isEn ? 'Brightness:' : 'উজ্জ্বলতা:'}</span>
                      <input
                        type="range"
                        min={50}
                        max={120}
                        value={tempConfig.bgBrightness ?? 100}
                        onChange={(e) => handleUpdate('bgBrightness', Number(e.target.value))}
                        className="w-24 accent-amber-400 cursor-pointer"
                      />
                      <span className="text-xs font-black text-amber-300 min-w-[35px]">
                        {tempConfig.bgBrightness ?? 100}%
                      </span>
                    </div>
                  </div>
                )}

                {/* Curated Preset Wallpapers 1-Click Select */}
                <div className="pt-2 border-t border-purple-800/60">
                  <span className="text-[11px] font-extrabold text-purple-200 block mb-2">
                    {isEn ? '✨ Or choose from curated wallpapers:' : '✨ অথবা জনপ্রিয় ওয়ালপেপার সংগ্রহ থেকে বেছে নিন:'}
                  </span>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {CURATED_WALLPAPERS.map((wall) => {
                      const isWallSelected =
                        tempConfig.gameBackground === 'custom_photo' &&
                        tempConfig.customBgUrl === wall.url;
                      return (
                        <button
                          key={wall.id}
                          onClick={() => {
                            Sound.playClick();
                            const updated: CustomizationConfig = {
                              ...tempConfig,
                              gameBackground: 'custom_photo',
                              customBgUrl: wall.url,
                            };
                            setTempConfig(updated);
                            onSaveConfig(updated);
                          }}
                          className={`relative h-14 rounded-2xl overflow-hidden border-2 transition-all active:scale-[0.98] group text-left cursor-pointer ${
                            isWallSelected
                              ? 'border-amber-400 ring-2 ring-amber-300 shadow-md'
                              : 'border-purple-700/60 hover:border-amber-300 opacity-80 hover:opacity-100'
                          }`}
                        >
                          <img
                            src={wall.url}
                            alt={wall.title}
                            className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent p-1.5 flex flex-col justify-end">
                            <span className="text-[10px] font-black text-white truncate leading-tight">
                              {wall.title}
                            </span>
                            <span className="text-[9px] text-amber-300 font-bold leading-none">
                              {wall.category}
                            </span>
                          </div>
                          {isWallSelected && (
                            <span className="absolute top-1 right-1 w-4 h-4 rounded-full bg-amber-400 text-amber-950 flex items-center justify-center shadow-md">
                              <Check className="w-3 h-3 stroke-[3]" />
                            </span>
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Handcrafted Themed Game Backgrounds */}
              <div>
                <h4 className="text-xs font-black text-slate-800 uppercase tracking-wider mb-2.5">
                  {isEn ? '🎨 Art & Thematic Backgrounds' : '🎨 আর্ট ও থিম্যাটিক ব্যাকগ্রাউন্ড সম্ভার'}
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {GAME_BACKGROUNDS.filter((bg) => bg.id !== 'custom_photo').map((bg) => {
                    const isSelected = tempConfig.gameBackground === bg.id;
                    return (
                      <button
                        key={bg.id}
                        onClick={() => handleUpdate('gameBackground', bg.id)}
                        className={`relative p-3.5 rounded-3xl text-left border-2 transition-all active:scale-[0.99] flex flex-col justify-between cursor-pointer ${
                          isSelected
                            ? 'border-amber-500 bg-amber-50/90 shadow-md ring-2 ring-amber-400'
                            : 'border-slate-200 bg-white hover:border-amber-300 shadow-sm'
                        }`}
                      >
                        <div className="flex items-start justify-between w-full mb-2">
                          <div className="flex items-center gap-2.5">
                            <div
                              className={`w-9 h-9 rounded-2xl bg-gradient-to-br ${bg.previewGradient} border-2 border-slate-300 shadow-inner flex items-center justify-center text-white text-xs font-black overflow-hidden relative`}
                            >
                              {bg.id === 'bd_flag' ? (
                                <div className="w-full h-full bg-[#006a4e] flex items-center justify-center relative">
                                  <div className="w-4 h-4 rounded-full bg-[#f42a41] shadow-xs" />
                                </div>
                              ) : (
                                '🎲'
                              )}
                            </div>
                            <div>
                              <h4 className="text-sm font-black text-slate-900 leading-tight">
                                {isEn ? bg.nameEn : bg.nameBn}
                              </h4>
                              <span className="text-[10px] text-slate-500 font-bold">
                                {isEn ? bg.nameBn : bg.nameEn}
                              </span>
                            </div>
                          </div>

                          <div className="flex items-center gap-1.5">
                            <span
                              className={`text-[9px] font-black px-2 py-0.5 rounded-full border ${
                                bg.themeTone === 'dark'
                                    ? 'bg-slate-900 text-slate-100 border-slate-800'
                                    : 'bg-amber-100 text-amber-900 border-amber-200'
                              }`}
                            >
                              {bg.badge}
                            </span>
                            {isSelected && (
                              <span className="w-5 h-5 rounded-full bg-amber-500 text-white flex items-center justify-center shadow-sm">
                                <Check className="w-3.5 h-3.5 stroke-[3]" />
                              </span>
                            )}
                          </div>
                        </div>

                        <p className="text-xs text-slate-600 font-medium mb-3">
                          {bg.descriptionBn}
                        </p>

                        {/* Background Theme Atmospheric Mini Preview */}
                        <div
                          className={`w-full h-8 rounded-xl p-1.5 flex items-center justify-between border ${bg.accentBorder} bg-gradient-to-r ${bg.previewGradient} shadow-inner`}
                        >
                          <span className="text-[10px] font-bold text-white/90 drop-shadow-xs">
                            {bg.themeTone === 'dark'
                              ? (isEn ? 'Dark Luxury Mode' : 'ডার্ক লাক্সারি মোড')
                              : (isEn ? 'Bright Light Mode' : 'উজ্জ্বল লাইট মোড')}
                          </span>
                          <span className="text-[10px] font-black px-2 py-0.5 rounded-md bg-white/20 text-white backdrop-blur-xs">
                            {isSelected
                              ? (isEn ? '✓ Active' : '✓ সক্রিয়')
                              : (isEn ? 'Select' : 'নির্বাচন করুন')}
                          </span>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Ambient Background Pattern Overlay Selector */}
              <div className="p-3.5 rounded-2xl bg-slate-100 border border-slate-200 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <Sliders className="w-4 h-4 text-slate-700" />
                    <span className="text-xs font-black text-slate-900">
                      {isEn ? 'Texture & Pattern Overlay' : 'টেক্সচার ও সারফেস প্যাটার্ন (Pattern Overlay)'}
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-500 font-bold">
                    {isEn ? 'Subtle texture effect' : 'হালকা টেক্সচার ইফেক্ট'}
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1">
                  {[
                    { id: 'none', labelBn: 'কোনো প্যাটার্ন নয়', labelEn: 'None' },
                    { id: 'velvet', labelBn: 'ভেলভেট টেবিল', labelEn: 'Velvet Table' },
                    { id: 'wood', labelBn: 'কাঠের গ্রেইন', labelEn: 'Wood Grain' },
                    { id: 'stars', labelBn: 'তারকা কণা', labelEn: 'Star Dust' },
                    { id: 'hex', labelBn: 'সাইবার হেক্সা', labelEn: 'Cyber Hex' },
                    { id: 'marble', labelBn: 'মার্বেল রেখা', labelEn: 'Marble Lines' },
                    { id: 'damask', labelBn: 'রয়্যাল ডামাস্ক', labelEn: 'Royal Damask' },
                  ].map((pat) => {
                    const isPatActive = (tempConfig.bgPattern ?? 'none') === pat.id;
                    return (
                      <button
                        key={pat.id}
                        onClick={() => handleUpdate('bgPattern', pat.id as any)}
                        className={`px-2.5 py-1.5 rounded-xl text-xs font-bold transition-all border text-center cursor-pointer ${
                          isPatActive
                            ? 'bg-amber-400 text-amber-950 border-amber-600 font-black shadow-xs'
                            : 'bg-white text-slate-700 border-slate-300 hover:border-amber-300'
                        }`}
                      >
                        {isEn ? pat.labelEn : pat.labelBn}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* TAB 1: BOARD THEMES */}
          {activeTab === 'board' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between mb-1">
                <div>
                  <h3 className="text-sm font-black text-slate-900">{isEn ? 'Select Board Theme' : 'লুডু বোর্ড পছন্দ করুন'}</h3>
                  <p className="text-xs text-slate-600">
                    {isEn ? 'Changes board colors, track cells, corner yards and center artwork' : 'বোর্ডের রঙ, ঘর, কোণার বাড়ি ও কেন্দ্রীয় নকশা পরিবর্তন হবে'}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {BOARD_THEMES.map((theme) => {
                  const isSelected = tempConfig.boardTheme === theme.id;
                  return (
                    <button
                      key={theme.id}
                      onClick={() => handleUpdate('boardTheme', theme.id)}
                      className={`relative p-3.5 rounded-2xl text-left border-2 transition-all active:scale-[0.99] flex flex-col justify-between cursor-pointer ${
                        isSelected
                          ? 'border-amber-500 bg-amber-50/80 shadow-md ring-2 ring-amber-400'
                          : 'border-slate-200 bg-white hover:border-amber-300 shadow-sm'
                      }`}
                    >
                      <div className="flex items-start justify-between w-full mb-2">
                        <div className="flex items-center gap-2">
                          <span
                            className={`w-6 h-6 rounded-lg bg-gradient-to-br ${theme.previewBg} border border-slate-300 shadow-sm`}
                          />
                          <div>
                            <h4 className="text-sm font-black text-slate-900 leading-tight">
                              {isEn ? theme.nameEn : theme.nameBn}
                            </h4>
                            <span className="text-[10px] text-slate-500 font-bold">
                              {isEn ? theme.nameBn : theme.nameEn}
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center gap-1">
                          <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 border border-slate-200">
                            {theme.badge}
                          </span>
                          {isSelected && (
                            <span className="w-5 h-5 rounded-full bg-amber-500 text-white flex items-center justify-center shadow-sm">
                              <Check className="w-3.5 h-3.5 stroke-[3]" />
                            </span>
                          )}
                        </div>
                      </div>

                      <p className="text-xs text-slate-600 font-medium mb-3">
                        {theme.descriptionBn}
                      </p>

                      {/* Mini Board Swatch Preview */}
                      <div className="w-full h-8 rounded-xl border border-slate-300 p-1 flex items-center justify-between gap-1 bg-slate-100/90 overflow-hidden">
                        <div
                          className="w-1/4 h-full rounded-md shadow-xs flex items-center justify-center text-[9px] font-bold text-white"
                          style={{ backgroundColor: theme.yardBgs.green.border }}
                        >
                          {isEn ? 'Green' : 'সবুজ'}
                        </div>
                        <div
                          className="w-1/4 h-full rounded-md shadow-xs flex items-center justify-center text-[9px] font-bold text-slate-900"
                          style={{ backgroundColor: theme.yardBgs.yellow.border }}
                        >
                          {isEn ? 'Yellow' : 'হলুদ'}
                        </div>
                        <div
                          className="w-1/4 h-full rounded-md shadow-xs flex items-center justify-center text-[9px] font-bold text-white"
                          style={{ backgroundColor: theme.yardBgs.red.border }}
                        >
                          {isEn ? 'Red' : 'লাল'}
                        </div>
                        <div
                          className="w-1/4 h-full rounded-md shadow-xs flex items-center justify-center text-[9px] font-bold text-white"
                          style={{ backgroundColor: theme.yardBgs.blue.border }}
                        >
                          {isEn ? 'Blue' : 'নীল'}
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 2: DICE STYLES */}
          {activeTab === 'dice' && (
            <div className="space-y-4">
              {/* Dice Type / Body Material */}
              <div>
                <h3 className="text-sm font-black text-slate-900 mb-1">{isEn ? 'Dice Material & Style' : 'ডাইসের উপাদান ও স্টাইল'}</h3>
                <p className="text-xs text-slate-600 mb-3">
                  {isEn ? 'Select dice cube color, material and gloss textures' : 'ডাইস কিউবের রঙ, উপাদান ও চকচকে টেক্সচার নির্বাচন করুন'}
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {DICE_STYLES.map((dice) => {
                    const isSelected = tempConfig.diceStyle === dice.id;
                    return (
                      <button
                        key={dice.id}
                        onClick={() => handleUpdate('diceStyle', dice.id)}
                        className={`relative p-3.5 rounded-2xl text-left border-2 transition-all active:scale-[0.99] flex items-center justify-between gap-3 cursor-pointer ${
                          isSelected
                            ? 'border-amber-500 bg-amber-50/80 shadow-md ring-2 ring-amber-400'
                            : 'border-slate-200 bg-white hover:border-amber-300 shadow-sm'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <DicePiece
                            value={5}
                            styleId={dice.id}
                            faceStyle={tempConfig.diceFace}
                            size={44}
                          />
                          <div>
                            <div className="flex items-center gap-1.5">
                              <h4 className="text-sm font-black text-slate-900 leading-tight">
                                {isEn ? dice.nameEn : dice.nameBn}
                              </h4>
                              <span className="text-[9px] font-black px-1.5 py-0.2 rounded-md bg-amber-100 text-amber-900 border border-amber-300">
                                {dice.badge}
                              </span>
                            </div>
                            <span className="text-[10px] text-slate-500 font-bold block">
                              {isEn ? dice.nameBn : dice.nameEn}
                            </span>
                            <p className="text-[11px] text-slate-600 font-medium mt-0.5 line-clamp-1">
                              {dice.descriptionBn}
                            </p>
                          </div>
                        </div>

                        {isSelected && (
                          <span className="w-5 h-5 rounded-full bg-amber-500 text-white flex items-center justify-center shadow-sm shrink-0">
                            <Check className="w-3.5 h-3.5 stroke-[3]" />
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Dice Face Options */}
              <div className="pt-3 border-t border-slate-200">
                <h3 className="text-sm font-black text-slate-900 mb-1">
                  {isEn ? 'Dice Face Type' : 'ডাইসের সংখ্যা বা ফোঁটা (Face Type)'}
                </h3>
                <p className="text-xs text-slate-600 mb-3">
                  {isEn ? 'Choose between classic dots, English numbers, or Bengali numerals' : 'ডাইসের উপর বিন্দু অথবা বাংলায় লেখা সংখ্যা দেখতে চান?'}
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                  {DICE_FACE_OPTIONS.map((face) => {
                    const isSelected = tempConfig.diceFace === face.id;
                    return (
                      <button
                        key={face.id}
                        onClick={() => handleUpdate('diceFace', face.id)}
                        className={`p-3 rounded-2xl border-2 text-center transition-all active:scale-[0.99] flex flex-col items-center justify-center gap-2 cursor-pointer ${
                          isSelected
                            ? 'border-amber-500 bg-amber-50/90 shadow-sm ring-2 ring-amber-400'
                            : 'border-slate-200 bg-white hover:border-amber-300'
                        }`}
                      >
                        <DicePiece
                          value={6}
                          styleId={tempConfig.diceStyle}
                          faceStyle={face.id}
                          size={40}
                        />
                        <div>
                          <span className="text-xs font-black text-slate-900 block">
                            {isEn
                              ? face.id === 'dots'
                                ? 'Classic Dots'
                                : face.id === 'bengali_numbers'
                                ? 'Bengali Numerals'
                                : 'English Digits'
                              : face.nameBn}
                          </span>
                          <span className="text-[10px] text-slate-500 font-medium block mt-0.5">
                            {isEn
                              ? face.id === 'dots'
                                ? 'Traditional dot pips'
                                : face.id === 'bengali_numbers'
                                ? 'Bengali digits (১-৬)'
                                : 'English digits (1-6)'
                              : face.descriptionBn}
                          </span>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: PLAYER TOKEN STYLES */}
          {activeTab === 'token' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between mb-1">
                <div>
                  <h3 className="text-sm font-black text-slate-900">{isEn ? 'Player Token Styles' : 'খেলোয়াড়দের গুটি (টোকেন)'}</h3>
                  <p className="text-xs text-slate-600">
                    {isEn ? 'Choose token shape and visual style on the board' : 'বোর্ডে চলাচলের জন্য গুটির আকৃতি ও নকশা পছন্দ করুন'}
                  </p>
                </div>
              </div>

              <div className="space-y-3">
                {TOKEN_STYLES.map((token) => {
                  const isSelected = tempConfig.tokenStyle === token.id;
                  return (
                    <button
                      key={token.id}
                      onClick={() => handleUpdate('tokenStyle', token.id)}
                      className={`w-full p-3.5 rounded-2xl text-left border-2 transition-all active:scale-[0.99] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 cursor-pointer ${
                        isSelected
                          ? 'border-amber-500 bg-amber-50/80 shadow-md ring-2 ring-amber-400'
                          : 'border-slate-200 bg-white hover:border-amber-300 shadow-sm'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-2xl bg-amber-100 border border-amber-300 flex items-center justify-center text-amber-900 shadow-inner">
                          {token.id === 'crown' && <Crown className="w-5 h-5" />}
                          {token.id === 'shield' && <Shield className="w-5 h-5" />}
                          {token.id === 'diamond' && <Gem className="w-5 h-5" />}
                          {token.id === 'star' && <Star className="w-5 h-5" />}
                          {token.id === 'classic' && <Layers className="w-5 h-5" />}
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <h4 className="text-sm font-black text-slate-900 leading-tight">
                              {isEn ? token.nameEn : token.nameBn}
                            </h4>
                            <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 border border-slate-200">
                              {token.badge}
                            </span>
                          </div>
                          <p className="text-xs text-slate-600 font-medium mt-0.5">
                            {token.descriptionBn}
                          </p>
                        </div>
                      </div>

                      {/* 4 Team Color Samples */}
                      <div className="flex items-center gap-2 self-end sm:self-center">
                        <div className="flex items-center gap-1.5 p-1.5 bg-slate-100 rounded-xl border border-slate-200">
                          {colors.map((c) => (
                            <TokenPiece
                              key={c}
                              color={c}
                              styleId={token.id}
                              size="sm"
                              title={isEn ? `${token.nameEn} (${c})` : `${token.nameBn} (${c})`}
                            />
                          ))}
                        </div>
                        {isSelected && (
                          <span className="w-6 h-6 rounded-full bg-amber-500 text-white flex items-center justify-center shadow-sm">
                            <Check className="w-4 h-4 stroke-[3]" />
                          </span>
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 4: PRESET BUNDLES */}
          {activeTab === 'presets' && (
            <div className="space-y-3">
              <div>
                <h3 className="text-sm font-black text-slate-900 mb-1">
                  {isEn ? 'Curated Preset Bundles (1-Click Apply)' : 'রেডিমেড প্রিসেট বান্ডেল (১-ক্লিকে সেট করুন)'}
                </h3>
                <p className="text-xs text-slate-600 mb-3">
                  {isEn ? 'Harmonious combinations of background, board, dice, and tokens' : 'ব্যাকগ্রাউন্ড, বোর্ড, ডাইস এবং গুটির নিখুঁত নান্দনিক সমন্বয়'}
                </p>
              </div>

              <div className="space-y-3">
                {PRESET_BUNDLES.map((bundle) => {
                  const isCurrent =
                    tempConfig.boardTheme === bundle.config.boardTheme &&
                    tempConfig.diceStyle === bundle.config.diceStyle &&
                    tempConfig.tokenStyle === bundle.config.tokenStyle &&
                    tempConfig.diceFace === bundle.config.diceFace &&
                    tempConfig.gameBackground === bundle.config.gameBackground;

                  return (
                    <div
                      key={bundle.id}
                      className={`p-4 rounded-2xl border-2 transition-all flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 ${
                        isCurrent
                          ? 'border-amber-500 bg-amber-50/90 shadow-md ring-2 ring-amber-400'
                          : 'border-slate-200 bg-white hover:border-amber-300 shadow-sm'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <DicePiece
                          value={6}
                          styleId={bundle.config.diceStyle}
                          faceStyle={bundle.config.diceFace}
                          size={46}
                        />
                        <div>
                          <h4 className="text-sm font-black text-slate-900 leading-tight">
                            {isEn ? bundle.nameEn : bundle.nameBn}
                          </h4>
                          <p className="text-xs text-slate-600 font-medium mt-0.5">
                            {isEn ? bundle.descriptionEn : bundle.descriptionBn}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-3 self-end sm:self-center">
                        <div className="flex items-center gap-1.5 p-1.5 bg-slate-100 rounded-xl border border-slate-200">
                          {colors.map((c) => (
                            <TokenPiece
                              key={c}
                              color={c}
                              styleId={bundle.config.tokenStyle}
                              size="sm"
                            />
                          ))}
                        </div>

                        <button
                          onClick={() => handleApplyPreset(bundle.config as CustomizationConfig)}
                          className={`px-4 py-2 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 cursor-pointer ${
                            isCurrent
                              ? 'bg-emerald-600 text-white cursor-default shadow-sm'
                              : 'bg-amber-400 hover:bg-amber-300 text-amber-950 shadow-md active:scale-95'
                          }`}
                        >
                          {isCurrent ? (
                            <>
                              <Check className="w-3.5 h-3.5 stroke-[3]" />
                              <span>{isEn ? 'Active' : 'চলতি সক্রিয়'}</span>
                            </>
                          ) : (
                            <>
                              <Sparkles className="w-3.5 h-3.5" />
                              <span>{isEn ? 'Apply Bundle' : 'বান্ডেল প্রয়োগ'}</span>
                            </>
                          )}
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* Footer actions */}
        <div className="px-4 sm:px-6 py-3.5 bg-white border-t border-slate-200 flex items-center justify-between gap-3 shadow-inner">
          <button
            onClick={handleResetDefaults}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-all active:scale-95 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>{isEn ? 'Reset to Defaults' : 'ডিফল্ট থিমে ফিরুন'}</span>
          </button>

          <button
            id="save-customization-btn"
            onClick={() => {
              Sound.playWin();
              onClose();
            }}
            className="px-6 py-2.5 rounded-2xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-amber-950 font-black text-xs uppercase tracking-wider shadow-lg border-b-2 border-amber-700 transition-all active:scale-95 flex items-center gap-2 cursor-pointer"
          >
            <Check className="w-4 h-4 stroke-[3]" />
            <span>{isEn ? 'Done / Save' : 'সম্পন্ন / সংরক্ষণ'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
