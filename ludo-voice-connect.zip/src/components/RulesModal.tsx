import React from 'react';
import { X, BookOpen, Trophy, ShieldCheck, Zap, Sparkles, CheckCircle2, Award, Flame } from 'lucide-react';
import { Sound } from '../utils/soundEffects';

interface RulesModalProps {
  isOpen: boolean;
  onClose: () => void;
  isEn?: boolean;
}

export const RulesModal: React.FC<RulesModalProps> = ({ isOpen, onClose, isEn = true }) => {
  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-xl bg-slate-900 border-2 border-amber-400 rounded-3xl p-5 sm:p-6 text-white shadow-2xl overflow-hidden max-h-[90vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-400">
              <BookOpen className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg font-black text-white">
                {isEn ? 'Ludo Rules & Coin Bonuses' : 'লুডু খেলার নিয়ম ও কয়েন বোনাস'}
              </h3>
              <p className="text-xs text-slate-400">
                {isEn ? '100% safe social entertainment & fair play guide' : '১০০% নিরাপদ সুস্থ বিনোদন ও ফেয়ার প্লে গাইড'}
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              Sound.playClick();
              onClose();
            }}
            className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center cursor-pointer transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="overflow-y-auto pr-1 my-4 space-y-4 text-xs text-slate-300 leading-relaxed">
          {/* ZERO MONEY GAMING NOTICE BANNER */}
          <div className="p-3.5 rounded-2xl bg-gradient-to-r from-emerald-950/80 to-slate-900 border-2 border-emerald-500/60 flex items-start gap-3 shadow-md">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0 border border-emerald-400/30 mt-0.5">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-black text-emerald-300 mb-0.5">
                {isEn ? 'No real money gambling or betting involved' : 'লুডু খেলার জন্য কোনো অর্থ দেওয়া বা নেওয়া হয় না'}
              </h4>
              <p className="text-[11px] text-emerald-100/90 leading-normal">
                {isEn
                  ? 'Joy Ludo is designed purely for fun and friendly competition. Win matches to collect virtual Coins & XP to unlock custom board skins, special dice, and VIP avatars.'
                  : 'লুডু খেলা সম্পূর্ণ বিনামূল্যে সুস্থ বিনোদনের জন্য। এখানে কোনো জুয়া বা আর্থিক বাজি নেই। খেলায় জিতলে চমৎকার ভার্চুয়াল কয়েন বোনাস (Coin Bonus) ও এক্সপি রিওয়ার্ড পাবেন যা দিয়ে ফ্রি ডাইস, কাস্টম বোর্ড ও অবতার আনলক করা যায়।'}
              </p>
            </div>
          </div>

          {/* Rule Sections */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* 1. Basic Movement */}
            <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800">
              <div className="flex items-center gap-2 mb-2">
                <span className="w-6 h-6 rounded-lg bg-amber-500/20 text-amber-400 font-black text-xs flex items-center justify-center border border-amber-400/30">
                  1
                </span>
                <h4 className="font-black text-white text-xs">
                  {isEn ? 'Releasing Tokens & Rolling Sixes' : 'গুটি বের করা ও চাল'}
                </h4>
              </div>
              <ul className="space-y-1.5 text-[11px] text-slate-300">
                <li className="flex items-start gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                  <span>
                    {isEn
                      ? 'Roll a 6 to move a token out of your starting yard onto the track.'
                      : 'ডাইসে ৬ (ছক্কা) পড়লে ঘর থেকে গুটি বোর্ডে নামানো যায়।'}
                  </span>
                </li>
                <li className="flex items-start gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                  <span>
                    {isEn
                      ? 'Rolling a 6 awards an extra bonus roll immediately.'
                      : 'ছক্কা পড়লে চাল দেওয়ার পর আবারও অতিরিক্ত চাল পাবেন।'}
                  </span>
                </li>
                <li className="flex items-start gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                  <span>
                    {isEn
                      ? 'Rolling three 6s in a row cancels the 3rd roll and passes turn to next player.'
                      : 'টানা ৩ বার ছক্কা পড়লে শেষ চালটি বাতিল হয়ে পরবর্তী খেলোয়াড়ের পালা আসবে।'}
                  </span>
                </li>
              </ul>
            </div>

            {/* 2. Token Capture & Star Safety */}
            <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800">
              <div className="flex items-center gap-2 mb-2">
                <span className="w-6 h-6 rounded-lg bg-rose-500/20 text-rose-400 font-black text-xs flex items-center justify-center border border-rose-400/30">
                  2
                </span>
                <h4 className="font-black text-white text-xs">
                  {isEn ? 'Captures & Safe Star Cells' : 'গুটি কাটা ও নিরাপদ ঘর (স্টার)'}
                </h4>
              </div>
              <ul className="space-y-1.5 text-[11px] text-slate-300">
                <li className="flex items-start gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />
                  <span>
                    {isEn
                      ? 'Landing on an opponent token sends it back to yard and grants +1 bonus turn.'
                      : 'বিপক্ষের গুটি কাটলে তা ঘরে ফিরে যাবে এবং আপনি ১টি অতিরিক্ত বোনাস চাল পাবেন।'}
                  </span>
                </li>
                <li className="flex items-start gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />
                  <span>
                    {isEn
                      ? 'Star (★) cells are protected zones where tokens cannot be captured.'
                      : 'স্টার (★) চিহ্নিত ঘরগুলো নিরাপদ, এখানে কোনো গুটি কাটা যাবে না।'}
                  </span>
                </li>
              </ul>
            </div>

            {/* 3. Victory & Coin Bonus */}
            <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800">
              <div className="flex items-center gap-2 mb-2">
                <span className="w-6 h-6 rounded-lg bg-yellow-500/20 text-yellow-400 font-black text-xs flex items-center justify-center border border-yellow-400/30">
                  3
                </span>
                <h4 className="font-black text-white text-xs">
                  {isEn ? 'Victory & Coin Rewards' : 'বিজয় ও কয়েন বোনাস'}
                </h4>
              </div>
              <ul className="space-y-1.5 text-[11px] text-slate-300">
                <li className="flex items-start gap-1.5">
                  <Award className="w-3.5 h-3.5 text-yellow-400 shrink-0 mt-0.5" />
                  <span>
                    {isEn
                      ? 'Classic mode: Guide all 4 tokens to home triangle to win +2,500 coins.'
                      : 'ক্লাসিক ম্যাচে ৪টি গুটি আগে সেন্ট্রাল হোমে নিয়ে গেলে +২,৫০০ কয়েন বোনাস পাবেন।'}
                  </span>
                </li>
                <li className="flex items-start gap-1.5">
                  <Zap className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                  <span>
                    {isEn
                      ? 'Quick Match: Bring just 2 tokens home to win +1,500 coins in fast action.'
                      : 'কুইক ম্যাচে মাত্র ২টি গুটি হোমে নিলেই +১,৫০০ কয়েন বোনাস সহ দ্রুত জয়!'}
                  </span>
                </li>
              </ul>
            </div>

            {/* 4. Game Modes */}
            <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800">
              <div className="flex items-center gap-2 mb-2">
                <span className="w-6 h-6 rounded-lg bg-indigo-500/20 text-indigo-400 font-black text-xs flex items-center justify-center border border-indigo-400/30">
                  4
                </span>
                <h4 className="font-black text-white text-xs">
                  {isEn ? 'Multiplayer & Tournament Modes' : 'বিভিন্ন মোড ও টিম প্লে'}
                </h4>
              </div>
              <ul className="space-y-1.5 text-[11px] text-slate-300">
                <li className="flex items-start gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-indigo-400 shrink-0 mt-0.5" />
                  <span>
                    {isEn
                      ? '2v2 Team Play: Cooperate with your partner to win +3,500 coins together.'
                      : '২ বনাম ২ টিম প্লে: পার্টনারের সাথে মিলে যৌথ জয় ও +৩,৫০০ কয়েন বোনাস।'}
                  </span>
                </li>
                <li className="flex items-start gap-1.5">
                  <Trophy className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                  <span>
                    {isEn
                      ? 'Grand Tournament: 3 knockout rounds leading to a +5,000 coin mega prize.'
                      : 'গ্র্যান্ড টুর্নামেন্ট: ৩ রাউন্ডে বিজয়ী হয়ে জিতুন +৫,০০০ কয়েন মেগা বোনাস।'}
                  </span>
                </li>
              </ul>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-slate-800 flex items-center justify-between">
          <span className="text-[11px] text-slate-400 flex items-center gap-1">
            <Flame className="w-3.5 h-3.5 text-amber-400" />
            {isEn ? 'Coin rewards and XP level progression in every game' : 'প্রতি খেলায় দারুণ কয়েন বোনাস ও লেভেল আপ রিওয়ার্ড'}
          </span>
          <button
            onClick={() => {
              Sound.playClick();
              onClose();
            }}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-xs shadow-md transition-all cursor-pointer"
          >
            {isEn ? 'Got it, Let’s Play' : 'বুঝেছি, খেলা শুরু করি'}
          </button>
        </div>
      </div>
    </div>
  );
};
