import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  Users,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Radio,
  Sparkles,
  Trophy,
  Gift,
  Send,
  Plus,
  Crown,
  Flame,
  Globe,
  Music,
  Share2,
  Smile,
  LogOut,
  Hand,
  CheckCircle2,
  Coffee,
  Heart,
  ChevronRight,
  ShieldCheck,
  Disc,
  Play,
  Pause,
  Upload,
  FileAudio,
  UserX,
  Ban,
  Sliders,
  RotateCcw,
  Sparkle,
  Image as ImageIcon,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { AvatarConfig, UserProfile } from '../types';
import { AvatarDisplay } from './AvatarDisplay';
import { VipBadge } from './VipBadge';
import { loadUserAgeConfig } from '../utils/ageLimitService';
import { loadVipState } from '../utils/vipService';
import { VIP_CHAT_BUBBLES } from '../utils/vipConstants';
import {
  AddaRoom,
  AddaSeat,
  AddaGift,
  AddaMessage,
  AddaSticker,
  ADDA_GIFTS,
  ADDA_SOUNDBOARD,
  ADDA_STICKERS,
  ADDA_EMOJIS,
  INITIAL_ADDA_ROOMS,
} from '../utils/addaConstants';
import {
  AddaMusic,
  AddaSong,
  PRESET_ADDA_SONGS,
} from '../utils/addaMusicService';
import {
  loadBlockedUsers,
  blockUser,
  unblockUser,
  isUserBlocked,
  BlockedUser,
} from '../utils/addaBlockService';
import { CountryInfo, COUNTRIES_195 } from '../utils/countryData';
import { Sound } from '../utils/soundEffects';

interface AddaLiveBoardModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile;
  userAvatar: AvatarConfig;
  userCoins: number;
  onUpdateCoins: (newCoins: number) => void;
}

export const AddaLiveBoardModal: React.FC<AddaLiveBoardModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  userAvatar,
  userCoins,
  onUpdateCoins,
}) => {
  const currentUserVipState = loadVipState(currentUser.id);

  // Navigation: 'lobby' or 'room'
  const [view, setView] = useState<'lobby' | 'room'>('room');
  const [rooms, setRooms] = useState<AddaRoom[]>(INITIAL_ADDA_ROOMS);
  const [activeRoom, setActiveRoom] = useState<AddaRoom>(INITIAL_ADDA_ROOMS[0]);
  const [activeCategory, setActiveCategory] = useState<string>('all');

  // Live Stage Seat & Mic States
  const [mySeatIndex, setMySeatIndex] = useState<number | null>(0); // Default seated at Host or Guest seat
  const [isMyMicMuted, setIsMyMicMuted] = useState<boolean>(false);
  const [isSpeakingLocally, setIsSpeakingLocally] = useState<boolean>(false);
  const [myHandRaised, setMyHandRaised] = useState<boolean>(false);

  // Room Speaker Mute State (Mute all incoming room sound/music)
  const [isRoomAudioMuted, setIsRoomAudioMuted] = useState<boolean>(false);

  // Center Activity Tab: 'dice' | 'music' | 'stickers' | 'ambience'
  const [centerTab, setCenterTab] = useState<'dice' | 'music' | 'stickers' | 'ambience'>('dice');

  // Live Music & Audio File Player State
  const [currentSong, setCurrentSong] = useState<AddaSong | null>(PRESET_ADDA_SONGS[0]);
  const [isPlayingMusic, setIsPlayingMusic] = useState<boolean>(false);
  const [musicCurrentTime, setMusicCurrentTime] = useState<number>(0);
  const [musicDuration, setMusicDuration] = useState<number>(180);
  const [musicVolume, setMusicVolume] = useState<number>(0.6);
  const [customUploadedSongs, setCustomUploadedSongs] = useState<AddaSong[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Block List State
  const [blockedUsers, setBlockedUsers] = useState<BlockedUser[]>([]);
  const [isBlockListModalOpen, setIsBlockListModalOpen] = useState<boolean>(false);

  // Selected User Action Sheet (for Seat / Chat user click)
  const [selectedUserAction, setSelectedUserAction] = useState<{
    seatIndex?: number;
    userId: string;
    userName: string;
    avatar: AvatarConfig;
    isHost?: boolean;
    isMuted?: boolean;
    countryFlag?: string;
  } | null>(null);

  // Dice Showdown State
  const [diceScores, setDiceScores] = useState<Record<number, number>>({
    0: 5,
    1: 6,
    2: 4,
    3: 3,
    4: 6,
    5: 2,
    6: 5,
  });
  const [isRollingDice, setIsRollingDice] = useState<boolean>(false);
  const [lastDiceWinner, setLastDiceWinner] = useState<{ name: string; score: number } | null>({
    name: 'সাদিয়া তাসনিম',
    score: 6,
  });

  // Chat & Stream Messages
  const [chatMessages, setChatMessages] = useState<AddaMessage[]>([
    {
      id: 'm1',
      userId: 'host_arif',
      userName: 'আরিফ ভাই (Host)',
      userCountryFlag: '🇧🇩',
      userLevel: 18,
      text: 'স্বাগতম সবাইকে আমাদের ১০ জনের লাইভ আড্ডা বোর্ডে! ☕🎙️',
      timestamp: Date.now() - 60000,
    },
    {
      id: 'm2',
      userId: 'user_sadia',
      userName: 'সাদিয়া তাসনিম',
      userCountryFlag: '🇧🇩',
      userLevel: 12,
      text: 'কে কে চা খাবেন হাত তুলুন! 🙋‍♀️',
      timestamp: Date.now() - 30000,
    },
    {
      id: 'm3',
      userId: 'user_kamrul',
      userName: 'কামরুল দুবাই',
      userCountryFlag: '🇦🇪',
      userLevel: 25,
      text: 'দুবাই থেকে একদম ক্লিয়ার শোনা যাচ্ছে, নো ভিপিএন! 🚀',
      timestamp: Date.now() - 15000,
    },
  ]);
  const [chatInput, setChatInput] = useState<string>('');
  const chatScrollRef = useRef<HTMLDivElement>(null);

  // Floating Reactions & Effects (Gifts, Emojis, Stickers)
  const [selectedSeatForGift, setSelectedSeatForGift] = useState<number | null>(null);
  const [floatingReactions, setFloatingReactions] = useState<
    {
      id: string;
      content: string;
      title?: string;
      type: 'gift' | 'emoji' | 'sticker';
      x: number;
      y: number;
      bgGradient?: string;
    }[]
  >([]);

  // Soundboard Popover
  const [isSoundboardOpen, setIsSoundboardOpen] = useState<boolean>(false);

  // Load blocked users on mount
  useEffect(() => {
    setBlockedUsers(loadBlockedUsers());
  }, [isOpen]);

  // Subscribe to Music Player
  useEffect(() => {
    const unsub = AddaMusic.subscribe((state) => {
      setIsPlayingMusic(state.isPlaying);
      if (state.currentSong) setCurrentSong(state.currentSong);
      setMusicCurrentTime(state.currentTime);
      setMusicDuration(state.duration || 180);
    });
    return () => {
      unsub();
    };
  }, []);

  // Sync room mute with sound engine
  useEffect(() => {
    if (isRoomAudioMuted) {
      AddaMusic.setVolume(0);
    } else {
      AddaMusic.setVolume(musicVolume);
    }
  }, [isRoomAudioMuted, musicVolume]);

  // Cleanup music when modal closes
  useEffect(() => {
    if (!isOpen) {
      AddaMusic.stop();
    }
  }, [isOpen]);

  // Format seconds to mm:ss
  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  // Simulated Speaking Pulses for Bots & Real participants
  useEffect(() => {
    if (!isOpen || view !== 'room') return;

    const interval = setInterval(() => {
      // Pick random occupied seat to animate speaking
      setActiveRoom((prev) => {
        const updatedSeats = prev.seats.map((seat, idx) => {
          if (!seat || !seat.occupied) return null;
          if (idx === mySeatIndex) {
            return { ...seat, isSpeaking: !isMyMicMuted && isSpeakingLocally };
          }
          // Random bot speaking simulation
          const shouldSpeak = Math.random() > 0.65;
          return {
            ...seat,
            isSpeaking: seat.isMuted ? false : shouldSpeak,
          };
        });
        return { ...prev, seats: updatedSeats };
      });
    }, 2500);

    return () => clearInterval(interval);
  }, [isOpen, view, mySeatIndex, isMyMicMuted, isSpeakingLocally]);

  // Auto scroll chat
  useEffect(() => {
    if (chatScrollRef.current) {
      chatScrollRef.current.scrollTop = chatScrollRef.current.scrollHeight;
    }
  }, [chatMessages]);

  if (!isOpen) return null;

  // Trigger celebration confetti
  const triggerCelebration = () => {
    confetti({
      particleCount: 50,
      spread: 70,
      origin: { y: 0.6 },
    });
  };

  // Join Room
  const handleJoinRoom = (room: AddaRoom) => {
    Sound.playClick();
    setActiveRoom(room);
    setView('room');
    setMySeatIndex(null); // Join as audience initially
  };

  // Take a specific seat (0 to 9)
  const handleTakeSeat = (seatIdx: number) => {
    Sound.playClick();
    const userCountry = COUNTRIES_195[0]; // Default BD or detected
    const newSeat: AddaSeat = {
      seatIndex: seatIdx,
      occupied: true,
      userId: currentUser.id || 'usr_me',
      userName: `${currentUser.name} (আপনি)`,
      avatar: userAvatar,
      country: userCountry,
      isMuted: false,
      isSpeaking: false,
      isHost: seatIdx === 0,
      coins: userCoins,
      level: currentUser.level || 5,
      vipTitle: seatIdx === 0 ? 'হোস্ট 👑' : 'আড্ডা মেম্বার ✨',
      score: 0,
    };

    setActiveRoom((prev) => {
      const seats = [...prev.seats];
      // Clear previous seat if already seated
      if (mySeatIndex !== null && seats[mySeatIndex]) {
        seats[mySeatIndex] = null;
      }
      seats[seatIdx] = newSeat;
      return { ...prev, seats };
    });

    setMySeatIndex(seatIdx);
    setIsMyMicMuted(false);

    // Send broadcast announcement
    const msg: AddaMessage = {
      id: 'join_' + Date.now(),
      userId: 'system',
      userName: 'সিস্টেম নোটিশ',
      userCountryFlag: '🎙️',
      text: `${currentUser.name} সিট #${seatIdx + 1} এ স্টেজে যুক্ত হয়েছেন!`,
      isHostNotice: true,
      timestamp: Date.now(),
    };
    setChatMessages((prev) => [...prev, msg]);
  };

  // Leave Seat
  const handleLeaveSeat = () => {
    Sound.playClick();
    if (mySeatIndex === null) return;

    setActiveRoom((prev) => {
      const seats = [...prev.seats];
      seats[mySeatIndex] = null;
      return { ...prev, seats };
    });

    setMySeatIndex(null);
    setIsSpeakingLocally(false);
  };

  // Toggle Mic
  const handleToggleMyMic = () => {
    const ageConfig = loadUserAgeConfig(currentUser);
    if (!ageConfig.voiceChatAllowed) {
      Sound.playAlert();
      alert('🧒 চাইল্ড সেফটি পলিসি: ১৩ বছরের নিচের অ্যাকাউন্টে শিশু সুরক্ষার জন্য উন্মুক্ত লাইভ ভয়েস স্টেজ বন্ধ রাখা হয়েছে।');
      return;
    }

    const nextMuted = !isMyMicMuted;
    setIsMyMicMuted(nextMuted);
    Sound.playMicToggle(nextMuted);

    if (mySeatIndex !== null) {
      setActiveRoom((prev) => {
        const seats = [...prev.seats];
        if (seats[mySeatIndex]) {
          seats[mySeatIndex] = {
            ...seats[mySeatIndex]!,
            isMuted: nextMuted,
            isSpeaking: !nextMuted,
          };
        }
        return { ...prev, seats };
      });
    }

    if (!nextMuted) {
      setIsSpeakingLocally(true);
      setTimeout(() => setIsSpeakingLocally(false), 3000);
    }
  };

  // Send Soundboard Voice Clip
  const handleSendSoundboard = (clip: (typeof ADDA_SOUNDBOARD)[0]) => {
    Sound.playBanglaVoice(clip.text);
    setIsSoundboardOpen(false);

    const msg: AddaMessage = {
      id: 'sb_' + Date.now(),
      userId: currentUser.id || 'usr_me',
      userName: currentUser.name,
      userCountryFlag: '🇧🇩',
      text: `🔊 "${clip.text}"`,
      timestamp: Date.now(),
    };
    setChatMessages((prev) => [...prev, msg]);

    // Local speaking ripple
    if (mySeatIndex !== null) {
      setIsSpeakingLocally(true);
      setTimeout(() => setIsSpeakingLocally(false), 2000);
    }
  };

  // Send Gift
  const handleSendGift = (gift: AddaGift) => {
    if (userCoins < gift.coinPrice) {
      Sound.playAlert();
      alert(`আপনার পর্যাপ্ত কয়েন নেই! কয়েন প্রয়োজন: ${gift.coinPrice} 🪙`);
      return;
    }

    // Deduct coins
    const newCoins = userCoins - gift.coinPrice;
    onUpdateCoins(newCoins);

    // Audio effect based on gift
    if (gift.animationType === 'rose' || gift.animationType === 'heart') {
      Sound.playGiftShower();
    } else if (gift.animationType === 'tea') {
      Sound.playChaiPour();
    } else if (gift.animationType === 'crown') {
      Sound.playCrownFanfare();
    } else if (gift.animationType === 'fireworks') {
      Sound.playFireworks();
    } else {
      Sound.playDiamondCollect();
    }

    triggerCelebration();

    // Determine target recipient
    let targetName = 'সবাইকে';
    if (selectedSeatForGift !== null && activeRoom.seats[selectedSeatForGift]) {
      targetName = activeRoom.seats[selectedSeatForGift]!.userName;
    }

    const msg: AddaMessage = {
      id: 'gift_' + Date.now(),
      userId: currentUser.id || 'usr_me',
      userName: currentUser.name,
      userCountryFlag: '🇧🇩',
      text: `🎁 ${gift.bengaliName} পাঠিয়েছেন ${targetName}-কে!`,
      isGift: true,
      giftData: {
        icon: gift.icon,
        name: gift.bengaliName,
        count: 1,
        toName: targetName,
      },
      timestamp: Date.now(),
    };
    setChatMessages((prev) => [...prev, msg]);

    // Floating particles
    const floatId = 'fl_' + Date.now();
    setFloatingReactions((prev) => [
      ...prev,
      {
        id: floatId,
        type: 'gift',
        content: gift.icon,
        title: gift.bengaliName,
        x: Math.random() * 60 + 20,
        y: Math.random() * 40 + 30,
      },
    ]);

    setTimeout(() => {
      setFloatingReactions((prev) => prev.filter((g) => g.id !== floatId));
    }, 2800);
  };

  // Roll 10-Player Dice Showdown
  const handleRollDiceShowdown = () => {
    if (isRollingDice) return;
    setIsRollingDice(true);
    Sound.playDiceRoll();

    setTimeout(() => {
      const myRoll = Math.floor(Math.random() * 6) + 1;
      const updatedScores: Record<number, number> = {};

      activeRoom.seats.forEach((seat, idx) => {
        if (seat && seat.occupied) {
          if (idx === mySeatIndex) {
            updatedScores[idx] = myRoll;
          } else {
            updatedScores[idx] = Math.floor(Math.random() * 6) + 1;
          }
        }
      });

      setDiceScores(updatedScores);
      setIsRollingDice(false);

      // Find highest roller
      let maxScore = -1;
      let winnerName = '';
      Object.entries(updatedScores).forEach(([seatStr, score]) => {
        const sIdx = parseInt(seatStr, 10);
        if (score > maxScore && activeRoom.seats[sIdx]) {
          maxScore = score;
          winnerName = activeRoom.seats[sIdx]!.userName;
        }
      });

      setLastDiceWinner({ name: winnerName, score: maxScore });
      Sound.playCrowdCheer();
      triggerCelebration();

      const msg: AddaMessage = {
        id: 'dice_' + Date.now(),
        userId: 'system',
        userName: '🎲 ডাইস শো-ডাউন',
        userCountryFlag: '🏆',
        text: `এই রাউন্ডে ${winnerName} সর্বোচ্চ ${maxScore} ফেলে বিজয়ী হয়েছেন! 🎉`,
        isHostNotice: true,
        timestamp: Date.now(),
      };
      setChatMessages((prev) => [...prev, msg]);
    }, 1200);
  };

  // Send Text Chat
  const handleSendChat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;

    Sound.playButtonTick();
    const msg: AddaMessage = {
      id: 'chat_' + Date.now(),
      userId: currentUser.id || 'usr_me',
      userName: currentUser.name,
      userCountryFlag: '🇧🇩',
      userLevel: currentUser.level || 5,
      text: chatInput.trim(),
      timestamp: Date.now(),
    };

    setChatMessages((prev) => [...prev, msg]);
    setChatInput('');
  };

  // Toggle Room Speaker Mute
  const handleToggleRoomMute = () => {
    const next = !isRoomAudioMuted;
    setIsRoomAudioMuted(next);
    Sound.playClick();
  };

  // Play Preset Song
  const handlePlayPresetSong = (song: AddaSong) => {
    Sound.playClick();
    AddaMusic.playPresetSong(song);
    setCurrentSong(song);

    // Chat broadcast
    const msg: AddaMessage = {
      id: 'music_' + Date.now(),
      userId: 'system',
      userName: '🎵 লাইভ মিউজিক',
      userCountryFlag: '📻',
      text: `লাইভ আড্ডায় গান বাজা শুরু হয়েছে: "${song.title}" 🎶`,
      isHostNotice: true,
      timestamp: Date.now(),
    };
    setChatMessages((prev) => [...prev, msg]);
  };

  // Toggle Song Play/Pause
  const handleToggleMusicPlay = () => {
    if (isPlayingMusic) {
      AddaMusic.pause();
    } else {
      if (currentSong) {
        if (currentSong.isCustom) {
          AddaMusic.resume();
        } else {
          AddaMusic.playPresetSong(currentSong);
        }
      } else {
        handlePlayPresetSong(PRESET_ADDA_SONGS[0]);
      }
    }
  };

  // Handle Custom Audio File Upload
  const handleCustomAudioUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Check audio type
    if (!file.type.startsWith('audio/') && !file.name.match(/\.(mp3|wav|ogg|m4a|aac)$/i)) {
      alert('অনুগ্রহ করে একটি সঠিক অডিও গান ফাইল (.mp3, .wav, .ogg, .m4a) নির্বাচন করুন!');
      return;
    }

    try {
      const customSong = AddaMusic.playCustomAudioFile(file);
      setCustomUploadedSongs((prev) => [customSong, ...prev]);
      setCurrentSong(customSong);
      triggerCelebration();

      // Chat broadcast
      const msg: AddaMessage = {
        id: 'upload_music_' + Date.now(),
        userId: currentUser.id || 'usr_me',
        userName: currentUser.name,
        userCountryFlag: '🎵',
        text: `লাইভ আড্ডায় নিজের গান ফাইল যুক্ত করেছেন: "${customSong.title}" 📻`,
        isHostNotice: true,
        timestamp: Date.now(),
      };
      setChatMessages((prev) => [...prev, msg]);
    } catch (err) {
      console.error('Failed to load audio file:', err);
      alert('অডিও ফাইলটি লোড করা সম্ভব হয়নি।');
    }
  };

  // Send Floating Emoji Reaction
  const handleSendEmojiReaction = (emoji: string) => {
    Sound.playButtonTick();

    const floatId = 'emo_' + Date.now() + '_' + Math.random().toString(36).substring(2, 5);
    setFloatingReactions((prev) => [
      ...prev,
      {
        id: floatId,
        content: emoji,
        type: 'emoji',
        x: Math.random() * 70 + 15,
        y: Math.random() * 40 + 35,
      },
    ]);

    setTimeout(() => {
      setFloatingReactions((prev) => prev.filter((r) => r.id !== floatId));
    }, 2500);

    // Send to chat
    const msg: AddaMessage = {
      id: 'chat_emo_' + Date.now(),
      userId: currentUser.id || 'usr_me',
      userName: currentUser.name,
      userCountryFlag: '🇧🇩',
      userLevel: currentUser.level || 5,
      text: emoji,
      timestamp: Date.now(),
    };
    setChatMessages((prev) => [...prev, msg]);
  };

  // Send Sticker
  const handleSendSticker = (sticker: AddaSticker) => {
    Sound.playCrownFanfare();
    triggerCelebration();

    const floatId = 'stk_' + Date.now() + '_' + Math.random().toString(36).substring(2, 5);
    setFloatingReactions((prev) => [
      ...prev,
      {
        id: floatId,
        content: sticker.emoji,
        title: sticker.title,
        type: 'sticker',
        bgGradient: sticker.bgGradient,
        x: Math.random() * 50 + 25,
        y: Math.random() * 30 + 35,
      },
    ]);

    setTimeout(() => {
      setFloatingReactions((prev) => prev.filter((r) => r.id !== floatId));
    }, 3200);

    // Send sticker card to chat
    const msg: AddaMessage = {
      id: 'msg_stk_' + Date.now(),
      userId: currentUser.id || 'usr_me',
      userName: currentUser.name,
      userCountryFlag: '🇧🇩',
      userLevel: currentUser.level || 5,
      text: sticker.title,
      isSticker: true,
      stickerData: {
        emoji: sticker.emoji,
        badgeText: sticker.badgeText,
        bgGradient: sticker.bgGradient,
      },
      timestamp: Date.now(),
    };
    setChatMessages((prev) => [...prev, msg]);
  };

  // Block User Handler
  const handleBlockUserAction = (targetUserId: string, targetUserName: string) => {
    const updated = blockUser(targetUserId, targetUserName);
    setBlockedUsers(updated);
    setSelectedUserAction(null);
    Sound.playAlert();

    const msg: AddaMessage = {
      id: 'blk_notice_' + Date.now(),
      userId: 'system',
      userName: 'ব্লক নোটিশ',
      userCountryFlag: '🚫',
      text: `"${targetUserName}" কে আপনার ব্লক লিস্টে যুক্ত করা হয়েছে।`,
      isHostNotice: true,
      timestamp: Date.now(),
    };
    setChatMessages((prev) => [...prev, msg]);
  };

  // Unblock User Handler
  const handleUnblockUserAction = (targetUserId: string) => {
    const updated = unblockUser(targetUserId);
    setBlockedUsers(updated);
    Sound.playClick();
  };

  // Board Out / Kick Out Member from Board (Host or Admin action)
  const handleKickOutFromSeat = (seatIdx: number) => {
    const targetSeat = activeRoom.seats[seatIdx];
    if (!targetSeat) return;

    Sound.playAlert();
    const targetName = targetSeat.userName;

    setActiveRoom((prev) => {
      const seats = [...prev.seats];
      seats[seatIdx] = null;
      return { ...prev, seats };
    });

    if (mySeatIndex === seatIdx) {
      setMySeatIndex(null);
      setIsSpeakingLocally(false);
    }

    setSelectedUserAction(null);

    const msg: AddaMessage = {
      id: 'kick_' + Date.now(),
      userId: 'system',
      userName: 'বোর্ড আউট নোটিশ 🚪',
      userCountryFlag: '⚠️',
      text: `হোস্ট কর্তৃক "${targetName}" কে সিট #${seatIdx + 1} থেকে বোর্ড আউট করা হয়েছে!`,
      isHostNotice: true,
      timestamp: Date.now(),
    };
    setChatMessages((prev) => [...prev, msg]);
  };

  // Toggle Mute on a Specific Seat (Host or User)
  const handleToggleSeatMute = (seatIdx: number) => {
    const targetSeat = activeRoom.seats[seatIdx];
    if (!targetSeat) return;

    Sound.playClick();
    const nextMuted = !targetSeat.isMuted;

    setActiveRoom((prev) => {
      const seats = [...prev.seats];
      if (seats[seatIdx]) {
        seats[seatIdx] = {
          ...seats[seatIdx]!,
          isMuted: nextMuted,
          isSpeaking: nextMuted ? false : seats[seatIdx]!.isSpeaking,
        };
      }
      return { ...prev, seats };
    });

    if (mySeatIndex === seatIdx) {
      setIsMyMicMuted(nextMuted);
    }

    setSelectedUserAction(null);
  };

  // Filtered Rooms for Lobby
  const filteredRooms = rooms.filter((r) => {
    if (activeCategory === 'all') return true;
    return r.tags.includes(activeCategory) || r.id.includes(activeCategory);
  });

  // Filter messages by blocked users
  const visibleChatMessages = chatMessages.filter(
    (m) => !isUserBlocked(m.userId, blockedUsers)
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/80 backdrop-blur-md animate-fade-in">
      {/* Hidden File Input for Custom Song Upload */}
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleCustomAudioUpload}
        accept="audio/*,.mp3,.wav,.ogg,.m4a,.aac"
        className="hidden"
      />

      <div className="relative w-full max-w-5xl h-[92vh] max-h-[880px] bg-slate-950 text-white rounded-3xl border-2 border-amber-500/50 shadow-2xl flex flex-col overflow-hidden">
        {/* Floating Animated Reactions (Gifts, Emojis, Stickers) */}
        {floatingReactions.map((fr) => (
          <div
            key={fr.id}
            style={{ left: `${fr.x}%`, top: `${fr.y}%` }}
            className={`absolute z-50 pointer-events-none transform -translate-x-1/2 -translate-y-1/2 animate-bounce flex flex-col items-center filter drop-shadow-2xl transition-all duration-1000 ${
              fr.type === 'sticker' ? 'scale-125' : ''
            }`}
          >
            {fr.type === 'sticker' ? (
              <div
                className={`p-3 rounded-2xl bg-gradient-to-r ${
                  fr.bgGradient || 'from-amber-500 to-rose-500'
                } border-2 border-white text-white shadow-2xl flex items-center gap-2`}
              >
                <span className="text-4xl sm:text-5xl">{fr.content}</span>
                {fr.title && (
                  <span className="text-xs sm:text-sm font-black text-white whitespace-nowrap drop-shadow-md">
                    {fr.title}
                  </span>
                )}
              </div>
            ) : fr.type === 'emoji' ? (
              <span className="text-4xl sm:text-6xl animate-pulse">{fr.content}</span>
            ) : (
              <span className="text-4xl sm:text-6xl">{fr.content}</span>
            )}
          </div>
        ))}

        {/* Header Bar */}
        <div className="px-3 sm:px-4 py-2.5 sm:py-3 bg-gradient-to-r from-amber-600 via-amber-700 to-yellow-600 flex items-center justify-between shadow-md shrink-0 border-b border-amber-400/40">
          <div className="flex items-center gap-2 sm:gap-2.5">
            <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-2xl bg-amber-950/40 border border-amber-300/40 flex items-center justify-center text-white shadow-inner">
              <Radio className="w-4 h-4 sm:w-5 sm:h-5 text-yellow-300 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-sm sm:text-lg font-black text-white tracking-wide truncate max-w-[180px] sm:max-w-[340px]">
                  {view === 'room' ? activeRoom.title : '🎙️ ১০ জনের লাইভ আড্ডা বোর্ড'}
                </h2>
                <span className="px-2 py-0.5 rounded-full bg-emerald-500 text-slate-950 font-black text-[9px] sm:text-[10px] uppercase tracking-wider flex items-center gap-1 shadow-xs shrink-0">
                  <span className="w-1.5 h-1.5 rounded-full bg-white animate-ping" />
                  ১০ জন লাইভ
                </span>
              </div>
              <p className="text-[10px] sm:text-[11px] text-amber-100 font-medium truncate max-w-[240px] sm:max-w-[420px]">
                {view === 'room'
                  ? `${activeRoom.tagline} • ১৯৫টি দেশে VPN ছাড়াই সরাসরি সংযুক্ত`
                  : 'বন্ধুদের সাথে লাইভ ভয়েস আড্ডা, গান, চা ও ১০ জনের ডাইস শো-ডাউন'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 sm:gap-2">
            {view === 'room' && (
              <>
                {/* Room Speaker Mute / Unmute Button */}
                <button
                  onClick={handleToggleRoomMute}
                  className={`px-2.5 sm:px-3 py-1.5 rounded-xl text-xs font-black flex items-center gap-1.5 transition-all cursor-pointer ${
                    isRoomAudioMuted
                      ? 'bg-red-600/90 hover:bg-red-600 text-white shadow-md'
                      : 'bg-amber-950/60 hover:bg-amber-900 text-amber-100 border border-amber-300/40'
                  }`}
                  title={isRoomAudioMuted ? 'রুমের স্পিকার আনমিউট করুন' : 'রুমের স্পিকার মিউট করুন'}
                >
                  {isRoomAudioMuted ? (
                    <VolumeX className="w-3.5 h-3.5 text-red-200" />
                  ) : (
                    <Volume2 className="w-3.5 h-3.5 text-amber-300" />
                  )}
                  <span className="hidden md:inline">
                    {isRoomAudioMuted ? 'স্পিকার মিউট' : 'শব্দ চালু'}
                  </span>
                </button>

                {/* Block List Button */}
                <button
                  onClick={() => {
                    Sound.playClick();
                    setIsBlockListModalOpen(true);
                  }}
                  className="relative px-2.5 sm:px-3 py-1.5 rounded-xl bg-amber-950/60 hover:bg-amber-900 text-amber-100 text-xs font-black border border-amber-300/40 flex items-center gap-1 transition-all cursor-pointer"
                  title="ব্লক লিস্ট দেখুন"
                >
                  <Ban className="w-3.5 h-3.5 text-rose-300" />
                  <span className="hidden sm:inline">ব্লক লিস্ট</span>
                  {blockedUsers.length > 0 && (
                    <span className="w-4 h-4 rounded-full bg-rose-500 text-white text-[9px] font-black flex items-center justify-center">
                      {blockedUsers.length}
                    </span>
                  )}
                </button>

                {/* Exit Board / Leave Room Button */}
                <button
                  onClick={() => {
                    Sound.playClick();
                    if (mySeatIndex !== null) {
                      handleLeaveSeat();
                    }
                    setView('lobby');
                  }}
                  className="px-2.5 sm:px-3 py-1.5 rounded-xl bg-rose-900/70 hover:bg-rose-800 text-rose-100 text-xs font-black border border-rose-400/40 flex items-center gap-1 transition-all cursor-pointer"
                  title="আড্ডা ত্যাগ / বোর্ড আউট"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">বোর্ড ত্যাগ</span>
                </button>
              </>
            )}

            <button
              onClick={() => {
                Sound.playClick();
                onClose();
              }}
              className="w-8 h-8 sm:w-9 sm:h-9 rounded-2xl bg-amber-950/50 hover:bg-red-600/80 text-white flex items-center justify-center transition-all cursor-pointer border border-amber-300/30"
              title="বন্ধ করুন"
            >
              <X className="w-4 h-4 sm:w-5 sm:h-5" />
            </button>
          </div>
        </div>

        {/* VIEW 1: LOBBY LIST */}
        {view === 'lobby' ? (
          <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-5 bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950">
            {/* Filter Tabs */}
            <div className="flex items-center gap-2 overflow-x-auto pb-1">
              {[
                { id: 'all', label: 'সব আড্ডা রুম', icon: '🌐' },
                { id: 'friends', label: 'ফ্রেন্ডস আড্ডা', icon: '☕' },
                { id: 'ludo', label: 'লুডো ও ডাইস', icon: '🎲' },
                { id: 'probasee', label: 'প্রবাসী আড্ডা', icon: '🌴' },
                { id: 'music', label: 'গান ও গল্প', icon: '🎸' },
                { id: 'international', label: 'আন্তর্জাতিক', icon: '🌍' },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => {
                    Sound.playClick();
                    setActiveCategory(tab.id);
                  }}
                  className={`px-3.5 py-2 rounded-2xl text-xs font-black shrink-0 transition-all flex items-center gap-1.5 cursor-pointer ${
                    activeCategory === tab.id
                      ? 'bg-amber-500 text-slate-950 shadow-md scale-105'
                      : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700/80'
                  }`}
                >
                  <span>{tab.icon}</span>
                  <span>{tab.label}</span>
                </button>
              ))}
            </div>

            {/* Room Cards Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredRooms.map((room) => {
                const filledSeats = room.seats.filter((s) => s && s.occupied).length;
                return (
                  <div
                    key={room.id}
                    className="p-4 rounded-3xl bg-slate-900/90 border-2 border-slate-800 hover:border-amber-500/60 transition-all shadow-lg flex flex-col justify-between group"
                  >
                    <div>
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <div className="flex items-center gap-2.5">
                          <AvatarDisplay avatar={room.hostAvatar} size={40} />
                          <div>
                            <h3 className="text-sm font-black text-white group-hover:text-amber-400 transition-colors">
                              {room.title}
                            </h3>
                            <p className="text-[11px] text-slate-400 font-medium">
                              হোস্ট: {room.hostName} {room.hostCountry.flag}
                            </p>
                          </div>
                        </div>
                        <span className="px-2.5 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[11px] font-black shrink-0">
                          {filledSeats}/১০ সিট
                        </span>
                      </div>

                      <p className="text-xs text-slate-300 font-medium mt-1 leading-relaxed">
                        {room.tagline}
                      </p>

                      <div className="flex flex-wrap gap-1.5 mt-3">
                        {room.tags.map((tag, tIdx) => (
                          <span
                            key={tIdx}
                            className="text-[10px] px-2 py-0.5 rounded-md bg-slate-800 text-slate-400 font-semibold"
                          >
                            #{tag}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between">
                      <span className="text-xs text-emerald-400 font-bold flex items-center gap-1.5">
                        <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                        {room.spectatorCount} জন শুনছেন
                      </span>

                      <button
                        onClick={() => handleJoinRoom(room)}
                        className="px-4 py-2 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 text-xs font-black shadow-md flex items-center gap-1.5 active:scale-95 transition-all cursor-pointer"
                      >
                        <Radio className="w-3.5 h-3.5" />
                        <span>আড্ডায় ঢুকুন</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ) : (
          /* VIEW 2: LIVE 10-SEAT STAGE ROOM */
          <div className="flex-1 overflow-hidden grid grid-cols-1 lg:grid-cols-12 bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950">
            {/* Left / Center Column: 10 Seats VIP Stage & Center Activity Board */}
            <div className="lg:col-span-8 p-3 sm:p-4 flex flex-col justify-between overflow-y-auto border-r border-slate-800/80">
              {/* TOP 5 SEATS (Seat 0 = Host, Seats 1 to 4) */}
              <div className="space-y-1">
                <div className="flex items-center justify-between px-2 mb-1">
                  <span className="text-xs font-black text-amber-400 flex items-center gap-1.5">
                    <Crown className="w-4 h-4 text-yellow-400" />
                    ১০ জনের লাইভ স্টেজ (সিট ১ - ৫)
                  </span>
                  <span className="text-[10px] font-bold text-slate-400">
                    {activeRoom.seats.filter((s) => s?.occupied).length}/১০ জন মাইক্রোফোনে
                  </span>
                </div>

                <div className="grid grid-cols-5 gap-2 sm:gap-3">
                  {activeRoom.seats.slice(0, 5).map((seat, sIdx) => {
                    const isMe = mySeatIndex === sIdx;
                    return (
                      <div
                        key={sIdx}
                        onClick={() => {
                          if (!seat || !seat.occupied) {
                            handleTakeSeat(sIdx);
                          } else {
                            // Open user actions sheet
                            setSelectedUserAction({
                              seatIndex: sIdx,
                              userId: seat.userId,
                              userName: seat.userName,
                              avatar: seat.avatar,
                              isHost: seat.isHost,
                              isMuted: seat.isMuted,
                              countryFlag: seat.country.flag,
                            });
                          }
                        }}
                        className={`relative rounded-2xl p-2 sm:p-2.5 flex flex-col items-center justify-center transition-all cursor-pointer group text-center min-h-[95px] sm:min-h-[110px] ${
                          seat && seat.occupied
                            ? seat.isSpeaking
                              ? 'bg-slate-900/90 border-2 border-emerald-400 shadow-lg shadow-emerald-500/20'
                              : 'bg-slate-900/70 border border-slate-700 hover:border-amber-400/60'
                            : 'bg-slate-900/30 border-2 border-dashed border-slate-800 hover:border-amber-500/60 hover:bg-slate-800/40'
                        }`}
                      >
                        {seat && seat.occupied ? (
                          <>
                            {/* Host Crown or VIP Badge */}
                            {seat.isHost && (
                              <div className="absolute -top-2 left-1/2 -translate-x-1/2 px-1.5 py-0.2 rounded-full bg-amber-500 text-slate-950 font-black text-[9px] flex items-center gap-0.5 shadow-sm">
                                <Crown className="w-2.5 h-2.5" />
                                Host
                              </div>
                            )}

                            {/* Dice Roll Badge if active */}
                            {diceScores[sIdx] !== undefined && (
                              <div className="absolute -top-2 -right-1 w-5 h-5 rounded-full bg-amber-400 text-slate-950 font-black text-xs flex items-center justify-center shadow-md border border-white">
                                {diceScores[sIdx]}
                              </div>
                            )}

                            {/* Avatar with speaking wave */}
                            <div className="relative mt-1">
                              <AvatarDisplay
                                avatar={seat.avatar}
                                size={38}
                                vipFrameId={
                                  isMe && currentUserVipState.isActive
                                    ? currentUserVipState.activeFrameId
                                    : seat.isHost
                                    ? 'vip_gold_dragon'
                                    : undefined
                                }
                              />
                              {seat.isSpeaking && (
                                <span className="absolute -inset-1 rounded-full border-2 border-emerald-400 animate-ping opacity-75 pointer-events-none" />
                              )}
                              <div
                                className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full flex items-center justify-center text-[9px] border border-slate-900 z-20 ${
                                  seat.isMuted
                                    ? 'bg-red-500 text-white'
                                    : 'bg-emerald-500 text-slate-950'
                                }`}
                              >
                                {seat.isMuted ? <MicOff className="w-2.5 h-2.5" /> : <Mic className="w-2.5 h-2.5" />}
                              </div>
                            </div>

                            <div className="mt-1.5 w-full">
                              <div className="flex items-center justify-center gap-1">
                                <span className="text-[11px] font-bold text-white truncate max-w-[65px]">
                                  {seat.userName}
                                </span>
                                {(seat.isHost || (isMe && currentUserVipState.isActive)) && (
                                  <VipBadge
                                    badgeId={isMe ? currentUserVipState.activeBadgeId : 'vip_crown'}
                                    size="sm"
                                    showText={false}
                                  />
                                )}
                              </div>
                              <span className="text-[9px] text-amber-300 font-semibold block truncate">
                                {seat.country.flag} Lv.{seat.level}
                              </span>
                            </div>
                          </>
                        ) : (
                          <div className="flex flex-col items-center justify-center text-slate-500 group-hover:text-amber-400 py-2">
                            <div className="w-8 h-8 rounded-full bg-slate-800/80 flex items-center justify-center group-hover:bg-amber-500/20 group-hover:text-amber-300 transition-all">
                              <Plus className="w-4 h-4" />
                            </div>
                            <span className="text-[10px] font-bold mt-1">সিট {sIdx + 1}</span>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* CENTER INTERACTIVE BOARD: DICE SHOWDOWN / LIVE MUSIC / STICKERS / AMBIENCE */}
              <div className="my-2.5 sm:my-3 p-3 rounded-3xl bg-slate-900/95 border border-slate-800 shadow-xl flex flex-col justify-between min-h-[160px]">
                {/* Center Sub-Tabs */}
                <div className="flex items-center justify-between border-b border-slate-800/80 pb-2 mb-2 gap-1 overflow-x-auto">
                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      onClick={() => setCenterTab('dice')}
                      className={`px-2.5 py-1 rounded-xl text-xs font-black flex items-center gap-1 transition-all cursor-pointer ${
                        centerTab === 'dice'
                          ? 'bg-amber-500 text-slate-950 shadow-sm'
                          : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      <Trophy className="w-3.5 h-3.5" />
                      <span>ডাইস লড়াই</span>
                    </button>

                    <button
                      onClick={() => setCenterTab('music')}
                      className={`px-2.5 py-1 rounded-xl text-xs font-black flex items-center gap-1 transition-all cursor-pointer ${
                        centerTab === 'music'
                          ? 'bg-amber-500 text-slate-950 shadow-sm'
                          : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      <Music className="w-3.5 h-3.5" />
                      <span>লাইভ গান ও অডিও</span>
                      {isPlayingMusic && (
                        <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                      )}
                    </button>

                    <button
                      onClick={() => setCenterTab('stickers')}
                      className={`px-2.5 py-1 rounded-xl text-xs font-black flex items-center gap-1 transition-all cursor-pointer ${
                        centerTab === 'stickers'
                          ? 'bg-amber-500 text-slate-950 shadow-sm'
                          : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>স্টিকার</span>
                    </button>

                    <button
                      onClick={() => setCenterTab('ambience')}
                      className={`px-2.5 py-1 rounded-xl text-xs font-black flex items-center gap-1 transition-all cursor-pointer ${
                        centerTab === 'ambience'
                          ? 'bg-amber-500 text-slate-950 shadow-sm'
                          : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      <Coffee className="w-3.5 h-3.5" />
                      <span>চা ও আবহ</span>
                    </button>
                  </div>

                  {lastDiceWinner && centerTab === 'dice' && (
                    <span className="text-[10px] sm:text-[11px] font-bold text-amber-300 hidden sm:flex items-center gap-1 shrink-0">
                      👑 চ্যাম্পিয়ন: {lastDiceWinner.name}
                    </span>
                  )}
                </div>

                {/* Tab 1 Content: 10-Dice Showdown Arena */}
                {centerTab === 'dice' && (
                  <div className="py-2 flex flex-col sm:flex-row items-center justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className="w-13 h-13 sm:w-14 sm:h-14 rounded-2xl bg-gradient-to-br from-amber-500 to-yellow-600 flex items-center justify-center text-slate-950 font-black text-2xl shadow-lg shadow-amber-500/20 border-2 border-yellow-300">
                        {isRollingDice ? (
                          <span className="animate-spin">🎲</span>
                        ) : mySeatIndex !== null && diceScores[mySeatIndex] ? (
                          diceScores[mySeatIndex]
                        ) : (
                          '৬'
                        )}
                      </div>
                      <div>
                        <h4 className="text-xs sm:text-sm font-black text-white">
                          ১০ সিটের লাইভ ডাইস শো-ডাউন
                        </h4>
                        <p className="text-[11px] text-slate-400 font-medium">
                          স্টেজে থাকা সব সদস্য একসাথে ডাইস রোল করে বিজয়ী নির্ধারণ করুন!
                        </p>
                      </div>
                    </div>

                    <button
                      onClick={handleRollDiceShowdown}
                      disabled={isRollingDice}
                      className="w-full sm:w-auto px-4 sm:px-5 py-2.5 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs shadow-md active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                    >
                      <Trophy className="w-4 h-4" />
                      <span>{isRollingDice ? 'রোল হচ্ছে...' : '🎲 ডাইস রোল শো-ডাউন'}</span>
                    </button>
                  </div>
                )}

                {/* Tab 2 Content: Live Music & Song File Player */}
                {centerTab === 'music' && (
                  <div className="py-1 space-y-3">
                    {/* Active Song Control Bar */}
                    <div className="p-3 rounded-2xl bg-slate-950/80 border border-amber-500/30 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-inner">
                      <div className="flex items-center gap-3 w-full sm:w-auto">
                        <div
                          className={`w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-500 to-rose-600 flex items-center justify-center text-white text-xl shadow-md border border-amber-300/40 shrink-0 ${
                            isPlayingMusic ? 'animate-spin' : ''
                          }`}
                          style={{ animationDuration: '6s' }}
                        >
                          <Disc className="w-6 h-6 text-amber-200" />
                        </div>
                        <div className="overflow-hidden">
                          <div className="flex items-center gap-2">
                            <h4 className="text-xs sm:text-sm font-black text-white truncate max-w-[200px]">
                              {currentSong?.title || 'গান নির্বাচন করুন'}
                            </h4>
                            <span className="text-[9px] px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 font-bold">
                              {currentSong?.isCustom ? 'নিজস্ব অডিও' : currentSong?.category || 'লাইভ গান'}
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-400 truncate">
                            {currentSong?.artist || 'শিল্পী'} • {formatTime(musicCurrentTime)} /{' '}
                            {formatTime(musicDuration)}
                          </p>
                        </div>
                      </div>

                      {/* Music Controls */}
                      <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
                        {/* Play/Pause Button */}
                        <button
                          onClick={handleToggleMusicPlay}
                          className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-xs flex items-center gap-1.5 shadow-md active:scale-95 cursor-pointer"
                        >
                          {isPlayingMusic ? (
                            <>
                              <Pause className="w-3.5 h-3.5 fill-slate-950" />
                              <span>বিরতি (Pause)</span>
                            </>
                          ) : (
                            <>
                              <Play className="w-3.5 h-3.5 fill-slate-950" />
                              <span>প্লে করুন</span>
                            </>
                          )}
                        </button>

                        {/* Upload Audio File Button */}
                        <button
                          onClick={() => fileInputRef.current?.click()}
                          className="px-3 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-black text-xs flex items-center gap-1.5 shadow-md active:scale-95 cursor-pointer"
                          title="নিজের অডিও গান ফাইল লাইভ চালান"
                        >
                          <Upload className="w-3.5 h-3.5" />
                          <span className="hidden sm:inline">গানের ফাইল আপলোড</span>
                          <span className="sm:hidden">ফাইল</span>
                        </button>
                      </div>
                    </div>

                    {/* Preset Songs Horizontal Bar */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                      {PRESET_ADDA_SONGS.slice(0, 4).map((s) => {
                        const isCurrent = currentSong?.id === s.id;
                        return (
                          <button
                            key={s.id}
                            onClick={() => handlePlayPresetSong(s)}
                            className={`p-2 rounded-xl border text-left transition-all text-xs cursor-pointer flex items-center gap-2 ${
                              isCurrent && isPlayingMusic
                                ? 'bg-amber-500/20 border-amber-400 text-amber-200'
                                : 'bg-slate-800/80 border-slate-700 hover:border-amber-400/40 text-slate-300'
                            }`}
                          >
                            <span className="text-base">{s.coverEmoji}</span>
                            <div className="overflow-hidden">
                              <span className="font-bold text-white block truncate text-[11px]">
                                {s.title}
                              </span>
                              <span className="text-[9px] text-slate-400 block truncate">
                                {s.artist}
                              </span>
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* Tab 3 Content: Adda Bengali Stickers Drawer */}
                {centerTab === 'stickers' && (
                  <div className="py-1 grid grid-cols-3 sm:grid-cols-6 gap-2">
                    {ADDA_STICKERS.map((stk) => (
                      <button
                        key={stk.id}
                        onClick={() => handleSendSticker(stk)}
                        className={`p-2 rounded-2xl bg-gradient-to-br ${stk.bgGradient} hover:scale-105 border border-white/30 text-white flex flex-col items-center justify-center transition-all shadow-md active:scale-95 cursor-pointer group`}
                        title={stk.title}
                      >
                        <span className="text-2xl sm:text-3xl group-hover:scale-125 transition-transform">
                          {stk.emoji}
                        </span>
                        <span className="text-[10px] font-black text-white mt-1 text-center truncate w-full drop-shadow">
                          {stk.title}
                        </span>
                        <span className="text-[8px] bg-black/30 px-1 rounded-full text-amber-200 font-bold mt-0.5">
                          {stk.badgeText}
                        </span>
                      </button>
                    ))}
                  </div>
                )}

                {/* Tab 4 Content: Ambience Tracks */}
                {centerTab === 'ambience' && (
                  <div className="py-1 grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {[
                      { id: 'tea', name: 'টিএসসি গরম চা ☕', icon: '☕', desc: 'চা এর কাপের আবহ' },
                      { id: 'acoustic', name: 'অ্যাকোস্টিক গিটার 🎸', icon: '🎸', desc: 'শান্ত সুর' },
                      { id: 'lofi', name: 'লো-ফাই চিল 🎧', icon: '🎧', desc: 'আড্ডার রিদম' },
                      { id: 'party', name: 'লুডো ধামাকা 🔥', icon: '🔥', desc: 'উৎসবের উল্লাস' },
                    ].map((item) => (
                      <button
                        key={item.id}
                        onClick={() => {
                          Sound.playChaiPour();
                        }}
                        className="p-2 rounded-2xl bg-slate-800/80 hover:bg-amber-500/20 border border-slate-700 hover:border-amber-400/40 text-left transition-all cursor-pointer"
                      >
                        <span className="text-sm block">{item.icon}</span>
                        <span className="text-xs font-bold text-white block mt-0.5">{item.name}</span>
                        <span className="text-[10px] text-slate-400 block">{item.desc}</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* BOTTOM 5 SEATS (Seats 5 to 9) */}
              <div className="space-y-1">
                <div className="flex items-center justify-between px-2 mb-1">
                  <span className="text-xs font-black text-amber-400 flex items-center gap-1.5">
                    <Users className="w-4 h-4 text-amber-400" />
                    গেস্ট ও মেম্বারস (সিট ৬ - ১০)
                  </span>
                  {mySeatIndex !== null && (
                    <button
                      onClick={handleLeaveSeat}
                      className="text-[10px] font-black text-rose-400 hover:text-rose-300 flex items-center gap-1 transition-colors cursor-pointer"
                    >
                      <LogOut className="w-3 h-3" />
                      <span>সিট ছাড়ুন (বোর্ড আউট)</span>
                    </button>
                  )}
                </div>

                <div className="grid grid-cols-5 gap-2 sm:gap-3">
                  {activeRoom.seats.slice(5, 10).map((seat, idx) => {
                    const sIdx = idx + 5;
                    const isMe = mySeatIndex === sIdx;
                    return (
                      <div
                        key={sIdx}
                        onClick={() => {
                          if (!seat || !seat.occupied) {
                            handleTakeSeat(sIdx);
                          } else {
                            // Open user action sheet
                            setSelectedUserAction({
                              seatIndex: sIdx,
                              userId: seat.userId,
                              userName: seat.userName,
                              avatar: seat.avatar,
                              isHost: seat.isHost,
                              isMuted: seat.isMuted,
                              countryFlag: seat.country.flag,
                            });
                          }
                        }}
                        className={`relative rounded-2xl p-2 sm:p-2.5 flex flex-col items-center justify-center transition-all cursor-pointer group text-center min-h-[95px] sm:min-h-[110px] ${
                          seat && seat.occupied
                            ? seat.isSpeaking
                              ? 'bg-slate-900/90 border-2 border-emerald-400 shadow-lg shadow-emerald-500/20'
                              : 'bg-slate-900/70 border border-slate-700 hover:border-amber-400/60'
                            : 'bg-slate-900/30 border-2 border-dashed border-slate-800 hover:border-amber-500/60 hover:bg-slate-800/40'
                        }`}
                      >
                        {seat && seat.occupied ? (
                          <>
                            {/* Dice Roll Badge */}
                            {diceScores[sIdx] !== undefined && (
                              <div className="absolute -top-2 -right-1 w-5 h-5 rounded-full bg-amber-400 text-slate-950 font-black text-xs flex items-center justify-center shadow-md border border-white">
                                {diceScores[sIdx]}
                              </div>
                            )}

                            {/* Avatar */}
                            <div className="relative mt-1">
                              <AvatarDisplay
                                avatar={seat.avatar}
                                size={38}
                                vipFrameId={
                                  isMe && currentUserVipState.isActive
                                    ? currentUserVipState.activeFrameId
                                    : undefined
                                }
                              />
                              {seat.isSpeaking && (
                                <span className="absolute -inset-1 rounded-full border-2 border-emerald-400 animate-ping opacity-75 pointer-events-none" />
                              )}
                              <div
                                className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full flex items-center justify-center text-[9px] border border-slate-900 z-20 ${
                                  seat.isMuted
                                    ? 'bg-red-500 text-white'
                                    : 'bg-emerald-500 text-slate-950'
                                }`}
                              >
                                {seat.isMuted ? <MicOff className="w-2.5 h-2.5" /> : <Mic className="w-2.5 h-2.5" />}
                              </div>
                            </div>

                            <div className="mt-1.5 w-full">
                              <div className="flex items-center justify-center gap-1">
                                <span className="text-[11px] font-bold text-white truncate max-w-[65px]">
                                  {seat.userName}
                                </span>
                                {isMe && currentUserVipState.isActive && (
                                  <VipBadge
                                    badgeId={currentUserVipState.activeBadgeId}
                                    size="sm"
                                    showText={false}
                                  />
                                )}
                              </div>
                              <span className="text-[9px] text-amber-300 font-semibold block truncate">
                                {seat.country.flag} Lv.{seat.level}
                              </span>
                            </div>
                          </>
                        ) : (
                          <div className="flex flex-col items-center justify-center text-slate-500 group-hover:text-amber-400 py-2">
                            <div className="w-8 h-8 rounded-full bg-slate-800/80 flex items-center justify-center group-hover:bg-amber-500/20 group-hover:text-amber-300 transition-all">
                              <Plus className="w-4 h-4" />
                            </div>
                            <span className="text-[10px] font-bold mt-1">সিট {sIdx + 1}</span>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* STAGE CONTROLS BAR: MIC MUTE/UNMUTE, SOUNDBOARD, COINS */}
              <div className="mt-3 pt-3 border-t border-slate-800 flex items-center justify-between gap-2">
                {mySeatIndex !== null ? (
                  <div className="flex items-center gap-2">
                    <button
                      onClick={handleToggleMyMic}
                      className={`px-4 py-2.5 rounded-2xl font-black text-xs flex items-center gap-2 transition-all shadow-md cursor-pointer ${
                        isMyMicMuted
                          ? 'bg-red-600 hover:bg-red-500 text-white'
                          : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 animate-pulse'
                      }`}
                    >
                      {isMyMicMuted ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                      <span>{isMyMicMuted ? 'আমার মাইক বন্ধ (Muted)' : 'আমার মাইক চালু (Live)'}</span>
                    </button>

                    <button
                      onClick={handleLeaveSeat}
                      className="px-3 py-2.5 rounded-2xl bg-rose-900/60 hover:bg-rose-800 text-rose-200 font-black text-xs flex items-center gap-1.5 border border-rose-500/40 cursor-pointer"
                      title="বোর্ড থেকে নেমে অডিয়েন্সে যান"
                    >
                      <LogOut className="w-3.5 h-3.5" />
                      <span className="hidden sm:inline">বোর্ড আউট</span>
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => {
                      const emptyIdx = activeRoom.seats.findIndex((s) => !s || !s.occupied);
                      if (emptyIdx !== -1) {
                        handleTakeSeat(emptyIdx);
                      } else {
                        alert('সবগুলো ১০টি সিট পূর্ণ! একটু অপেক্ষা করুন।');
                      }
                    }}
                    className="px-4 py-2.5 rounded-2xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs flex items-center gap-2 shadow-md transition-all cursor-pointer"
                  >
                    <Mic className="w-4 h-4" />
                    <span>স্টেজে সিট নিন (১০ জন)</span>
                  </button>
                )}

                <div className="flex items-center gap-2">
                  {/* Bengali Voice Soundboard Button */}
                  <button
                    onClick={() => {
                      Sound.playClick();
                      setIsSoundboardOpen(!isSoundboardOpen);
                    }}
                    className="px-3 py-2.5 rounded-2xl bg-purple-600 hover:bg-purple-500 text-white font-black text-xs flex items-center gap-1.5 shadow-md transition-all cursor-pointer"
                  >
                    <span>🎙️</span>
                    <span className="hidden sm:inline">বাংলা ডায়লগ</span>
                  </button>

                  {/* Coin Balance Pill */}
                  <div className="px-3 py-2 rounded-2xl bg-slate-900 border border-amber-500/40 text-amber-300 text-xs font-black flex items-center gap-1.5 shadow-inner">
                    <span>🪙</span>
                    <span>{userCoins.toLocaleString('bn-BD')}</span>
                  </div>
                </div>
              </div>

              {/* Soundboard Popover Drawer */}
              {isSoundboardOpen && (
                <div className="mt-2 p-3 rounded-2xl bg-slate-900 border border-purple-500/50 shadow-2xl animate-fade-in">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-black text-purple-300">
                      🔊 বাংলা ভয়েস সাউন্ডবোর্ড (ক্লিক করলেই লাইভ বেজে উঠবে)
                    </span>
                    <button
                      onClick={() => setIsSoundboardOpen(false)}
                      className="text-slate-400 hover:text-white text-xs cursor-pointer"
                    >
                      ✕
                    </button>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                    {ADDA_SOUNDBOARD.map((clip) => (
                      <button
                        key={clip.id}
                        onClick={() => handleSendSoundboard(clip)}
                        className="p-2 rounded-xl bg-purple-950/60 hover:bg-purple-800/80 border border-purple-700/50 text-left transition-all text-xs font-bold text-white flex items-center gap-1.5 active:scale-95 cursor-pointer"
                      >
                        <span>{clip.emoji}</span>
                        <span className="truncate">{clip.title}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Right Column: Live Chat Feed, Quick Emojis & Gifts */}
            <div className="lg:col-span-4 p-3 sm:p-4 flex flex-col justify-between h-full bg-slate-950/80 border-t lg:border-t-0 border-slate-800">
              {/* Chat Stream Header */}
              <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800">
                <span className="text-xs font-black text-amber-400 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5" />
                  লাইভ আড্ডা চ্যাট ও ইন্টারঅ্যাকশন
                </span>
                <span className="text-[10px] font-bold text-slate-400">
                  {activeRoom.spectatorCount} জন দর্শক
                </span>
              </div>

              {/* Chat Messages List (Filtered by Blocked Users) */}
              <div
                ref={chatScrollRef}
                className="flex-1 overflow-y-auto space-y-2 pr-1 min-h-[160px] max-h-[300px] sm:max-h-[360px]"
              >
                {visibleChatMessages.map((msg) => {
                  const isLocalUserMsg = msg.userId === currentUser.id;
                  const isVipMsg =
                    (isLocalUserMsg && currentUserVipState.isActive) || msg.isHostNotice;
                  const activeBubbleDef =
                    VIP_CHAT_BUBBLES.find((b) => b.id === currentUserVipState.activeChatBubbleId) ||
                    VIP_CHAT_BUBBLES[0];

                  return (
                    <div
                      key={msg.id}
                      className={`p-2.5 rounded-2xl text-xs transition-all ${
                        msg.isSticker
                          ? 'bg-gradient-to-r from-purple-950/80 via-slate-900 to-amber-950/80 border border-purple-500/40 text-white'
                          : msg.isGift
                          ? 'bg-gradient-to-r from-amber-950/80 to-purple-950/80 border border-amber-500/40 text-amber-200'
                          : isLocalUserMsg && currentUserVipState.isActive
                          ? `${activeBubbleDef.themeStyle.bubbleBg} ${activeBubbleDef.themeStyle.bubbleBorder} ${activeBubbleDef.themeStyle.accentGlow} border text-white`
                          : msg.isHostNotice
                          ? 'bg-gradient-to-r from-amber-950/60 via-slate-900 to-indigo-950 border border-amber-400/50 text-amber-200'
                          : 'bg-slate-900/60 border border-slate-800 text-slate-200'
                      }`}
                    >
                      <div className="flex items-center gap-1.5 mb-0.5">
                        <span className="text-[11px]">{msg.userCountryFlag}</span>
                        <span className="font-black text-amber-400 text-[11px] truncate">
                          {msg.userName}
                        </span>
                        {isVipMsg && (
                          <VipBadge
                            badgeId={isLocalUserMsg ? currentUserVipState.activeBadgeId : 'vip_crown'}
                            size="sm"
                            showText={false}
                          />
                        )}
                        {msg.userLevel && (
                          <span className="text-[9px] px-1 bg-amber-500/20 text-amber-300 rounded font-mono">
                            Lv.{msg.userLevel}
                          </span>
                        )}
                      </div>

                      {/* If message is a sticker card */}
                      {msg.isSticker && msg.stickerData ? (
                        <div className="mt-1 flex items-center gap-2 p-2 rounded-xl bg-black/40 border border-white/10">
                          <span className="text-3xl">{msg.stickerData.emoji}</span>
                          <div>
                            <p className="text-xs font-black text-white">{msg.text}</p>
                            <span className="text-[9px] text-amber-300 font-bold">
                              {msg.stickerData.badgeText}
                            </span>
                          </div>
                        </div>
                      ) : (
                        <p className="text-xs font-medium leading-snug">{msg.text}</p>
                      )}
                    </div>
                  );
                })}
              </div>

              {/* Quick Reaction Emojis Bar */}
              <div className="mt-2 pt-2 border-t border-slate-800/80">
                <div className="flex items-center gap-1.5 overflow-x-auto pb-1.5 scrollbar-none">
                  {ADDA_EMOJIS.map((emoji, eIdx) => (
                    <button
                      key={eIdx}
                      onClick={() => handleSendEmojiReaction(emoji)}
                      className="p-1 rounded-lg bg-slate-900 hover:bg-amber-500/20 border border-slate-800 hover:border-amber-400 text-base shrink-0 active:scale-125 transition-transform cursor-pointer"
                      title="ইমোজি রিঅ্যাকশন দিন"
                    >
                      {emoji}
                    </button>
                  ))}
                </div>
              </div>

              {/* 7 Animated Gifts Bar */}
              <div className="mt-1 pt-1.5 border-t border-slate-800">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-[11px] font-black text-amber-300 flex items-center gap-1">
                    <Gift className="w-3 h-3 text-amber-400" />
                    গিফট বৃষ্টি পাঠান
                  </span>
                  <span className="text-[10px] text-slate-400">ক্লিক করলেই উড়বে 🎁</span>
                </div>

                <div className="grid grid-cols-7 gap-1">
                  {ADDA_GIFTS.map((g) => (
                    <button
                      key={g.id}
                      onClick={() => handleSendGift(g)}
                      className="p-1 rounded-xl bg-slate-900 hover:bg-amber-500/20 border border-slate-800 hover:border-amber-400/50 flex flex-col items-center justify-center transition-all group active:scale-90 cursor-pointer"
                      title={`${g.bengaliName} (${g.coinPrice} কয়েন)`}
                    >
                      <span className="text-base sm:text-lg group-hover:scale-125 transition-transform">
                        {g.icon}
                      </span>
                      <span className="text-[9px] font-black text-amber-400 mt-0.5">{g.coinPrice}🪙</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Chat Input Form */}
              <form onSubmit={handleSendChat} className="mt-2.5 flex items-center gap-1.5">
                <input
                  type="text"
                  placeholder="আড্ডায় মেসেজ লিখুন..."
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  className="flex-1 px-3.5 py-2 bg-slate-900 border border-slate-700 focus:border-amber-400 rounded-2xl text-xs text-white placeholder:text-slate-500 focus:outline-none"
                />
                <button
                  type="submit"
                  disabled={!chatInput.trim()}
                  className="p-2 rounded-2xl bg-amber-500 hover:bg-amber-400 text-slate-950 transition-all active:scale-95 disabled:opacity-40 cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                </button>
              </form>
            </div>
          </div>
        )}
      </div>

      {/* MODAL 1: BLOCK LIST MODAL */}
      {isBlockListModalOpen && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fade-in">
          <div className="w-full max-w-md bg-slate-900 rounded-3xl border-2 border-rose-500/50 shadow-2xl p-5 text-white flex flex-col">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-rose-500/20 text-rose-400 flex items-center justify-center">
                  <Ban className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-white">আড্ডা ব্লক লিস্ট (Block List)</h3>
                  <p className="text-[10px] text-slate-400">
                    ব্লক করা ইউজারদের মেসেজ এবং ভয়েস আপনার আড্ডায় ফিল্টার থাকবে
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsBlockListModalOpen(false)}
                className="w-7 h-7 rounded-xl bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-300 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* List */}
            <div className="flex-1 overflow-y-auto max-h-[300px] space-y-2 pr-1">
              {blockedUsers.length === 0 ? (
                <div className="py-8 text-center text-slate-500 text-xs">
                  <UserX className="w-8 h-8 mx-auto mb-2 opacity-40" />
                  <p>আপনার কোনো ব্লক করা ইউজার নেই।</p>
                </div>
              ) : (
                blockedUsers.map((bu) => (
                  <div
                    key={bu.userId}
                    className="p-3 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-2"
                  >
                    <div>
                      <h4 className="text-xs font-black text-white">{bu.userName}</h4>
                      <p className="text-[10px] text-slate-400">
                        তারিখ: {new Date(bu.blockedAt).toLocaleDateString('bn-BD')}
                      </p>
                    </div>

                    <button
                      onClick={() => handleUnblockUserAction(bu.userId)}
                      className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-slate-950 text-[11px] font-black shadow-md cursor-pointer transition-all active:scale-95"
                    >
                      আনব্লক করুন
                    </button>
                  </div>
                ))
              )}
            </div>

            <div className="mt-4 pt-3 border-t border-slate-800 flex justify-end">
              <button
                onClick={() => setIsBlockListModalOpen(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold cursor-pointer"
              >
                ঠিক আছে
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 2: USER PROFILE & SEAT ACTION SHEET (Mute, Kick Out, Block, Send Gift) */}
      {selectedUserAction && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fade-in">
          <div className="w-full max-w-sm bg-slate-900 rounded-3xl border-2 border-amber-500/50 shadow-2xl p-5 text-white flex flex-col items-center text-center">
            <button
              onClick={() => setSelectedUserAction(null)}
              className="self-end w-7 h-7 rounded-xl bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-300 cursor-pointer mb-1"
            >
              <X className="w-4 h-4" />
            </button>

            {/* Avatar & Info */}
            <div className="relative mb-2">
              <AvatarDisplay avatar={selectedUserAction.avatar} size={56} />
              {selectedUserAction.isHost && (
                <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 px-2 py-0.5 rounded-full bg-amber-500 text-slate-950 font-black text-[9px]">
                  Host
                </div>
              )}
            </div>

            <h3 className="text-sm font-black text-white flex items-center gap-1.5 mt-1">
              <span>{selectedUserAction.userName}</span>
              {selectedUserAction.countryFlag && <span>{selectedUserAction.countryFlag}</span>}
            </h3>
            <p className="text-[11px] text-amber-300 font-medium">
              {selectedUserAction.seatIndex !== undefined
                ? `সিট #${selectedUserAction.seatIndex + 1} মেম্বার`
                : 'আড্ডা মেম্বার'}
            </p>

            {/* Action Buttons Grid */}
            <div className="w-full mt-4 space-y-2">
              {/* Send Gift */}
              <button
                onClick={() => {
                  if (selectedUserAction.seatIndex !== undefined) {
                    setSelectedSeatForGift(selectedUserAction.seatIndex);
                  }
                  setSelectedUserAction(null);
                  handleSendGift(ADDA_GIFTS[0]); // Send rose
                }}
                className="w-full py-2.5 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-xs flex items-center justify-center gap-2 shadow-md cursor-pointer transition-all active:scale-95"
              >
                <Gift className="w-4 h-4" />
                <span>গোলাপ গিফট পাঠান (১০ 🪙)</span>
              </button>

              {/* Mute/Unmute Mic on Seat */}
              {selectedUserAction.seatIndex !== undefined && (
                <button
                  onClick={() => handleToggleSeatMute(selectedUserAction.seatIndex!)}
                  className={`w-full py-2.5 rounded-2xl font-black text-xs flex items-center justify-center gap-2 shadow-md cursor-pointer transition-all active:scale-95 ${
                    selectedUserAction.isMuted
                      ? 'bg-emerald-600 hover:bg-emerald-500 text-slate-950'
                      : 'bg-slate-800 hover:bg-slate-700 text-amber-200 border border-slate-700'
                  }`}
                >
                  {selectedUserAction.isMuted ? (
                    <>
                      <Mic className="w-4 h-4" />
                      <span>মাইক আনমিউট করুন</span>
                    </>
                  ) : (
                    <>
                      <MicOff className="w-4 h-4" />
                      <span>মাইক মিউট করুন</span>
                    </>
                  )}
                </button>
              )}

              {/* Kick Out / Board Out */}
              {selectedUserAction.seatIndex !== undefined && (
                <button
                  onClick={() => handleKickOutFromSeat(selectedUserAction.seatIndex!)}
                  className="w-full py-2.5 rounded-2xl bg-rose-900/80 hover:bg-rose-800 text-rose-100 border border-rose-500/40 font-black text-xs flex items-center justify-center gap-2 shadow-md cursor-pointer transition-all active:scale-95"
                >
                  <LogOut className="w-4 h-4" />
                  <span>🚪 সিট থেকে বোর্ড আউট করুন</span>
                </button>
              )}

              {/* Block User */}
              <button
                onClick={() =>
                  handleBlockUserAction(selectedUserAction.userId, selectedUserAction.userName)
                }
                className="w-full py-2.5 rounded-2xl bg-slate-950 hover:bg-slate-900 text-rose-400 border border-rose-600/40 font-black text-xs flex items-center justify-center gap-2 shadow-md cursor-pointer transition-all active:scale-95"
              >
                <Ban className="w-4 h-4" />
                <span>🚫 ইউজারকে ব্লক লিস্টে যোগ করুন</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
