import React, { useState } from 'react';
import {
  X,
  Crown,
  Sparkles,
  Diamond,
  Flame,
  CheckCircle2,
  Lock,
  ChevronRight,
  Zap,
  ShieldCheck,
  Award,
  MessageSquare,
  Gift,
  Check,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import {
  AvatarConfig,
  UserProfile,
  VipBadgeId,
  VipChatBubbleId,
  VipFrameId,
  VipPackage,
  VipSubscriptionState,
} from '../types';
import {
  VIP_PACKAGES,
  VIP_FRAMES,
  VIP_CHAT_BUBBLES,
  VIP_BADGES,
} from '../utils/vipConstants';
import {
  purchaseVipPackage,
  equipVipFrame,
  equipVipChatBubble,
  equipVipBadge,
  getVipRemainingDays,
} from '../utils/vipService';
import { AvatarDisplay } from './AvatarDisplay';
import { VipBadge } from './VipBadge';
import { Sound } from '../utils/soundEffects';

interface VipSubscriptionModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile;
  userAvatar: AvatarConfig;
  userDiamonds: number;
  vipState: VipSubscriptionState;
  onUpdateVipState: (newState: VipSubscriptionState) => void;
  onDeductDiamonds: (amount: number) => void;
  onOpenStoreModal?: () => void;
  onOpenRoadmapModal?: () => void;
}

export const VipSubscriptionModal: React.FC<VipSubscriptionModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  userAvatar,
  userDiamonds,
  vipState,
  onUpdateVipState,
  onDeductDiamonds,
  onOpenStoreModal,
  onOpenRoadmapModal,
}) => {
  const [activeTab, setActiveTab] = useState<'packages' | 'frames' | 'bubbles' | 'badges'>('packages');
  const [previewFrame, setPreviewFrame] = useState<VipFrameId>(vipState.activeFrameId || 'vip_gold_dragon');
  const [previewBubble, setPreviewBubble] = useState<VipChatBubbleId>(vipState.activeChatBubbleId || 'vip_gold_royal');
  const [previewBadge, setPreviewBadge] = useState<VipBadgeId>(vipState.activeBadgeId || 'vip_crown');
  const [purchaseStatus, setPurchaseStatus] = useState<{ message: string; isError?: boolean } | null>(null);

  if (!isOpen) return null;

  const remainingDays = getVipRemainingDays(vipState);
  const isVip = vipState.isActive;

  // Handle purchasing VIP package with Diamonds
  const handlePurchase = (pkg: VipPackage) => {
    Sound.playClick();

    if (userDiamonds < pkg.diamondPrice) {
      setPurchaseStatus({
        message: `পর্যাপ্ত ডায়মন্ড নেই! আপনার দরকার ${pkg.diamondPrice} 💎 কিন্তু আছে ${userDiamonds} 💎। লেভেল আপ বা স্টোর থেকে ডায়মন্ড সংগ্রহ করুন।`,
        isError: true,
      });
      return;
    }

    const result = purchaseVipPackage(pkg, vipState, userDiamonds, currentUser);
    if (result.success) {
      onDeductDiamonds(pkg.diamondPrice);
      onUpdateVipState(result.newState);
      setPreviewFrame(result.newState.activeFrameId);
      setPreviewBubble(result.newState.activeChatBubbleId);
      setPreviewBadge(result.newState.activeBadgeId);

      Sound.playWin();

      // Confetti celebration
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#fbbf24', '#f59e0b', '#38bdf8', '#ef4444', '#ec4899'],
      });

      setPurchaseStatus({
        message: result.messageBn,
        isError: false,
      });
    } else {
      setPurchaseStatus({
        message: result.messageBn,
        isError: true,
      });
    }
  };

  // Equip VIP Frame
  const handleEquipFrame = (frameId: VipFrameId) => {
    Sound.playClick();
    const updated = equipVipFrame(frameId, vipState, currentUser);
    onUpdateVipState(updated);
    setPreviewFrame(frameId);
  };

  // Equip VIP Chat Bubble
  const handleEquipBubble = (bubbleId: VipChatBubbleId) => {
    Sound.playClick();
    const updated = equipVipChatBubble(bubbleId, vipState, currentUser);
    onUpdateVipState(updated);
    setPreviewBubble(bubbleId);
  };

  // Equip VIP Badge
  const handleEquipBadge = (badgeId: VipBadgeId) => {
    Sound.playClick();
    const updated = equipVipBadge(badgeId, vipState, currentUser);
    onUpdateVipState(updated);
    setPreviewBadge(badgeId);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in overflow-y-auto">
      <div className="relative w-full max-w-3xl bg-gradient-to-b from-slate-900 via-slate-900 to-indigo-950 text-white rounded-3xl shadow-2xl border-2 border-amber-500/50 overflow-hidden my-auto max-h-[92vh] flex flex-col">
        {/* Top Header Banner */}
        <div className="relative p-4 sm:p-5 bg-gradient-to-r from-amber-600 via-yellow-500 to-amber-700 text-slate-950 flex items-center justify-between shadow-lg border-b-2 border-amber-400">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-2xl bg-slate-950 text-amber-300 flex items-center justify-center shadow-md border border-amber-300">
              <Crown className="w-6 h-6 animate-bounce" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-xl font-black tracking-tight leading-tight">
                  জয় লুডু VIP সাবস্ক্রিপশন
                </h2>
                <span className="bg-slate-950 text-amber-300 text-[10px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider">
                  ELITE
                </span>
              </div>
              <p className="text-[11px] sm:text-xs text-slate-950/90 font-bold mt-0.5">
                ডায়মন্ড দিয়ে আনলক করুন স্পেশাল প্রোফাইল ফ্রেম, লাক্সারি চ্যাট বাবল ও এক্সক্লুসিভ VIP ব্যাজ!
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Live Diamond Balance */}
            <div
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-2xl bg-slate-950 text-cyan-300 font-black text-xs sm:text-sm border border-cyan-400/50 shadow-inner cursor-pointer"
              onClick={() => {
                if (onOpenRoadmapModal) onOpenRoadmapModal();
              }}
              title="আপনার বর্তমান ডায়মন্ড ব্যালেন্স"
            >
              <Diamond className="w-4 h-4 fill-cyan-400 text-cyan-300 animate-pulse" />
              <span>{userDiamonds.toLocaleString('bn-BD')}</span>
              <span className="text-[10px] text-cyan-400/80 font-bold">💎</span>
            </div>

            <button
              onClick={() => {
                Sound.playClick();
                onClose();
              }}
              className="p-1.5 rounded-full bg-slate-950/20 hover:bg-slate-950/40 text-slate-950 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* VIP Status Summary Bar */}
        <div className="bg-slate-900/90 px-4 sm:px-6 py-2.5 border-b border-white/10 flex flex-wrap items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-2">
            <span className="text-slate-400 font-medium">স্ট্যাটাস:</span>
            {isVip ? (
              <div className="flex items-center gap-1.5 font-black text-amber-300 bg-amber-500/10 px-2.5 py-1 rounded-xl border border-amber-500/30">
                <Crown className="w-3.5 h-3.5 text-amber-400" />
                <span>ভিআইপি সক্রিয়</span>
                <span className="text-[10px] text-amber-200/80">
                  ({remainingDays === 'lifetime' ? 'আজীবন মেয়াদ 👑' : `${remainingDays} দিন বাকি`})
                </span>
              </div>
            ) : (
              <span className="font-bold text-slate-400 bg-slate-800 px-2.5 py-0.5 rounded-xl">
                কোনো ভিআইপি প্যাক সক্রিয় নেই
              </span>
            )}
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[11px] text-cyan-300 font-bold">
              ডায়মন্ড দরকার?
            </span>
            <button
              onClick={() => {
                Sound.playClick();
                if (onOpenRoadmapModal) onOpenRoadmapModal();
              }}
              className="text-[11px] font-black text-amber-400 hover:text-amber-300 underline cursor-pointer"
            >
              লেভেল রোডম্যাপ দেখুন
            </button>
            <span className="text-slate-600">•</span>
            <button
              onClick={() => {
                Sound.playClick();
                if (onOpenStoreModal) onOpenStoreModal();
              }}
              className="text-[11px] font-black text-amber-400 hover:text-amber-300 underline cursor-pointer"
            >
              কয়েন ও ডায়মন্ড শপ
            </button>
          </div>
        </div>

        {/* Live Preview Studio Box */}
        <div className="p-3 sm:p-4 bg-gradient-to-r from-slate-950 via-indigo-950/80 to-slate-950 border-b border-indigo-500/20">
          <div className="max-w-xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 p-3.5 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md">
            {/* Left: Avatar with VIP Frame & Badge */}
            <div className="flex items-center gap-3">
              <div className="relative p-1">
                <AvatarDisplay
                  avatar={userAvatar}
                  size={58}
                  vipFrameId={previewFrame}
                />
              </div>
              <div className="flex flex-col items-start gap-1">
                <div className="flex items-center gap-1.5 flex-wrap">
                  <span className="text-sm font-black text-white">
                    {currentUser?.name || 'খেলোয়াড়'}
                  </span>
                  <VipBadge badgeId={previewBadge} size="md" />
                </div>
                <span className="text-[10px] text-amber-300/90 font-bold">
                  {VIP_FRAMES.find((f) => f.id === previewFrame)?.nameBn || 'স্ট্যান্ডার্ড'} ফ্রেম
                </span>
              </div>
            </div>

            {/* Right: Live Sample Chat Bubble Preview */}
            <div className="flex-1 w-full sm:max-w-xs">
              <div className="text-[10px] text-slate-400 font-bold mb-1">
                চ্যাটে আপনার মেসেজ যেমন দেখাবে:
              </div>
              {(() => {
                const bubbleDef = VIP_CHAT_BUBBLES.find((b) => b.id === previewBubble) || VIP_CHAT_BUBBLES[0];
                return (
                  <div
                    className={`p-2.5 rounded-2xl border ${bubbleDef.themeStyle.bubbleBg} ${bubbleDef.themeStyle.bubbleBorder} ${bubbleDef.themeStyle.accentGlow} text-xs transition-all`}
                  >
                    <div className="flex items-center justify-between gap-1 mb-0.5">
                      <span className={`text-[11px] ${bubbleDef.themeStyle.senderColor} flex items-center gap-1`}>
                        <span>{bubbleDef.themeStyle.badgeIcon}</span>
                        <span>{currentUser?.name || 'আপনি'}</span>
                      </span>
                      <span className="text-[9px] opacity-75">এইমাত্র</span>
                    </div>
                    <p className={`font-semibold ${bubbleDef.themeStyle.textColor} leading-tight`}>
                      "চলো সবাই একসাথে লুডু লাইভে ছক্কা মারি! 🎲🔥"
                    </p>
                  </div>
                );
              })()}
            </div>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center border-b border-white/10 px-4 sm:px-6 bg-slate-900/60 overflow-x-auto">
          <button
            onClick={() => {
              Sound.playClick();
              setActiveTab('packages');
            }}
            className={`flex items-center gap-2 py-3 px-4 text-xs sm:text-sm font-black border-b-2 transition-all cursor-pointer shrink-0 ${
              activeTab === 'packages'
                ? 'border-amber-400 text-amber-300 bg-white/5'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <Diamond className="w-4 h-4 text-cyan-400" />
            <span>১. VIP পাস কিনুন</span>
          </button>

          <button
            onClick={() => {
              Sound.playClick();
              setActiveTab('frames');
            }}
            className={`flex items-center gap-2 py-3 px-4 text-xs sm:text-sm font-black border-b-2 transition-all cursor-pointer shrink-0 ${
              activeTab === 'frames'
                ? 'border-amber-400 text-amber-300 bg-white/5'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>২. স্পেশাল প্রোফাইল ফ্রেম</span>
          </button>

          <button
            onClick={() => {
              Sound.playClick();
              setActiveTab('bubbles');
            }}
            className={`flex items-center gap-2 py-3 px-4 text-xs sm:text-sm font-black border-b-2 transition-all cursor-pointer shrink-0 ${
              activeTab === 'bubbles'
                ? 'border-amber-400 text-amber-300 bg-white/5'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <MessageSquare className="w-4 h-4 text-purple-400" />
            <span>৩. এক্সক্লুসিভ চ্যাট বাবল</span>
          </button>

          <button
            onClick={() => {
              Sound.playClick();
              setActiveTab('badges');
            }}
            className={`flex items-center gap-2 py-3 px-4 text-xs sm:text-sm font-black border-b-2 transition-all cursor-pointer shrink-0 ${
              activeTab === 'badges'
                ? 'border-amber-400 text-amber-300 bg-white/5'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <Crown className="w-4 h-4 text-yellow-400" />
            <span>৪. VIP ব্যাজ ও সুবিধা</span>
          </button>
        </div>

        {/* Purchase Notification Toast */}
        {purchaseStatus && (
          <div
            className={`mx-4 sm:mx-6 mt-3 p-3 rounded-2xl text-xs font-black flex items-center justify-between gap-2 shadow-md animate-fade-in ${
              purchaseStatus.isError
                ? 'bg-rose-950/80 border border-rose-500 text-rose-200'
                : 'bg-emerald-950/80 border border-emerald-500 text-emerald-200'
            }`}
          >
            <div className="flex items-center gap-2">
              {purchaseStatus.isError ? (
                <Lock className="w-4 h-4 text-rose-400 shrink-0" />
              ) : (
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              )}
              <span>{purchaseStatus.message}</span>
            </div>
            <button
              onClick={() => setPurchaseStatus(null)}
              className="text-xs opacity-75 hover:opacity-100 p-1"
            >
              ✕
            </button>
          </div>
        )}

        {/* Tab Body */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1">
          {/* TAB 1: VIP Packages */}
          {activeTab === 'packages' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {VIP_PACKAGES.map((pkg) => {
                const canAfford = userDiamonds >= pkg.diamondPrice;
                const isCurrentActive = isVip && vipState.passType === pkg.id;

                return (
                  <div
                    key={pkg.id}
                    className={`relative p-4 sm:p-5 rounded-3xl flex flex-col justify-between transition-all ${
                      pkg.isPopular
                        ? 'bg-gradient-to-b from-amber-950/60 via-slate-900 to-indigo-950 border-2 border-amber-400 shadow-xl shadow-amber-950/30'
                        : pkg.isBestValue
                        ? 'bg-gradient-to-b from-cyan-950/60 via-slate-900 to-indigo-950 border-2 border-cyan-400 shadow-xl shadow-cyan-950/30'
                        : 'bg-slate-900/80 border border-white/10 hover:border-white/20'
                    }`}
                  >
                    {/* Badge Pill */}
                    <div className="flex items-center justify-between mb-2">
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-amber-400 text-slate-950">
                        {pkg.badgeBn}
                      </span>
                      <span className="text-xs font-extrabold text-slate-300">
                        {pkg.durationLabelBn}
                      </span>
                    </div>

                    <div>
                      <h3 className="text-base sm:text-lg font-black text-white flex items-center gap-2">
                        {pkg.nameBn}
                      </h3>

                      {/* Diamond Price */}
                      <div className="flex items-baseline gap-2 my-2.5">
                        <div className="flex items-center gap-1.5 px-3 py-1 rounded-xl bg-cyan-950/80 border border-cyan-500/40 text-cyan-300 font-black text-lg sm:text-xl">
                          <Diamond className="w-5 h-5 fill-cyan-400 text-cyan-300" />
                          <span>{pkg.diamondPrice}</span>
                          <span className="text-xs text-cyan-400">ডায়মন্ড</span>
                        </div>
                        <span className="text-xs text-slate-400 line-through">
                          {pkg.originalDiamondPrice} 💎
                        </span>
                      </div>

                      {/* Perks list */}
                      <div className="space-y-1.5 my-3 pt-2 border-t border-white/10 text-xs text-slate-300">
                        <div className="flex items-center gap-2 font-black text-amber-300">
                          <Zap className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                          <span>+{pkg.xpBoosterPercent}% এক্সট্রা XP ও লেভেল বোনাস</span>
                        </div>
                        {pkg.perksBn.map((perk, idx) => (
                          <div key={idx} className="flex items-start gap-2">
                            <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                            <span className="leading-snug">{perk}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Action Button */}
                    <div className="mt-4 pt-3 border-t border-white/10">
                      <button
                        onClick={() => handlePurchase(pkg)}
                        className={`w-full py-2.5 px-4 rounded-2xl font-black text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg transition-all active:scale-98 cursor-pointer ${
                          canAfford
                            ? pkg.isPopular
                              ? 'bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 hover:from-amber-300 hover:to-yellow-300 text-slate-950 border-b-2 border-amber-700'
                              : 'bg-gradient-to-r from-cyan-400 via-sky-400 to-blue-500 hover:from-cyan-300 hover:to-sky-300 text-slate-950 border-b-2 border-cyan-700'
                            : 'bg-slate-800 text-slate-400 hover:bg-slate-700 cursor-not-allowed'
                        }`}
                      >
                        <Diamond className="w-4 h-4 fill-current" />
                        <span>
                          {isCurrentActive
                            ? 'মেয়াদ বৃদ্ধি করুন (Extend)'
                            : `${pkg.diamondPrice} ডায়মন্ড দিয়ে কিনুন`}
                        </span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* TAB 2: Special Profile Frames */}
          {activeTab === 'frames' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-black text-white">
                    স্পেশাল প্রোফাইল ফ্রেম স্টুডিও
                  </h3>
                  <p className="text-xs text-slate-400">
                    আপনার অবতারের চারপাশে রাজকীয় আভা ও ডাইনামিক ফ্রেম যোগ করুন।
                  </p>
                </div>
                {!isVip && (
                  <span className="text-[11px] font-bold text-amber-300 bg-amber-500/10 px-2.5 py-1 rounded-xl border border-amber-500/30">
                    🔒 আনলক করতে VIP পাস প্রয়োজন
                  </span>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
                {VIP_FRAMES.map((frame) => {
                  const isUnlocked =
                    frame.id === 'none' ||
                    (isVip && vipState.unlockedFrames.includes(frame.id));
                  const isEquipped = vipState.activeFrameId === frame.id;
                  const isPreviewing = previewFrame === frame.id;

                  return (
                    <div
                      key={frame.id}
                      onClick={() => setPreviewFrame(frame.id)}
                      className={`p-3.5 rounded-2xl flex items-center justify-between gap-3 border transition-all cursor-pointer ${
                        isPreviewing
                          ? 'bg-white/10 border-amber-400 shadow-md'
                          : 'bg-slate-900/60 border-white/10 hover:border-white/20'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className="relative p-1">
                          <AvatarDisplay
                            avatar={userAvatar}
                            size={44}
                            vipFrameId={frame.id}
                          />
                        </div>
                        <div>
                          <div className="flex items-center gap-1.5">
                            <span className="text-xs font-black text-white">
                              {frame.nameBn}
                            </span>
                            {isEquipped && (
                              <span className="bg-emerald-500 text-slate-950 text-[9px] font-black px-1.5 py-0.2 rounded-full">
                                সক্রিয়
                              </span>
                            )}
                          </div>
                          <p className="text-[10px] text-slate-400 line-clamp-1 mt-0.5">
                            {frame.descriptionBn}
                          </p>
                        </div>
                      </div>

                      <div>
                        {isUnlocked ? (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleEquipFrame(frame.id);
                            }}
                            className={`px-3 py-1 rounded-xl text-xs font-black transition-all cursor-pointer ${
                              isEquipped
                                ? 'bg-emerald-500 text-slate-950'
                                : 'bg-amber-400 hover:bg-amber-300 text-slate-950 active:scale-95'
                            }`}
                          >
                            {isEquipped ? 'ব্যবহৃত' : 'ব্যবহার করুন'}
                          </button>
                        ) : (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setActiveTab('packages');
                            }}
                            className="px-2.5 py-1 rounded-xl bg-slate-800 text-slate-400 text-[11px] font-bold flex items-center gap-1 hover:text-amber-300 cursor-pointer"
                          >
                            <Lock className="w-3 h-3 text-amber-400" />
                            <span>লকড</span>
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 3: Exclusive Chat Bubbles */}
          {activeTab === 'bubbles' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-black text-white">
                    লাক্সারি চ্যাট বাবল কালেকশন
                  </h3>
                  <p className="text-xs text-slate-400">
                    ইন-গেম টেক্সট ও ১০ জনের লাইভ আড্ডা বোর্ডে মেসেজ পাঠানোর স্পেশাল স্টাইল।
                  </p>
                </div>
                {!isVip && (
                  <span className="text-[11px] font-bold text-amber-300 bg-amber-500/10 px-2.5 py-1 rounded-xl border border-amber-500/30">
                    🔒 আনলক করতে VIP পাস প্রয়োজন
                  </span>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                {VIP_CHAT_BUBBLES.map((bubble) => {
                  const isUnlocked =
                    bubble.id === 'classic' ||
                    (isVip && vipState.unlockedChatBubbles.includes(bubble.id));
                  const isEquipped = vipState.activeChatBubbleId === bubble.id;
                  const isPreviewing = previewBubble === bubble.id;

                  return (
                    <div
                      key={bubble.id}
                      onClick={() => setPreviewBubble(bubble.id)}
                      className={`p-3.5 rounded-2xl border transition-all cursor-pointer ${
                        isPreviewing
                          ? 'bg-white/10 border-amber-400 shadow-md'
                          : 'bg-slate-900/60 border-white/10 hover:border-white/20'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-1.5">
                          <span className="text-xs font-black text-white">
                            {bubble.nameBn}
                          </span>
                          {isEquipped && (
                            <span className="bg-emerald-500 text-slate-950 text-[9px] font-black px-1.5 py-0.2 rounded-full">
                              বর্তমান
                            </span>
                          )}
                        </div>

                        {isUnlocked ? (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleEquipBubble(bubble.id);
                            }}
                            className={`px-3 py-1 rounded-xl text-xs font-black transition-all cursor-pointer ${
                              isEquipped
                                ? 'bg-emerald-500 text-slate-950'
                                : 'bg-amber-400 hover:bg-amber-300 text-slate-950 active:scale-95'
                            }`}
                          >
                            {isEquipped ? 'সক্রিয় আছে' : 'সক্রিয় করুন'}
                          </button>
                        ) : (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setActiveTab('packages');
                            }}
                            className="px-2.5 py-1 rounded-xl bg-slate-800 text-slate-400 text-[11px] font-bold flex items-center gap-1 hover:text-amber-300 cursor-pointer"
                          >
                            <Lock className="w-3 h-3 text-amber-400" />
                            <span>VIP আনলক</span>
                          </button>
                        )}
                      </div>

                      {/* Bubble Visual Preview */}
                      <div
                        className={`p-2.5 rounded-2xl border ${bubble.themeStyle.bubbleBg} ${bubble.themeStyle.bubbleBorder} ${bubble.themeStyle.accentGlow} text-xs`}
                      >
                        <div className="flex items-center justify-between gap-1 mb-0.5">
                          <span className={`text-[11px] ${bubble.themeStyle.senderColor} flex items-center gap-1`}>
                            <span>{bubble.themeStyle.badgeIcon}</span>
                            <span>{currentUser?.name || 'প্লেয়ার'}</span>
                          </span>
                          <span className="text-[9px] opacity-75">প্রিভিউ</span>
                        </div>
                        <p className={`font-semibold ${bubble.themeStyle.textColor} text-xs leading-snug`}>
                          "জয় লুডু তে খেলছি, আড্ডা দিচ্ছি এবং জিতছি! 🏆✨"
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 4: VIP Badges & Perks */}
          {activeTab === 'badges' && (
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-black text-white">
                  VIP ব্যাজ নির্বাচন ও স্পেশাল প্রিভিলেজ
                </h3>
                <p className="text-xs text-slate-400">
                  আপনার নামের পাশে ডিসপ্লে হওয়ার জন্য আপনার পছন্দের VIP ব্যাজটি সিলেক্ট করুন।
                </p>
              </div>

              {/* Badges Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {VIP_BADGES.map((b) => {
                  const isUnlocked = isVip && vipState.unlockedBadges.includes(b.id);
                  const isEquipped = vipState.activeBadgeId === b.id;

                  return (
                    <div
                      key={b.id}
                      onClick={() => setPreviewBadge(b.id)}
                      className={`p-3.5 rounded-2xl border flex items-center justify-between gap-2 transition-all cursor-pointer ${
                        previewBadge === b.id
                          ? 'bg-white/10 border-amber-400 shadow-md'
                          : 'bg-slate-900/60 border-white/10 hover:border-white/20'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-2xl bg-slate-950 flex items-center justify-center text-xl shadow-inner border border-white/10">
                          {b.icon}
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-black text-white">
                              {b.nameBn}
                            </span>
                            <VipBadge badgeId={b.id} size="sm" animate={false} />
                          </div>
                          <span className="text-[10px] text-slate-400">
                            গেম ও আড্ডা বোর্ডে নামের পাশে দৃশ্যমান
                          </span>
                        </div>
                      </div>

                      <div>
                        {isUnlocked ? (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleEquipBadge(b.id);
                            }}
                            className={`px-3 py-1 rounded-xl text-xs font-black transition-all cursor-pointer ${
                              isEquipped
                                ? 'bg-emerald-500 text-slate-950'
                                : 'bg-amber-400 hover:bg-amber-300 text-slate-950 active:scale-95'
                            }`}
                          >
                            {isEquipped ? 'নির্বাচিত' : 'সিলেক্ট'}
                          </button>
                        ) : (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setActiveTab('packages');
                            }}
                            className="px-2.5 py-1 rounded-xl bg-slate-800 text-slate-400 text-[11px] font-bold flex items-center gap-1 hover:text-amber-300 cursor-pointer"
                          >
                            <Lock className="w-3 h-3 text-amber-400" />
                            <span>লকড</span>
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* VIP Member Perks Summary Card */}
              <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-950/40 via-indigo-950/40 to-slate-900 border border-amber-500/30 mt-4">
                <h4 className="text-xs font-black text-amber-300 flex items-center gap-1.5 mb-2">
                  <ShieldCheck className="w-4 h-4 text-amber-400" />
                  <span>VIP মেম্বারশিপের সকল এক্সক্লুসিভ সুবিধাসমূহ:</span>
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-slate-300">
                  <div className="flex items-center gap-2">
                    <span className="text-amber-400 font-bold">✓</span>
                    <span>নামের পাশে ঝলমলে ভিআইপি ব্যাজ ও গোল্ডেন নেমপ্লেট</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-amber-400 font-bold">✓</span>
                    <span>স্পেশাল ড্রাগন, ক্রাউন, সাইবার ও ফিনিক্স প্রোফাইল ফ্রেম</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-amber-400 font-bold">✓</span>
                    <span>৫টি কাস্টম অ্যানিমেটেড লাক্সারি চ্যাট বাবল</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-amber-400 font-bold">✓</span>
                    <span>প্রতি ম্যাচে +১৫% থেকে +৫০% অতিরিক্ত XP ও লেভেল বোনাস</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-amber-400 font-bold">✓</span>
                    <span>১০ জনের লাইভ আড্ডা বোর্ডে স্পেশাল গোল্ডেন সিট</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-amber-400 font-bold">✓</span>
                    <span>টুর্নামেন্টে অগ্রাধিকার সিডিং ও ভিআইপি এন্ট্রি সাউন্ড</span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer info */}
        <div className="p-3 sm:p-4 bg-slate-950 border-t border-white/10 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <Award className="w-4 h-4 text-amber-400" />
            <span>
              সব ডায়মন্ড সরাসরি গেম খেলে ও লেভেল আপ করে ফ্রি অর্জন করা যায়।
            </span>
          </div>
          <button
            onClick={() => {
              Sound.playClick();
              onClose();
            }}
            className="px-4 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs cursor-pointer"
          >
            বন্ধ করুন
          </button>
        </div>
      </div>
    </div>
  );
};
