import React, { useState } from 'react';
import { Flame, Coins, Check, Sparkles, Gift, Crown, Trophy, ChevronRight, Clock, AlertCircle } from 'lucide-react';
import { DailyStreakState } from '../types';
import {
  DAILY_STREAK_REWARDS,
  evaluateStreak,
  toBnNumber,
} from '../utils/streakConstants';
import { Sound } from '../utils/soundEffects';

interface DailyLoginStreakProps {
  streakState: DailyStreakState;
  onClaimReward: (rewardCoins: number, rewardDiamonds: number, newStreak: number) => void;
}

export const DailyLoginStreak: React.FC<DailyLoginStreakProps> = ({
  streakState,
  onClaimReward,
}) => {
  const [showCelebration, setShowCelebration] = useState<boolean>(false);
  const [lastClaimedCoins, setLastClaimedCoins] = useState<number>(0);
  const [lastClaimedDiamonds, setLastClaimedDiamonds] = useState<number>(0);
  const [isClaiming, setIsClaiming] = useState<boolean>(false);

  const evaluation = evaluateStreak(streakState);
  const {
    canClaimToday,
    isAlreadyClaimedToday,
    isStreakBroken,
    activeRewardDay,
    activeRewardCoins,
    activeRewardDiamonds,
    nextRewardDay,
    nextRewardCoins,
    nextRewardDiamonds,
    displayStreakCount,
    isMegaDay,
  } = evaluation;

  const handleClaim = () => {
    if (!canClaimToday || isClaiming) return;

    setIsClaiming(true);
    Sound.playWin();
    Sound.playCoinSound();
    if (activeRewardDiamonds > 0) {
      Sound.playDiamondCollect();
    }

    const newStreak = isAlreadyClaimedToday
      ? streakState.currentStreak
      : evaluation.isStreakBroken || streakState.lastClaimDate === null
      ? 1
      : streakState.currentStreak + 1;

    setLastClaimedCoins(activeRewardCoins);
    setLastClaimedDiamonds(activeRewardDiamonds);
    setShowCelebration(true);

    // Trigger parent state update
    onClaimReward(activeRewardCoins, activeRewardDiamonds, newStreak);

    setTimeout(() => {
      setIsClaiming(false);
    }, 600);

    setTimeout(() => {
      setShowCelebration(false);
    }, 4500);
  };

  return (
    <div
      id="daily-login-streak-widget"
      className="relative overflow-hidden bg-gradient-to-br from-amber-500 via-orange-500 to-rose-600 rounded-3xl p-4 text-white shadow-xl border-b-4 border-rose-800 transition-all select-none"
    >
      {/* Background ambient lighting */}
      <div className="absolute -right-8 -top-8 w-32 h-32 bg-yellow-300/20 rounded-full blur-2xl pointer-events-none" />
      <div className="absolute -left-8 -bottom-8 w-32 h-32 bg-rose-900/30 rounded-full blur-2xl pointer-events-none" />

      {/* Header Section: Streak title & Badge */}
      <div className="relative z-10 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 rounded-2xl bg-white/20 backdrop-blur-md border border-white/30 flex items-center justify-center shadow-inner">
            <Flame className="w-5 h-5 text-yellow-200 fill-yellow-300 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h3 className="text-sm sm:text-base font-black text-white leading-tight">
                Daily Login Streak
              </h3>
              {displayStreakCount > 0 && (
                <span className="bg-yellow-300 text-amber-950 text-[10px] font-black px-1.5 py-0.5 rounded-full shadow-xs">
                  {displayStreakCount} Days 🔥
                </span>
              )}
            </div>
            <p className="text-[11px] text-amber-100 font-medium">
              Log in daily to claim free coins & diamond bonuses
            </p>
          </div>
        </div>

        {/* Highest Streak Pill */}
        {streakState.highestStreak > 0 && (
          <div
            className="hidden sm:flex flex-col items-end bg-black/20 backdrop-blur-xs px-2.5 py-1 rounded-xl border border-white/10"
            title="All-time highest streak"
          >
            <span className="text-[9px] text-amber-200 uppercase font-black tracking-wider">Record</span>
            <span className="text-xs font-black text-white flex items-center gap-0.5">
              <Trophy className="w-3 h-3 text-yellow-300 inline" />
              {streakState.highestStreak} Days
            </span>
          </div>
        )}
      </div>

      {/* Warning banner if streak was broken */}
      {isStreakBroken && (
        <div className="relative z-10 mt-2.5 px-2.5 py-1.5 rounded-xl bg-black/30 backdrop-blur-xs border border-yellow-300/30 flex items-center gap-2 text-[11px] text-yellow-100 font-bold">
          <AlertCircle className="w-4 h-4 text-yellow-300 shrink-0" />
          <span>Yesterday was missed! Your streak has restarted from Day 1.</span>
        </div>
      )}

      {/* Main Reward & Next Reward Banner */}
      <div className="relative z-10 mt-3 p-3 rounded-2xl bg-black/25 backdrop-blur-sm border border-white/15 shadow-inner">
        <div className="flex items-center justify-between">
          <div>
            <span className="text-[10px] uppercase font-black text-amber-200 tracking-wider block">
              {canClaimToday ? "Today's Reward" : "Claimed Today"}
            </span>
            <div className="flex items-center gap-1.5 mt-0.5 flex-wrap">
              <Coins className="w-5 h-5 text-yellow-300 fill-yellow-300 shrink-0" />
              <span className="text-lg sm:text-xl font-black text-white tracking-tight">
                +{activeRewardCoins.toLocaleString('en-US')} Coins
              </span>
              {activeRewardDiamonds > 0 && (
                <span className="bg-cyan-500/30 border border-cyan-300 text-cyan-200 text-xs font-black px-2 py-0.5 rounded-md flex items-center gap-1 shadow-sm">
                  +{activeRewardDiamonds} 💎 Diamonds
                </span>
              )}
              {isMegaDay && (
                <span className="bg-gradient-to-r from-yellow-300 to-amber-400 text-slate-950 text-[10px] font-black px-1.5 py-0.5 rounded-md flex items-center gap-1 shadow-sm">
                  <Crown className="w-3 h-3 text-amber-900 fill-amber-900" />
                  MEGA JACKPOT
                </span>
              )}
            </div>
          </div>

          {/* Next Reward Preview */}
          <div className="text-right pl-3 border-l border-white/15">
            <span className="text-[10px] uppercase font-bold text-amber-200/90 tracking-wider block">
              Next Reward
            </span>
            <span className="text-xs sm:text-sm font-extrabold text-yellow-200 flex items-center justify-end gap-1 mt-0.5">
              +{nextRewardCoins.toLocaleString('en-US')}
              <span className="text-[10px] text-amber-100 font-normal">
                (Day {nextRewardDay})
              </span>
            </span>
          </div>
        </div>
      </div>

      {/* 7-Day Visual Progress Track */}
      <div className="relative z-10 mt-3">
        <div className="flex items-center justify-between mb-1.5">
          <span className="text-[11px] font-bold text-amber-100 flex items-center gap-1">
            <Sparkles className="w-3.5 h-3.5 text-yellow-300" />
            7-Day Reward Cycle
          </span>
          <span className="text-[10px] font-extrabold text-yellow-200">
            {isAlreadyClaimedToday
              ? `Done Today (${activeRewardDay}/7)`
              : `Pending Claim (Day ${activeRewardDay})`}
          </span>
        </div>

        <div className="grid grid-cols-7 gap-1 sm:gap-1.5">
          {DAILY_STREAK_REWARDS.map((reward) => {
            const isClaimed =
              isAlreadyClaimedToday
                ? reward.day <= activeRewardDay
                : reward.day < activeRewardDay;
            const isToday = reward.day === activeRewardDay;

            let cardBg = 'bg-white/10 border-white/15 text-white/70';
            if (isClaimed) {
              cardBg = 'bg-emerald-500/80 border-emerald-300 text-white shadow-xs';
            } else if (isToday) {
              cardBg =
                'bg-gradient-to-b from-yellow-300 to-amber-400 border-2 border-white text-slate-950 shadow-md ring-2 ring-yellow-300/60 scale-105 z-10';
            }

            return (
              <div
                key={`streak_day_${reward.day}`}
                className={`relative flex flex-col items-center justify-between p-1.5 rounded-xl border transition-all ${cardBg}`}
              >
                {/* Day Header */}
                <span className={`text-[9px] font-black ${isToday ? 'text-amber-950' : 'text-white/90'}`}>
                  Day {reward.day}
                </span>

                {/* Center Badge / Status */}
                <div className="my-1 flex items-center justify-center">
                  {isClaimed ? (
                    <div className="w-4 h-4 rounded-full bg-white text-emerald-600 flex items-center justify-center shadow-xs">
                      <Check className="w-3 h-3 stroke-[3]" />
                    </div>
                  ) : isToday ? (
                    <span className="text-sm animate-bounce">{reward.badge || '🎁'}</span>
                  ) : (
                    <span className="text-xs opacity-75">{reward.badge || '🔒'}</span>
                  )}
                </div>

                {/* Coin amount */}
                <span
                  className={`text-[9px] sm:text-[10px] font-black truncate max-w-full leading-tight ${
                    isToday ? 'text-amber-950' : 'text-yellow-200'
                  }`}
                >
                  +{reward.coins >= 1000 ? `${reward.coins / 1000}k` : reward.coins}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Action Button / Claim Status */}
      <div className="relative z-10 mt-3 pt-2.5 border-t border-white/20 flex items-center justify-between gap-2">
        {canClaimToday ? (
          <button
            id="claim-daily-streak-btn"
            disabled={isClaiming}
            onClick={handleClaim}
            className="w-full py-2.5 px-4 bg-gradient-to-r from-yellow-300 via-amber-300 to-yellow-400 hover:from-yellow-200 hover:to-amber-300 active:scale-98 text-amber-950 font-black text-xs sm:text-sm rounded-xl shadow-lg border-b-2 border-amber-600 flex items-center justify-center gap-2 transition-all cursor-pointer animate-pulse"
          >
            <Gift className="w-4 h-4 text-amber-900 fill-amber-400" />
            <span>Claim Today's Bonus (+{activeRewardCoins.toLocaleString('en-US')} Coins)</span>
          </button>
        ) : (
          <div className="w-full py-2 px-3 rounded-xl bg-black/20 backdrop-blur-xs border border-white/10 flex items-center justify-between text-xs font-bold text-amber-100">
            <div className="flex items-center gap-1.5">
              <div className="w-5 h-5 rounded-full bg-emerald-500 text-white flex items-center justify-center shrink-0 shadow-xs">
                <Check className="w-3 h-3 stroke-[3]" />
              </div>
              <span>Today's Bonus Collected!</span>
            </div>
            <div className="flex items-center gap-1 text-[11px] text-yellow-200 font-extrabold">
              <Clock className="w-3.5 h-3.5 text-yellow-300" />
              <span>Come back tomorrow</span>
            </div>
          </div>
        )}
      </div>

      {/* Celebration Popup Overlay Animation when claimed */}
      {showCelebration && (
        <div className="absolute inset-0 z-30 bg-slate-950/90 backdrop-blur-sm flex flex-col items-center justify-center p-4 text-center animate-in fade-in zoom-in-95 duration-200">
          <div className="w-14 h-14 rounded-3xl bg-gradient-to-tr from-yellow-300 via-amber-400 to-yellow-200 flex items-center justify-center shadow-2xl border-2 border-white mb-2 animate-bounce">
            <Coins className="w-8 h-8 text-amber-950 fill-amber-400" />
          </div>
          <span className="text-xs font-black text-yellow-300 uppercase tracking-widest">
            Congratulations! 🎉
          </span>
          <h4 className="text-lg sm:text-xl font-black text-white mt-0.5">
            +{lastClaimedCoins.toLocaleString('en-US')} Coins{' '}
            {lastClaimedDiamonds > 0 && `& +${lastClaimedDiamonds} Diamonds 💎 `}
            Claimed!
          </h4>
          <p className="text-xs text-amber-200 font-semibold mt-1">
            Current Streak: <span className="text-white font-black">{streakState.currentStreak} Days</span> 🔥
          </p>
          <button
            onClick={() => setShowCelebration(false)}
            className="mt-3 px-5 py-1.5 bg-yellow-400 hover:bg-yellow-300 text-slate-950 font-black text-xs rounded-xl shadow-md transition-all active:scale-95"
          >
            Awesome!
          </button>
        </div>
      )}
    </div>
  );
};
