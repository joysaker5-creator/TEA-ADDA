// Adda Live Music & Song Player Service

export interface AddaSong {
  id: string;
  title: string;
  artist: string;
  category: 'baul' | 'lofi' | 'flute' | 'party' | 'monsoon' | 'custom';
  coverEmoji: string;
  duration: number; // in seconds
  isCustom?: boolean;
  file?: File;
  objectUrl?: string;
}

export const PRESET_ADDA_SONGS: AddaSong[] = [
  {
    id: 'song_baul',
    title: 'বাউল একতারা সুর (Baul Ektara Live)',
    artist: 'আড্ডা ফোক ক্লাব',
    category: 'baul',
    coverEmoji: '🪕',
    duration: 180,
  },
  {
    id: 'song_lofi',
    title: 'টিএসসি মিডনাইট লো-ফাই (TSC Midnight Lofi)',
    artist: 'ডিজে শান্তনু',
    category: 'lofi',
    coverEmoji: '🎧',
    duration: 210,
  },
  {
    id: 'song_flute',
    title: 'সুরমা নদীর বাঁশির তান (Surma Flute Breeze)',
    artist: 'ওস্তাদ মনসুর',
    category: 'flute',
    coverEmoji: '🎋',
    duration: 195,
  },
  {
    id: 'song_party',
    title: 'লুডো ধামাকা সেলিব্রেশন (Ludo Party Beats)',
    artist: 'আড্ডা মিউজিক ক্রু',
    category: 'party',
    coverEmoji: '🔥',
    duration: 160,
  },
  {
    id: 'song_monsoon',
    title: 'বৃষ্টি ভেজা চায়ের আড্ডা (Monsoon Chai Serenade)',
    artist: 'ক্যাম্পাস মেলোডি',
    category: 'monsoon',
    coverEmoji: '☕',
    duration: 220,
  },
];

class AddaMusicEngine {
  private audioCtx: AudioContext | null = null;
  private synthInterval: any = null;
  private audioElement: HTMLAudioElement | null = null;
  private currentSong: AddaSong | null = null;
  private isPlaying: boolean = false;
  private volume: number = 0.6;
  private currentTime: number = 0;
  private listeners: Set<(state: { isPlaying: boolean; currentSong: AddaSong | null; currentTime: number; duration: number }) => void> = new Set();

  private getAudioContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.audioCtx) {
      const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtxClass) {
        this.audioCtx = new AudioCtxClass();
      }
    }
    if (this.audioCtx && this.audioCtx.state === 'suspended') {
      this.audioCtx.resume().catch(() => {});
    }
    return this.audioCtx;
  }

  public subscribe(cb: (state: { isPlaying: boolean; currentSong: AddaSong | null; currentTime: number; duration: number }) => void) {
    this.listeners.add(cb);
    return () => {
      this.listeners.delete(cb);
    };
  }

  private notify() {
    const duration = this.audioElement && this.currentSong?.isCustom ? this.audioElement.duration || this.currentSong.duration : this.currentSong?.duration || 0;
    this.listeners.forEach((cb) => {
      cb({
        isPlaying: this.isPlaying,
        currentSong: this.currentSong,
        currentTime: this.currentTime,
        duration,
      });
    });
  }

  public playPresetSong(song: AddaSong) {
    this.stop();
    this.currentSong = song;
    this.isPlaying = true;
    this.currentTime = 0;
    this.notify();

    // Start synthesized ambient melodic loop
    const ctx = this.getAudioContext();
    if (!ctx) return;

    let step = 0;
    // Pentatonic & Raag note frequencies
    const scales: Record<string, number[]> = {
      baul: [220, 247.5, 277.18, 329.63, 370, 440, 495, 554.37],
      lofi: [261.63, 293.66, 329.63, 392.00, 440.00, 523.25],
      flute: [329.63, 370, 392, 440, 493.88, 587.33, 659.25],
      party: [130.81, 196, 261.63, 329.63, 392, 523.25],
      monsoon: [174.61, 220, 261.63, 329.63, 349.23, 440, 523.25],
    };

    const notes = scales[song.category] || scales.baul;

    this.synthInterval = setInterval(() => {
      if (!this.isPlaying) return;
      this.currentTime += 0.5;
      if (this.currentTime >= song.duration) {
        this.currentTime = 0;
      }
      this.notify();

      try {
        if (ctx.state === 'suspended') {
          ctx.resume().catch(() => {});
        }
        const now = ctx.currentTime;
        const noteFreq = notes[step % notes.length];
        step = (step + 1) % (notes.length * 4);

        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        if (song.category === 'baul') {
          osc.type = 'sawtooth';
          osc.frequency.setValueAtTime(noteFreq * (step % 2 === 0 ? 1 : 1.5), now);
          gain.gain.setValueAtTime(0.08 * this.volume, now);
          gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.45);
        } else if (song.category === 'lofi') {
          osc.type = 'triangle';
          osc.frequency.setValueAtTime(noteFreq * 0.75, now);
          gain.gain.setValueAtTime(0.12 * this.volume, now);
          gain.gain.exponentialRampToValueAtTime(0.001, now + 0.6);
        } else if (song.category === 'flute') {
          osc.type = 'sine';
          osc.frequency.setValueAtTime(noteFreq * 1.25, now);
          gain.gain.setValueAtTime(0.14 * this.volume, now);
          gain.gain.exponentialRampToValueAtTime(0.001, now + 0.5);
        } else if (song.category === 'party') {
          osc.type = 'square';
          osc.frequency.setValueAtTime(step % 4 === 0 ? 80 : noteFreq, now);
          gain.gain.setValueAtTime(0.15 * this.volume, now);
          gain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);
        } else {
          osc.type = 'sine';
          osc.frequency.setValueAtTime(noteFreq, now);
          gain.gain.setValueAtTime(0.1 * this.volume, now);
          gain.gain.exponentialRampToValueAtTime(0.001, now + 0.7);
        }

        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 0.75);
      } catch {
        // audio error ignored
      }
    }, 500);
  }

  public playCustomAudioFile(file: File): AddaSong {
    this.stop();
    const url = URL.createObjectURL(file);
    const customSong: AddaSong = {
      id: `custom_${Date.now()}`,
      title: file.name.replace(/\.[^/.]+$/, ''),
      artist: 'আপনার অডিও ফাইল 🎵',
      category: 'custom',
      coverEmoji: '🎶',
      duration: 180,
      isCustom: true,
      file,
      objectUrl: url,
    };

    this.currentSong = customSong;
    this.audioElement = new Audio(url);
    this.audioElement.volume = this.volume;
    this.audioElement.loop = true;

    this.audioElement.onloadedmetadata = () => {
      if (this.audioElement && this.currentSong) {
        this.currentSong.duration = Math.floor(this.audioElement.duration) || 180;
        this.notify();
      }
    };

    this.audioElement.ontimeupdate = () => {
      if (this.audioElement) {
        this.currentTime = Math.floor(this.audioElement.currentTime);
        this.notify();
      }
    };

    this.audioElement.play().catch((err) => {
      console.warn('Audio play prevented:', err);
    });

    this.isPlaying = true;
    this.notify();
    return customSong;
  }

  public pause() {
    this.isPlaying = false;
    if (this.audioElement) {
      this.audioElement.pause();
    }
    if (this.synthInterval) {
      clearInterval(this.synthInterval);
      this.synthInterval = null;
    }
    this.notify();
  }

  public resume() {
    if (!this.currentSong) return;
    if (this.currentSong.isCustom && this.audioElement) {
      this.audioElement.play().catch(() => {});
      this.isPlaying = true;
      this.notify();
    } else {
      this.playPresetSong(this.currentSong);
    }
  }

  public stop() {
    this.isPlaying = false;
    this.currentTime = 0;
    if (this.audioElement) {
      this.audioElement.pause();
      if (this.currentSong?.objectUrl) {
        URL.revokeObjectURL(this.currentSong.objectUrl);
      }
      this.audioElement = null;
    }
    if (this.synthInterval) {
      clearInterval(this.synthInterval);
      this.synthInterval = null;
    }
    this.notify();
  }

  public setVolume(vol: number) {
    this.volume = Math.max(0, Math.min(1, vol));
    if (this.audioElement) {
      this.audioElement.volume = this.volume;
    }
    this.notify();
  }

  public getVolume(): number {
    return this.volume;
  }

  public seek(seconds: number) {
    this.currentTime = seconds;
    if (this.audioElement) {
      this.audioElement.currentTime = seconds;
    }
    this.notify();
  }

  public getCurrentSong(): AddaSong | null {
    return this.currentSong;
  }

  public getIsPlaying(): boolean {
    return this.isPlaying;
  }
}

export const AddaMusic = new AddaMusicEngine();
