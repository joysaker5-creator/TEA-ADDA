import { AccountLevelState, LevelReward, DiamondPackage, LevelUpEventData } from '../types';

export const STORAGE_KEY_ACCOUNT_LEVEL = 'ludo_account_level_v1';
export const STORAGE_KEY_USER_DIAMONDS = 'ludo_user_diamonds_v1';

export const INITIAL_DIAMONDS = 50;

/**
 * Diamond purchase packages with bKash/Nagad pricing (Benchmark: 50,000 Coins = 1,000 BDT -> 1 Diamond = 50 Coins = 1 BDT)
 */
export const DIAMOND_PACKAGES: DiamondPackage[] = [
  {
    id: 'dia_starter',
    title: 'স্টার্টার জেমস প্যাক',
    diamonds: 50,
    bonus: 0,
    priceBDT: 50,
    color: 'from-cyan-500 to-blue-600',
    badge: 'শুরুয়াত',
  },
  {
    id: 'dia_popular',
    title: 'সিলভার জেমস প্যাক',
    diamonds: 100,
    bonus: 20,
    priceBDT: 100,
    color: 'from-blue-500 to-indigo-600',
    badge: '+২০ বোনাস',
  },
  {
    id: 'dia_value',
    title: 'গোল্ড ডায়মন্ড বক্স',
    diamonds: 250,
    bonus: 60,
    priceBDT: 250,
    color: 'from-purple-500 to-pink-600',
    badge: 'সেরা ডিল 🔥',
  },
  {
    id: 'dia_vip',
    title: 'রয়্যাল ডায়মন্ড ট্রেজার',
    diamonds: 500,
    bonus: 150,
    priceBDT: 500,
    color: 'from-amber-500 to-rose-600',
    badge: 'মেগা সেভিংস',
  },
  {
    id: 'dia_emperor',
    title: '১০০০ জেমস ভিআইপি চেস্ট',
    diamonds: 1000,
    bonus: 400,
    priceBDT: 1000,
    color: 'from-emerald-500 to-cyan-600',
    badge: '১০০০ জেমস ভিআইপি 👑',
  },
];

/**
 * Currency Exchange Options (1 Diamond = 50 Coins)
 */
export const CURRENCY_EXCHANGES = [
  {
    id: 'dia_to_coin_1',
    fromDiamonds: 30,
    toCoins: 1500,
    titleBn: 'ছোট কয়েন থলি (১৫০০ কয়েন)',
    bonusCoins: 0,
  },
  {
    id: 'dia_to_coin_2',
    fromDiamonds: 100,
    toCoins: 5000,
    titleBn: 'বড় কয়েন থলি (৫৫০০ কয়েন)',
    bonusCoins: 500,
  },
  {
    id: 'dia_to_coin_3',
    fromDiamonds: 300,
    toCoins: 15000,
    titleBn: 'রাজকীয় কয়েন ভল্ট (১৭,৫০০ কয়েন)',
    bonusCoins: 2500,
  },
  {
    id: 'dia_to_coin_4',
    fromDiamonds: 1000,
    toCoins: 50000,
    titleBn: '৫০ হাজার মেগা কয়েন ভল্ট',
    bonusCoins: 10000,
  },
  {
    id: 'coin_to_dia_1',
    fromCoins: 2500,
    toDiamonds: 50,
    titleBn: '২৫০০ কয়েন দিয়ে ৫০ ডায়মন্ড',
    badge: 'জনপ্রিয় এক্সচেঞ্জ',
  },
  {
    id: 'coin_to_dia_2',
    fromCoins: 6000,
    toDiamonds: 120,
    titleBn: '৬০০০ কয়েন দিয়ে ১২০ ডায়মন্ড',
    badge: '+১০ ফ্রি ডায়মন্ড',
  },
  {
    id: 'coin_to_dia_3',
    fromCoins: 15000,
    toDiamonds: 300,
    titleBn: '১৫০০০ কয়েন দিয়ে ৩০০ ডায়মন্ড',
    badge: '+৩০ ফ্রি ডায়মন্ড',
  },
  {
    id: 'coin_to_dia_4',
    fromCoins: 50000,
    toDiamonds: 1000,
    titleBn: '৫০ হাজার কয়েন দিয়ে ১০০০ ডায়মন্ড',
    badge: '+১০০ মেগা বোনাস 💎',
  },
];

/**
 * XP Award table for in-game actions
 */
export const XP_REWARDS = {
  MATCH_PLAY: 40,
  MATCH_WIN: 120,
  QUICK_MATCH_WIN: 80,
  TEAM_WIN: 140,
  TOURNAMENT_WIN: 250,
  SIX_ROLLED: 10,
  TOKEN_CAPTURED: 30,
  TOKEN_HOME: 40,
  DAILY_STREAK: 60,
  AD_WATCH: 50,
};

/**
 * Tier Metadata Definitions
 */
export interface TierInfo {
  nameBn: string;
  badgeBg: string;
  badgeBorder: string;
  textColor: string;
  glowColor: string;
  icon: string;
  minLevel: number;
  maxLevel: number;
}

export const TIERS: TierInfo[] = [
  {
    nameBn: 'রুকি ট্রেইনি',
    badgeBg: 'bg-slate-100',
    badgeBorder: 'border-slate-300',
    textColor: 'text-slate-700',
    glowColor: 'rgba(148, 163, 184, 0.3)',
    icon: '🌱',
    minLevel: 1,
    maxLevel: 2,
  },
  {
    nameBn: 'ব্রোঞ্জ প্লেয়ার 🥉',
    badgeBg: 'bg-amber-900/10',
    badgeBorder: 'border-amber-700/40',
    textColor: 'text-amber-800',
    glowColor: 'rgba(180, 83, 9, 0.3)',
    icon: '🥉',
    minLevel: 3,
    maxLevel: 5,
  },
  {
    nameBn: 'সিলভার ওয়ারিয়র 🥈',
    badgeBg: 'bg-slate-200',
    badgeBorder: 'border-slate-400',
    textColor: 'text-slate-800',
    glowColor: 'rgba(203, 213, 225, 0.4)',
    icon: '🥈',
    minLevel: 6,
    maxLevel: 9,
  },
  {
    nameBn: 'গোল্ড মাস্টার 🥇',
    badgeBg: 'bg-amber-100',
    badgeBorder: 'border-amber-400',
    textColor: 'text-amber-900',
    glowColor: 'rgba(245, 158, 11, 0.4)',
    icon: '🥇',
    minLevel: 10,
    maxLevel: 14,
  },
  {
    nameBn: 'প্লাটিনাম চ্যাম্পিয়ন 💠',
    badgeBg: 'bg-cyan-100',
    badgeBorder: 'border-cyan-400',
    textColor: 'text-cyan-900',
    glowColor: 'rgba(6, 182, 212, 0.4)',
    icon: '💠',
    minLevel: 15,
    maxLevel: 19,
  },
  {
    nameBn: 'ডায়মন্ড লিজেন্ড 💎',
    badgeBg: 'bg-gradient-to-r from-blue-100 to-indigo-100',
    badgeBorder: 'border-blue-400',
    textColor: 'text-blue-900',
    glowColor: 'rgba(59, 130, 246, 0.5)',
    icon: '💎',
    minLevel: 20,
    maxLevel: 24,
  },
  {
    nameBn: 'মাস্টার লুডো কিং 👑',
    badgeBg: 'bg-gradient-to-r from-purple-100 to-pink-100',
    badgeBorder: 'border-purple-400',
    textColor: 'text-purple-900',
    glowColor: 'rgba(168, 85, 247, 0.5)',
    icon: '👑',
    minLevel: 25,
    maxLevel: 29,
  },
  {
    nameBn: 'গ্র্যান্ডমাস্টার টাইটান 🏆',
    badgeBg: 'bg-gradient-to-r from-rose-100 to-amber-100',
    badgeBorder: 'border-rose-400',
    textColor: 'text-rose-950',
    glowColor: 'rgba(244, 63, 94, 0.5)',
    icon: '🏆',
    minLevel: 30,
    maxLevel: 39,
  },
  {
    nameBn: 'রয়্যাল লুডু সম্রাট ⚡',
    badgeBg: 'bg-gradient-to-r from-amber-200 via-yellow-200 to-amber-300',
    badgeBorder: 'border-yellow-500',
    textColor: 'text-amber-950',
    glowColor: 'rgba(234, 179, 8, 0.6)',
    icon: '⚡',
    minLevel: 40,
    maxLevel: 999,
  },
];

export const LEVEL_TIERS = TIERS;

/**
 * Get Tier Info by Level
 */
export function getTierByLevel(level: number): TierInfo {
  const tier = TIERS.find((t) => level >= t.minLevel && level <= t.maxLevel);
  return tier || TIERS[TIERS.length - 1];
}

/**
 * Get localized level title
 */
export function getLevelTitle(level: number): string {
  const tier = getTierByLevel(level);
  return `${tier.nameBn} (লেভেল ${level.toLocaleString('bn-BD')})`;
}

/**
 * Get level badge icon/string
 */
export function getLevelBadge(level: number): string {
  const tier = getTierByLevel(level);
  return tier.icon;
}

/**
 * XP formula per level:
 * Base is 200 XP, smoothly grows by 65 XP per level.
 */
export function getXPRequiredForLevel(level: number): number {
  return 200 + level * 65;
}

/**
 * Calculate level progress percentage and values
 */
export function calculateLevelProgress(
  stateOrXp: AccountLevelState | number,
  levelMaybe?: number
): {
  percent: number;
  currentXP: number;
  requiredXP: number;
} {
  let level = 1;
  let currentXP = 0;
  if (typeof stateOrXp === 'number') {
    currentXP = Math.max(0, stateOrXp);
    level = typeof levelMaybe === 'number' ? levelMaybe : 1;
  } else {
    currentXP = Math.max(0, stateOrXp.currentXP);
    level = stateOrXp.currentLevel;
  }
  const requiredXP = getXPRequiredForLevel(level);
  const percent = Math.min(100, Math.max(0, Math.round((currentXP / requiredXP) * 100)));
  return { percent, currentXP, requiredXP };
}

/**
 * Pre-generated Level Rewards Table up to Level 50
 */
export const LEVEL_REWARDS: LevelReward[] = Array.from({ length: 50 }, (_, i) => {
  const level = i + 1;
  const tier = getTierByLevel(level);
  const isMilestone = level % 5 === 0 || level === 1;

  // Scaling rewards
  let rewardCoins = 300 + level * 150;
  let rewardDiamonds = Math.floor(level * 1.5) + 3;

  if (isMilestone) {
    rewardCoins += level * 300;
    rewardDiamonds += 15 + Math.floor(level * 1.2);
  }

  let badge: string | undefined;
  let exclusiveItem: string | undefined;

  if (level === 1) {
    badge = 'স্বাগতম বোনাস';
  } else if (level === 5) {
    badge = 'সিলভার আনলক';
    exclusiveItem = 'রৌপ্য ডাইস ফ্রেম';
  } else if (level === 10) {
    badge = 'গোল্ড ব্যাজ';
    exclusiveItem = 'গোল্ডেন অবতার বর্ডার';
  } else if (level === 15) {
    badge = 'প্লাটিনাম আনলক';
    exclusiveItem = 'এক্সক্লুসিভ গেম ব্যাকগ্রাউন্ড';
  } else if (level === 20) {
    badge = 'ডায়মন্ড এলিট 💎';
    exclusiveItem = 'শাইনিং ডায়মন্ড ডাইস';
  } else if (level === 25) {
    badge = 'মাস্টার ট্রফি';
    exclusiveItem = 'রয়্যাল সাউন্ড এফেক্টস প্যাক';
  } else if (level === 30) {
    badge = 'গ্র্যান্ড মাস্টার';
    exclusiveItem = 'কিং ক্রাউন অবতার ফ্রেম';
  } else if (level === 40) {
    badge = 'সম্রাট মুকুট 👑';
    exclusiveItem = 'গোল্ডেন সম্রাট বোর্ড থিম';
  } else if (level === 50) {
    badge = 'সর্বোচ্চ চূড়া ⚡';
    exclusiveItem = 'ইনফিনিটি গড ডাইস স্কিন';
  }

  return {
    level,
    titleBn: `লেভেল ${level.toLocaleString('bn-BD')}`,
    rewardCoins,
    rewardDiamonds,
    coins: rewardCoins,
    diamonds: rewardDiamonds,
    tierNameBn: tier.nameBn,
    badge,
    exclusiveItem,
    isMilestone,
  };
});

export const DEFAULT_ACCOUNT_LEVEL: AccountLevelState = {
  currentLevel: 4,
  currentXP: 180,
  totalAccumulatedXP: 1420,
  diamonds: 50,
  totalDiamondsEarned: 50,
  claimedLevelRewards: [1, 2, 3],
  lastLevelUpTimestamp: Date.now() - 3600000 * 5,
};

/**
 * Load Account Level State from localStorage
 */
export function loadAccountLevelState(): AccountLevelState {
  try {
    const saved = localStorage.getItem(STORAGE_KEY_ACCOUNT_LEVEL);
    if (saved) {
      const parsed = JSON.parse(saved);
      return {
        ...DEFAULT_ACCOUNT_LEVEL,
        ...parsed,
        diamonds: typeof parsed.diamonds === 'number' ? parsed.diamonds : 50,
        totalDiamondsEarned: typeof parsed.totalDiamondsEarned === 'number' ? parsed.totalDiamondsEarned : 50,
        claimedLevelRewards: Array.isArray(parsed.claimedLevelRewards)
          ? parsed.claimedLevelRewards
          : [1],
      };
    }
  } catch (e) {
    console.error('Error loading account level state:', e);
  }
  return DEFAULT_ACCOUNT_LEVEL;
}

/**
 * Save Account Level State to localStorage
 */
export function saveAccountLevelState(state: AccountLevelState): void {
  try {
    localStorage.setItem(STORAGE_KEY_ACCOUNT_LEVEL, JSON.stringify(state));
  } catch (e) {
    console.error('Error saving account level state:', e);
  }
}

/**
 * Load User Diamonds
 */
export function loadUserDiamonds(): number {
  try {
    const saved = localStorage.getItem(STORAGE_KEY_USER_DIAMONDS);
    if (saved !== null) {
      const parsed = parseInt(saved, 10);
      if (!isNaN(parsed) && parsed >= 0) return parsed;
    }
  } catch (e) {
    console.error('Error loading user diamonds:', e);
  }
  return INITIAL_DIAMONDS;
}

/**
 * Save User Diamonds
 */
export function saveUserDiamonds(diamonds: number): void {
  try {
    localStorage.setItem(STORAGE_KEY_USER_DIAMONDS, diamonds.toString());
  } catch (e) {
    console.error('Error saving user diamonds:', e);
  }
}

/**
 * Claim level reward in state
 */
export function claimLevelRewardInState(
  state: AccountLevelState,
  level: number
): AccountLevelState {
  if (state.claimedLevelRewards.includes(level)) return state;
  const reward = LEVEL_REWARDS.find((r) => r.level === level);
  const addedDiamonds = reward ? reward.rewardDiamonds : 5;

  const updated: AccountLevelState = {
    ...state,
    diamonds: state.diamonds + addedDiamonds,
    totalDiamondsEarned: state.totalDiamondsEarned + addedDiamonds,
    claimedLevelRewards: [...state.claimedLevelRewards, level],
  };
  saveAccountLevelState(updated);
  return updated;
}

/**
 * Add XP and check for Level Up
 */
export function addXPAndCheckLevelUp(
  prevState: AccountLevelState,
  xpToAdd: number
): {
  newState: AccountLevelState;
  updatedState: AccountLevelState;
  didLevelUp: boolean;
  levelUpEvent: LevelUpEventData | null;
  levelUpEvents: LevelUpEventData[];
} {
  let level = prevState.currentLevel;
  let xp = prevState.currentXP + xpToAdd;
  const totalAccumulatedXP = prevState.totalAccumulatedXP + xpToAdd;
  const levelUpEvents: LevelUpEventData[] = [];

  let requiredXP = getXPRequiredForLevel(level);

  while (xp >= requiredXP && level < 100) {
    const prevLvl = level;
    xp -= requiredXP;
    level += 1;
    requiredXP = getXPRequiredForLevel(level);

    const reward = LEVEL_REWARDS.find((r) => r.level === level) || {
      level,
      titleBn: `লেভেল ${level}`,
      rewardCoins: 500,
      rewardDiamonds: 5,
      tierNameBn: getTierByLevel(level).nameBn,
    };

    levelUpEvents.push({
      previousLevel: prevLvl,
      newLevel: level,
      rewardCoins: reward.rewardCoins,
      rewardDiamonds: reward.rewardDiamonds,
      reward: {
        coins: reward.rewardCoins,
        diamonds: reward.rewardDiamonds,
      },
      tierTitleBn: reward.tierNameBn,
      exclusivePerk: reward.exclusiveItem,
    });
  }

  const newState: AccountLevelState = {
    ...prevState,
    currentLevel: level,
    currentXP: xp,
    totalAccumulatedXP,
    lastLevelUpTimestamp: levelUpEvents.length > 0 ? Date.now() : prevState.lastLevelUpTimestamp,
  };

  saveAccountLevelState(newState);

  return {
    newState,
    updatedState: newState,
    didLevelUp: levelUpEvents.length > 0,
    levelUpEvent: levelUpEvents.length > 0 ? levelUpEvents[levelUpEvents.length - 1] : null,
    levelUpEvents,
  };
}
