import {
  BoardThemeId,
  DiceStyleId,
  DiceFaceStyle,
  TokenStyleId,
  GameBackgroundId,
  CustomizationConfig,
  PlayerColor,
} from '../types';

export interface BoardThemeDef {
  id: BoardThemeId;
  nameBn: string;
  nameEn: string;
  descriptionBn: string;
  badge: string;
  previewBg: string;
  outerFrameClass: string;
  gridBorderClass: string;
  trackCellBg: string;
  trackCellBorder: string;
  trackCellText: string;
  safeStarColor: string;
  safeStarFill: string;
  yardBgs: Record<PlayerColor, { bg: string; border: string; dockBg: string; dockBorder: string; text: string }>;
  homeLanes: Record<PlayerColor, { bg: string; border: string; text: string }>;
  startCells: Record<PlayerColor, { bg: string; border: string; text: string }>;
  centerHome: {
    bgClass: string;
    borderClass: string;
    triangleOpacity: string;
    centerBadgeClass: string;
  };
}

export interface DiceStyleDef {
  id: DiceStyleId;
  nameBn: string;
  nameEn: string;
  descriptionBn: string;
  badge: string;
  bodyGradient: string;
  borderClass: string;
  shadowClass: string;
  dotColor: string;
  centerDotColor: string;
  numberColor: string;
  highlightGlow: string;
}

export interface TokenStyleDef {
  id: TokenStyleId;
  nameBn: string;
  nameEn: string;
  descriptionBn: string;
  badge: string;
  iconName: string;
}

export interface GameBackgroundDef {
  id: GameBackgroundId;
  nameBn: string;
  nameEn: string;
  descriptionBn: string;
  badge: string;
  themeTone: 'light' | 'dark' | 'rich';
  containerBgClass: string;
  headerClass: string;
  subHeaderClass: string;
  footerClass: string;
  sidebarCardClass: string;
  patternType: 'velvet' | 'wood' | 'stars' | 'hex' | 'marble' | 'damask' | 'none';
  accentBorder: string;
  previewGradient: string;
}

export const DEFAULT_CUSTOMIZATION: CustomizationConfig = {
  boardTheme: 'classic',
  diceStyle: 'classic',
  diceFace: 'dots',
  tokenStyle: 'classic',
  gameBackground: 'bd_flag',
  bgPattern: 'none',
  bgBrightness: 100,
};

export const GAME_BACKGROUNDS: GameBackgroundDef[] = [
  {
    id: 'bd_flag',
    nameBn: 'বাংলাদেশের লাল-সবুজ পতাকা',
    nameEn: 'Bangladesh Flag (National)',
    descriptionBn: 'গৌরবময় লাল-সবুজ জাতীয় পতাকার চিরসবুজ জমিন ও রক্তিম সূর্য',
    badge: 'বাংলাদেশ',
    themeTone: 'dark',
    containerBgClass: 'bg-[#006a4e]',
    headerClass: 'bg-[#004d39]/95 backdrop-blur-md border-emerald-500/60 shadow-lg text-emerald-50',
    subHeaderClass: 'bg-[#003829]/95 border-emerald-600/60 text-emerald-200',
    footerClass: 'bg-[#004d39]/95 border-emerald-600/60 text-emerald-200',
    sidebarCardClass: 'bg-[#00523d]/90 backdrop-blur-md border-emerald-500/50 text-emerald-50 shadow-xl',
    patternType: 'none',
    accentBorder: 'border-rose-500',
    previewGradient: 'from-[#006a4e] via-[#006a4e] to-[#f42a41]',
  },
  {
    id: 'classic_amber',
    nameBn: 'উষ্ণ ক্লাসিক অ্যাম্বার',
    nameEn: 'Warm Classic Amber',
    descriptionBn: 'চিরচেনা উষ্ণ সোনালী অ্যাম্বার ও রাজকীয় আভিজাত্যের পরিবেশ',
    badge: 'ডিফল্ট',
    themeTone: 'light',
    containerBgClass: 'bg-gradient-to-br from-amber-50 via-orange-50/50 to-amber-100/70',
    headerClass: 'bg-white/95 backdrop-blur-md border-amber-200 shadow-sm text-slate-900',
    subHeaderClass: 'bg-amber-100/80 border-amber-200 text-amber-950',
    footerClass: 'bg-white/90 border-amber-200 text-slate-600',
    sidebarCardClass: 'bg-white border-amber-200 shadow-md',
    patternType: 'none',
    accentBorder: 'border-amber-400',
    previewGradient: 'from-amber-100 via-amber-200 to-orange-200',
  },
  {
    id: 'casino_green',
    nameBn: 'রয়্যাল ক্যাসিনো ভেলভেট',
    nameEn: 'Casino Emerald Felt',
    descriptionBn: 'অভিজাত ভিআইপি ক্লাবের পান্না সবুজ ভেলভেট কাপড়ের টেবিল',
    badge: 'জনপ্রিয়',
    themeTone: 'dark',
    containerBgClass: 'bg-gradient-to-br from-[#062c19] via-[#093f24] to-[#041a0f]',
    headerClass: 'bg-[#0b3820]/90 backdrop-blur-md border-emerald-600/60 shadow-lg text-emerald-50',
    subHeaderClass: 'bg-[#062414]/90 border-emerald-700/60 text-emerald-200',
    footerClass: 'bg-[#082a18]/95 border-emerald-700/60 text-emerald-300',
    sidebarCardClass: 'bg-[#0c3a21]/80 backdrop-blur-md border-emerald-600/50 text-emerald-50 shadow-xl',
    patternType: 'velvet',
    accentBorder: 'border-emerald-400',
    previewGradient: 'from-emerald-700 via-emerald-800 to-emerald-950',
  },
  {
    id: 'royal_purple',
    nameBn: 'রাজকীয় পার্পল লাউঞ্জ',
    nameEn: 'Imperial Purple Velvet',
    descriptionBn: 'গভীর রাজকীয় বেগুনী ভেলভেট ও সুবর্ণ আভাযুক্ত বিলাসী আবহ',
    badge: 'লাক্সারি',
    themeTone: 'dark',
    containerBgClass: 'bg-gradient-to-br from-[#1d0c2e] via-[#2d1245] to-[#12061e]',
    headerClass: 'bg-[#291141]/90 backdrop-blur-md border-purple-500/60 shadow-lg text-purple-50',
    subHeaderClass: 'bg-[#180927]/90 border-purple-600/60 text-purple-200',
    footerClass: 'bg-[#1e0a31]/95 border-purple-600/60 text-purple-300',
    sidebarCardClass: 'bg-[#2a1242]/80 backdrop-blur-md border-purple-500/50 text-purple-50 shadow-xl',
    patternType: 'damask',
    accentBorder: 'border-purple-400',
    previewGradient: 'from-purple-800 via-indigo-900 to-purple-950',
  },
  {
    id: 'cyber_neon',
    nameBn: 'সাইবার নিওন গ্যালাক্সি',
    nameEn: 'Cyber Neon Galaxy',
    descriptionBn: 'উজ্জ্বল নিওন স্ট্রেস, গ্যালাক্সি মহাকাশ ও আর্কেড আলোর ঝলক',
    badge: 'ফিউচারিস্টিক',
    themeTone: 'dark',
    containerBgClass: 'bg-gradient-to-br from-[#070b19] via-[#0f172a] to-[#050813]',
    headerClass: 'bg-[#0c142b]/90 backdrop-blur-md border-cyan-500/60 shadow-[0_0_20px_rgba(6,182,212,0.2)] text-cyan-50',
    subHeaderClass: 'bg-[#080d1e]/90 border-cyan-700/60 text-cyan-200',
    footerClass: 'bg-[#091024]/95 border-cyan-700/60 text-cyan-300',
    sidebarCardClass: 'bg-[#0d1836]/80 backdrop-blur-md border-cyan-500/40 text-cyan-50 shadow-xl',
    patternType: 'hex',
    accentBorder: 'border-cyan-400',
    previewGradient: 'from-cyan-900 via-slate-900 to-indigo-950',
  },
  {
    id: 'marble_palace',
    nameBn: 'শ্বেত মার্বেল রাজমহল',
    nameEn: 'White Palace Marble',
    descriptionBn: 'ধবধবে শ্বেত মার্বেল মেঝে ও স্বর্ণালী কারুকার্যময় রাজপ্রাসাদ',
    badge: 'অভিজাত',
    themeTone: 'light',
    containerBgClass: 'bg-gradient-to-br from-slate-100 via-amber-50/60 to-slate-200/80',
    headerClass: 'bg-white/95 backdrop-blur-md border-amber-300 shadow-md text-slate-900',
    subHeaderClass: 'bg-slate-100/90 border-amber-200 text-slate-800',
    footerClass: 'bg-white/90 border-amber-200 text-slate-600',
    sidebarCardClass: 'bg-white/95 border-amber-200/90 text-slate-900 shadow-md',
    patternType: 'marble',
    accentBorder: 'border-amber-400',
    previewGradient: 'from-slate-100 via-amber-50 to-slate-200',
  },
  {
    id: 'sunset_red',
    nameBn: 'সানসেট রুবি গ্লো',
    nameEn: 'Sunset Ruby Glow',
    descriptionBn: 'গোধূলির রক্তিম আভা, রুবি রত্ন ও উষ্ণ আগুনের স্ফুলিঙ্গ',
    badge: 'উজ্জ্বল',
    themeTone: 'dark',
    containerBgClass: 'bg-gradient-to-br from-[#3b0d11] via-[#521319] to-[#240609]',
    headerClass: 'bg-[#4a1016]/90 backdrop-blur-md border-rose-500/60 shadow-lg text-rose-50',
    subHeaderClass: 'bg-[#2e090d]/90 border-rose-700/60 text-rose-200',
    footerClass: 'bg-[#360b10]/95 border-rose-700/60 text-rose-300',
    sidebarCardClass: 'bg-[#4d1218]/80 backdrop-blur-md border-rose-500/50 text-rose-50 shadow-xl',
    patternType: 'stars',
    accentBorder: 'border-rose-400',
    previewGradient: 'from-rose-800 via-red-900 to-amber-950',
  },
  {
    id: 'ocean_breeze',
    nameBn: 'সাগর নীল ওয়েসিস',
    nameEn: 'Ocean Blue Waves',
    descriptionBn: 'গভীর সমুদ্রের শান্ত নীল জলরাশি ও স্নিগ্ধ প্রশান্তির আবহ',
    badge: 'শান্তিময়',
    themeTone: 'dark',
    containerBgClass: 'bg-gradient-to-br from-[#061e38] via-[#0b2f56] to-[#041324]',
    headerClass: 'bg-[#092b4f]/90 backdrop-blur-md border-sky-500/60 shadow-lg text-sky-50',
    subHeaderClass: 'bg-[#05192e]/90 border-sky-700/60 text-sky-200',
    footerClass: 'bg-[#07213d]/95 border-sky-700/60 text-sky-300',
    sidebarCardClass: 'bg-[#0a315b]/80 backdrop-blur-md border-sky-500/50 text-sky-50 shadow-xl',
    patternType: 'stars',
    accentBorder: 'border-sky-400',
    previewGradient: 'from-sky-800 via-blue-900 to-slate-950',
  },
  {
    id: 'midnight_carbon',
    nameBn: 'মিডনাইট ব্ল্যাক লাক্সারি',
    nameEn: 'Midnight Carbon Gold',
    descriptionBn: 'অভিজাত ডার্ক কার্বন ব্ল্যাক ও সোনালী বর্ডারের লাক্সারি ডার্ক মোড',
    badge: 'ডার্ক মোড',
    themeTone: 'dark',
    containerBgClass: 'bg-gradient-to-br from-[#0f1117] via-[#161922] to-[#0a0c10]',
    headerClass: 'bg-[#151821]/90 backdrop-blur-md border-amber-500/50 shadow-xl text-slate-100',
    subHeaderClass: 'bg-[#0e1017]/90 border-amber-600/40 text-amber-200',
    footerClass: 'bg-[#11131a]/95 border-amber-600/40 text-slate-400',
    sidebarCardClass: 'bg-[#181c26]/80 backdrop-blur-md border-slate-700/60 text-slate-100 shadow-xl',
    patternType: 'hex',
    accentBorder: 'border-amber-400',
    previewGradient: 'from-slate-900 via-slate-950 to-amber-950',
  },
  {
    id: 'custom_photo',
    nameBn: 'গ্যালারি ফটো / ওয়ালপেপার',
    nameEn: 'Custom Gallery Wallpaper',
    descriptionBn: 'আপনার মোবাইল বা কম্পিউটার গ্যালারি থেকে যেকোনো ছবি বা ওয়ালপেপার',
    badge: 'কাস্টম',
    themeTone: 'rich',
    containerBgClass: 'bg-slate-950',
    headerClass: 'bg-slate-900/85 backdrop-blur-md border-amber-400/60 shadow-xl text-white',
    subHeaderClass: 'bg-slate-950/80 backdrop-blur-md border-slate-700 text-amber-200',
    footerClass: 'bg-slate-900/90 backdrop-blur-md border-slate-700 text-slate-300',
    sidebarCardClass: 'bg-slate-900/75 backdrop-blur-md border-slate-700/80 text-white shadow-xl',
    patternType: 'none',
    accentBorder: 'border-amber-400',
    previewGradient: 'from-purple-900 via-amber-800 to-indigo-950',
  },
];

export const CURATED_WALLPAPERS = [
  {
    id: 'wall_casino',
    title: 'রয়্যাল ক্লাব গ্রিন',
    category: 'ক্যাসিনো',
    url: 'https://images.unsplash.com/photo-1511193311914-0346f16efe90?auto=format&fit=crop&w=1200&q=80',
  },
  {
    id: 'wall_wood',
    title: 'মেহগনি উড লাউঞ্জ',
    category: 'উডেন',
    url: 'https://images.unsplash.com/photo-1546484396-fb3fc6f95f98?auto=format&fit=crop&w=1200&q=80',
  },
  {
    id: 'wall_galaxy',
    title: 'কসমিক নিওন স্টার্স',
    category: 'মহাকাশ',
    url: 'https://images.unsplash.com/photo-1506703719100-a0f3a48c0f86?auto=format&fit=crop&w=1200&q=80',
  },
  {
    id: 'wall_marble',
    title: 'গোল্ডেন মার্বেল লাক্সারি',
    category: 'মার্বেল',
    url: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80',
  },
  {
    id: 'wall_sunset',
    title: 'গোধূলি সানসেট স্কাই',
    category: 'প্রকৃতি',
    url: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1200&q=80',
  },
  {
    id: 'wall_night_city',
    title: 'সাইবার সিটি আর্কেড',
    category: 'আর্কেড',
    url: 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?auto=format&fit=crop&w=1200&q=80',
  },
];

export const BOARD_THEMES: BoardThemeDef[] = [
  {
    id: 'classic',
    nameBn: 'ঐতিহ্যবাহী ক্ল্যাসিক',
    nameEn: 'Classic Bengali',
    descriptionBn: 'চিরচেনা ঐতিহ্যবাহী উজ্জ্বল রঙিন লুডু বোর্ড',
    badge: 'ডিফল্ট',
    previewBg: 'from-amber-100 to-amber-200',
    outerFrameClass:
      'bg-gradient-to-br from-amber-50 via-white to-amber-100 border-b-8 border-amber-300 border-x-2 border-t-2 border-amber-200 shadow-2xl',
    gridBorderClass: 'border-4 border-slate-900 shadow-md',
    trackCellBg: 'bg-slate-100',
    trackCellBorder: 'border-slate-300',
    trackCellText: 'text-slate-800',
    safeStarColor: '#f59e0b',
    safeStarFill: '#fbbf24',
    yardBgs: {
      red: { bg: '#fee2e2', border: '#e11d48', dockBg: 'bg-slate-100', dockBorder: 'border-slate-300', text: '#be123c' },
      green: { bg: '#dcfce7', border: '#16a34a', dockBg: 'bg-slate-100', dockBorder: 'border-slate-300', text: '#15803d' },
      yellow: { bg: '#fef3c7', border: '#d97706', dockBg: 'bg-slate-100', dockBorder: 'border-slate-300', text: '#b45309' },
      blue: { bg: '#dbeafe', border: '#2563eb', dockBg: 'bg-slate-100', dockBorder: 'border-slate-300', text: '#1d4ed8' },
    },
    homeLanes: {
      red: { bg: 'bg-rose-500', border: 'border-rose-600', text: 'text-white' },
      green: { bg: 'bg-emerald-500', border: 'border-emerald-600', text: 'text-white' },
      yellow: { bg: 'bg-amber-400', border: 'border-amber-500', text: 'text-slate-900' },
      blue: { bg: 'bg-blue-500', border: 'border-blue-600', text: 'text-white' },
    },
    startCells: {
      red: { bg: 'bg-rose-100', border: 'border-rose-400', text: 'text-rose-700' },
      green: { bg: 'bg-emerald-100', border: 'border-emerald-400', text: 'text-emerald-700' },
      yellow: { bg: 'bg-amber-100', border: 'border-amber-400', text: 'text-amber-700' },
      blue: { bg: 'bg-blue-100', border: 'border-blue-400', text: 'text-blue-700' },
    },
    centerHome: {
      bgClass: 'bg-slate-900',
      borderClass: 'border-2 border-slate-700',
      triangleOpacity: '0.9',
      centerBadgeClass: 'bg-gradient-to-tr from-amber-400 via-yellow-200 to-amber-500 border-amber-300 text-slate-950',
    },
  },
  {
    id: 'wooden',
    nameBn: 'রয়্যাল উডেন (কাষ্ঠল)',
    nameEn: 'Royal Wooden',
    descriptionBn: 'অভিজাত রাজকীয় মেহগনি কাঠ ও পিতলের খোদাই করা ফিনিশ',
    badge: 'অভিজাত',
    previewBg: 'from-amber-900 to-amber-950',
    outerFrameClass:
      'bg-gradient-to-br from-[#381e11] via-[#2a140a] to-[#1a0c06] border-b-8 border-[#140804] border-x-4 border-t-4 border-amber-700/80 shadow-[0_20px_50px_rgba(0,0,0,0.6)] ring-4 ring-amber-900/60',
    gridBorderClass: 'border-4 border-[#2b160b] shadow-xl',
    trackCellBg: 'bg-[#FAF2DF]',
    trackCellBorder: 'border-[#D9C4A1]',
    trackCellText: 'text-amber-950',
    safeStarColor: '#b45309',
    safeStarFill: '#f59e0b',
    yardBgs: {
      red: { bg: '#541c1c', border: '#dc2626', dockBg: 'bg-[#F3E5C8]', dockBorder: 'border-[#CBB691]', text: '#fecaca' },
      green: { bg: '#1c4526', border: '#22c55e', dockBg: 'bg-[#F3E5C8]', dockBorder: 'border-[#CBB691]', text: '#bbf7d0' },
      yellow: { bg: '#593b13', border: '#eab308', dockBg: 'bg-[#F3E5C8]', dockBorder: 'border-[#CBB691]', text: '#fef08a' },
      blue: { bg: '#1c3459', border: '#3b82f6', dockBg: 'bg-[#F3E5C8]', dockBorder: 'border-[#CBB691]', text: '#bfdbfe' },
    },
    homeLanes: {
      red: { bg: 'bg-[#991b1b]', border: 'border-[#7f1d1d]', text: 'text-amber-100' },
      green: { bg: 'bg-[#14532d]', border: 'border-[#052e16]', text: 'text-emerald-100' },
      yellow: { bg: 'bg-[#b45309]', border: 'border-[#92400e]', text: 'text-amber-100' },
      blue: { bg: 'bg-[#1e3a8a]', border: 'border-[#172554]', text: 'text-blue-100' },
    },
    startCells: {
      red: { bg: 'bg-[#fed7d7]', border: 'border-[#b91c1c]', text: 'text-[#7f1d1d]' },
      green: { bg: 'bg-[#d1fae5]', border: 'border-[#15803d]', text: 'text-[#065f46]' },
      yellow: { bg: 'bg-[#fef08a]', border: 'border-[#d97706]', text: 'text-[#854d0e]' },
      blue: { bg: 'bg-[#dbeafe]', border: 'border-[#1d4ed8]', text: 'text-[#1e40af]' },
    },
    centerHome: {
      bgClass: 'bg-[#211107]',
      borderClass: 'border-2 border-amber-600',
      triangleOpacity: '0.92',
      centerBadgeClass: 'bg-gradient-to-tr from-amber-500 via-amber-300 to-yellow-600 border-amber-400 text-amber-950',
    },
  },
  {
    id: 'neon',
    nameBn: 'সাইবার নিওন (আর্কেড)',
    nameEn: 'Cyber Neon',
    descriptionBn: 'উজ্জ্বল নিওন আলো ও ডার্ক হাই-টেক আর্কেড অনুভূতি',
    badge: 'ফিউচারিস্টিক',
    previewBg: 'from-slate-950 via-purple-950 to-slate-900',
    outerFrameClass:
      'bg-gradient-to-br from-slate-950 via-[#130d24] to-[#0a0715] border-b-8 border-cyan-700 border-x-4 border-t-4 border-purple-500/80 shadow-[0_0_40px_rgba(6,182,212,0.45)] ring-4 ring-cyan-900/50',
    gridBorderClass: 'border-4 border-cyan-400 shadow-[0_0_20px_rgba(6,182,212,0.5)]',
    trackCellBg: 'bg-[#0a0f1d]',
    trackCellBorder: 'border-cyan-900/60',
    trackCellText: 'text-cyan-300',
    safeStarColor: '#06b6d4',
    safeStarFill: '#22d3ee',
    yardBgs: {
      red: { bg: '#250813', border: '#f43f5e', dockBg: 'bg-[#150a1e]', dockBorder: 'border-pink-500/60', text: '#fb7185' },
      green: { bg: '#062319', border: '#10b981', dockBg: 'bg-[#081e18]', dockBorder: 'border-emerald-500/60', text: '#34d399' },
      yellow: { bg: '#292005', border: '#facc15', dockBg: 'bg-[#1a1708]', dockBorder: 'border-amber-500/60', text: '#fde047' },
      blue: { bg: '#081c30', border: '#06b6d4', dockBg: 'bg-[#091726]', dockBorder: 'border-cyan-500/60', text: '#38bdf8' },
    },
    homeLanes: {
      red: { bg: 'bg-rose-600 shadow-[0_0_12px_#f43f5e]', border: 'border-pink-400', text: 'text-white' },
      green: { bg: 'bg-emerald-600 shadow-[0_0_12px_#10b981]', border: 'border-emerald-400', text: 'text-white' },
      yellow: { bg: 'bg-yellow-400 shadow-[0_0_12px_#facc15]', border: 'border-amber-300', text: 'text-slate-950' },
      blue: { bg: 'bg-cyan-500 shadow-[0_0_12px_#06b6d4]', border: 'border-cyan-300', text: 'text-slate-950' },
    },
    startCells: {
      red: { bg: 'bg-rose-950/80', border: 'border-rose-500', text: 'text-pink-300' },
      green: { bg: 'bg-emerald-950/80', border: 'border-emerald-500', text: 'text-emerald-300' },
      yellow: { bg: 'bg-amber-950/80', border: 'border-amber-500', text: 'text-yellow-300' },
      blue: { bg: 'bg-cyan-950/80', border: 'border-cyan-500', text: 'text-cyan-300' },
    },
    centerHome: {
      bgClass: 'bg-[#05060b]',
      borderClass: 'border-2 border-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.6)]',
      triangleOpacity: '0.95',
      centerBadgeClass: 'bg-gradient-to-tr from-cyan-400 via-purple-400 to-pink-500 border-cyan-300 text-white shadow-[0_0_15px_rgba(6,182,212,0.8)]',
    },
  },
  {
    id: 'marble',
    nameBn: 'মার্বেল প্যালেস (স্বর্ণালী)',
    nameEn: 'Marble Palace',
    descriptionBn: 'শ্বেত মার্বেল পাথর ও স্বর্ণালী কারুকাজের রাজপ্রাসাদ লুক',
    badge: 'লাক্সারি',
    previewBg: 'from-slate-100 via-amber-50 to-amber-100',
    outerFrameClass:
      'bg-gradient-to-br from-slate-50 via-white to-amber-50 border-b-8 border-amber-400 border-x-4 border-t-4 border-amber-300 shadow-[0_20px_50px_rgba(217,119,6,0.25)] ring-4 ring-amber-400/30',
    gridBorderClass: 'border-4 border-amber-700 shadow-lg',
    trackCellBg: 'bg-[#FCFCFA]',
    trackCellBorder: 'border-amber-200/90',
    trackCellText: 'text-slate-800',
    safeStarColor: '#d97706',
    safeStarFill: '#f59e0b',
    yardBgs: {
      red: { bg: '#fff1f2', border: '#e11d48', dockBg: 'bg-white', dockBorder: 'border-amber-200', text: '#9f1239' },
      green: { bg: '#f0fdf4', border: '#16a34a', dockBg: 'bg-white', dockBorder: 'border-amber-200', text: '#166534' },
      yellow: { bg: '#fffbeb', border: '#d97706', dockBg: 'bg-white', dockBorder: 'border-amber-200', text: '#92400e' },
      blue: { bg: '#eff6ff', border: '#2563eb', dockBg: 'bg-white', dockBorder: 'border-amber-200', text: '#1e40af' },
    },
    homeLanes: {
      red: { bg: 'bg-gradient-to-br from-red-500 to-rose-600', border: 'border-red-700', text: 'text-white' },
      green: { bg: 'bg-gradient-to-br from-emerald-500 to-teal-600', border: 'border-emerald-700', text: 'text-white' },
      yellow: { bg: 'bg-gradient-to-br from-amber-400 to-yellow-500', border: 'border-amber-600', text: 'text-amber-950' },
      blue: { bg: 'bg-gradient-to-br from-blue-500 to-indigo-600', border: 'border-blue-700', text: 'text-white' },
    },
    startCells: {
      red: { bg: 'bg-red-50', border: 'border-red-300', text: 'text-red-700' },
      green: { bg: 'bg-emerald-50', border: 'border-emerald-300', text: 'text-emerald-700' },
      yellow: { bg: 'bg-amber-50', border: 'border-amber-300', text: 'text-amber-700' },
      blue: { bg: 'bg-blue-50', border: 'border-blue-300', text: 'text-blue-700' },
    },
    centerHome: {
      bgClass: 'bg-slate-900',
      borderClass: 'border-2 border-amber-400',
      triangleOpacity: '0.92',
      centerBadgeClass: 'bg-gradient-to-tr from-amber-300 via-yellow-200 to-amber-500 border-amber-400 text-amber-950 shadow-md',
    },
  },
  {
    id: 'nature',
    nameBn: 'ফরেস্ট ওয়েসিস (প্রকৃতি)',
    nameEn: 'Forest Oasis',
    descriptionBn: 'শান্ত সবুজ অরণ্য ও প্রাকৃতিক মাটির স্নিগ্ধ আবহ',
    badge: 'ন্যাচারাল',
    previewBg: 'from-emerald-800 to-green-950',
    outerFrameClass:
      'bg-gradient-to-br from-emerald-950 via-[#13301c] to-[#0b1c11] border-b-8 border-emerald-900 border-x-4 border-t-4 border-lime-600/70 shadow-[0_20px_40px_rgba(22,101,52,0.35)] ring-4 ring-emerald-800/40',
    gridBorderClass: 'border-4 border-emerald-950 shadow-lg',
    trackCellBg: 'bg-[#F6FAF1]',
    trackCellBorder: 'border-[#CBDBC0]',
    trackCellText: 'text-emerald-950',
    safeStarColor: '#65a30d',
    safeStarFill: '#84cc16',
    yardBgs: {
      red: { bg: '#fef2f2', border: '#b91c1c', dockBg: 'bg-[#EDF5E6]', dockBorder: 'border-[#CBDBC0]', text: '#991b1b' },
      green: { bg: '#ecfdf5', border: '#047857', dockBg: 'bg-[#EDF5E6]', dockBorder: 'border-[#CBDBC0]', text: '#065f46' },
      yellow: { bg: '#fefce8', border: '#ca8a04', dockBg: 'bg-[#EDF5E6]', dockBorder: 'border-[#CBDBC0]', text: '#854d0e' },
      blue: { bg: '#f0fdfa', border: '#0e7490', dockBg: 'bg-[#EDF5E6]', dockBorder: 'border-[#CBDBC0]', text: '#155e75' },
    },
    homeLanes: {
      red: { bg: 'bg-[#dc2626]', border: 'border-red-800', text: 'text-white' },
      green: { bg: 'bg-[#15803d]', border: 'border-green-900', text: 'text-white' },
      yellow: { bg: 'bg-[#d97706]', border: 'border-amber-800', text: 'text-amber-950' },
      blue: { bg: 'bg-[#0284c7]', border: 'border-sky-900', text: 'text-white' },
    },
    startCells: {
      red: { bg: 'bg-red-100', border: 'border-red-400', text: 'text-red-800' },
      green: { bg: 'bg-emerald-100', border: 'border-emerald-400', text: 'text-emerald-800' },
      yellow: { bg: 'bg-amber-100', border: 'border-amber-400', text: 'text-amber-800' },
      blue: { bg: 'bg-sky-100', border: 'border-sky-400', text: 'text-sky-800' },
    },
    centerHome: {
      bgClass: 'bg-[#0d2816]',
      borderClass: 'border-2 border-emerald-600',
      triangleOpacity: '0.9',
      centerBadgeClass: 'bg-gradient-to-tr from-lime-400 via-emerald-300 to-green-500 border-lime-300 text-emerald-950',
    },
  },
];

export const DICE_STYLES: DiceStyleDef[] = [
  {
    id: 'classic',
    nameBn: 'ক্ল্যাসিক আইভরি',
    nameEn: 'Classic Ivory',
    descriptionBn: 'ধবধবে সাদা মসৃণ হাতির দাঁতের ডাইস ও কালো-লাল ডট',
    badge: 'ডিফল্ট',
    bodyGradient: 'bg-gradient-to-br from-white via-slate-50 to-slate-200',
    borderClass: 'border-slate-900',
    shadowClass: 'shadow-lg',
    dotColor: 'bg-slate-900',
    centerDotColor: 'bg-rose-600',
    numberColor: 'text-slate-900',
    highlightGlow: 'ring-slate-400',
  },
  {
    id: 'golden',
    nameBn: 'রয়্যাল গোল্ড (স্বর্ণালী)',
    nameEn: 'Royal Gold',
    descriptionBn: 'ঝলমলে পালিশ করা খাঁটি সোনার ডাইস ও রুবি খচিত নকশা',
    badge: 'প্রিমিয়াম',
    bodyGradient: 'bg-gradient-to-br from-amber-200 via-yellow-400 to-amber-600',
    borderClass: 'border-amber-800',
    shadowClass: 'shadow-xl shadow-amber-500/40',
    dotColor: 'bg-amber-950',
    centerDotColor: 'bg-rose-700',
    numberColor: 'text-amber-950',
    highlightGlow: 'ring-amber-300',
  },
  {
    id: 'crystal',
    nameBn: 'ক্রিস্টাল স্যাফায়ার',
    nameEn: 'Crystal Sapphire',
    descriptionBn: 'স্বচ্ছ বরফ-নীল ক্রিস্টাল কাচ ও জ্বলন্ত নিওন আলো',
    badge: 'স্পেশাল',
    bodyGradient: 'bg-gradient-to-br from-cyan-300 via-blue-500 to-indigo-700',
    borderClass: 'border-cyan-300',
    shadowClass: 'shadow-xl shadow-cyan-500/50',
    dotColor: 'bg-white shadow-[0_0_8px_#ffffff]',
    centerDotColor: 'bg-yellow-300 shadow-[0_0_10px_#fde047]',
    numberColor: 'text-white drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]',
    highlightGlow: 'ring-cyan-400',
  },
  {
    id: 'wooden',
    nameBn: 'খোদাইকৃত কাষ্ঠল',
    nameEn: 'Carved Wood',
    descriptionBn: 'হাতে খোদাই করা ওক কাঠ ও আগুনে পোড়া পিতলের বিন্দু',
    badge: 'ভিন্টেজ',
    bodyGradient: 'bg-gradient-to-br from-amber-700 via-amber-800 to-amber-950',
    borderClass: 'border-amber-950',
    shadowClass: 'shadow-lg shadow-black/50',
    dotColor: 'bg-amber-200',
    centerDotColor: 'bg-yellow-400',
    numberColor: 'text-amber-100',
    highlightGlow: 'ring-amber-600',
  },
  {
    id: 'ruby',
    nameBn: 'রুবি ফায়ার (অগ্নিশিখা)',
    nameEn: 'Ruby Fire',
    descriptionBn: 'উত্তপ্ত লাল রক্তিম রুবি রত্ন ও উজ্জ্বল সোনালী বিন্দু',
    badge: 'লিজেন্ডারি',
    bodyGradient: 'bg-gradient-to-br from-rose-500 via-red-600 to-rose-900',
    borderClass: 'border-red-950',
    shadowClass: 'shadow-xl shadow-rose-600/50',
    dotColor: 'bg-amber-300 shadow-[0_0_6px_#fde047]',
    centerDotColor: 'bg-white shadow-[0_0_8px_#ffffff]',
    numberColor: 'text-amber-200 drop-shadow-md',
    highlightGlow: 'ring-red-400',
  },
];

export const DICE_FACE_OPTIONS = [
  {
    id: 'dots' as DiceFaceStyle,
    nameBn: 'ঐতিহ্যবাহী বিন্দু (Dots)',
    descriptionBn: 'ক্ল্যাসিক ডাইসের বিন্দু ফোটা ১ থেকে ৬',
  },
  {
    id: 'bengali_numbers' as DiceFaceStyle,
    nameBn: 'বাংলা সংখ্যা (১, ২, ৩, ৪, ৫, ৬)',
    descriptionBn: 'খাঁটি বাংলা হরফে লেখা সংখ্যা',
  },
  {
    id: 'english_numbers' as DiceFaceStyle,
    nameBn: 'ইংরেজি সংখ্যা (1, 2, 3, 4, 5, 6)',
    descriptionBn: 'বোল্ড আধুনিক আধুনিক ডিজিট',
  },
];

export const TOKEN_STYLES: TokenStyleDef[] = [
  {
    id: 'classic',
    nameBn: 'ক্ল্যাসিক ডিস্ক (পন)',
    nameEn: 'Classic Disc',
    descriptionBn: 'ঐতিহ্যবাহী ৩ডি মসৃণ গোলাকার চকচকে গুটি',
    badge: 'ডিফল্ট',
    iconName: 'disc',
  },
  {
    id: 'crown',
    nameBn: 'রয়্যাল ক্রাউন (মুকুট)',
    nameEn: 'Royal Crown',
    descriptionBn: 'রাজকীয় ৫-চূড়ার স্বর্ণালী মুকুট শোভিত গুটি',
    badge: 'অভিজাত',
    iconName: 'crown',
  },
  {
    id: 'shield',
    nameBn: 'ওয়ারিয়র শিল্ড (ঢাল)',
    nameEn: 'Warrior Shield',
    descriptionBn: 'যোদ্ধার আত্মরক্ষার মেটালিক খোদাই করা বর্ম-ঢাল',
    badge: 'সাহসী',
    iconName: 'shield',
  },
  {
    id: 'diamond',
    nameBn: 'ক্রিস্টাল ডায়মন্ড (রত্ন)',
    nameEn: 'Crystal Diamond',
    descriptionBn: 'আলো ঠিকরানো বহুভুজী চকচকে হিরের গুটি',
    badge: 'রত্নসম',
    iconName: 'diamond',
  },
  {
    id: 'star',
    nameBn: 'চ্যাম্পিয়ন স্টার (তারকা)',
    nameEn: 'Champion Star',
    descriptionBn: 'বিজয়ীর স্বর্ণালী ৫-কোণা জ্বলজ্বলে তারকা গুটি',
    badge: 'চ্যাম্পিয়ন',
    iconName: 'star',
  },
];

export const PRESET_BUNDLES = [
  {
    id: 'bundle_classic',
    nameBn: 'ঐতিহ্যবাহী নস্টালজিয়া',
    nameEn: 'Traditional Nostalgia',
    descriptionBn: 'ক্লাসিক অ্যাম্বার ব্যাকগ্রাউন্ড + ক্ল্যাসিক বোর্ড + আইভরি ডাইস + সাধারণ গুটি',
    descriptionEn: 'Classic Amber Background + Classic Board + Ivory Dice + Classic Tokens',
    config: {
      boardTheme: 'classic' as BoardThemeId,
      diceStyle: 'classic' as DiceStyleId,
      diceFace: 'dots' as DiceFaceStyle,
      tokenStyle: 'classic' as TokenStyleId,
      gameBackground: 'classic_amber' as GameBackgroundId,
    },
  },
  {
    id: 'bundle_royal',
    nameBn: 'রাজকীয় স্বর্ণালী মেহগনি',
    nameEn: 'Royal Golden Mahogany',
    descriptionBn: 'ক্যাসিনো গ্রিন ব্যাকগ্রাউন্ড + উডেন বোর্ড + রয়্যাল গোল্ড ডাইস + রাজমুকুট গুটি',
    descriptionEn: 'Casino Green Background + Wooden Board + Royal Gold Dice + Crown Tokens',
    config: {
      boardTheme: 'wooden' as BoardThemeId,
      diceStyle: 'golden' as DiceStyleId,
      diceFace: 'bengali_numbers' as DiceFaceStyle,
      tokenStyle: 'crown' as TokenStyleId,
      gameBackground: 'casino_green' as GameBackgroundId,
    },
  },
  {
    id: 'bundle_neon',
    nameBn: 'সাইবার নিওন গ্যালাক্সি',
    nameEn: 'Cyber Neon Galaxy',
    descriptionBn: 'নিওন গ্যালাক্সি ব্যাকগ্রাউন্ড + নিওন বোর্ড + ক্রিস্টাল ডাইস + ডায়মন্ড গুটি',
    descriptionEn: 'Neon Galaxy Background + Neon Board + Crystal Dice + Diamond Tokens',
    config: {
      boardTheme: 'neon' as BoardThemeId,
      diceStyle: 'crystal' as DiceStyleId,
      diceFace: 'english_numbers' as DiceFaceStyle,
      tokenStyle: 'diamond' as TokenStyleId,
      gameBackground: 'cyber_neon' as GameBackgroundId,
    },
  },
  {
    id: 'bundle_marble',
    nameBn: 'মার্বেল প্যালেস লাক্সারি',
    nameEn: 'Marble Palace Luxury',
    descriptionBn: 'শ্বেত মার্বেল ব্যাকগ্রাউন্ড + মার্বেল বোর্ড + গোল্ডেন ডাইস + তারকা গুটি',
    descriptionEn: 'White Marble Background + Marble Board + Golden Dice + Star Tokens',
    config: {
      boardTheme: 'marble' as BoardThemeId,
      diceStyle: 'golden' as DiceStyleId,
      diceFace: 'dots' as DiceFaceStyle,
      tokenStyle: 'star' as TokenStyleId,
      gameBackground: 'marble_palace' as GameBackgroundId,
    },
  },
  {
    id: 'bundle_purple',
    nameBn: 'ভিআইপি পার্পল লাউঞ্জ',
    nameEn: 'VIP Purple Lounge',
    descriptionBn: 'পার্পল ভেলভেট ব্যাকগ্রাউন্ড + উডেন বোর্ড + রুবি ফায়ার ডাইস + ক্রাউন গুটি',
    descriptionEn: 'Purple Velvet Background + Wooden Board + Ruby Fire Dice + Crown Tokens',
    config: {
      boardTheme: 'wooden' as BoardThemeId,
      diceStyle: 'ruby' as DiceStyleId,
      diceFace: 'bengali_numbers' as DiceFaceStyle,
      tokenStyle: 'crown' as TokenStyleId,
      gameBackground: 'royal_purple' as GameBackgroundId,
    },
  },
  {
    id: 'bundle_nature',
    nameBn: 'অরণ্য ও সাগর নীল',
    nameEn: 'Forest & Ocean Breeze',
    descriptionBn: 'সাগর নীল ব্যাকগ্রাউন্ড + ফরেস্ট বোর্ড + কাষ্ঠল ডাইস + শিল্ড গুটি',
    descriptionEn: 'Ocean Blue Background + Forest Board + Wooden Dice + Shield Tokens',
    config: {
      boardTheme: 'nature' as BoardThemeId,
      diceStyle: 'wooden' as DiceStyleId,
      diceFace: 'dots' as DiceFaceStyle,
      tokenStyle: 'shield' as TokenStyleId,
      gameBackground: 'ocean_breeze' as GameBackgroundId,
    },
  },
];
