import { AvatarConfig } from '../types';
import { CountryInfo, COUNTRIES_195 } from './countryData';
import { DEFAULT_AVATARS } from './ludoConstants';

export interface AddaSeat {
  seatIndex: number; // 0 to 9 (Total 10 seats)
  occupied: boolean;
  userId: string;
  userName: string;
  avatar: AvatarConfig;
  country: CountryInfo;
  isMuted: boolean;
  isSpeaking: boolean;
  isHost: boolean;
  coins: number;
  level: number;
  vipTitle?: string;
  handRaised?: boolean;
  score?: number;
  lastGift?: {
    icon: string;
    name: string;
    from: string;
    time: number;
  };
}

export interface AddaGift {
  id: string;
  name: string;
  icon: string;
  coinPrice: number;
  bengaliName: string;
  animationType: 'rose' | 'tea' | 'heart' | 'dice' | 'crown' | 'diamond' | 'fireworks';
  color: string;
}

export interface AddaSticker {
  id: string;
  title: string;
  emoji: string;
  badgeText: string;
  bgGradient: string;
  borderColor: string;
  category: 'adda' | 'ludo' | 'emotion' | 'fun';
}

export interface AddaMessage {
  id: string;
  userId: string;
  userName: string;
  userCountryFlag: string;
  userLevel?: number;
  text: string;
  isGift?: boolean;
  giftData?: {
    icon: string;
    name: string;
    count: number;
    toName: string;
  };
  isSticker?: boolean;
  stickerData?: {
    emoji: string;
    badgeText: string;
    bgGradient: string;
  };
  isHostNotice?: boolean;
  timestamp: number;
}

export interface AddaSoundClip {
  id: string;
  title: string;
  text: string;
  emoji: string;
  category: 'greeting' | 'cheer' | 'fun' | 'tea' | 'game';
}

export type AddaThemeId = 'royal_gold' | 'cyber_neon' | 'sunset_glow' | 'emerald_palace' | 'midnight_club';

export interface AddaRoom {
  id: string;
  title: string;
  tagline: string;
  category: 'friends' | 'ludo' | 'music' | 'probasee' | 'international';
  hostId: string;
  hostName: string;
  hostCountry: CountryInfo;
  hostAvatar: AvatarConfig;
  seats: (AddaSeat | null)[];
  spectatorCount: number;
  theme: AddaThemeId;
  ambience: 'acoustic_tea' | 'lofi_chill' | 'party_dhamaal' | 'bangla_adda' | 'none';
  tags: string[];
  gameMode: 'free_talk' | '10_dice_showdown' | 'lucky_number' | 'rapid_trivia';
  gameRound?: number;
  gameTargetNumber?: number;
  lastDiceWinner?: { name: string; score: number; avatar: AvatarConfig };
  createdAt: number;
}

// 7 Preset Animated Gifts
export const ADDA_GIFTS: AddaGift[] = [
  {
    id: 'gift_rose',
    name: 'Rose',
    bengaliName: 'লাল গোলাপ',
    icon: '🌹',
    coinPrice: 10,
    animationType: 'rose',
    color: 'from-rose-500 to-pink-600',
  },
  {
    id: 'gift_tea',
    name: 'Karak Chai',
    bengaliName: 'গরম চা',
    icon: '☕',
    coinPrice: 25,
    animationType: 'tea',
    color: 'from-amber-600 to-orange-700',
  },
  {
    id: 'gift_heart',
    name: 'Love Heart',
    bengaliName: 'হৃদয়ের ভালোবাসা',
    icon: '❤️',
    coinPrice: 50,
    animationType: 'heart',
    color: 'from-red-500 to-rose-600',
  },
  {
    id: 'gift_dice',
    name: 'Lucky Dice',
    bengaliName: 'গোল্ডেন ডাইস',
    icon: '🎲',
    coinPrice: 100,
    animationType: 'dice',
    color: 'from-amber-400 to-yellow-500',
  },
  {
    id: 'gift_crown',
    name: 'Royal Crown',
    bengaliName: 'রয়্যাল ক্রাউন',
    icon: '👑',
    coinPrice: 250,
    animationType: 'crown',
    color: 'from-yellow-400 to-amber-600',
  },
  {
    id: 'gift_diamond',
    name: 'Blue Diamond',
    bengaliName: 'নীল ডায়মন্ড',
    icon: '💎',
    coinPrice: 500,
    animationType: 'diamond',
    color: 'from-cyan-400 to-blue-600',
  },
  {
    id: 'gift_fireworks',
    name: 'Mega Fireworks',
    bengaliName: 'মেগা আতশবাজি',
    icon: '🎆',
    coinPrice: 1000,
    animationType: 'fireworks',
    color: 'from-purple-500 to-indigo-600',
  },
];

// Bengali Soundboard Voice Reactions
export const ADDA_SOUNDBOARD: AddaSoundClip[] = [
  { id: 'sb_1', title: 'কিরে ভাই!', text: 'কিরে ভাই কেমন আছিস?', emoji: '👋', category: 'greeting' },
  { id: 'sb_2', title: 'ছক্কা মারো!', text: 'আরে ভাই ছক্কা মারো!', emoji: '🎲', category: 'game' },
  { id: 'sb_3', title: 'আড্ডা জমবে!', text: 'আজকের আড্ডাটা পুরা জমবে!', emoji: '🔥', category: 'fun' },
  { id: 'sb_4', title: 'গান শোনাও!', text: 'দোস্ত একটা সুন্দর গান শোনাও তো!', emoji: '🎤', category: 'music' as any },
  { id: 'sb_5', title: 'চা খাবা?', text: 'চা কার কার লাগবে বলো?', emoji: '☕', category: 'tea' },
  { id: 'sb_6', title: 'অসাধারণ!', text: 'অসাধারণ খেলা হচ্ছে ভাই!', emoji: '✨', category: 'cheer' },
  { id: 'sb_7', title: 'তালি বাজাও!', text: 'সবাই একটু তালি বাজাও! 👏', emoji: '👏', category: 'cheer' },
  { id: 'sb_8', title: 'লুডো কিং!', text: 'আমিই লুডো আড্ডা কিং!', emoji: '👑', category: 'game' },
];

const findCountry = (code: string): CountryInfo => {
  return COUNTRIES_195.find((c) => c.code === code) || COUNTRIES_195[0];
};

// 12 Animated & Expressive Bengali Stickers for Live Adda & Ludo Board
export const ADDA_STICKERS: AddaSticker[] = [
  {
    id: 'stk_tea',
    title: 'চা দে রে ভাই!',
    emoji: '☕',
    badgeText: 'গরম চা লাগবে!',
    bgGradient: 'from-amber-600 to-orange-700',
    borderColor: 'border-amber-400',
    category: 'adda',
  },
  {
    id: 'stk_six',
    title: 'ছক্কা মারো!',
    emoji: '🎲',
    badgeText: 'এবার ছক্কা চাই!',
    bgGradient: 'from-blue-600 to-indigo-700',
    borderColor: 'border-blue-400',
    category: 'ludo',
  },
  {
    id: 'stk_fire',
    title: 'উরাধুরা আড্ডা!',
    emoji: '🔥',
    badgeText: 'আজ আড্ডা জমবে!',
    bgGradient: 'from-red-600 to-rose-700',
    borderColor: 'border-red-400',
    category: 'adda',
  },
  {
    id: 'stk_king',
    title: 'আমিই কিং 👑',
    emoji: '👑',
    badgeText: 'আড্ডার বস!',
    bgGradient: 'from-yellow-500 to-amber-600',
    borderColor: 'border-yellow-300',
    category: 'ludo',
  },
  {
    id: 'stk_love',
    title: 'লাভ ইউ দোস্ত! ❤️',
    emoji: '❤️',
    badgeText: 'বেস্ট ফ্রেন্ডস ফরএভার',
    bgGradient: 'from-pink-600 to-rose-600',
    borderColor: 'border-pink-400',
    category: 'emotion',
  },
  {
    id: 'stk_clap',
    title: 'তালি মারো 👏',
    emoji: '👏',
    badgeText: 'অসাধারণ পারফর্মেন্স!',
    bgGradient: 'from-emerald-600 to-teal-700',
    borderColor: 'border-emerald-400',
    category: 'fun',
  },
  {
    id: 'stk_sing',
    title: 'গান শোনাও 🎤',
    emoji: '🎤',
    badgeText: 'দোস্ত একটা গান গা!',
    bgGradient: 'from-purple-600 to-violet-700',
    borderColor: 'border-purple-400',
    category: 'adda',
  },
  {
    id: 'stk_rocket',
    title: 'বোর্ড কাঁপবে! 🚀',
    emoji: '🚀',
    badgeText: 'ফুল এনার্জি!',
    bgGradient: 'from-cyan-600 to-blue-700',
    borderColor: 'border-cyan-400',
    category: 'fun',
  },
  {
    id: 'stk_bd',
    title: 'জয় বাংলা! 🇧🇩',
    emoji: '🇧🇩',
    badgeText: 'হৃদয়ে বাংলাদেশ',
    bgGradient: 'from-green-700 to-emerald-800',
    borderColor: 'border-green-400',
    category: 'emotion',
  },
  {
    id: 'stk_laugh',
    title: 'হাসতে হাসতে শেষ 😂',
    emoji: '🤣',
    badgeText: 'মারো আমাকে মারো!',
    bgGradient: 'from-amber-500 to-yellow-600',
    borderColor: 'border-yellow-400',
    category: 'fun',
  },
  {
    id: 'stk_khelahobe',
    title: 'খেলা হবে! 💥',
    emoji: '💥',
    badgeText: 'তৈরি হও সবাই!',
    bgGradient: 'from-orange-600 to-red-700',
    borderColor: 'border-orange-400',
    category: 'ludo',
  },
  {
    id: 'stk_win',
    title: 'ধামাকা জিত! 🏆',
    emoji: '🏆',
    badgeText: 'চ্যাম্পিয়ন ট্রফি!',
    bgGradient: 'from-yellow-400 to-amber-500',
    borderColor: 'border-amber-300',
    category: 'ludo',
  },
];

// Quick Tap Reaction Emojis
export const ADDA_EMOJIS: string[] = [
  '😂', '🔥', '❤️', '👏', '☕', '🎲', '👑', '😍', '🥳', '💃', '🎤', '🌹', '🚀', '💯', '🤩', '🤣', '🤙', '💥', '🌙', '✨'
];

export const INITIAL_ADDA_ROOMS: AddaRoom[] = [
  {
    id: 'ADDA-101',
    title: 'ঢাকা বিশ্ববিদ্যালয় টিএসসি আড্ডা ☕',
    tagline: '১০ জন একসাথে লাইভ ভয়েস ও গল্পগুজব',
    category: 'friends',
    hostId: 'host_arif',
    hostName: 'আরিফ ভাই',
    hostCountry: findCountry('BD'),
    hostAvatar: DEFAULT_AVATARS.red,
    spectatorCount: 68,
    theme: 'royal_gold',
    ambience: 'acoustic_tea',
    tags: ['টিএসসি', 'লাইভআড্ডা', 'ঢাকা', 'চা'],
    gameMode: '10_dice_showdown',
    gameRound: 1,
    createdAt: Date.now() - 3600000,
    seats: [
      {
        seatIndex: 0,
        occupied: true,
        userId: 'host_arif',
        userName: 'আরিফ ভাই (Host)',
        avatar: DEFAULT_AVATARS.red,
        country: findCountry('BD'),
        isMuted: false,
        isSpeaking: true,
        isHost: true,
        coins: 14500,
        level: 18,
        vipTitle: 'ক্লাব ওনার 👑',
        score: 18,
      },
      {
        seatIndex: 1,
        occupied: true,
        userId: 'user_sadia',
        userName: 'সাদিয়া তাসনিম',
        avatar: DEFAULT_AVATARS.yellow,
        country: findCountry('BD'),
        isMuted: false,
        isSpeaking: false,
        isHost: false,
        coins: 8900,
        level: 12,
        vipTitle: 'আড্ডা কুইন 🌸',
        score: 14,
      },
      {
        seatIndex: 2,
        occupied: true,
        userId: 'user_rakib',
        userName: 'রাকিবুল হাসান',
        avatar: DEFAULT_AVATARS.blue,
        country: findCountry('BD'),
        isMuted: false,
        isSpeaking: false,
        isHost: false,
        coins: 6200,
        level: 9,
        score: 12,
      },
      {
        seatIndex: 3,
        occupied: true,
        userId: 'user_afrin',
        userName: 'আফরিন জাহান',
        avatar: DEFAULT_AVATARS.green,
        country: findCountry('BD'),
        isMuted: true,
        isSpeaking: false,
        isHost: false,
        coins: 11000,
        level: 15,
        score: 16,
      },
      {
        seatIndex: 4,
        occupied: true,
        userId: 'user_shuvo',
        userName: 'শুভ আহমেদ',
        avatar: {
          ...DEFAULT_AVATARS.red,
          clothing: 'hoodie',
          hairStyle: 'curly',
          accessory: 'glasses',
        },
        country: findCountry('BD'),
        isMuted: false,
        isSpeaking: false,
        isHost: false,
        coins: 4500,
        level: 7,
        score: 8,
      },
      {
        seatIndex: 5,
        occupied: true,
        userId: 'user_tanveer',
        userName: 'তানভীর চৌধুরী',
        avatar: DEFAULT_AVATARS.green,
        country: findCountry('BD'),
        isMuted: false,
        isSpeaking: false,
        isHost: false,
        coins: 7800,
        level: 11,
        score: 11,
      },
      {
        seatIndex: 6,
        occupied: true,
        userId: 'user_mimi',
        userName: 'মিমি আক্তার',
        avatar: DEFAULT_AVATARS.yellow,
        country: findCountry('BD'),
        isMuted: true,
        isSpeaking: false,
        isHost: false,
        coins: 5300,
        level: 8,
        score: 9,
      },
      null, // Seat 7 Empty
      null, // Seat 8 Empty
      null, // Seat 9 Empty
    ],
  },
  {
    id: 'ADDA-102',
    title: 'দুবাই-জেদ্দা-কাতার প্রবাসী আড্ডা 🌴',
    tagline: '১৯৫টি দেশ থেকে VPN ছাড়া সরাসরি সংযোগ',
    category: 'probasee',
    hostId: 'host_kamrul',
    hostName: 'কামরুল ভাই (দুবাই 🇦🇪)',
    hostCountry: findCountry('AE'),
    hostAvatar: {
      ...DEFAULT_AVATARS.red,
      clothing: 'suit',
      hairStyle: 'short',
      accessory: 'sunglasses',
    },
    spectatorCount: 142,
    theme: 'emerald_palace',
    ambience: 'lofi_chill',
    tags: ['প্রবাসী', 'দুবাই', 'সৌদি', 'VPNমুক্ত'],
    gameMode: '10_dice_showdown',
    gameRound: 2,
    createdAt: Date.now() - 7200000,
    seats: [
      {
        seatIndex: 0,
        occupied: true,
        userId: 'host_kamrul',
        userName: 'কামরুল হাসান 🇦🇪',
        avatar: { ...DEFAULT_AVATARS.red, clothing: 'suit' },
        country: findCountry('AE'),
        isMuted: false,
        isSpeaking: true,
        isHost: true,
        coins: 52000,
        level: 25,
        vipTitle: 'গোল্ডেন ভিআইপি 💎',
        score: 22,
      },
      {
        seatIndex: 1,
        occupied: true,
        userId: 'user_saudi_firoz',
        userName: 'ফিরোজ রিয়াদ 🇸🇦',
        avatar: DEFAULT_AVATARS.blue,
        country: findCountry('SA'),
        isMuted: false,
        isSpeaking: false,
        isHost: false,
        coins: 38000,
        level: 20,
        score: 19,
      },
      {
        seatIndex: 2,
        occupied: true,
        userId: 'user_qatar_reza',
        userName: 'রেজাউল দোহা 🇶🇦',
        avatar: DEFAULT_AVATARS.yellow,
        country: findCountry('QA'),
        isMuted: false,
        isSpeaking: false,
        isHost: false,
        coins: 29000,
        level: 17,
        score: 15,
      },
      {
        seatIndex: 3,
        occupied: true,
        userId: 'user_kuwait_jamal',
        userName: 'জামাল কুয়েত 🇰🇼',
        avatar: DEFAULT_AVATARS.green,
        country: findCountry('KW'),
        isMuted: true,
        isSpeaking: false,
        isHost: false,
        coins: 21000,
        level: 14,
        score: 13,
      },
      {
        seatIndex: 4,
        occupied: true,
        userId: 'user_malaysia_robi',
        userName: 'রবিউল কেএল 🇲🇾',
        avatar: DEFAULT_AVATARS.red,
        country: findCountry('MY'),
        isMuted: false,
        isSpeaking: false,
        isHost: false,
        coins: 16000,
        level: 13,
        score: 10,
      },
      null, // Seat 5 Empty
      null, // Seat 6 Empty
      null, // Seat 7 Empty
      null, // Seat 8 Empty
      null, // Seat 9 Empty
    ],
  },
  {
    id: 'ADDA-103',
    title: 'লুডো কিং মেগা ১০ ডাইস শো-ডাউন 👑',
    tagline: '১০ জন মিলে ডাইস রোল ও লাইভ চ্যালেঞ্জ',
    category: 'ludo',
    hostId: 'host_ludo_king',
    hostName: 'কিং সাকিব',
    hostCountry: findCountry('BD'),
    hostAvatar: {
      ...DEFAULT_AVATARS.red,
      hairStyle: 'crown',
      clothing: 'royal_robe',
    },
    spectatorCount: 95,
    theme: 'cyber_neon',
    ambience: 'party_dhamaal',
    tags: ['ডাইসলড়াই', 'শোডাউন', '১০খেলোয়াড়', 'চ্যাম্পিয়ন'],
    gameMode: '10_dice_showdown',
    gameRound: 3,
    createdAt: Date.now() - 1800000,
    seats: [
      {
        seatIndex: 0,
        occupied: true,
        userId: 'host_ludo_king',
        userName: 'কিং সাকিব 👑',
        avatar: { ...DEFAULT_AVATARS.red, hairStyle: 'crown' },
        country: findCountry('BD'),
        isMuted: false,
        isSpeaking: true,
        isHost: true,
        coins: 48000,
        level: 30,
        vipTitle: 'মেগা কিং 🏆',
        score: 24,
      },
      {
        seatIndex: 1,
        occupied: true,
        userId: 'user_farhan',
        userName: 'ফারহান রয়্যাল',
        avatar: DEFAULT_AVATARS.yellow,
        country: findCountry('BD'),
        isMuted: false,
        isSpeaking: false,
        isHost: false,
        coins: 24000,
        level: 19,
        score: 18,
      },
      {
        seatIndex: 2,
        occupied: true,
        userId: 'user_tania',
        userName: 'তানিয়া খান',
        avatar: DEFAULT_AVATARS.green,
        country: findCountry('BD'),
        isMuted: false,
        isSpeaking: false,
        isHost: false,
        coins: 19000,
        level: 16,
        score: 17,
      },
      {
        seatIndex: 3,
        occupied: true,
        userId: 'user_emon',
        userName: 'ইমন চৌধুরী',
        avatar: DEFAULT_AVATARS.blue,
        country: findCountry('BD'),
        isMuted: false,
        isSpeaking: false,
        isHost: false,
        coins: 13500,
        level: 12,
        score: 14,
      },
      {
        seatIndex: 4,
        occupied: true,
        userId: 'user_labib',
        userName: 'লাবিব ভাই',
        avatar: DEFAULT_AVATARS.red,
        country: findCountry('BD'),
        isMuted: true,
        isSpeaking: false,
        isHost: false,
        coins: 11200,
        level: 10,
        score: 11,
      },
      null, // Seat 5
      null, // Seat 6
      null, // Seat 7
      null, // Seat 8
      null, // Seat 9
    ],
  },
  {
    id: 'ADDA-104',
    title: 'মধ্যরাতের গান ও আড্ডা কর্নার 🎸',
    tagline: 'লাইভ সিংগিং, গিটার ভাইবস ও গিফট বৃষ্টি',
    category: 'music',
    hostId: 'host_singer_riya',
    hostName: 'রিয়া সুরকার 🎶',
    hostCountry: findCountry('BD'),
    hostAvatar: {
      ...DEFAULT_AVATARS.yellow,
      accessory: 'headphone',
      clothing: 'hoodie',
    },
    spectatorCount: 110,
    theme: 'sunset_glow',
    ambience: 'acoustic_tea',
    tags: ['গান', 'গিটার', 'গসিপ', 'নাইটআড্ডা'],
    gameMode: 'free_talk',
    createdAt: Date.now() - 5400000,
    seats: [
      {
        seatIndex: 0,
        occupied: true,
        userId: 'host_singer_riya',
        userName: 'রিয়া সুরকার 🎶',
        avatar: { ...DEFAULT_AVATARS.yellow, accessory: 'headphone' },
        country: findCountry('BD'),
        isMuted: false,
        isSpeaking: true,
        isHost: true,
        coins: 31000,
        level: 22,
        vipTitle: 'ভয়েস আর্টিস্ট 🎤',
      },
      {
        seatIndex: 1,
        occupied: true,
        userId: 'user_guitar_anwar',
        userName: 'আনোয়ার গিটারিস্ট 🎸',
        avatar: DEFAULT_AVATARS.blue,
        country: findCountry('BD'),
        isMuted: false,
        isSpeaking: false,
        isHost: false,
        coins: 17500,
        level: 15,
      },
      {
        seatIndex: 2,
        occupied: true,
        userId: 'user_uk_nisha',
        userName: 'নিশা লন্ডন 🇬🇧',
        avatar: DEFAULT_AVATARS.green,
        country: findCountry('GB'),
        isMuted: false,
        isSpeaking: false,
        isHost: false,
        coins: 26000,
        level: 18,
      },
      null,
      null,
      null,
      null,
      null,
      null,
      null,
    ],
  },
  {
    id: 'ADDA-105',
    title: 'গ্লোবাল ১৯৫ দেশ ফ্রেন্ডস ক্লাব 🌐',
    tagline: 'বিশ্বের যেকোনো প্রান্ত থেকে যুক্ত হোন সহজেই',
    category: 'international',
    hostId: 'host_global_mahfuz',
    hostName: 'মাহফুজ নিউইয়র্ক 🇺🇸',
    hostCountry: findCountry('US'),
    hostAvatar: {
      ...DEFAULT_AVATARS.blue,
      clothing: 'suit',
      accessory: 'glasses',
    },
    spectatorCount: 84,
    theme: 'midnight_club',
    ambience: 'bangla_adda',
    tags: ['গ্লোবাল', 'যুক্তরাষ্ট্র', 'ইতালি', 'কানাডা'],
    gameMode: 'lucky_number',
    gameTargetNumber: 6,
    createdAt: Date.now() - 4200000,
    seats: [
      {
        seatIndex: 0,
        occupied: true,
        userId: 'host_global_mahfuz',
        userName: 'মাহফুজ ইউএসএ 🇺🇸',
        avatar: { ...DEFAULT_AVATARS.blue, clothing: 'suit' },
        country: findCountry('US'),
        isMuted: false,
        isSpeaking: true,
        isHost: true,
        coins: 65000,
        level: 28,
        vipTitle: 'গ্লোবাল অ্যাম্বাসেডর 🌐',
      },
      {
        seatIndex: 1,
        occupied: true,
        userId: 'user_italy_sohel',
        userName: 'সোহেল রোম 🇮🇹',
        avatar: DEFAULT_AVATARS.red,
        country: findCountry('IT'),
        isMuted: false,
        isSpeaking: false,
        isHost: false,
        coins: 22000,
        level: 14,
      },
      {
        seatIndex: 2,
        occupied: true,
        userId: 'user_canada_nabil',
        userName: 'নাবিল টরন্টো 🇨🇦',
        avatar: DEFAULT_AVATARS.yellow,
        country: findCountry('CA'),
        isMuted: false,
        isSpeaking: false,
        isHost: false,
        coins: 34000,
        level: 19,
      },
      null,
      null,
      null,
      null,
      null,
      null,
      null,
    ],
  },
];
