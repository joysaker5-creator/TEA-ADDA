import { AdvertiserInquiry } from '../types';

const STORAGE_ADVERTISER_INQUIRIES_KEY = 'joy_ludo_advertiser_inquiries_v1';

export interface AdPlacementPackage {
  id: string;
  titleBn: string;
  titleEn?: string;
  badge: string;
  descriptionBn: string;
  descriptionEn?: string;
  reachEstimate: string;
  estimatedImpressions: string;
  startingPriceBDT: string;
  iconEmoji: string;
  features: string[];
}

export const AD_PLACEMENT_PACKAGES: AdPlacementPackage[] = [
  {
    id: 'board_banner',
    titleBn: 'লুডু বোর্ড সেন্টার ও কর্নার ব্র্যান্ডিং',
    titleEn: 'Ludo Board Center & Corner Branding',
    badge: 'সবচেয়ে জনপ্রিয় 🔥',
    descriptionBn: 'প্রতিটি গেম চলাকালীন বোর্ডে ও ডাইস রোলিং এর সময় খেলোয়াড়দের সরাসরি আপনার ব্র্যান্ডের লোগো ও ব্যানার প্রদর্শিত হবে।',
    descriptionEn: 'Showcase your brand logo and banners on the board and dice rolls directly to players throughout matches.',
    reachEstimate: '৫ লাখ+ খেলোয়াড় / দিন',
    estimatedImpressions: '২০ লাখ+ ম্যাচ ইম্প্রেশন / মাস',
    startingPriceBDT: '৳ ২৫,০০০ / মাস',
    iconEmoji: '🎲',
    features: [
      'লুডু বোর্ডের কেন্দ্রে ৩ডি লোগো প্লেসমেন্ট',
      'ডাইস রোলিং সাউন্ড ও অ্যানিমেটেড ব্যানার',
      'ওয়েবসাইটে সরাসরি ক্লিক ট্র্যাকিং ও রিডাইরেক্ট',
      'দৈনিক ও সাপ্তাহিক ইম্প্রেশন অ্যানালিটিক্স রিপোর্ট',
    ],
  },
  {
    id: 'video_sponsor',
    titleBn: 'ভিডিও শর্টস ও স্টুডিও স্পনসরশিপ',
    titleEn: 'Video Shorts & Studio Sponsorship',
    badge: 'হাই এনগেজমেন্ট 🎬',
    descriptionBn: 'জয় লুডু শর্টস ভিডিও ফিড ও ক্রিয়েটর মনিটাইজেশন প্ল্যাটফর্মে স্পনসরড ভিডিও ও নন-স্কিপেবল রিওয়ার্ড ভিডিও।',
    descriptionEn: 'Sponsored videos and rewarded non-skippable video placements on Joy Ludo Shorts feed and Creator Studio.',
    reachEstimate: '২.৫ লাখ+ ভিউ / দিন',
    estimatedImpressions: '১৫ লাখ+ ভিডিও ভিউ / মাস',
    startingPriceBDT: '৳ ৩৫,০০০ / মাস',
    iconEmoji: '🎥',
    features: [
      'ভিডিওর শুরুতে ও শেষে স্পনসরড ওয়াটারমার্ক',
      'ক্রিয়েটর ইনফ্লুয়েন্সার কো-ব্র্যান্ডিং সুযোগ',
      'ভিডিও ডেসক্রিপশনে স্পেশাল ডিসকাউন্ট লিংক ও প্রোমোকোড',
      'সোশ্যাল মিডিয়া শেয়ারিং সাপোর্ট',
    ],
  },
  {
    id: 'voice_adda_sponsor',
    titleBn: '১০ জনের লাইভ আড্ডা রুম স্পনসরশিপ',
    titleEn: '10-Player Live Adda Room Sponsorship',
    badge: 'লাইভ কানেকশন 🎤',
    descriptionBn: 'লাইভ ভয়েস আড্ডা বোর্ডে স্পেশাল রুম ব্যানার, ভার্চুয়াল গিফট ব্র্যান্ডিং এবং হোস্ট অডিও অ্যানাউন্সমেন্ট।',
    descriptionEn: 'Special room banners, virtual branded gifts, and host voice announcements on live voice Adda clubs.',
    reachEstimate: '১ লাখ+ সক্রিয় শ্রোতা / দিন',
    estimatedImpressions: '১০ লাখ+ অডিও-ভিজ্যুয়াল ইম্প্রেশন',
    startingPriceBDT: '৳ ২০,০০০ / মাস',
    iconEmoji: '☕',
    features: [
      'লাইভ আড্ডা রুমের উপরে ব্র্যান্ড ব্যানার ও পিন মেসেজ',
      'কাস্টম ভার্চুয়াল ব্র্যান্ড গিফট (যেমন: স্পেশাল চা/কোক/গিফট বক্স)',
      'ভয়েস স্টেজ হোস্ট কর্তৃক লাইভ ব্র্যান্ড প্রমোশন',
      'লাইভ পার্টি ও উইকেন্ড স্পেশাল ইভেন্ট হোস্ট করার সুবিধা',
    ],
  },
  {
    id: 'tournament_partner',
    titleBn: 'মেগা টুর্নামেন্ট টাইটেল পার্টনার',
    titleEn: 'Mega Tournament Title Partner',
    badge: 'প্রিমিয়াম ব্র্যান্ডিং 🏆',
    descriptionBn: 'জাতীয় ও রিজিওনাল গ্র্যান্ড লুডু টুর্নামেন্টের টাইটেল স্পনসরশিপ (যেমন: "[আপনার ব্র্যান্ড] কাপ জয় লুডু চ্যাম্পিয়নশিপ")।',
    descriptionEn: 'Title sponsorship for national and regional Grand Ludo tournaments (e.g., "[Your Brand] Cup Joy Ludo Championship").',
    reachEstimate: '১০ লাখ+ প্রতিযোগী ও দর্শক',
    estimatedImpressions: '৫০ লাখ+ মিডিয়া ও গেম ইম্প্রেশন',
    startingPriceBDT: '৳ ১,০০,০০০+ / টুর্নামেন্ট',
    iconEmoji: '👑',
    features: [
      'টুর্নামেন্ট ট্রফি, সার্টিফিকেট ও প্রাইজ পুলে ব্র্যান্ড লোগো',
      'বিজ্ঞাপন ব্যানার, পুশ নোটিফিকেশন ও সোশাল ক্যাম্পেইন',
      'চ্যাম্পিয়নদের সাথে ফটো ও ভিডিও শুটে ব্র্যান্ডিং',
      'প্রেস রিলিজ ও টিভি/ডিজিটাল মিডিয়া কাভারেজ',
    ],
  },
];

export const JOY_LUDO_AUDIENCE_STATS = {
  activeUsersMonthly: '১.৫ মিলিয়ন+ (1.5M+ Active Users)',
  dailyGamesPlayed: '৩,৫০,০০০+ ম্যাচ প্রতিদিন',
  averageSessionTime: '২৪.৫ মিনিট / সেশন',
  demographics: {
    bangladeshAudience: '৮৬%',
    expatriateBengalis: '১৪% (সৌদি, আরব আমিরাত, কাতার, মালয়েশিয়া ইত্যাদি)',
    age18to34: '৭৪%',
    maleFemaleRatio: '৬৫% পুরুষ / ৩৫% নারী',
  },
};

export const OFFICIAL_AD_CONTACT_INFO = {
  email: 'Joysaker5@gmail.com',
  secondaryEmail: 'Joysaker5@gmail.com',
  supportEmail: 'Joysaker5@gmail.com',
  officeAddress: 'জয় লুডু মিডিয়া ও ডিজিটাল সেল, গুলশান-২, ঢাকা-১২১২, বাংলাদেশ',
  supportHours: 'সকাল ৯:০০ টা - রাত ১০:০০ টা (সপ্তাহের ৭ দিন)',
  responseTime: 'সর্বোচ্চ ১২ থেকে ২৪ ঘণ্টার মধ্যে সরাসরি ইমেইলে যোগাযোগ করা হবে',
};

// Load Saved Inquiries
export const loadAdvertiserInquiries = (): AdvertiserInquiry[] => {
  try {
    const raw = localStorage.getItem(STORAGE_ADVERTISER_INQUIRIES_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch (err) {
    console.error('Error loading advertiser inquiries:', err);
  }
  return [];
};

// Save Saved Inquiries
export const saveAdvertiserInquiry = (inquiry: AdvertiserInquiry): void => {
  try {
    const existing = loadAdvertiserInquiries();
    const updated = [inquiry, ...existing];
    localStorage.setItem(STORAGE_ADVERTISER_INQUIRIES_KEY, JSON.stringify(updated));
  } catch (err) {
    console.error('Error saving advertiser inquiry:', err);
  }
};
