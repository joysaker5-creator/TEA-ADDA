export interface BlockedUser {
  id: string;
  userId: string;
  userName: string;
  reason?: string;
  blockedAt: number;
}

const STORAGE_KEY = 'joy_ludo_adda_blocked_users';

export function loadBlockedUsers(): BlockedUser[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function saveBlockedUsers(users: BlockedUser[]): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(users));
  } catch (e) {
    console.error('Failed to save blocked users:', e);
  }
}

export function blockUser(userId: string, userName: string, reason?: string): BlockedUser[] {
  const current = loadBlockedUsers();
  if (current.some((u) => u.userId === userId)) {
    return current;
  }
  const newUser: BlockedUser = {
    id: `blk_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    userId,
    userName,
    reason: reason || 'আড্ডা নিয়ম লঙ্ঘন / বিরক্তিকর আচরণ',
    blockedAt: Date.now(),
  };
  const updated = [newUser, ...current];
  saveBlockedUsers(updated);
  return updated;
}

export function unblockUser(userId: string): BlockedUser[] {
  const current = loadBlockedUsers();
  const updated = current.filter((u) => u.userId !== userId);
  saveBlockedUsers(updated);
  return updated;
}

export function isUserBlocked(userId: string, blockedList?: BlockedUser[]): boolean {
  const list = blockedList || loadBlockedUsers();
  return list.some((u) => u.userId === userId);
}
