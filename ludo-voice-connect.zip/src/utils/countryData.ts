export interface CountryInfo {
  code: string; // ISO 2-letter
  name: string; // English
  nameBn: string; // Bengali
  dialCode: string; // e.g. "+880"
  flag: string; // Emoji flag
  popular?: boolean;
}

// 195 Sovereign Countries and Territories with Bengali & English names, flags, and dial codes
export const COUNTRIES_195: CountryInfo[] = [
  // Most popular among South Asian & Diaspora communities
  { code: 'BD', name: 'Bangladesh', nameBn: 'বাংলাদেশ', dialCode: '+880', flag: '🇧🇩', popular: true },
  { code: 'SA', name: 'Saudi Arabia', nameBn: 'সৌদি আরব', dialCode: '+966', flag: '🇸🇦', popular: true },
  { code: 'AE', name: 'United Arab Emirates', nameBn: 'সংযুক্ত আরব আমিরাত (দুবাই)', dialCode: '+971', flag: '🇦🇪', popular: true },
  { code: 'IN', name: 'India', nameBn: 'ভারত', dialCode: '+91', flag: '🇮🇳', popular: true },
  { code: 'MY', name: 'Malaysia', nameBn: 'মালয়েশিয়া', dialCode: '+60', flag: '🇲🇾', popular: true },
  { code: 'US', name: 'United States', nameBn: 'যুক্তরাষ্ট্র (আমেরিকা)', dialCode: '+1', flag: '🇺🇸', popular: true },
  { code: 'GB', name: 'United Kingdom', nameBn: 'যুক্তরাজ্য (লন্ডন)', dialCode: '+44', flag: '🇬🇧', popular: true },
  { code: 'OM', name: 'Oman', nameBn: 'ওমান', dialCode: '+968', flag: '🇴🇲', popular: true },
  { code: 'QA', name: 'Qatar', nameBn: 'কাতার', dialCode: '+974', flag: '🇶🇦', popular: true },
  { code: 'KW', name: 'Kuwait', nameBn: 'কুয়েত', dialCode: '+965', flag: '🇰🇼', popular: true },
  { code: 'SG', name: 'Singapore', nameBn: 'সিঙ্গাপুর', dialCode: '+65', flag: '🇸🇬', popular: true },
  { code: 'IT', name: 'Italy', nameBn: 'ইতালি', dialCode: '+39', flag: '🇮🇹', popular: true },
  { code: 'CA', name: 'Canada', nameBn: 'কানাডা', dialCode: '+1', flag: '🇨🇦', popular: true },
  { code: 'BH', name: 'Bahrain', nameBn: 'বাহরাইন', dialCode: '+973', flag: '🇧🇭', popular: true },
  { code: 'PK', name: 'Pakistan', nameBn: 'পাকিস্তান', dialCode: '+92', flag: '🇵🇰', popular: true },
  { code: 'MV', name: 'Maldives', nameBn: 'মালদ্বীপ', dialCode: '+960', flag: '🇲🇻', popular: true },
  { code: 'AU', name: 'Australia', nameBn: 'অস্ট্রেলিয়া', dialCode: '+61', flag: '🇦🇺', popular: true },
  { code: 'DE', name: 'Germany', nameBn: 'জার্মানি', dialCode: '+49', flag: '🇩🇪', popular: true },
  { code: 'FR', name: 'France', nameBn: 'ফ্রান্স', dialCode: '+33', flag: '🇫🇷', popular: true },
  { code: 'JP', name: 'Japan', nameBn: 'জাপান', dialCode: '+81', flag: '🇯🇵', popular: true },
  { code: 'KR', name: 'South Korea', nameBn: 'দক্ষিণ কোরিয়া', dialCode: '+82', flag: '🇰🇷', popular: true },

  // Rest of Asia & Middle East
  { code: 'AF', name: 'Afghanistan', nameBn: 'আফগানিস্তান', dialCode: '+93', flag: '🇦🇫' },
  { code: 'AM', name: 'Armenia', nameBn: 'আর্মেনিয়া', dialCode: '+374', flag: '🇦🇲' },
  { code: 'AZ', name: 'Azerbaijan', nameBn: 'আজারবাইজান', dialCode: '+994', flag: '🇦🇿' },
  { code: 'BT', name: 'Bhutan', nameBn: 'ভুটান', dialCode: '+975', flag: '🇧🇹' },
  { code: 'BN', name: 'Brunei', nameBn: 'ব্রুনাই', dialCode: '+673', flag: '🇧🇳' },
  { code: 'KH', name: 'Cambodia', nameBn: 'কম্বোডিয়া', dialCode: '+855', flag: '🇰🇭' },
  { code: 'CN', name: 'China', nameBn: 'চীন', dialCode: '+86', flag: '🇨🇳' },
  { code: 'CY', name: 'Cyprus', nameBn: 'সাইপ্রাস', dialCode: '+357', flag: '🇨🇾' },
  { code: 'GE', name: 'Georgia', nameBn: 'জর্জিয়া', dialCode: '+995', flag: '🇬🇪' },
  { code: 'ID', name: 'Indonesia', nameBn: 'ইন্দোনেশিয়া', dialCode: '+62', flag: '🇮🇩' },
  { code: 'IR', name: 'Iran', nameBn: 'ইরান', dialCode: '+98', flag: '🇮🇷' },
  { code: 'IQ', name: 'Iraq', nameBn: 'ইরাক', dialCode: '+964', flag: '🇮🇶' },
  { code: 'IL', name: 'Israel', nameBn: 'ইসরায়েল', dialCode: '+972', flag: '🇮🇱' },
  { code: 'JO', name: 'Jordan', nameBn: 'জর্ডান', dialCode: '+962', flag: '🇯🇴' },
  { code: 'KZ', name: 'Kazakhstan', nameBn: 'কাজাখস্তান', dialCode: '+7', flag: '🇰🇿' },
  { code: 'KG', name: 'Kyrgyzstan', nameBn: 'কিরগিজস্তান', dialCode: '+996', flag: '🇰🇬' },
  { code: 'LA', name: 'Laos', nameBn: 'লাওস', dialCode: '+856', flag: '🇱🇦' },
  { code: 'LB', name: 'Lebanon', nameBn: 'লেবানন', dialCode: '+961', flag: '🇱🇧' },
  { code: 'MN', name: 'Mongolia', nameBn: 'মঙ্গোলিয়া', dialCode: '+976', flag: '🇲🇳' },
  { code: 'MM', name: 'Myanmar', nameBn: 'মায়ানমার', dialCode: '+95', flag: '🇲🇲' },
  { code: 'NP', name: 'Nepal', nameBn: 'নেপাল', dialCode: '+977', flag: '🇳🇵' },
  { code: 'PH', name: 'Philippines', nameBn: 'ফিলিপাইন', dialCode: '+63', flag: '🇵🇭' },
  { code: 'LK', name: 'Sri Lanka', nameBn: 'শ্রীলঙ্কা', dialCode: '+94', flag: '🇱🇰' },
  { code: 'SY', name: 'Syria', nameBn: 'সিরিয়া', dialCode: '+963', flag: '🇸🇾' },
  { code: 'TW', name: 'Taiwan', nameBn: 'তাইওয়ান', dialCode: '+886', flag: '🇹🇼' },
  { code: 'TJ', name: 'Tajikistan', nameBn: 'তাজিকিস্তান', dialCode: '+992', flag: '🇹🇯' },
  { code: 'TH', name: 'Thailand', nameBn: 'থাইল্যান্ড', dialCode: '+66', flag: '🇹🇭' },
  { code: 'TR', name: 'Turkey', nameBn: 'তুরস্ক', dialCode: '+90', flag: '🇹🇷' },
  { code: 'TM', name: 'Turkmenistan', nameBn: 'তুর্কমেনিস্তান', dialCode: '+993', flag: '🇹🇲' },
  { code: 'UZ', name: 'Uzbekistan', nameBn: 'উজবেকিস্তান', dialCode: '+998', flag: '🇺🇿' },
  { code: 'VN', name: 'Vietnam', nameBn: 'ভিয়েতনাম', dialCode: '+84', flag: '🇻🇳' },
  { code: 'YE', name: 'Yemen', nameBn: 'ইয়েমেন', dialCode: '+967', flag: '🇾🇪' },
  { code: 'PS', name: 'Palestine', nameBn: 'ফিলিস্তিন', dialCode: '+970', flag: '🇵🇸' },

  // Europe
  { code: 'AL', name: 'Albania', nameBn: 'আলবেনিয়া', dialCode: '+355', flag: '🇦🇱' },
  { code: 'AD', name: 'Andorra', nameBn: 'অ্যান্ডোরা', dialCode: '+376', flag: '🇦🇩' },
  { code: 'AT', name: 'Austria', nameBn: 'অস্ট্রিয়া', dialCode: '+43', flag: '🇦🇹' },
  { code: 'BY', name: 'Belarus', nameBn: 'বেলারুশ', dialCode: '+375', flag: '🇧🇾' },
  { code: 'BE', name: 'Belgium', nameBn: 'বেলজিয়াম', dialCode: '+32', flag: '🇧🇪' },
  { code: 'BA', name: 'Bosnia and Herzegovina', nameBn: 'বসনিয়া ও হার্জেগোভিনা', dialCode: '+387', flag: '🇧🇦' },
  { code: 'BG', name: 'Bulgaria', nameBn: 'বুলগেরিয়া', dialCode: '+359', flag: '🇧🇬' },
  { code: 'HR', name: 'Croatia', nameBn: 'ক্রোয়েশিয়া', dialCode: '+385', flag: '🇭🇷' },
  { code: 'CZ', name: 'Czech Republic', nameBn: 'চেক প্রজাতন্ত্র', dialCode: '+420', flag: '🇨🇿' },
  { code: 'DK', name: 'Denmark', nameBn: 'ডেনমার্ক', dialCode: '+45', flag: '🇩🇰' },
  { code: 'EE', name: 'Estonia', nameBn: 'এস্তোনিয়া', dialCode: '+372', flag: '🇪🇪' },
  { code: 'FI', name: 'Finland', nameBn: 'ফিনল্যান্ড', dialCode: '+358', flag: '🇫🇮' },
  { code: 'GR', name: 'Greece', nameBn: 'গ্রীস', dialCode: '+30', flag: '🇬🇷' },
  { code: 'HU', name: 'Hungary', nameBn: 'হাঙ্গেরি', dialCode: '+36', flag: '🇭🇺' },
  { code: 'IS', name: 'Iceland', nameBn: 'আইসল্যান্ড', dialCode: '+354', flag: '🇮🇸' },
  { code: 'IE', name: 'Ireland', nameBn: 'আয়ারল্যান্ড', dialCode: '+353', flag: '🇮🇪' },
  { code: 'LV', name: 'Latvia', nameBn: 'লাটভিয়া', dialCode: '+371', flag: '🇱🇻' },
  { code: 'LI', name: 'Liechtenstein', nameBn: 'লিশটেনস্টাইন', dialCode: '+423', flag: '🇱🇮' },
  { code: 'LT', name: 'Lithuania', nameBn: 'লিথুয়ানিয়া', dialCode: '+370', flag: '🇱🇹' },
  { code: 'LU', name: 'Luxembourg', nameBn: 'লুক্সেমবার্গ', dialCode: '+352', flag: '🇱🇺' },
  { code: 'MT', name: 'Malta', nameBn: 'মাল্টা', dialCode: '+356', flag: '🇲🇹' },
  { code: 'MD', name: 'Moldova', nameBn: 'মলদোভা', dialCode: '+373', flag: '🇲🇩' },
  { code: 'MC', name: 'Monaco', nameBn: 'মোনাকো', dialCode: '+377', flag: '🇲🇨' },
  { code: 'ME', name: 'Montenegro', nameBn: 'মন্টিনিগ্রো', dialCode: '+382', flag: '🇲🇪' },
  { code: 'NL', name: 'Netherlands', nameBn: 'নেদারল্যান্ডস', dialCode: '+31', flag: '🇳🇱' },
  { code: 'MK', name: 'North Macedonia', nameBn: 'উত্তর মেসিডোনিয়া', dialCode: '+389', flag: '🇲🇰' },
  { code: 'NO', name: 'Norway', nameBn: 'নরওয়ে', dialCode: '+47', flag: '🇳🇴' },
  { code: 'PL', name: 'Poland', nameBn: 'পোল্যান্ড', dialCode: '+48', flag: '🇵🇱' },
  { code: 'PT', name: 'Portugal', nameBn: 'পর্তুগাল', dialCode: '+351', flag: '🇵🇹' },
  { code: 'RO', name: 'Romania', nameBn: 'রোমানিয়া', dialCode: '+40', flag: '🇷🇴' },
  { code: 'RU', name: 'Russia', nameBn: 'রাশিয়া', dialCode: '+7', flag: '🇷🇺' },
  { code: 'RS', name: 'Serbia', nameBn: 'সার্বিয়া', dialCode: '+381', flag: '🇷🇸' },
  { code: 'SK', name: 'Slovakia', nameBn: 'স্লোভাকিয়া', dialCode: '+421', flag: '🇸🇰' },
  { code: 'SI', name: 'Slovenia', nameBn: 'স্লোভেনিয়া', dialCode: '+386', flag: '🇸🇮' },
  { code: 'ES', name: 'Spain', nameBn: 'স্পেন', dialCode: '+34', flag: '🇪🇸' },
  { code: 'SE', name: 'Sweden', nameBn: 'সুইডেন', dialCode: '+46', flag: '🇸🇪' },
  { code: 'CH', name: 'Switzerland', nameBn: 'সুইজারল্যান্ড', dialCode: '+41', flag: '🇨🇭' },
  { code: 'UA', name: 'Ukraine', nameBn: 'ইউক্রেন', dialCode: '+380', flag: '🇺🇦' },

  // Africa
  { code: 'DZ', name: 'Algeria', nameBn: 'আলজেরিয়া', dialCode: '+213', flag: '🇩🇿' },
  { code: 'AO', name: 'Angola', nameBn: 'অ্যাঙ্গোলা', dialCode: '+244', flag: '🇦🇴' },
  { code: 'BJ', name: 'Benin', nameBn: 'বেনিন', dialCode: '+229', flag: '🇧🇯' },
  { code: 'BW', name: 'Botswana', nameBn: 'বতসোয়ানা', dialCode: '+267', flag: '🇧🇼' },
  { code: 'BF', name: 'Burkina Faso', nameBn: 'বুর্কিনা ফাসো', dialCode: '+226', flag: '🇧🇫' },
  { code: 'BI', name: 'Burundi', nameBn: 'বুরুন্ডি', dialCode: '+257', flag: '🇧🇮' },
  { code: 'CM', name: 'Cameroon', nameBn: 'ক্যামেরুন', dialCode: '+237', flag: '🇨🇲' },
  { code: 'CV', name: 'Cape Verde', nameBn: 'কেপ ভার্দে', dialCode: '+238', flag: '🇨🇻' },
  { code: 'CF', name: 'Central African Republic', nameBn: 'মধ্য আফ্রিকান প্রজাতন্ত্র', dialCode: '+236', flag: '🇨🇫' },
  { code: 'TD', name: 'Chad', nameBn: 'চাদ', dialCode: '+235', flag: '🇹🇩' },
  { code: 'KM', name: 'Comoros', nameBn: 'কমোরোস', dialCode: '+269', flag: '🇰🇲' },
  { code: 'CG', name: 'Congo', nameBn: 'কঙ্গো', dialCode: '+242', flag: '🇨🇬' },
  { code: 'CD', name: 'Congo (DRC)', nameBn: 'গণতান্ত্রিক কঙ্গো', dialCode: '+243', flag: '🇨🇩' },
  { code: 'CI', name: 'Ivory Coast', nameBn: 'আইভরি কোস্ট', dialCode: '+225', flag: '🇨🇮' },
  { code: 'DJ', name: 'Djibouti', nameBn: 'জিবুতি', dialCode: '+253', flag: '🇩🇯' },
  { code: 'EG', name: 'Egypt', nameBn: 'মিশর', dialCode: '+20', flag: '🇪🇬' },
  { code: 'GQ', name: 'Equatorial Guinea', nameBn: 'নিরক্ষীয় গিনি', dialCode: '+240', flag: '🇬🇶' },
  { code: 'ER', name: 'Eritrea', nameBn: 'ইরিত্রিয়া', dialCode: '+291', flag: '🇪🇷' },
  { code: 'ET', name: 'Ethiopia', nameBn: 'ইথিওপিয়া', dialCode: '+251', flag: '🇪🇹' },
  { code: 'GA', name: 'Gabon', nameBn: 'গ্যাবন', dialCode: '+241', flag: '🇬🇦' },
  { code: 'GM', name: 'Gambia', nameBn: 'গাম্বিয়া', dialCode: '+220', flag: '🇬🇲' },
  { code: 'GH', name: 'Ghana', nameBn: 'ঘানা', dialCode: '+233', flag: '🇬🇭' },
  { code: 'GN', name: 'Guinea', nameBn: 'গিনি', dialCode: '+224', flag: '🇬🇳' },
  { code: 'GW', name: 'Guinea-Bissau', nameBn: 'গিনি-বিসাউ', dialCode: '+245', flag: '🇬🇼' },
  { code: 'KE', name: 'Kenya', nameBn: 'কেনিয়া', dialCode: '+254', flag: '🇰🇪' },
  { code: 'LS', name: 'Lesotho', nameBn: 'লেসোথো', dialCode: '+266', flag: '🇱🇸' },
  { code: 'LR', name: 'Liberia', nameBn: 'লাইবেরিয়া', dialCode: '+231', flag: '🇱🇷' },
  { code: 'LY', name: 'Libya', nameBn: 'লিবিয়া', dialCode: '+218', flag: '🇱🇾' },
  { code: 'MG', name: 'Madagascar', nameBn: 'মাদাগাস্কার', dialCode: '+261', flag: '🇲🇬' },
  { code: 'MW', name: 'Malawi', nameBn: 'মালাউই', dialCode: '+265', flag: '🇲🇼' },
  { code: 'ML', name: 'Mali', nameBn: 'মালি', dialCode: '+223', flag: '🇲🇱' },
  { code: 'MR', name: 'Mauritania', nameBn: 'মৌরিতানিয়া', dialCode: '+222', flag: '🇲🇷' },
  { code: 'MU', name: 'Mauritius', nameBn: 'মরিশাস', dialCode: '+230', flag: '🇲🇺' },
  { code: 'MA', name: 'Morocco', nameBn: 'মরক্কো', dialCode: '+212', flag: '🇲🇦' },
  { code: 'MZ', name: 'Mozambique', nameBn: 'মোজাম্বিক', dialCode: '+258', flag: '🇲🇿' },
  { code: 'NA', name: 'Namibia', nameBn: 'নামিবিয়া', dialCode: '+264', flag: '🇳🇦' },
  { code: 'NE', name: 'Niger', nameBn: 'নাইজার', dialCode: '+227', flag: '🇳🇪' },
  { code: 'NG', name: 'Nigeria', nameBn: 'নাইজেরিয়া', dialCode: '+234', flag: '🇳🇬' },
  { code: 'RW', name: 'Rwanda', nameBn: 'রুয়ান্ডা', dialCode: '+250', flag: '🇷🇼' },
  { code: 'SN', name: 'Senegal', nameBn: 'সেনেগাল', dialCode: '+221', flag: '🇸🇳' },
  { code: 'SC', name: 'Seychelles', nameBn: 'সিসিলিস', dialCode: '+248', flag: '🇸🇨' },
  { code: 'SL', name: 'Sierra Leone', nameBn: 'সিয়েরা লিওন', dialCode: '+232', flag: '🇸🇱' },
  { code: 'SO', name: 'Somalia', nameBn: 'সোমালিয়া', dialCode: '+252', flag: '🇸🇴' },
  { code: 'ZA', name: 'South Africa', nameBn: 'দক্ষিণ আফ্রিকা', dialCode: '+27', flag: '🇿🇦' },
  { code: 'SS', name: 'South Sudan', nameBn: 'দক্ষিণ সুদান', dialCode: '+211', flag: '🇸🇸' },
  { code: 'SD', name: 'Sudan', nameBn: 'সুদান', dialCode: '+249', flag: '🇸🇩' },
  { code: 'SZ', name: 'Eswatini', nameBn: 'ইসোয়াতিনি', dialCode: '+268', flag: '🇸🇿' },
  { code: 'TZ', name: 'Tanzania', nameBn: 'তানজানিয়া', dialCode: '+255', flag: '🇹🇿' },
  { code: 'TG', name: 'Togo', nameBn: 'টোগো', dialCode: '+228', flag: '🇹🇬' },
  { code: 'TN', name: 'Tunisia', nameBn: 'তিউনিসিয়া', dialCode: '+216', flag: '🇹🇳' },
  { code: 'UG', name: 'Uganda', nameBn: 'উগান্ডা', dialCode: '+256', flag: '🇺🇬' },
  { code: 'ZM', name: 'Zambia', nameBn: 'জাম্বিয়া', dialCode: '+260', flag: '🇿🇲' },
  { code: 'ZW', name: 'Zimbabwe', nameBn: 'জিম্বাবুয়ে', dialCode: '+263', flag: '🇿🇼' },

  // Americas
  { code: 'AG', name: 'Antigua and Barbuda', nameBn: 'অ্যান্টিগুয়া ও বার্বুডা', dialCode: '+1268', flag: '🇦🇬' },
  { code: 'AR', name: 'Argentina', nameBn: 'আর্জেন্টিনা', dialCode: '+54', flag: '🇦🇷' },
  { code: 'BS', name: 'Bahamas', nameBn: 'বাহামাস', dialCode: '+1242', flag: '🇧🇸' },
  { code: 'BB', name: 'Barbados', nameBn: 'বার্বাডোজ', dialCode: '+1246', flag: '🇧🇧' },
  { code: 'BZ', name: 'Belize', nameBn: 'বেলিজ', dialCode: '+501', flag: '🇧🇿' },
  { code: 'BO', name: 'Bolivia', nameBn: 'বলিভিয়া', dialCode: '+591', flag: '🇧🇴' },
  { code: 'BR', name: 'Brazil', nameBn: 'ব্রাজিল', dialCode: '+55', flag: '🇧🇷' },
  { code: 'CL', name: 'Chile', nameBn: 'চিলি', dialCode: '+56', flag: '🇨🇱' },
  { code: 'CO', name: 'Colombia', nameBn: 'কলম্বিয়া', dialCode: '+57', flag: '🇨🇴' },
  { code: 'CR', name: 'Costa Rica', nameBn: 'কোস্টারিকা', dialCode: '+506', flag: '🇨🇷' },
  { code: 'CU', name: 'Cuba', nameBn: 'কিউবা', dialCode: '+53', flag: '🇨🇺' },
  { code: 'DM', name: 'Dominica', nameBn: 'ডোমিনিকা', dialCode: '+1767', flag: '🇩🇲' },
  { code: 'DO', name: 'Dominican Republic', nameBn: 'ডোমিনিকান প্রজাতন্ত্র', dialCode: '+1809', flag: '🇩🇴' },
  { code: 'EC', name: 'Ecuador', nameBn: 'ইকুয়েডর', dialCode: '+593', flag: '🇪🇨' },
  { code: 'SV', name: 'El Salvador', nameBn: 'এল সালভাদর', dialCode: '+503', flag: '🇸🇻' },
  { code: 'GD', name: 'Grenada', nameBn: 'গ্রেনাডা', dialCode: '+1473', flag: '🇬🇩' },
  { code: 'GT', name: 'Guatemala', nameBn: 'গুয়াতেমালা', dialCode: '+502', flag: '🇬🇹' },
  { code: 'GY', name: 'Guyana', nameBn: 'গায়ানা', dialCode: '+592', flag: '🇬🇾' },
  { code: 'HT', name: 'Haiti', nameBn: 'হাইতি', dialCode: '+509', flag: '🇭🇹' },
  { code: 'HN', name: 'Honduras', nameBn: 'হন্ডুরাস', dialCode: '+504', flag: '🇭🇳' },
  { code: 'JM', name: 'Jamaica', nameBn: 'জ্যামাইকা', dialCode: '+1876', flag: '🇯🇲' },
  { code: 'MX', name: 'Mexico', nameBn: 'মেক্সিকো', dialCode: '+52', flag: '🇲🇽' },
  { code: 'NI', name: 'Nicaragua', nameBn: 'নিকারাগুয়া', dialCode: '+505', flag: '🇳🇮' },
  { code: 'PA', name: 'Panama', nameBn: 'পানামা', dialCode: '+507', flag: '🇵🇦' },
  { code: 'PY', name: 'Paraguay', nameBn: 'প্যারাগুয়ে', dialCode: '+595', flag: '🇵🇾' },
  { code: 'PE', name: 'Peru', nameBn: 'পেরু', dialCode: '+51', flag: '🇵🇪' },
  { code: 'KN', name: 'Saint Kitts and Nevis', nameBn: 'সেন্ট কিটস ও নেভিস', dialCode: '+1869', flag: '🇰🇳' },
  { code: 'LC', name: 'Saint Lucia', nameBn: 'সেন্ট লুসিয়া', dialCode: '+1758', flag: '🇱🇨' },
  { code: 'VC', name: 'Saint Vincent', nameBn: 'সেন্ট ভিনসেন্ট', dialCode: '+1784', flag: '🇻🇨' },
  { code: 'SR', name: 'Suriname', nameBn: 'সুরিনাম', dialCode: '+597', flag: '🇸🇷' },
  { code: 'TT', name: 'Trinidad and Tobago', nameBn: 'ত্রিনিদাদ ও টোবাগো', dialCode: '+1868', flag: '🇹🇹' },
  { code: 'UY', name: 'Uruguay', nameBn: 'উরুগুয়ে', dialCode: '+598', flag: '🇺🇾' },
  { code: 'VE', name: 'Venezuela', nameBn: 'ভেনেজুয়েলা', dialCode: '+58', flag: '🇻🇪' },

  // Oceania
  { code: 'FJ', name: 'Fiji', nameBn: 'ফিজি', dialCode: '+679', flag: '🇫🇯' },
  { code: 'KI', name: 'Kiribati', nameBn: 'কিরিবাতি', dialCode: '+686', flag: '🇰🇮' },
  { code: 'MH', name: 'Marshall Islands', nameBn: 'মার্শাল দ্বীপপুঞ্জ', dialCode: '+692', flag: '🇲🇭' },
  { code: 'FM', name: 'Micronesia', nameBn: 'মাইক্রোনেশিয়া', dialCode: '+691', flag: '🇫🇲' },
  { code: 'NR', name: 'Nauru', nameBn: 'নাউরু', dialCode: '+674', flag: '🇳🇷' },
  { code: 'NZ', name: 'New Zealand', nameBn: 'নিউজিল্যান্ড', dialCode: '+64', flag: '🇳🇿' },
  { code: 'PW', name: 'Palau', nameBn: 'পালাউ', dialCode: '+680', flag: '🇵🇼' },
  { code: 'PG', name: 'Papua New Guinea', nameBn: 'পাপুয়া নিউগিনি', dialCode: '+675', flag: '🇵🇬' },
  { code: 'WS', name: 'Samoa', nameBn: 'সামোয়া', dialCode: '+685', flag: '🇼🇸' },
  { code: 'SB', name: 'Solomon Islands', nameBn: 'সলোমন দ্বীপপুঞ্জ', dialCode: '+677', flag: '🇸🇧' },
  { code: 'TO', name: 'Tonga', nameBn: 'টোঙ্গা', dialCode: '+676', flag: '🇹🇴' },
  { code: 'TV', name: 'Tuvalu', nameBn: 'টুভালু', dialCode: '+688', flag: '🇹🇻' },
  { code: 'VU', name: 'Vanuatu', nameBn: 'ভানুয়াতু', dialCode: '+678', flag: '🇻🇺' },
];

// Helper to find country by dial code or auto-detect from raw input
export const findCountryByDialCode = (dialCode: string): CountryInfo => {
  const clean = dialCode.startsWith('+') ? dialCode : `+${dialCode}`;
  const found = COUNTRIES_195.find((c) => c.dialCode === clean);
  return found || COUNTRIES_195[0]; // Default BD
};

// Helper to auto-detect country from user input string
export const detectCountryFromPhoneInput = (input: string): { country: CountryInfo; localNumber: string } | null => {
  const clean = input.trim();
  if (!clean.startsWith('+')) {
    // If standard 01... local Bangladesh number
    if (clean.startsWith('01') || clean.startsWith('880')) {
      return { country: COUNTRIES_195[0], localNumber: clean.replace(/^(\+880|880)/, '0') };
    }
    return null;
  }

  // Sort countries by dialCode length descending so +971 matches before +9
  const sorted = [...COUNTRIES_195].sort((a, b) => b.dialCode.length - a.dialCode.length);
  for (const c of sorted) {
    if (clean.startsWith(c.dialCode)) {
      return {
        country: c,
        localNumber: clean.substring(c.dialCode.length).trim(),
      };
    }
  }

  return null;
};

// Format international phone number cleanly
export const formatInternationalPhone = (country: CountryInfo, localNumber: string): string => {
  let cleanLocal = localNumber.replace(/[^\d]/g, '');
  if (country.code === 'BD' && cleanLocal.startsWith('0')) {
    cleanLocal = cleanLocal.substring(1);
  }
  return `${country.dialCode} ${cleanLocal}`.trim();
};

// WebRTC Global ICE configuration for VPN-free 195 Countries operation
export const GLOBAL_WEBRTC_ICE_SERVERS: RTCIceServer[] = [
  { urls: 'stun:stun.l.google.com:19302' },
  { urls: 'stun:stun1.l.google.com:19302' },
  { urls: 'stun:stun2.l.google.com:19302' },
  { urls: 'stun:stun3.l.google.com:19302' },
  { urls: 'stun:stun4.l.google.com:19302' },
  { urls: 'stun:global.stun.twilio.com:3478?transport=udp' },
  { urls: 'stun:stun.services.mozilla.com' },
];
