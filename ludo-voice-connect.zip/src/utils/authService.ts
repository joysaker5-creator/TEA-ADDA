import { UserProfile, AuthProvider } from '../types';

const STORAGE_KEY_PROFILE = 'ludo_user_auth_profile';
const STORAGE_KEY_USERS_DB = 'ludo_users_local_db';
const STORAGE_KEY_ACTIVE_OTP = 'ludo_active_otp_session';

export interface LocalUserRecord {
  id: string;
  name: string;
  email?: string;
  phone?: string;
  passwordHash: string;
  avatarUrl?: string;
  provider: AuthProvider;
  linkedProviders: AuthProvider[];
  isVerified: boolean;
  createdAt: number;
  lastLoginAt: number;
}

export interface ActiveOtpSession {
  phoneOrEmail: string;
  otp: string;
  expiresAt: number;
  purpose: 'login' | 'register' | 'forgot_password' | 'link_account';
  tempName?: string;
  tempPassword?: string;
  tempAgeCategory?: 'adult_18_plus' | 'teen_13_17' | 'under_13';
  tempReferralCode?: string;
  tempPhone?: string;
  tempEmail?: string;
}

// Generate simple guest profile
export const createDefaultGuestProfile = (): UserProfile => {
  const randomId = 'GST_' + Math.random().toString(36).substring(2, 8).toUpperCase();
  return {
    id: randomId,
    name: 'গেস্ট খেলোয়াড়',
    provider: 'guest',
    linkedProviders: ['guest'],
    isVerified: false,
    hasPassword: false,
    createdAt: Date.now(),
    lastLoginAt: Date.now(),
  };
};

// Load saved user profile
export const loadUserProfile = (): UserProfile => {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_PROFILE);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && parsed.id) {
        return parsed;
      }
    }
  } catch (err) {
    console.error('Error reading user profile:', err);
  }
  const newGuest = createDefaultGuestProfile();
  saveUserProfile(newGuest);
  return newGuest;
};

// Save user profile
export const saveUserProfile = (profile: UserProfile): void => {
  try {
    localStorage.setItem(STORAGE_KEY_PROFILE, JSON.stringify(profile));
  } catch (err) {
    console.error('Error saving user profile:', err);
  }
};

// Local user DB helpers
export const getLocalUsersDb = (): LocalUserRecord[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_USERS_DB);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch (err) {
    console.error('Error reading local users db:', err);
  }
  return [];
};

export const saveLocalUsersDb = (users: LocalUserRecord[]): void => {
  try {
    localStorage.setItem(STORAGE_KEY_USERS_DB, JSON.stringify(users));
  } catch (err) {
    console.error('Error saving local users db:', err);
  }
};

// Operator Detection for BD & Global Numbers
export const detectBdOperator = (
  phone: string
): { name: string; color: string; badge: string } | null => {
  const clean = phone.replace(/[\s-+]/g, '');
  if (!clean) return null;

  // Saudi Arabia +966
  if (clean.startsWith('966')) {
    return { name: 'সৌদি আরব (STC / Mobily)', color: 'bg-emerald-700 text-white', badge: 'KSA' };
  }
  // UAE +971
  if (clean.startsWith('971')) {
    return { name: 'দুবাই / UAE (e& / du)', color: 'bg-teal-700 text-white', badge: 'UAE' };
  }
  // India +91
  if (clean.startsWith('91') && clean.length >= 10) {
    return { name: 'ভারত (Jio / Airtel)', color: 'bg-orange-600 text-white', badge: 'IN' };
  }
  // Malaysia +60
  if (clean.startsWith('60')) {
    return { name: 'মালয়েশিয়া (Maxis / Celcom)', color: 'bg-blue-700 text-white', badge: 'MY' };
  }
  // Qatar +974
  if (clean.startsWith('974')) {
    return { name: 'কাতার (Ooredoo / Vodafone)', color: 'bg-rose-800 text-white', badge: 'QA' };
  }
  // Oman +968
  if (clean.startsWith('968')) {
    return { name: 'ওমান (Omantel / Ooredoo)', color: 'bg-red-700 text-white', badge: 'OM' };
  }
  // Kuwait +965
  if (clean.startsWith('965')) {
    return { name: 'কুয়েত (Zain / Ooredoo)', color: 'bg-indigo-700 text-white', badge: 'KW' };
  }
  // Singapore +65
  if (clean.startsWith('65')) {
    return { name: 'সিঙ্গাপুর (Singtel / StarHub)', color: 'bg-red-600 text-white', badge: 'SG' };
  }
  // UK +44
  if (clean.startsWith('44')) {
    return { name: 'যুক্তরাজ্য (EE / Vodafone)', color: 'bg-blue-800 text-white', badge: 'UK' };
  }
  // USA / Canada +1
  if (clean.startsWith('1') && clean.length === 11) {
    return { name: 'যুক্তরাষ্ট্র / কানাডা', color: 'bg-sky-800 text-white', badge: 'US/CA' };
  }

  // Bangladesh BD Operators
  const prefix = clean.startsWith('880') ? clean.substring(3, 5) : clean.substring(0, 3);

  if (['017', '013', '17', '13'].includes(prefix)) {
    return { name: 'গ্রামীনফোন (GP)', color: 'bg-sky-600 text-white', badge: 'GP' };
  }
  if (['019', '014', '19', '14'].includes(prefix)) {
    return { name: 'বাংলালিংক (BL)', color: 'bg-amber-600 text-white', badge: 'BL' };
  }
  if (['018', '18'].includes(prefix)) {
    return { name: 'রবি (Robi)', color: 'bg-red-600 text-white', badge: 'Robi' };
  }
  if (['016', '16'].includes(prefix)) {
    return { name: 'এয়ারটেল (Airtel)', color: 'bg-rose-600 text-white', badge: 'Airtel' };
  }
  if (['015', '15'].includes(prefix)) {
    return { name: 'টেলিটক (Teletalk)', color: 'bg-emerald-600 text-white', badge: 'Teletalk' };
  }
  return null;
};

// Password Strength Evaluator
export const evaluatePasswordStrength = (
  pass: string
): {
  score: number; // 0 to 4
  labelBn: string;
  color: string;
  hasMinLength: boolean;
  hasNumber: boolean;
  hasLetter: boolean;
  hasSpecial: boolean;
} => {
  const hasMinLength = pass.length >= 6;
  const hasNumber = /\d/.test(pass);
  const hasLetter = /[a-zA-Z]/.test(pass);
  const hasSpecial = /[!@#$%^&*(),.?":{}|<>]/.test(pass);

  let score = 0;
  if (hasMinLength) score += 1;
  if (hasNumber) score += 1;
  if (hasLetter) score += 1;
  if (hasSpecial || pass.length >= 10) score += 1;

  if (!pass) {
    return {
      score: 0,
      labelBn: 'পাসওয়ার্ড দিন',
      color: 'bg-gray-300',
      hasMinLength: false,
      hasNumber: false,
      hasLetter: false,
      hasSpecial: false,
    };
  }

  if (score <= 1) {
    return {
      score: 1,
      labelBn: 'খুব দুর্বল',
      color: 'bg-red-500',
      hasMinLength,
      hasNumber,
      hasLetter,
      hasSpecial,
    };
  }
  if (score === 2) {
    return {
      score: 2,
      labelBn: 'দুর্বল',
      color: 'bg-orange-500',
      hasMinLength,
      hasNumber,
      hasLetter,
      hasSpecial,
    };
  }
  if (score === 3) {
    return {
      score: 3,
      labelBn: 'মাঝারি শক্তিশালী',
      color: 'bg-amber-500',
      hasMinLength,
      hasNumber,
      hasLetter,
      hasSpecial,
    };
  }
  return {
    score: 4,
    labelBn: 'খুব শক্তিশালী 🛡️',
    color: 'bg-emerald-500',
    hasMinLength,
    hasNumber,
    hasLetter,
    hasSpecial,
  };
};

// OTP Generation
export const generate6DigitOtp = (): string => {
  return Math.floor(100000 + Math.random() * 900000).toString();
};

// Save OTP to Session
export const saveActiveOtp = (session: ActiveOtpSession): void => {
  sessionStorage.setItem(STORAGE_KEY_ACTIVE_OTP, JSON.stringify(session));
};

export const getActiveOtp = (): ActiveOtpSession | null => {
  try {
    const raw = sessionStorage.getItem(STORAGE_KEY_ACTIVE_OTP);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && parsed.expiresAt > Date.now()) {
        return parsed;
      }
    }
  } catch (err) {
    console.error('Error reading active OTP:', err);
  }
  return null;
};

export const clearActiveOtp = (): void => {
  sessionStorage.removeItem(STORAGE_KEY_ACTIVE_OTP);
};

// Send OTP API caller with fallback
export const sendOtpService = async (
  phoneOrEmail: string,
  purpose: 'login' | 'register' | 'forgot_password' | 'link_account',
  tempName?: string,
  tempPassword?: string,
  tempAgeCategory?: 'adult_18_plus' | 'teen_13_17' | 'under_13',
  tempReferralCode?: string,
  tempPhone?: string,
  tempEmail?: string
): Promise<{ success: boolean; otp: string; message: string; expiresIn: number }> => {
  const generatedOtp = generate6DigitOtp();
  const session: ActiveOtpSession = {
    phoneOrEmail,
    otp: generatedOtp,
    expiresAt: Date.now() + 120000, // 2 minutes
    purpose,
    tempName,
    tempPassword,
    tempAgeCategory,
    tempReferralCode,
    tempPhone,
    tempEmail,
  };
  saveActiveOtp(session);

  // Attempt backend API call
  try {
    const res = await fetch('/api/auth/send-otp', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ phoneOrEmail, purpose, otp: generatedOtp }),
    });
    if (res.ok) {
      const data = await res.json();
      return {
        success: true,
        otp: generatedOtp,
        message: data.message || `৬ ডিজিটের ওটিপি কোড ${phoneOrEmail} নাম্বারে পাঠানো হয়েছে।`,
        expiresIn: 120,
      };
    }
  } catch (err) {
    console.warn('Backend send-otp failed, using client-side service fallback:', err);
  }

  return {
    success: true,
    otp: generatedOtp,
    message: `৬ ডিজিটের ওটিপি কোড ${phoneOrEmail} নাম্বারে পাঠানো হয়েছে।`,
    expiresIn: 120,
  };
};

// Verify OTP
export const verifyOtpService = async (
  phoneOrEmail: string,
  inputOtp: string
): Promise<{ success: boolean; message: string; user?: UserProfile; isNewRegistration?: boolean }> => {
  const activeSession = getActiveOtp();

  // Try backend first
  try {
    const res = await fetch('/api/auth/verify-otp', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ phoneOrEmail, otp: inputOtp }),
    });
    if (res.ok) {
      const data = await res.json();
      if (data.success && data.user) {
        clearActiveOtp();
        saveUserProfile(data.user);
        return { success: true, message: data.message || 'ভেরিফিকেশন সফল হয়েছে!', user: data.user, isNewRegistration: true };
      }
    }
  } catch {
    // fallback to local verification
  }

  if (!activeSession) {
    return { success: false, message: 'ওটিপি এর মেয়াদ শেষ হয়ে গেছে। দয়া করে নতুন কোড পাঠান।' };
  }

  if (activeSession.otp !== inputOtp.trim()) {
    return { success: false, message: 'ভুল ওটিপি কোড! অনুগ্রহ করে সঠিক ৬ ডিজিটের কোডটি দিন।' };
  }

  // OTP Matches! Build or update user
  const users = getLocalUsersDb();
  let existing = users.find((u) => u.phone === phoneOrEmail || u.email === phoneOrEmail);
  const isNew = !existing;

  if (!existing) {
    // Create new registered user with strict verified status
    const newId = 'USR_' + Math.random().toString(36).substring(2, 9).toUpperCase();
    const isEmail = (activeSession.tempEmail || phoneOrEmail).includes('@');
    const finalEmail = activeSession.tempEmail || (isEmail ? phoneOrEmail : undefined);
    const finalPhone = activeSession.tempPhone || (!isEmail ? phoneOrEmail : undefined);
    
    const newUser: LocalUserRecord = {
      id: newId,
      name: activeSession.tempName || (isEmail ? (finalEmail || '').split('@')[0] : `প্লেয়ার ${(finalPhone || phoneOrEmail).slice(-4)}`),
      email: finalEmail,
      phone: finalPhone,
      passwordHash: activeSession.tempPassword || 'default_otp_auth',
      provider: isEmail ? 'email' : 'phone',
      linkedProviders: [isEmail ? 'email' : 'phone'],
      isVerified: true,
      createdAt: Date.now(),
      lastLoginAt: Date.now(),
    };
    users.push(newUser);
    saveLocalUsersDb(users);
    existing = newUser;
  } else {
    existing.isVerified = true;
    if (activeSession.tempName) existing.name = activeSession.tempName;
    if (activeSession.tempPassword && activeSession.tempPassword !== 'default_otp_auth') {
      existing.passwordHash = activeSession.tempPassword;
    }
    existing.lastLoginAt = Date.now();
    saveLocalUsersDb(users);
  }

  clearActiveOtp();

  const profile: UserProfile = {
    id: existing.id,
    name: existing.name,
    email: existing.email,
    phone: existing.phone,
    avatarUrl: existing.avatarUrl,
    provider: existing.provider,
    linkedProviders: existing.linkedProviders,
    isVerified: true,
    hasPassword: !!existing.passwordHash && existing.passwordHash !== 'default_otp_auth',
    createdAt: existing.createdAt,
    lastLoginAt: existing.lastLoginAt,
  };

  saveUserProfile(profile);
  return { 
    success: true, 
    message: isNew ? 'অভিনন্দন! আপনার ভেরিফাইড আইডি সফলভাবে তৈরি হয়েছে।' : 'অভিনন্দন! সফলভাবে ওটিপি ভেরিফিকেশন সম্পন্ন হয়েছে।', 
    user: profile,
    isNewRegistration: isNew
  };
};

// Register with Email & Password
export const registerWithEmailPassword = async (
  name: string,
  email: string,
  password: string,
  phone?: string
): Promise<{ success: boolean; message: string; user?: UserProfile }> => {
  const users = getLocalUsersDb();
  const lowerEmail = email.toLowerCase().trim();

  if (users.some((u) => u.email?.toLowerCase() === lowerEmail)) {
    return { success: false, message: 'এই ইমেইল দিয়ে ইতিমধ্যে একটি অ্যাকাউন্ট তৈরি করা আছে।' };
  }

  if (phone && users.some((u) => u.phone === phone.trim())) {
    return { success: false, message: 'এই মোবাইল নাম্বার দিয়ে ইতিমধ্যে একটি অ্যাকাউন্ট আছে।' };
  }

  const newId = 'USR_' + Math.random().toString(36).substring(2, 9).toUpperCase();
  const newUser: LocalUserRecord = {
    id: newId,
    name: name.trim() || 'লুডু মাস্টার',
    email: lowerEmail,
    phone: phone ? phone.trim() : undefined,
    passwordHash: password, // In client mock we store cleanly
    provider: 'email',
    linkedProviders: ['email'],
    isVerified: true,
    createdAt: Date.now(),
    lastLoginAt: Date.now(),
  };

  users.push(newUser);
  saveLocalUsersDb(users);

  const profile: UserProfile = {
    id: newUser.id,
    name: newUser.name,
    email: newUser.email,
    phone: newUser.phone,
    provider: 'email',
    linkedProviders: ['email'],
    isVerified: true,
    hasPassword: true,
    createdAt: newUser.createdAt,
    lastLoginAt: newUser.lastLoginAt,
  };

  saveUserProfile(profile);

  // Send to backend in background
  try {
    await fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, email: lowerEmail, password, phone }),
    });
  } catch {
    // silent
  }

  return {
    success: true,
    message: 'অ্যাকাউন্ট সফলভাবে তৈরি হয়েছে! স্বাগতম লুডু রয়্যালে।',
    user: profile,
  };
};

// Login with Email or Phone & Password
export const loginWithEmailPassword = async (
  emailOrPhone: string,
  password: string
): Promise<{ success: boolean; message: string; user?: UserProfile }> => {
  const users = getLocalUsersDb();
  const target = emailOrPhone.trim().toLowerCase();

  const user = users.find(
    (u) =>
      u.email?.toLowerCase() === target ||
      u.phone?.replace(/[\s-+]/g, '') === target.replace(/[\s-+]/g, '')
  );

  if (!user) {
    return { success: false, message: 'এই ইমেইল বা ফোন নাম্বারে কোনো অ্যাকাউন্ট পাওয়া যায়নি।' };
  }

  if (user.passwordHash !== password) {
    return { success: false, message: 'ভুল পাসওয়ার্ড! অনুগ্রহ করে সঠিক পাসওয়ার্ড দিন।' };
  }

  user.lastLoginAt = Date.now();
  saveLocalUsersDb(users);

  const profile: UserProfile = {
    id: user.id,
    name: user.name,
    email: user.email,
    phone: user.phone,
    avatarUrl: user.avatarUrl,
    provider: user.provider,
    linkedProviders: user.linkedProviders,
    isVerified: user.isVerified,
    hasPassword: true,
    createdAt: user.createdAt,
    lastLoginAt: user.lastLoginAt,
  };

  saveUserProfile(profile);
  return { success: true, message: `স্বাগতম ${user.name}! লগইন সফল হয়েছে।`, user: profile };
};

// Google / Gmail Social Auth
export const loginWithGoogleService = async (
  customName?: string,
  customEmail?: string,
  customAvatarUrl?: string
): Promise<{ success: boolean; message: string; user: UserProfile }> => {
  const email = customEmail || 'joysaker5@gmail.com';
  const name = customName || 'Joy Sarker';
  const avatarUrl = customAvatarUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${name}`;
  const users = getLocalUsersDb();

  let user = users.find((u) => u.email?.toLowerCase() === email.toLowerCase());
  if (!user) {
    user = {
      id: 'GGL_' + Math.random().toString(36).substring(2, 9).toUpperCase(),
      name,
      email,
      passwordHash: 'google_oauth_verified',
      avatarUrl,
      provider: 'google',
      linkedProviders: ['google'],
      isVerified: true,
      createdAt: Date.now(),
      lastLoginAt: Date.now(),
    };
    users.push(user);
  } else {
    if (!user.linkedProviders.includes('google')) {
      user.linkedProviders.push('google');
    }
    user.name = name;
    user.avatarUrl = avatarUrl || user.avatarUrl;
    user.isVerified = true;
    user.lastLoginAt = Date.now();
  }
  saveLocalUsersDb(users);

  const profile: UserProfile = {
    id: user.id,
    name: user.name,
    email: user.email,
    phone: user.phone,
    avatarUrl: user.avatarUrl,
    provider: 'google',
    linkedProviders: user.linkedProviders,
    isVerified: true,
    hasPassword: user.passwordHash !== 'google_oauth_verified',
    createdAt: user.createdAt,
    lastLoginAt: user.lastLoginAt,
  };

  saveUserProfile(profile);
  return { success: true, message: 'গুগল ভেরিফাইড আইডি দিয়ে লগইন সফল হয়েছে!', user: profile };
};

// WhatsApp Social / Phone Direct Auth
export const loginWithWhatsAppService = async (
  phone: string,
  name?: string
): Promise<{ success: boolean; message: string; user: UserProfile }> => {
  const finalPhone = phone || '+8801700000000';
  const finalName = name || `WhatsApp User ${finalPhone.slice(-4)}`;
  const users = getLocalUsersDb();

  let user = users.find((u) => u.phone === finalPhone);
  if (!user) {
    user = {
      id: 'WA_' + Math.random().toString(36).substring(2, 9).toUpperCase(),
      name: finalName,
      phone: finalPhone,
      passwordHash: 'whatsapp_verified',
      avatarUrl: `https://api.dicebear.com/7.x/avataaars/svg?seed=${finalName}`,
      provider: 'phone',
      linkedProviders: ['phone'],
      isVerified: true,
      createdAt: Date.now(),
      lastLoginAt: Date.now(),
    };
    users.push(user);
  } else {
    user.isVerified = true;
    user.lastLoginAt = Date.now();
  }
  saveLocalUsersDb(users);

  const profile: UserProfile = {
    id: user.id,
    name: user.name,
    email: user.email,
    phone: user.phone,
    avatarUrl: user.avatarUrl,
    provider: 'phone',
    linkedProviders: user.linkedProviders,
    isVerified: true,
    hasPassword: false,
    createdAt: user.createdAt,
    lastLoginAt: user.lastLoginAt,
  };

  saveUserProfile(profile);
  return { success: true, message: 'হোয়াটসঅ্যাপ ভেরিফিকেশন দিয়ে সফলভাবে লগইন হয়েছে!', user: profile };
};

// Facebook Social Auth
export const loginWithFacebookService = async (
  customName?: string,
  customEmail?: string,
  customAvatarUrl?: string
): Promise<{ success: boolean; message: string; user: UserProfile }> => {
  const name = customName || 'ফেসবুক ইউজার';
  const email = customEmail || `fb_${Math.random().toString(36).substring(2, 7)}@facebook.com`;
  const avatarUrl = customAvatarUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${name}`;
  const users = getLocalUsersDb();

  let user = users.find((u) => (u.email?.toLowerCase() === email.toLowerCase()) || (u.name === name && u.provider === 'facebook'));

  if (!user) {
    user = {
      id: 'FB_' + Math.random().toString(36).substring(2, 9).toUpperCase(),
      name,
      email,
      passwordHash: 'fb_oauth_verified',
      avatarUrl,
      provider: 'facebook',
      linkedProviders: ['facebook'],
      isVerified: true,
      createdAt: Date.now(),
      lastLoginAt: Date.now(),
    };
    users.push(user);
  } else {
    if (!user.linkedProviders.includes('facebook')) {
      user.linkedProviders.push('facebook');
    }
    user.lastLoginAt = Date.now();
  }
  saveLocalUsersDb(users);

  const profile: UserProfile = {
    id: user.id,
    name: user.name,
    email: user.email,
    avatarUrl: user.avatarUrl,
    provider: 'facebook',
    linkedProviders: user.linkedProviders,
    isVerified: true,
    hasPassword: false,
    createdAt: user.createdAt,
    lastLoginAt: user.lastLoginAt,
  };

  saveUserProfile(profile);
  return { success: true, message: 'ফেসবুক ভেরিফাইড এক্সেস দিয়ে আইডি নিশ্চিত হয়েছে!', user: profile };
};

// Reset Password with Verified OTP
export const resetPasswordWithOtpService = async (
  phoneOrEmail: string,
  otp: string,
  newPassword: string
): Promise<{ success: boolean; message: string; user?: UserProfile }> => {
  const activeSession = getActiveOtp();

  if (!activeSession || activeSession.purpose !== 'forgot_password') {
    // If testing fallback or expired, allow verification if otp is 6 digits
    if (otp.trim().length !== 6) {
      return { success: false, message: 'ওটিপি কোড অবশ্যই ৬ ডিজিট হতে হবে।' };
    }
  } else if (activeSession.otp !== otp.trim()) {
    return { success: false, message: 'ভুল ওটিপি কোড! অনুগ্রহ করে সঠিক কোডটি দিন।' };
  }

  const users = getLocalUsersDb();
  const target = phoneOrEmail.trim().toLowerCase();
  let user = users.find(
    (u) =>
      u.email?.toLowerCase() === target ||
      u.phone?.replace(/[\s-+]/g, '') === target.replace(/[\s-+]/g, '')
  );

  if (!user) {
    // Auto-create user if reset request for new user
    const isEmail = target.includes('@');
    user = {
      id: 'USR_' + Math.random().toString(36).substring(2, 9).toUpperCase(),
      name: isEmail ? target.split('@')[0] : `ইউজার ${target.slice(-4)}`,
      email: isEmail ? target : undefined,
      phone: !isEmail ? target : undefined,
      passwordHash: newPassword,
      provider: isEmail ? 'email' : 'phone',
      linkedProviders: [isEmail ? 'email' : 'phone'],
      isVerified: true,
      createdAt: Date.now(),
      lastLoginAt: Date.now(),
    };
    users.push(user);
  } else {
    user.passwordHash = newPassword;
    user.lastLoginAt = Date.now();
  }

  saveLocalUsersDb(users);
  clearActiveOtp();

  const profile: UserProfile = {
    id: user.id,
    name: user.name,
    email: user.email,
    phone: user.phone,
    avatarUrl: user.avatarUrl,
    provider: user.provider,
    linkedProviders: user.linkedProviders,
    isVerified: true,
    hasPassword: true,
    createdAt: user.createdAt,
    lastLoginAt: user.lastLoginAt,
  };

  saveUserProfile(profile);
  return { success: true, message: 'পাসওয়ার্ড সফলভাবে পরিবর্তন করা হয়েছে! আপনি এখন লগইন আছেন।', user: profile };
};

// Change Password for Logged In User
export const changeUserPasswordService = (
  userId: string,
  oldPassword: string,
  newPassword: string
): { success: boolean; message: string } => {
  const users = getLocalUsersDb();
  const user = users.find((u) => u.id === userId);

  if (!user) {
    return { success: false, message: 'ব্যবহারকারী খুঁজে পাওয়া যায়নি।' };
  }

  if (user.passwordHash && user.passwordHash !== 'default_otp_auth' && user.passwordHash !== 'google_oauth_verified' && user.passwordHash !== 'fb_oauth_verified') {
    if (user.passwordHash !== oldPassword) {
      return { success: false, message: 'বর্তমান পাসওয়ার্ডটি সঠিক নয়!' };
    }
  }

  user.passwordHash = newPassword;
  saveLocalUsersDb(users);

  // Update profile
  const profile = loadUserProfile();
  if (profile.id === userId) {
    profile.hasPassword = true;
    saveUserProfile(profile);
  }

  return { success: true, message: 'আপনার অ্যাকাউন্টের পাসওয়ার্ড সফলভাবে আপডেট হয়েছে।' };
};

// Logout User -> revert to guest
export const logoutUserService = (): UserProfile => {
  clearActiveOtp();
  const guest = createDefaultGuestProfile();
  saveUserProfile(guest);
  return guest;
};
