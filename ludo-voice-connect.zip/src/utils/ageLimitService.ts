import { AgeCategory, AgeVerificationConfig, UserProfile } from '../types';

const STORAGE_AGE_KEY_PREFIX = 'joy_ludo_age_config_';
const STORAGE_SCREEN_TIME_PREFIX = 'joy_ludo_screen_time_';

export const AGE_THRESHOLDS = {
  KIDS_MAX: 12,
  TEEN_MIN: 13,
  TEEN_MAX: 17,
  ADULT_MIN: 18,
};

// Calculate age from birth date string (YYYY-MM-DD)
export const calculateAgeFromDOB = (birthDateStr: string): number => {
  if (!birthDateStr) return 18;
  const birth = new Date(birthDateStr);
  if (isNaN(birth.getTime())) return 18;
  const now = new Date();
  let age = now.getFullYear() - birth.getFullYear();
  const m = now.getMonth() - birth.getMonth();
  if (m < 0 || (m === 0 && now.getDate() < birth.getDate())) {
    age--;
  }
  return Math.max(1, Math.min(120, age));
};

// Categorize age
export const getAgeCategory = (age: number): AgeCategory => {
  if (age < 13) return 'under_13';
  if (age <= 17) return 'teen_13_17';
  return 'adult_18_plus';
};

// Get default configuration based on age
export const buildDefaultAgeConfig = (age: number, birthDate?: string): AgeVerificationConfig => {
  const category = getAgeCategory(age);
  const isUnder13 = category === 'under_13';

  return {
    isAgeVerified: true,
    age,
    birthDate: birthDate || '',
    ageCategory: category,
    childSafeMode: isUnder13,
    dailyScreenTimeLimitMinutes: isUnder13 ? 60 : 0, // 0 = unlimited
    hasParentalPin: false,
    parentalPin: '',
    verifiedAt: Date.now(),
    voiceChatAllowed: !isUnder13,
    textChatAllowed: true,
  };
};

// Load age configuration for a user
export const loadUserAgeConfig = (user: UserProfile): AgeVerificationConfig => {
  try {
    const key = STORAGE_AGE_KEY_PREFIX + (user?.id || 'guest');
    const raw = localStorage.getItem(key);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && typeof parsed.age === 'number') {
        return parsed;
      }
    }
  } catch (err) {
    console.error('Error loading age config:', err);
  }

  // If user profile has age data
  if (user && user.age) {
    const config = buildDefaultAgeConfig(user.age, user.birthDate);
    saveUserAgeConfig(user.id, config);
    return config;
  }

  // Default unverified/standard state (default to 18+ for adult players unless set)
  return {
    isAgeVerified: false,
    age: 18,
    birthDate: '',
    ageCategory: 'adult_18_plus',
    childSafeMode: false,
    dailyScreenTimeLimitMinutes: 0,
    hasParentalPin: false,
    parentalPin: '',
    voiceChatAllowed: true,
    textChatAllowed: true,
  };
};

// Save age configuration for a user
export const saveUserAgeConfig = (userId: string, config: AgeVerificationConfig): void => {
  try {
    const key = STORAGE_AGE_KEY_PREFIX + (userId || 'guest');
    localStorage.setItem(key, JSON.stringify(config));
  } catch (err) {
    console.error('Error saving age config:', err);
  }
};

// Track and get screen time in minutes for today
export const getTodayScreenTimeMinutes = (userId: string): number => {
  try {
    const todayStr = new Date().toISOString().slice(0, 10);
    const key = `${STORAGE_SCREEN_TIME_PREFIX}${userId || 'guest'}_${todayStr}`;
    const raw = localStorage.getItem(key);
    return raw ? parseInt(raw, 10) || 0 : 0;
  } catch {
    return 0;
  }
};

// Increment screen time
export const addScreenTimeMinutes = (userId: string, minutesToAdd: number = 1): number => {
  try {
    const todayStr = new Date().toISOString().slice(0, 10);
    const key = `${STORAGE_SCREEN_TIME_PREFIX}${userId || 'guest'}_${todayStr}`;
    const current = getTodayScreenTimeMinutes(userId);
    const updated = current + minutesToAdd;
    localStorage.setItem(key, updated.toString());
    return updated;
  } catch {
    return 0;
  }
};

// Check if daily screen time is exceeded
export const isScreenTimeLimitExceeded = (
  userId: string,
  limitMinutes: number
): { exceeded: boolean; usedMinutes: number; limitMinutes: number } => {
  if (!limitMinutes || limitMinutes <= 0) {
    return { exceeded: false, usedMinutes: 0, limitMinutes: 0 };
  }
  const used = getTodayScreenTimeMinutes(userId);
  return {
    exceeded: used >= limitMinutes,
    usedMinutes: used,
    limitMinutes,
  };
};

// Age Info & Guidelines in Bangla
export const AGE_CATEGORY_DETAILS = {
  under_13: {
    titleBn: '১৩ বছরের নিচে (কিডস ও চাইল্ড-সেফ মোড)',
    badgeBn: '🧒 কিড-সেফ জোন',
    color: 'emerald',
    descriptionBn: 'শিশুদের সুরক্ষার জন্য উন্মুক্ত ভয়েস চ্যাট বন্ধ থাকবে, ফিল্টার্ড নিরাপদ চ্যাট ও দৈনিক স্ক্রিন টাইম লিমিট সক্রিয় থাকবে।',
    safetyPoints: [
      'উন্মুক্ত মাইক্রোফোন ও লাইভ ভয়েস স্টেজ বন্ধ থাকবে',
      'অশ্লীল ও অনুপযুক্ত মেসেজ স্বয়ংক্রিয়ভাবে ফিল্টার হবে',
      'দৈনিক স্ক্রিন টাইম লিমিট (অভিভাবকীয় রিমাইন্ডার)',
      'অভিভাবকীয় পিন (Parental PIN) দিয়ে সেটিংস সুরক্ষিত রাখা যাবে',
    ],
  },
  teen_13_17: {
    titleBn: '১৩ - ১৭ বছর (টিন মোড)',
    badgeBn: '🛡️ টিন প্রটেক্টেড',
    color: 'amber',
    descriptionBn: 'কিশোর-কিশোরীদের জন্য নিরাপদ সোশ্যাল পরিবেশ, পরিমিত স্ক্রিন টাইম রিমাইন্ডার এবং সুরক্ষিত চ্যাট।',
    safetyPoints: [
      'নিরাপদ ফ্রেন্ডলি ভয়েস চ্যাট ও আড্ডা',
      'ডিজিটাল ওয়েলবিয়িং ও স্ক্রিন টাইম ব্রেক রিমাইন্ডার',
      'কমিউনিটি নির্দেশিকা ও প্লেয়ার সেফটি গাইডলাইন',
    ],
  },
  adult_18_plus: {
    titleBn: '১৮+ বছর (ফুল এক্সেস মোড)',
    badgeBn: '👑 ১৮+ আনরেস্ট্রিক্টেড',
    color: 'purple',
    descriptionBn: 'প্রাপ্তবয়স্কদের জন্য সম্পূর্ণ উন্মুক্ত লাইভ ভয়েস স্টেজ, টুর্নামেন্ট ও ১০ জনের আড্ডা বোর্ড।',
    safetyPoints: [
      'সকল লাইভ ভয়েস রুম ও ১০ জনের আড্ডা বোর্ডে ফুল এক্সেস',
      'কয়েন ও ডায়মন্ডস ম্যাচ, টুর্নামেন্ট ও টিম প্লে',
      'কোনো স্ক্রিন টাইম লিমিট বা নিষেধাজ্ঞা নেই',
    ],
  },
};
